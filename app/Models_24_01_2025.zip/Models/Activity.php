<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Activity extends Model
{
    use HasFactory;

    protected $table ='activities';

    public function activityData()
    {
        return $this->belongsTo(EntryProcessModel::class, 'project_id');
    }
    

    public function createdByUser()
    {
        return $this->belongsTo(User::class, 'created_by', 'id');
    }

    // Relationship to ActivityReplies (Activity has many replies)
    public function replies()
    {
        return $this->hasMany(ActivityReplies::class, 'activity_id', 'id')
        ->where('is_read', 0)
        ->with(['createdByUser']);
    }
}
