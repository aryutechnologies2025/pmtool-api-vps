<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProjectStatus extends Model
{
    use HasFactory;
    protected $table = 'project_status';

    public function writer()
    {
        return $this->hasOne(User::class, 'id', 'writer_id')
        ->with('createdByUser');
    }

    public function reviewer()
    {
        return $this->hasOne(User::class, 'id', 'reviewer_id')->with('createdByUser');
    }

    public function journal()
    {
        return $this->hasOne(User::class, 'id', 'journal_id')->with('createdByUser'); 
    }

    public function statistican()
    {
        return $this->hasOne(User::class, 'id', 'statistican_id')->with('createdByUser');
    }

}
