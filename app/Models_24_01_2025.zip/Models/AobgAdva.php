<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AobgAdva extends Model
{
    use HasFactory;

    protected $table = 'aobg_adva'; // Replace with your actual table name
    protected $fillable = [
        'Agent',
        'submission_date',
        'policy_status',
        'Eff_Date',
        'issuer',
        'state',
        'ffm_app_id',
        'first_name',
        'last_name',
        'PMPM',
        'Advance',
        'Members',
        'Advance_Excluded_Reason',
        'Post_Date',
        'Period',
        'FFM_Subscriber_ID',
    ];
}
