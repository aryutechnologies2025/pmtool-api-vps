<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EntryProcessModel extends Model
{
    use HasFactory;
    protected $table = 'entry_processes';
    
    public function institute()
    {
        return $this->belongsTo(InstitutionModel::class, 'institute', 'id');
    }

    public function department()
    {
        return $this->belongsTo(DepartmentModel::class, 'department', 'id');
    }

    public function profession()
    {
        return $this->belongsTo(ProfessionModel::class, 'profession', 'id');
    }

    public static function generateCustomId(string $typeOfWork): string
    {
        $lastEntry = self::where('type_of_work', $typeOfWork)
            ->orderBy('id', 'desc')
            ->first();

        $increment = $lastEntry
            ? (int)substr($lastEntry->project_id, strlen($typeOfWork) + 1) + 1
            : 1;

        $formattedIncrement = str_pad($increment, 3, '0', STR_PAD_LEFT);

        return $typeOfWork . '-' . $formattedIncrement;
    }
    public function documents()
    {
        return $this->hasMany(EntryDocument::class, 'entry_process_model_id')
        ->where('is_deleted', 0)
        ->with('createdByUser');
    }

    public function pendingStatusModel()
    {
        return $this->hasOne(PendingStatusModel::class, 'project_id', 'project_id');
    }

    public function paymentProcess()
    {
        return $this->belongsTo(PaymentStatusModel::class, 'id', 'project_id')->with(['paymentData','paymentLog']);
    }

    public function rejectReason()
    {
        return $this->hasMany(RejectReason::class, 'project_id')
        ->with('createdByUser')
        ->orderBy('id', 'desc');
    }


    public function activityData()
    {
        return $this->hasMany(Activity::class, 'project_id')
        ->with('createdByUser')
        ->orderBy('id', 'desc');
    }

    public function userData()
    {
        return $this->hasOne(User::class, 'id', 'assign_by')
        ->with('createdByUser');
    }

    public function writerData()
    {
        return $this->hasOne(User::class, 'id', 'writer')->with('createdByUser');
    }

    public function reviewerData()
    {
        return $this->hasOne(User::class, 'id', 'reviewer')->with('createdByUser');
    }

    public function journalData()
    {
        return $this->hasOne(User::class, 'id', 'journal')->with('createdByUser');
    }

    public function statisticanData()
    {
        return $this->hasOne(User::class, 'id', 'statistican')->with('createdByUser');
    }

    public function writer()
    {
        return $this->hasOne(User::class, 'id', 'writer');
    }

    public function reviewer()
    {
        return $this->hasOne(User::class, 'id', 'reviewer');
    }

    public function journal()
    {
        return $this->hasOne(User::class, 'id', 'journal');
    }

    public function statistican()
    {
        return $this->hasOne(User::class, 'id', 'statistican');
    }

    public function projectStatus()
    {
        return $this->hasOne(ProjectStatus::class, 'project_id', 'id')
        ->with(['writer','reviewer','journal','statistican']);
    }
    
}
