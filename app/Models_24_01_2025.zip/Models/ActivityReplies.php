<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ActivityReplies extends Model
{
    use HasFactory;

    protected $table='activity_replies';

    // Relationship to Activity
    public function activity()
    {
        return $this->belongsTo(Activity::class, 'activity_id');
    }

    public function createdByUser()
    {
        return $this->belongsTo(User::class, 'created_by', 'id')
        ->with(['createdByUser']);
    }
}
