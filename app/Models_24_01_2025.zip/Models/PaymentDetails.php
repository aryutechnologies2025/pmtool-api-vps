<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PaymentDetails extends Model
{
    use HasFactory;

    protected $guarded = [];


    protected $table = 'payment_details';

    public function paymentProcess()
    {
        return $this->belongsTo(PaymentStatusModel::class, 'payment_id', 'id');
    }
}
