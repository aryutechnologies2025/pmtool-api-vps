<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EntryDocument extends Model
{
    protected $fillable = [
        'entry_process_model_id',
        'select_document',
        'file',
        'created_by'
    ];
    public function entryProcessModel()
    {
        return $this->belongsTo(EntryProcessModel::class, 'entry_process_model_id');
    }

    public function createdByUser()
    {
        return $this->belongsTo(User::class, 'created_by', 'id');
    }
}
