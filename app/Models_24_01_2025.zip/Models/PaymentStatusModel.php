<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\PaymentDetails;
use App\Models\EntryProcessModel;



class PaymentStatusModel extends Model
{
    use HasFactory;
    protected $table = 'payment_processes';

    public function paymentData()
    {
        return $this->hasMany(PaymentDetails::class, 'payment_id', 'id')
            ->where('is_deleted', 0); // Fetch non-deleted payment details
    }

    public function paymentLog()
    {
        return $this->hasMany(PaymentLogs::class, 'payment_id', 'id');
    }

    public function projectData()
    {
        return $this->hasOne(EntryProcessModel::class, 'id', 'project_id')
            ->with(['writer', 'reviewer', 'journal', 'statistican']);
    }

    public function writerId()
    {
        return $this->hasOne(User::class, 'id', 'writer_id');
    }

    public function reviewerID()
    {
        return $this->hasOne(User::class, 'id', 'reviewer_id');
    }

    public function journalId()
    {
        return $this->hasOne(User::class, 'id', 'journal_id');
    }

    public function statisticanID()
    {
        return $this->hasOne(User::class, 'id', 'statistican_id');
    }
}
