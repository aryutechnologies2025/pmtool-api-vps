<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProjectLogs extends Model
{
    use HasFactory;

    protected $table='projectlogs';

    protected $fillable = [
        'project_id',  
        'employee_id',
        'assigned_date',
        'status',
        'status_date',
        'status_type',
        'created_by',
        'created_date'
    ];
}
