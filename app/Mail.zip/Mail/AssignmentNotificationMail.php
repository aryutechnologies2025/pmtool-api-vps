<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class AssignmentNotificationMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     */
    public $details;

    public function __construct(array $details)
    {
        $this->details = $details;
    }
 
    public function build()
    {
        return $this->subject('Project Assignment Notification')
            ->view('emails.assignmentNotification')
            ->with('details', $this->details);
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Task Notification Mail',
        );
    }

    /**
     * Get the message content definition.
     */
    // public function content(): Content
    // {
    //     return new Content(
    //         view: 'view.name',
    //     );
    // }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
// public function getClientNotification(Request $request, $id)
//     {
//         $projectDetails = EntryProcessModel::find($id);


//         if ($projectDetails) {
//             if (!empty($projectDetails->email)) {
//                 try {
//                     Mail::to($projectDetails->email)->send(new ClientEmail([
//                         'client_name' => $projectDetails->client_name,
//                         'type_of_work' => $projectDetails->type_of_work,
//                         'project_id' => $projectDetails->project_id,
//                         'project_title' => $projectDetails->title,
//                         'project_status' => $projectDetails->project_status,
//                         'contact_number' => $projectDetails->contact_number
//                     ]));

//                     return response()->json(['success' => true, 'message' => 'Email sent successfully.']);
//                 } catch (\Exception $e) {
//                     // Log the error
//                     Log::error('Mail failed: ' . $e->getMessage());

//                     return response()->json(['success' => false, 'message' => 'Failed to send email.']);
//                 }
//             } else {
//                 Log::error('Client email is empty or invalid');
//                 return response()->json(['success' => false, 'message' => 'Client email is empty or invalid.']);
//             }
//         } else {
//             Log::error('Project not found');
//             return response()->json(['success' => false, 'message' => 'Project not found.']);
//         }
//     }