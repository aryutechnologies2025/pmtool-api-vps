export const Capitalize = (status) => {
    if (typeof status !== 'string') {
      return ''; // Return an empty string or handle the error as needed
    }
    return status
      .replace(/_/g, ' ') // Replace underscores with spaces
      .replace(/\b\w/g, (char) => char.toUpperCase()); // Capitalize first letter of each word
  };
  