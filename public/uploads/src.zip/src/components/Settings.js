import "../assests/css/setting.css";
import Sider from "./Sider";
import Vector from "../assests/images/Vector.svg";
// import { PencilSquare } from "react-bootstrap-icons";
import { FaPencilAlt } from "react-icons/fa";
import { Link } from "react-router-dom";
import Settingpic from "../assests/images/setting.png";
import { API_URL } from "../config.js";

import React, { useState, useEffect } from "react";
import Header from "./Header";
import Breadcrumbs from "../routes/Breadcrumbs";
import Footer from "../components/Footer";
import axios from "axios";
import Loader from "../components/Loader.js";
import Swal from "sweetalert2";

function Settings() {
  const [favImage, setFavImage] = useState(null);
  const [favFile, setFavFile] = useState(null);

  const [logoImage, setLogoImage] = useState(null);
  const [logoFile, setLogoFile] = useState(null);
  const [siteTitle, setSiteTitle] = useState("");
  const [siteDescription, setSiteDescription] = useState("");
  const [adminEmail, setAdminEmail] = useState("");
  const [ccMail, setCcMail] = useState("");
  const [contactNo, setContactNo] = useState("");
  const [project_target, setProjectTarget] = useState("");

  const [companyName, setCompanyName] = useState("");
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNo, setPhoneNo] = useState("");
  const [signature, setSignature] = useState(null);

  // Bank Information states
  const [bankName, setBankName] = useState("");
  const [accountNo, setAccountNo] = useState("");
  const [ifscCode, setIfscCode] = useState("");
  const [branchName, setBranchName] = useState("");

  const handleFavChange = (event, setImage, setFile) => {
    const file = event.target.files[0];
    if (file) {
      setImage(URL.createObjectURL(file)); // Set preview
      setFile(file); // Store file for form submission
    }
  };

  const handleImageChange = (event, setImage, setFile) => {
    const file = event.target.files[0];
    if (file) {
      setImage(URL.createObjectURL(file)); // Set preview
      setFile(file); // Store file for form submission
    }
  };

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await axios.get(`${API_URL}/api/setting-list`);

        const savedData = response.data.data; // Assuming 'data' is returned from the API

        // Set the values in state
        setFavImage(
          savedData.fav_icon
            ? `${API_URL}/uploads/settings/${savedData.fav_icon}`
            : Settingpic
        );
        setLogoImage(
          savedData.logo_image
            ? `${API_URL}/uploads/settings/${savedData.logo_image}`
            : Settingpic
        );
        setSiteTitle(savedData.site_title);
        setSiteDescription(savedData.site_description);
        setAdminEmail(savedData.admin_email);
        setCcMail(savedData.cc_mail);
        setContactNo(savedData.contact_no);
        setProjectTarget(savedData.project_target);
        setCompanyName(savedData.company_name);
        setName(savedData.name);
        setAddress(savedData.address);
        setEmail(savedData.email);
        setPhoneNo(savedData.phone_number);
        setSignature(savedData.sign_image);
        setBankName(savedData.bank_name);
        setAccountNo(savedData.account_number);
        setIfscCode(savedData.ifsc);
        setBranchName(savedData.branch_name);

      } catch (error) {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: "An error occurred while updating the settings.",
        });
      }
    };

    fetchSettings();
  }, []); // Empty dependency array to run only once when the component mounts

  const handleSubmit = async (e) => {
    e.preventDefault();
    document.getElementById("global-loader").style.display = "flex";
    
    const formData = new FormData();
    formData.append("site_title", siteTitle);
    formData.append("site_description", siteDescription);
    formData.append("admin_email", adminEmail);
    formData.append("cc_mail", ccMail);
    formData.append("contact_no", contactNo);
    formData.append("project_target", project_target);
    formData.append("company_name", companyName);
    formData.append("name", name);
    formData.append("address", address);
    formData.append("email", email);
    formData.append("phone_number", phoneNo);
    formData.append("sign_image", signature);
    formData.append("bank_name", bankName);
    formData.append("account_number", accountNo);
    formData.append("ifsc", ifscCode);
    formData.append("branch_name", branchName);

    if (favFile) {
      formData.append("fav_icon", favFile);
    }
    if (logoFile) {
      formData.append("logo_image", logoFile);
    }

    try {
      const response = await axios.post(`${API_URL}/api/setting`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      const savedData = response.data.data;
      setFavImage(
        savedData.fav_icon
          ? `${API_URL}/uploads/settings/${savedData.fav_icon}`
          : null
      );
      setLogoImage(
        savedData.logo_image
          ? `${API_URL}/uploads/settings/${savedData.logo_image}`
          : null
      );
      setSiteTitle(savedData.site_title);
      setSiteDescription(savedData.site_description);
      setAdminEmail(savedData.admin_email);
      setCcMail(savedData.cc_mail);
      setContactNo(savedData.contact_no);
      setProjectTarget(savedData.project_target);
      setCompanyName(savedData.company_name);
      setName(savedData.name);
      setAddress(savedData.address);
      setEmail(savedData.email);
      setPhoneNo(savedData.phone_number);
      setSignature(savedData.sign_image);
      setBankName(savedData.bank_name);
      setAccountNo(savedData.account_number);
      setIfscCode(savedData.ifsc);
      setBranchName(savedData.branch_name);

      Swal.fire({
        icon: "success",
        title: "Settings updated successfully!",
        showConfirmButton: true,
        confirmButtonText: "OK",
        timer: 1500,
      });
    } catch (error) {
      console.error("Error saving settings:", error);
    }finally {
      document.getElementById("global-loader").style.display = "none";
    }
  };

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }
  return (
    <>
      <section className="container d-flex flex-column min-vh-100 justify-content-between">
        <div className="row mt-4 w-100 ">
          {/* <div className="col-1 d-flex justify-content-center">
            <Sider />
          </div> */}
          <div className="col-12  ">
            <div className="col-12">
              <Header></Header>
            </div>
            <div className="col-12 pt-1 wapper w-100 mt-3 ">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className="col-12 col-md-9  px-4 ">
                  <p className="heading-entr">Settings</p>
                </div>
                <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>

              <form className="p-3" onSubmit={handleSubmit}>
                <div className="row  mt-2">
                  <div className="col-2 mx-3 d-flex d-md-block">
                    <label htmlFor="site-title" className="site-name mx-2">
                      Fav Icons
                    </label>
                    <div className="col-md-12 profile-container position-relative d-inline d-flex justify-content-center">
                      <img
                        src={favImage || Settingpic}
                        alt="Profile"
                        className="profile-image rounded-circle"
                      />
                      <input
                        type="file"
                        accept="image/*"
                        id="favImageInput"
                        className="file-input"
                        onChange={(e) =>
                          handleFavChange(e, setFavImage, setFavFile)
                        } // Pass both functions
                      />
                      <label htmlFor="favImageInput" className="edit-icon1">
                        <FaPencilAlt className="pencil-icon-size" />
                      </label>
                    </div>
                    <label htmlFor="site-title" className="site-name">
                      Site Logo
                    </label>
                    <div className="col-md-12 ms-4 ms-md-0 profile-container position-relative d-inline d-flex justify-content-center">
                      <img
                        src={logoImage}
                        alt="Cover"
                        className="profile-image rounded-circle"
                      />
                      <input
                        type="file"
                        accept="image/*"
                        id="logoImageInput"
                        className="file-input"
                        onChange={(e) =>
                          handleImageChange(e, setLogoImage, setLogoFile)
                        } // Pass both functions
                      />
                      <label htmlFor="logoImageInput" className="edit-icon1">
                        <FaPencilAlt className="pencil-icon-size" />
                      </label>
                    </div>
                  </div>

                  <div className="col-md-9 mt-2 mt-md-0">
                    <div className="row mt-0 w-100 ">
                      <div className="col-md-6 float-start ">
                        <label htmlFor="site-title" className="site-name mx-2">
                          Site Title
                        </label>
                        <input
                          type="text"
                          id="site-title"
                          value={siteTitle}
                          autoComplete="off"
                          onChange={(e) => setSiteTitle(e.target.value)}
                          className="setting-input"
                          placeholder="Enter Title"
                        />
                      </div>
                      <div className="col-md-6 float-start ">
                        <label
                          htmlFor="site-description"
                          className="site-name mx-2"
                        >
                          Site Description
                        </label>
                        <input
                          type="text"
                          id="site-description"
                          className="setting-input"
                          placeholder="Enter Description"
                          value={siteDescription}
                          onChange={(e) => setSiteDescription(e.target.value)}
                          autoComplete="off"
                        />
                      </div>

                      <div className="col-md-6 float-start pt-3">
                        <label htmlFor="set-admin" className="site-name mx-2">
                          Admin Email
                        </label>
                        <input
                          type="email"
                          id="set-admin"
                          className="setting-input"
                          placeholder="Enter Gmail"
                          value={adminEmail}
                          onChange={(e) => setAdminEmail(e.target.value)}
                          autoComplete="off"
                        />
                      </div>
                      <div className="col-md-6 float-start pt-3">
                        <label htmlFor="set-mail" className="site-name mx-2">
                          Cc Mail
                        </label>
                        <input
                          type="email"
                          id="set-mail"
                          className="setting-input"
                          placeholder="Enter Mail"
                          value={ccMail}
                          onChange={(e) => setCcMail(e.target.value)}
                          autoComplete="off"
                        />
                      </div>

                      <div className="col-md-6 float-start pt-3">
                        <label htmlFor="set-contact" className="site-name mx-2">
                          Contact No
                        </label>
                        <input
                          type="number"
                          id="set-contact"
                          className="setting-input"
                          placeholder="Enter Contact"
                          value={contactNo}
                          onChange={(e) => setContactNo(e.target.value)}
                          autoComplete="off"
                        />
                      </div>

                      <div className="col-md-6 float-start pt-3">
                        <label htmlFor="set-contact" className="site-name mx-2">
                          Project Target
                        </label>
                        <input
                          type="number"
                          id="set-contact"
                          className="setting-input"
                          placeholder="Enter target"
                          value={project_target}
                          onChange={(e) => setProjectTarget(e.target.value)}
                          autoComplete="off"
                        />
                      </div>

                      {/* invoice */}

                      <div className="col-12 col-md-9  px-3 mt-3 ">
                        <div className="heading-entr">Invoice Information</div>
                      </div>
                      <div className="col-md-6 float-start">
                        <label htmlFor="company" className="site-name mx-2">
                          Company Name
                        </label>
                        <input
                          type="text"
                          id="company"
                          className="setting-input"
                          placeholder="Enter Company Name"
                          value={companyName}
                          onChange={(e) => setCompanyName(e.target.value)}
                          autoComplete="off"
                        />
                      </div>

                      <div className="col-md-6 float-start">
                        <label
                          htmlFor="Name-inovice"
                          className="site-name mx-2"
                        >
                          Name
                        </label>
                        <input
                          type="text"
                          id="Name-inovice"
                          className="setting-input"
                          placeholder="Enter Name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          autoComplete="off"
                        />
                      </div>

                      <div className="col-md-6 float-start pt-3">
                        <label
                          htmlFor="address-invoice"
                          className="site-name mx-2"
                        >
                          Address
                        </label>
                        <input
                          type="text" // Changed from email to text since address isn't an email
                          id="address-invoice"
                          className="setting-input"
                          placeholder="Enter Address"
                          value={address}
                          onChange={(e) => setAddress(e.target.value)}
                          autoComplete="off"
                        />
                      </div>

                      <div className="col-md-6 float-start pt-3">
                        <label htmlFor="ino-mail" className="site-name mx-2">
                          Email
                        </label>
                        <input
                          type="email"
                          id="ino-mail"
                          className="setting-input"
                          placeholder="Enter Email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          autoComplete="off"
                        />
                      </div>

                      <div className="col-md-6 float-start pt-3">
                        <label htmlFor="ino-contact" className="site-name mx-2">
                          Phone No
                        </label>
                        <input
                          type="number"
                          id="ino-contact"
                          className="setting-input"
                          placeholder="Enter Contact"
                          value={phoneNo}
                          onChange={(e) => setPhoneNo(e.target.value)}
                          autoComplete="off"
                        />
                      </div>

                      <div className="col-md-6 float-start pt-3">
                        <label
                          htmlFor="ino-signature"
                          className="site-name mx-2"
                        >
                          Signature
                        </label>
                        <input
                          type="file"
                          id="ino-signature"
                          className="form-control pt-2 p-3"
                          onChange={(e) => setSignature(e.target.files[0])}
                        />
                      </div>

                      {/* Bank Information */}
                      <div className="col-12 col-md-9 px-3 mt-3">
                        <div className="heading-entr">Bank Information</div>
                      </div>

                      <div className="col-md-6 float-start">
                        <label htmlFor="bank-name" className="site-name mx-2">
                          Bank Name
                        </label>
                        <input
                          type="text"
                          id="bank-name"
                          className="setting-input"
                          placeholder="Enter Bank Name"
                          value={bankName}
                          onChange={(e) => setBankName(e.target.value)}
                          autoComplete="off"
                        />
                      </div>

                      <div className="col-md-6 float-start">
                        <label htmlFor="ac-no" className="site-name mx-2">
                          A/C No
                        </label>
                        <input
                          type="text"
                          id="ac-no"
                          className="setting-input"
                          placeholder="Enter A/C No"
                          value={accountNo}
                          onChange={(e) => setAccountNo(e.target.value)}
                          autoComplete="off"
                        />
                      </div>

                      <div className="col-md-6 float-start pt-3">
                        <label htmlFor="ifsc" className="site-name mx-2">
                          IFSC Code
                        </label>
                        <input
                          type="text" // Changed from email to text
                          id="ifsc"
                          className="setting-input"
                          placeholder="Enter IFSC Code"
                          value={ifscCode}
                          onChange={(e) => setIfscCode(e.target.value)}
                          autoComplete="off"
                        />
                      </div>

                      <div className="col-md-6 float-start pt-3">
                        <label htmlFor="branch-name" className="site-name mx-2">
                          Branch Name
                        </label>
                        <input
                          type="text" // Changed from email to text
                          id="branch-name"
                          className="setting-input"
                          placeholder="Enter Branch Name"
                          value={branchName}
                          onChange={(e) => setBranchName(e.target.value)}
                          autoComplete="off"
                        />
                      </div>
                      <div className="col-md-12 text-end  mt-4">
                        <button
                          type="submit"
                          className="save-form-setting mx-2"
                        >
                          SAVE
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div>
          <Footer />
        </div>
      </section>
    </>
  );
}

export default Settings;
