import React from "react";
import "../assests/css/entryprocess.css";
import { API_URL } from "../config.js";
import { IoIosSearch } from "react-icons/io";
// import { IoFilter } from "react-icons/io5";
import { IoMdAdd } from "react-icons/io";
import { VscGitStashPop } from "react-icons/vsc";
import { VscEye } from "react-icons/vsc";
import { NavLink } from "react-router-dom";
import { useState, useEffect } from "react";
// import { MdKeyboardArrowDown } from "react-icons/md";
import axios from "axios";
// import axios from '../api/axiosConfig.js';

import Sider from "./Sider";
import { FaBookReader } from "react-icons/fa";
import Swal from "sweetalert2";

import DatePicker from "react-datepicker";
import Breadcrumbs from "../routes/Breadcrumbs";

import "react-datepicker/dist/react-datepicker.css";
import Header from "./Header";

import ReactDOM from "react-dom";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { TfiPencilAlt } from "react-icons/tfi";
import { RiDeleteBin6Line } from "react-icons/ri";
import { TbClockExclamation } from "react-icons/tb";
import { Capitalize } from "../campsCase.js";
import { CapitalizeCase } from "../capsUnderCase.js";

import Tooltip from "@mui/material/Tooltip";
import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";
import { getDateFormate } from "../dateFormate.js";
import { saveAs } from "file-saver";
import Papa from "papaparse";
import { LuBadgeDollarSign } from "react-icons/lu";
import { useLocation } from "react-router-dom";

DataTable.use(DT);
function EntryProjectView() {
  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const location = useLocation();
  const { count_type } = location.state || {};

  const [data, setData] = useState([]);
  const [startDate, setStartDate] = useState(""); // Start date filter
  const [endDate, setEndDate] = useState(""); // End date filter
  const [showData, setShowData] = useState({});
  const [selectedId, setSelectedId] = useState(null);
  const [filteredData, setFilteredData] = useState([]);

  console.log("filterdata:",filteredData)
  const [typeofwork, setTypeOfWork] = useState([]);
  // const [filtertypeofwork, getTypeOfwork] = useState("all");

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;
  const employee_name = parsedDetails ? parsedDetails.employee_name : null;
  const positionData = parsedDetails ? parsedDetails.position : null;
  const [filtertypeofwork, getTypeOfwork] = useState("all");

  const [formData, setFormData] = useState({});

  const fetchData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/project-emp-list`,
        {
          params: {
            start_date: startDate,
            end_date: endDate,
            count_type: count_type,
            createdby: createdby,
            position: positionData,
            type_of_work: filtertypeofwork,

          },
        }
      );

      setData(response.data.details);
      setFilteredData(response.data.details);
      setTypeOfWork(response.data.typeofwork);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // const handleChange = (event) => {
  //     const selectedValue = event.target.value;
  //     getTypeOfwork(selectedValue);
  // };

  //exprt
  const exportToCSV = () => {
    // Define custom headers and map them to data fields
    const headers = [
      {
        label: "Project Title",
        value: "title",
        render: (data) => Capitalize(data),
      },
      {
        label: "Project Id",
        value: "project_id",
        render: (data) => Capitalize(data),
      },
      {
        label: "Type of Work",
        value: "type_of_work",
        render: (data) => Capitalize(data),
      },
      {
        label: "Entry Date",
        value: "entry_date",
        render: (data) => data, // No transformation needed for entry_date
      },
    ];

    // Prepare data with headers, ensure proper field transformation
    const csv = Papa.unparse({
      fields: headers.map((header) => header.label), // Use labels as headers
      data: filteredData.map((row) =>
        headers.map((header) =>
          header.render ? header.render(row[header.value]) : row[header.value]
        )
      ),
    });

    // Create a Blob from the CSV string
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });

    // Format the filename with the start and end dates
    const formattedStartDate = startDate
      ? startDate.replace(/-/g, "")
      : new Date().toISOString().split("T")[0].replace(/-/g, ""); // Default to current date if startDate is empty
    const formattedEndDate = endDate
      ? endDate.replace(/-/g, "")
      : new Date().toISOString().split("T")[0].replace(/-/g, ""); // Default to current date if endDate is empty

    const fileName = `entryprocess_${formattedStartDate}_to_${formattedEndDate}.csv`;

    // Use FileSaver to save the file
    saveAs(blob, fileName);
  };

  const columns = [
    { title: "ID", data: "project_id", render: (data) => Capitalize(data) },
    {
      title: "DATE",
      data: "entry_date",
      render: (data) => getDateFormate(data),
    },
    { title: "TITLE", data: "title" },
    {
      title: "TYPE OF WORK",
      data: "type_of_work",
      render: (data) => Capitalize(data),
    },
  ];

  const handleChange = (event) => {
    const selectedValue = event.target.value;
    getTypeOfwork(selectedValue);
  };
 const handleFilterClick = () => {
    fetchData();
  };
  const handleClearClick = () => {
    setStartDate("");
    setEndDate("");
   getTypeOfwork("all");
   
  
    fetchData({
      start_date: "",
      end_date: "",
      type_of_work: "all",

      
      
    }); 
  };
  return (
    <section className="container d-flex flex-column min-vh-100 justify-content-between">
      <div className=" row mt-4">
        <div className="col-12">
          <div className="col-12">
            <Header></Header>
          </div>

          <div className="col-12 mt-3 pt-1 wapper w-100 py-5">
            <div className=" row mt-3 d-flex   w-100 ">
              <div className="col-12 col-md-9  px-4 ">
                <p className="heading-entr">Project Viewd</p>
              </div>
              <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>

            {/* <div className="col-5 col-md-2 text-center mt-2 ">
                <div className=" d-flex justify-content-center    ">
                  <div className="add-icon">
                    <VscGitStashPop className="exit-icon" onClick={exportToCSV} />
                  </div>
                </div>
              </div> */}

            <div className="row p-2">
              <div className=" col-12  d-flex justify-content-between gap-3">
              <div className="d-flex flex-wrap justify-content-left gap-3">

                <div className="width-default">
                  <label htmlFor="start-date" className="">
                    Start-Date
                  </label>
                  <input
                    type="date"
                    id="start-date"
                    className="form-control-date ms-3 ms-md-0"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    dateFormat="yyyy-MM-dd"
                  />
                </div>

                <div className="width-default ">
                  <label htmlFor="end-date" className="">
                    End-Date
                  </label>
                  <input
                    type="date"
                    id="end-date"
                    className="form-control-date "
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    dateFormat="yyyy-MM-dd"
                  />
                </div>
                    <div className=" width-default ">
                    <label className="">Type Of Work</label>
                    <select
                      className=" form-select-date"
                      value={filtertypeofwork}
                      onChange={handleChange}
                    >
                      <option value="" disabled selected>
                        Select an option
                      </option>
                      <option value="statistics">Statistics</option>
                      <option value="manuscript">Manuscript</option>
                      <option value="thesis">Thesis</option>
                      <option value="others">Others</option>
                    </select>
                  </div>
               

                <div className="mt-4">
                  <button className="button-primary " onClick={handleFilterClick}>
                    Filter
                  </button>
                </div>
                <div className="mt-4 ">
                    <button
                      className="button-primary-all"
                      onClick={handleClearClick}
                    >
                      All Clear
                    </button>
                  </div>

                </div>

                <div className=" d-flex justify-content-end ">
                  <div className=" text-center mt-3">
                    <div className=" d-flex justify-content-center    ">
                      <Tooltip title="Export">
                        <div className="add-icon">
                          <VscGitStashPop
                            className="exit-icon"
                            onClick={exportToCSV}
                          />
                        </div>
                      </Tooltip>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-2">
              <DataTable
                id="example"
                data={filteredData}
                columns={columns}
                className="display"
                options={{
                  scrollX: true,
                  select: true,
                  pageLength: 20, // Default number of rows per page
                  lengthMenu: [
                    [20, 30, 50],
                    [20, 30, 50],
                  ],
                }}
              />
            </div>
          </div>
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </section>
  );
}

export default EntryProjectView;
