import React, { useState, useRef, useEffect } from "react";

import { Link, useLocation } from "react-router-dom";

import Sider from "../components/Sider";
import { formatDistanceToNow, format } from "date-fns";
import Header from "../components/Header";
import "../assests/css/project-management-view.css";
import "../assests/css/payment_form.css";
import Profile from "../assests/images/profile.png";
import Medicslogo from "../assests/images/medicslogo.svg";
import Breadcrumbs from "../routes/Breadcrumbs";
import { IoMdAdd } from "react-icons/io";
import RichEditor_view from "../components/RichEditor_view.js";
import { Editor } from "primereact/editor";
import { getTotalDuration } from "../utils/projectDurations.js";
import { IoMdClose } from "react-icons/io";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import { FiDownload } from "react-icons/fi";
import Select from "react-select";
import { useParams } from "react-router-dom";
import { API_URL } from "../config.js";
import { HRMS_API_URL } from "../config.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import Swal from "sweetalert2";
import Footer from "../components/Footer";

import { getTimeDateFormate } from "../getTimeDateFormate.js";
import { getDateFormate } from "../dateFormate.js";
import axios from "axios";
import Loader from "../components/Loader.js";
import { faChevronRight } from "@fortawesome/free-solid-svg-icons";

import PDF from "../assests/images/pdf.svg";
import Excel from "../assests/images/excel.svg";
import ppt from "../assests/images/ppt.svg";
import Word from "../assests/images/word.svg";
import Image from "../assests/images/image.svg";
import Sav from "../assests/images/sav-file-format.png";
import Zip from "../assests/images/Zip.png";

// import { MdCancelScheduleSend } from "react-icons/md";
import { GrDocumentMissing } from "react-icons/gr";
import { capitalize } from "@mui/material";
import { CiCircleInfo } from "react-icons/ci";
import { IoIosAddCircleOutline } from "react-icons/io";

function Project_management_view() {
  const location = useLocation();
  // Access state
  const dataValue = location.state?.data;

  // console.log("dataValue:", dataValue);
  const [isReadOnly, setIsReadOnly] = React.useState(true);

  const { id } = useParams();

  const [formData, setFormData] = useState({
    commandbox: "",
  });

  const [loading, setLoading] = useState(true);

  const allrole_type = localStorage.getItem("medicsroleName");

  // console.log("allrole:", allrole_type);

  const [fetchData, setFetchData] = useState({});
  const [publicationStatus, setPublicationStatus] = useState([]);
  // console.log("abc", publicationStatus);
  const [docmentData, setDocumentData] = useState({});

  const [alltype, setAlltype] = useState([]);

  // console.log("fetchData:", fetchData);

  // console.log("alldatafetch", alltype);

  const [writesdetails, setWritersdetails] = useState([]);
  // console.log("writersdetails", writesdetails);

  const [empData, setEmployeeData] = useState({});
  const [reviewerid, setReviewerid] = useState([]);

  // console.log("reviewerid:", reviewerid);

  useEffect(() => {
    if (id) {
      fetchShowData(id);
    }
  }, [id]);

  // useEffect(() => {

  //   fetchShowData(id);

  // }, [id]);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0"); // Pad single digits
    const day = String(date.getDate()).padStart(2, "0"); // Pad single digits
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  };

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;
  const employee_name = parsedDetails ? parsedDetails.employee_name : null;
  const positionData = parsedDetails ? parsedDetails.position : null;

  // console.log("postion", positionData);

  const rolename = localStorage.getItem("medocsrolename") || "Admin";

  // console.log("rolename", rolename);
  const emp_type = localStorage.getItem("medicsEmpName") || "Admin";

  // allstatus

  const [writer, setWriter] = useState([]);
  const [reviewer, setReviewerdata] = useState([]);
  const [statistician, setStatistician] = useState([]);

  // console.log("WriterStatus:", writer);
  // console.log("ReviewerStatus:", reviewer);
  // console.log("StatisticianStatus:", statistician);

  const [project_id, setProjectId] = useState("");
  // console.log("projectid:", project_id);
  const [rejectreason, setRejectReason] = useState([]);
  // console.log("reject vreason:", rejectreason);
  const [activityreason, setActivityReason] = useState([]);
  const [assignByPosition, setAssignByPosition] = useState("");
  const [type_of_work, setTypeOfWork] = useState("");

  // console.log("typework:", type_of_work);
  const [projectStatusCheck, setProjectStatus] = useState(null);
  // console.log("allproject check:", projectStatusCheck);
  const [projectStatusId, setProjectStatusId] = useState(null);
  const [projectStatusVal, setProjectStatusVal] = useState(null);
  const [projectcomments, setProjectcomments] = useState([]);
  // console.log("projectcomments:", projectcomments);
  const [projectcommetnsR, setProjectcommentRs] = useState([]);
  const [empimages, setEmployeeImage] = useState({});
  const [writercompleted, setWriterCompleted] = useState({});
  const [revierecompleted, setReviewerCompleted] = useState({});
  const [statiscompleted, setStatisCompleted] = useState({});
  const [createdbyFiles, setCreatedByDetails] = useState([]);
  // console.log("createdbyFiles",createdbyFiles)
  const [projectId, setProjectName] = useState([]);

  const [rejectUserData, setRejectUserData] = useState([]);
  const [commonFiles, setCommonFiles] = useState([]);
  // console.log("commonFiles :", commonFiles);

  const [rejectlist, setRejectlist] = useState([]);
  // console.log("rejectlist",rejectlist)
  const [rejectlistid, setRejectlistid] = useState([]);

  const [widthdraw, setwidthdraw] = useState([]);

  // console.log("widthdrawn:", widthdraw);

  // console.log("rejectlistdata:", rejectlist);

  const [documentname, setDocument] = useState([]);

  // console.log("documnet 1234523:", documentname);

  const [rejectedAssignUserIds, setRejectedAssignUserIds] = useState([]);

  const [tcStatus, setTcStatus] = useState("");
  // console.log("tcStatus :", tcStatus);

  const [payStatus, setPayStatus] = useState("");

  const allowedValuespay = [
    "final_payment_pending",
    "partial_payment_pending",
    "advance_pending",
    "completed",
  ];

  // console.log("payStatus :", payStatus);
  const [tcData, setTCData] = useState("");
  // console.log("tcData :", tcData);

  const [commonStatus, setCommonStatus] = useState("");

  const allowedValues = ["client_review", "completed", "pending_author"];

  // console.log("commonStatus :", commonStatus);

  const [tcdetails, setTcdetails] = useState([]);
  // console.log("tc", tcdetails );
  const [tcdetailsType, setTcdetailsType] = useState([]);

  // console.log("commonstatus:", commonStatus);
  // console.log("Rejected assign_user IDs:", rejectedAssignUserIds);

  // console.log("datetime:", createdbyFiles);

  const [alldocumnts, setAlldocumnet] = useState([]);

  const [allproid, setAllproid] = useState([]);

  // console.log("allproid:", allproid);
  const fetchShowData = async (id) => {
    try {
      const responseShow = await axios.get(
        `${API_URL}/api/entry_process/project-view/${id}`,
        {
          params: {
            created_by: createdby,
            ids: allproid,
            assign_user: reviewerid,
          },
        }
      );

      const fetchData = responseShow.data;

      // console.log("fetchdatacc:", fetchData);
      setPublicationStatus(fetchData?.publication_status);

      // allwriter

      setWriter(
        fetchData.response?.project_details?.writer_data?.[0]?.status ?? "-"
      );
      setReviewerdata(
        fetchData.response?.project_details?.reviewer_data?.[0]?.status ?? "-"
      );
      setStatistician(
        fetchData.response?.project_details?.statistican_data?.[0]?.status ??
        "-"
      );

      setAlldocumnet(fetchData.duration_options);

      const rejectAssignIds = responseShow.data.rejected_list.map(
        (item) => item.assign_id
      );
      setRejectlistid(rejectAssignIds);
      setTCData(
        fetchData.response?.project_details?.tc_data?.[0]?.status ?? "-"
      );
      // console.log("allcheckdata:", fetchData);
      // const flatenTCdata = fetchData.response.project_details.tc_data.map(
      //   (item) => {
      //     // This will call setTcStatus for each item
      //     return {
      //       status: item.status,
      //     };
      //   }
      // );
      // setTCData(flatenTCdata);
      // console.log("TC Data :", flatenTCdata);
      // console.log("TC Status :", flatenTCdata.status);
      // setTcStatus(flatenTCdata.status)
      const originaltodoData = fetchData.rejected_list;
      const revertalllist = fetchData.revert_list;
      // console.log("originaltodoData :", originaltodoData);
      setRejectUserData(originaltodoData);

      const alljoinrejcet = [...originaltodoData, ...revertalllist];
      // console.log("alljoinrejcet",alljoinrejcet)

      const flattenedToData = alljoinrejcet.map((item) => {
        return {
          status: CapitalizeCaseU(item.status),
          employee_name: item.employee_name || "",
          name: CapitalizeCaseU(item.role),
          updated_at: formatDate(item.created_at),
          reason: CapitalizeCaseU(item.content || "-"),
        };
      });

      setRejectlist(flattenedToData);

      const rejectedIds = fetchData.response.project_details.writer_data
        .filter((writer) => writer.status === "rejected")
        .map((writer) => writer.assign_user);

      setRejectedAssignUserIds(rejectedIds);

      setWriterCompleted(fetchData.writerCompleted);

      setProjectName(fetchData.response.project_details.project_id);
      setReviewerCompleted(fetchData.reviewerCompleted);
      setStatisCompleted(fetchData.statisticanCompleted);
      setProjectId(fetchData.response.project_details.id);
      setTypeOfWork(fetchData.response.project_details.type_of_work);

      setDocument(fetchData.duration_options);

      setProjectcomments(
        fetchData?.response?.project_details?.projectcomment || []
      );
      setProjectcommentRs(
        fetchData?.response?.project_details?.projectcomment_r || []
      );

      const projectstatus =
        fetchData?.response?.project_details?.projectcomment_r || [];

      // console.log("projectstatus", projectstatus);
      setProjectStatusVal(projectstatus[0]?.type);

      const projectAcceptStatus =
        fetchData?.response?.project_details?.project_accept_statust || [];
      setProjectStatus(projectAcceptStatus[0]?.status);
      setFetchData(fetchData.response.project_details);

      setAlltype(fetchData?.response?.reviewerFind[0]?.type || []);

      // setReviewerid(fetchData.response.project_details?.reviewer_data[0]?.assign_user)

      const reviewerIds =
        fetchData.response.project_details?.reviewer_data?.map(
          (item) => item.assign_user
        ) || [];

      setReviewerid(reviewerIds);

      setAllproid(fetchData?.response?.project_details?.id);
      const mappedDocuments = fetchData.response.project_details.documents.map(
        (item) => ({
          type_of_work: item.select_document,
        })
      );

      const document = mappedDocuments[0].type_of_work;
      // If you need to store the result in state:
      setDocumentData(document);

      setwidthdraw(fetchData.response.project_details.process_status);

      setWritersdetails(fetchData.response.project_details.writer_data);
      setEmployeeData(fetchData.response.employee_details);
      const employeedetails = fetchData.response.employee_details;
      const profileimage_f = employeedetails?.profile_image || "";
      const profileimage = profileimage_f
        ? `${HRMS_API_URL}/${profileimage_f}`
        : Profile;

      setEmployeeImage(profileimage);
      setCommonStatus(fetchData.response.project_details.process_status);
      setPayStatus(
        fetchData.response.project_details.payment_process.payment_status
      );
      // const formattedEmployees = fetchData.employees.map((employee) => ({
      //   name: employee.employee_name,
      //   id: employee.id,
      //   role_id: employee.position || null,
      //   position: employee.role_name?.name,
      //   image: employee.profile_image
      //     ? `${HRMS_API_URL}/${employee.profile_image}`
      //     : Profile,
      // }));

      // setOptionsAssigner(formattedEmployees);

      setChosenOption(fetchData.response.project_details.process_status || "");
      const fetchedFiles =
        fetchData?.response?.project_details?.documents || [];

      const formattedFiles = fetchedFiles.flatMap((doc) => {
        const filesArray = Array.isArray(doc.file) ? doc.file : [doc.file];

        return filesArray.map((file) => {
          const fileType = file.file.split(".").pop(); // Extract file extension
          const relativePath = file.file.replace(/\\/g, "/"); // Handle backslashes

          let documentTitles = [];
          try {
            const parsedData = JSON.parse(doc.select_document || "[]");
            documentTitles = Array.isArray(parsedData) ? parsedData : []; // Ensure it's an array
          } catch (error) {
            console.error(
              "Invalid JSON format for select_document:",
              doc.select_document
            );
          }
          const title = Array.isArray(documentTitles)
            ? documentTitles.join(", ")
            : "";

          return {
            entry_process_model_id: doc.entry_process_model_id,
            name: file.file,
            original_name: file.original_name,
            id: file.id,
            created_by: doc.created_by,
            optionName: title, // Use the formatted string
            type: fileType, // File type/extension
            fileName: file.file.split("/").pop(), // Extract filename
            url: file.file
              ? `${API_URL}/uploads/${relativePath}`
              : "Unknown URL",
            // url: ${BASE_URL}/uploads/${relativePath},
            url_d: `${API_URL}/uploads/${relativePath}`, // Construct file URL

            dateAdded: formatDate(doc.created_at),
            assigne: doc?.created_by_user?.employee_name || "Unknown",
          };
        });
      });

      setSubmittedFiles(formattedFiles);
      //reject reason
      setRejectReason(fetchData.response.project_details?.reject_reason);
      setActivityReason(fetchData.response.project_details.activity_data);
      // console.log("fetchData.response. :", fetchData.response);
      const createdbyFiles =
        fetchData.response?.project_details?.commentslist || [];
      // console.log("createdbyFiles :", createdbyFiles);

      const uploadedFiles = createdbyFiles.map((doc) => {
        // const comment = doc.created_by_users ? doc.comments[0].comment
        //   : undefined;

        // Handle both array and single file cases
        const filesArray = Array.isArray(doc.file) ? doc.file : [doc.file];

        return {
          date: doc.created_date?.split(" ")[0] || "",
          added_at: doc.created_date,
          createdby: doc.createdby_name,
          type: doc.type || undefined,
          employee_name: doc.employee_name || undefined,
          role_name: doc.name || doc.position,
          // doc_id: doc.doc_id,
          files: filesArray.map((file) => ({
            // created_at: file.file_create,
            // file_ids: file.id,
            file_path: file.files,
            file_name: file.original_name || "",
            extension: file.original_name?.split(".").pop()?.toLowerCase(),
          })),
          comments: doc.activity,
          documentcount: filesArray.length,
        };
      });
      const commonFiles = fetchData.response.project_details.common_doc;
      const flattenedFiles = commonFiles.map((item) => ({
        ...item.file,
      }));

      setCommonFiles(flattenedFiles);

      // console.log('flattenedFiles :',flattenedFiles);
      // console.log("uploadedFiles :", uploadedFiles);

      setCreatedByDetails(uploadedFiles);

      if (projectstatus?.length > 0) {
        // console.log("projectstatus", projectstatus);

        const formattedEmployee = {
          name: projectstatus[0]?.user_date?.employee_name || "Unknown",
          id: projectstatus[0]?.assign_user || null,
          position: projectstatus[0]?.type || "Unassigned",
          role_id: projectstatus[0]?.user_date?.position || null,
          image: projectstatus[0]?.user_date?.profile_image
            ? `${HRMS_API_URL}/${projectstatus[0]?.user_date?.profile_image}`
            : Profile,
        };
        // Set the selectedOption
        setSelectedOption(formattedEmployee);
        setSelectedStatus(projectstatus[0].status);
      }

      setTcdetails(
        fetchData.response.project_details.tc_data[0]?.status || "-"
      );
      setTcdetailsType(
        fetchData.response.project_details.tc_data[0]?.type_sme || "-"
      );
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const handleDownload = async (filePath, original_name) => {
    try {
      // Extract filename from path (assuming filePath is the full path)
      const fileName = filePath.split("/").pop();

      const downloadUrl = `${API_URL}/activity_files/${filePath}`;

      // Create temporary link for download
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.setAttribute("download", original_name);
      link.setAttribute("target", "_blank");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Optional: Show success message
      // Swal.fire({
      //   icon: "success",
      //   title: "Download started",
      //   text: `File ${fileName} is being downloaded`,
      //   showConfirmButton: true,
      // });
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Download failed",
        text: error.message,
        showConfirmButton: true,
      });
    }
  };

  const handleCommonFileDownload = async (filePath, original_name) => {
    // console.log("original:", original_name);
    try {
      // Extract filename from path (assuming filePath is the full path)
      const fileName = filePath.split("/").pop();

      const downloadUrl = `${API_URL}/uploads/${filePath}`;

      // Create temporary link for download
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.setAttribute("download", original_name);
      link.setAttribute("target", "_blank");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Optional: Show success message
      // Swal.fire({
      //   icon: "success",
      //   title: "Download started",
      //   text: `File ${fileName} is being downloaded`,
      //   showConfirmButton: true,
      // });
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Download failed",
        text: error.message,
        showConfirmButton: true,
      });
    }
  };

  // single file download

  // =================== DOWNLOAD FUNCTION ===================
  const handleDownloadsingle = async (createdby, date, type, projectid) => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/document-download`,
        {
          params: {
            createdby,
            date,
            type,
            projectid,
            pid: project_id, // Ensure this is defined
          },
          responseType: "blob",
        }
      );

      // Check if the response is an error (sometimes errors come as blobs)
      if (response.headers["content-type"]?.includes("application/json")) {
        const errorText = await response.data.text();
        const errorData = JSON.parse(errorText);
        throw new Error(errorData.message || "Download failed");
      }

      // Extract filename from headers
      const contentDisposition = response.headers["content-disposition"];
      let filename = "document";

      if (contentDisposition) {
        const match = contentDisposition.match(
          /filename\*?=['"]?(?:UTF-\d['"]*)?([^;\r\n"']*)['"]?;?/i
        );
        filename = match?.[1] || filename;
      }

      // Create a download link and trigger it
      const blob = new Blob([response.data], {
        type: response.headers["content-type"] || "application/octet-stream",
      });
      const downloadUrl = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(downloadUrl);
    } catch (error) {
      console.error("Download error:", error);
      Swal.fire("Error", error.message || "Failed to download file", "error");
    }
  };

  const [editorError, setEditorError] = useState(false);

  const handleTextChange = (e) => {
    const newText = e.htmlValue;
    setFormData((prevData) => ({
      ...prevData,
      commandbox: newText,
    }));
  };

  const [editorKey, setEditorKey] = useState(0);

  const [uploadAfile, setFileAcData] = useState([]);
  const fileInputRef = useRef(null);

  const handleActivityFileChange = (event) => {
    const selectedFiles = Array.from(event.target.files);
    setFileAcData(selectedFiles);
  };

  const handleEditorChange = async (e) => {
    e.preventDefault();
    if (!formData.commandbox || formData.commandbox.trim() === "") {
      setEditorError(true);
      return;
    }

    setEditorError(false);

    const updatedData = {
      project_id: project_id,
      activity: formData.commandbox,
      createdby: createdby,
      createdby_name: employee_name,
    };

    const formDataToSend = new FormData();

    for (const key in updatedData) {
      formDataToSend.append(key, updatedData[key]);
    }

    if (uploadAfile && uploadAfile.length > 0) {
      uploadAfile.forEach((file, index) => {
        formDataToSend.append("activity_file[]", file);
      });
    }

    try {
      const response = await axios.post(
        `${API_URL}/api/projects/store`,
        formDataToSend,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      setFormData((prevData) => ({
        ...prevData,
        commandbox: "",
      }));
      setEditorKey((prevKey) => prevKey + 1);
      setFileAcData([]);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      fetchShowData(id);
    } catch (error) {
      Swal.fire("Error", "Failed to update the comments", "error");
    }
  };

  const [errors, setErrors] = useState({});

  const [optionsAssigner, setOptionsAssigner] = useState([
    { name: "", id: "", image: Medicslogo, position: "" },
  ]);

  const [selectedOption, setSelectedOption] = useState(null);
  // console.log("assignuser:", selectedOption);

  const [searchQuery, setSearchQuery] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownAssgineStatus = useRef(null);
  const toggleDropdown = () => setIsDropdownOpen((prev) => !prev);

  const handleOptionSelect = async (option) => {
    Swal.fire({
      title: "Are you sure?",
      text: "Do you want to change the assignee?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, change it!",
      cancelButtonText: "Cancel",
    }).then(async (result) => {
      // Add 'async' here for the 'then' block
      if (result.isConfirmed) {
        const id_p = project_id;
        const updatedData = {
          assign_by: option.id,
          position: option.role_id,
        };

        try {
          // API call to update project status using 'await' since the function is now 'async'
          const response = await axios.post(
            `${API_URL}/api/entry_process/project-status/${id_p}`,
            updatedData
          );

          Swal.fire("Success!", "The assignee has been updated.", "success");
          fetchShowData(id);
        } catch (error) {
          Swal.fire("Error", "Failed to update the assignee", "error");
        }
      } else {
        // If the user clicks "Cancel", no action is taken
        console.log("Assignee change was canceled");
      }
    });
  };

  const filteredOptions = optionsAssigner.filter(
    (option) =>
      option.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      option.position.toLowerCase().includes(searchQuery.toLowerCase())
  );
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownAssgineStatus.current &&
        !dropdownAssgineStatus.current.contains(event.target)
      ) {
        setIsDropdownOpen(false);
      }
    };

    // Add event listener for clicks outside
    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      // Clean up event listener
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleDelete = async (fileName, documentId, createdById) => {
    const storedDetails = localStorage.getItem("medicsuser");
    const parsedDetails = JSON.parse(storedDetails);
    const currentUserId = parsedDetails ? parsedDetails.id : null;
    const currentUserRole = parsedDetails ? parsedDetails.position : null; // Assuming role is stored here, adjust if different

    // Admin check: If user is an admin, allow deletion of any file
    if (currentUserRole === "Admin") {
      const result = await Swal.fire({
        title: "Are you sure?",
        text: "Do you want to delete this document?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "Cancel",
      });

      if (result.isConfirmed) {
        try {
          const response = await fetch(
            `${API_URL}/api/entry_process/document-delete/${documentId}?created_by=${createdby}`,
            {
              method: "DELETE",
              headers: {
                "Content-Type": "application/json",
              },
            }
          );

          if (response.ok) {
            setFiles(files.filter((file) => file.documentId !== documentId));
            fetchShowData(id);
            Swal.fire("Success!", "File deleted successfully!", "success");
          } else {
            // Handle error response
            const errorData = await response.json();
            console.error("Error deleting document:", errorData.message);
          }
        } catch (error) {
          console.error("Error deleting document:", error.message);
        }
      } else {
        Swal.fire("Cancelled", "Your document is safe :)", "info");
      }
    } else {
      if (`'.${currentUserId}.'` === `'.${createdById}.'`) {
        const result = await Swal.fire({
          title: "Are you sure?",
          text: "Do you want to delete this document?",
          icon: "warning",
          showCancelButton: true,
          confirmButtonText: "Yes, delete it!",
          cancelButtonText: "Cancel",
        });

        if (result.isConfirmed) {
          try {
            const response = await fetch(
              `${API_URL}/api/entry_process/document-delete/${documentId}?created_by=${createdby}`,
              {
                method: "DELETE",
                headers: {
                  "Content-Type": "application/json",
                },
              }
            );
            if (response.ok) {
              setFiles(files.filter((file) => file.documentId !== documentId));
              fetchShowData(id);
              Swal.fire("Success!", "File deleted successfully!", "success");
            } else {
              const errorData = await response.json();
              console.error("Error deleting document:", errorData.message);
            }
          } catch (error) {
            console.error("Error deleting document:", error.message);
          }
        } else {
          Swal.fire("Cancelled", "Your document is safe :)", "info");
        }
      } else {
        Swal.fire(
          "Not Allowed",
          "You are not allowed to delete this document.",
          "error"
        );
      }
    }
  };

  const allOptions = [
    { value: "not_assigned", label: "Not Assigned" },
    { value: "pending_author", label: "Pending - Author" },
    { value: "completed", label: "Completed" },
    { value: "withdrawal", label: "Withdrawal" },
    { value: "in_progress", label: "In Progress" },
  ];

  // States to manage the dropdown
  const [isListExpanded, setIsListExpanded] = useState(false);
  const [chosenOption, setChosenOption] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const dropdownRef = useRef(null);

  // Filter options based on search term
  const filtereddepOptions = allOptions.filter((option) =>
    option.label.toLowerCase().includes(searchInput.toLowerCase())
  );

  const toggleList = () => setIsListExpanded(!isListExpanded);

  const handledepOptionSelect = async (option) => {
    Swal.fire({
      title: "Are you sure?",
      text: "Do you want to change the status?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, change it!",
      cancelButtonText: "Cancel",
    }).then(async (result) => {
      if (result.isConfirmed) {
        setChosenOption(option.value);
        setIsListExpanded(false);
        setSearchInput("");

        const id = project_id;
        const updatedData = {
          status: option.value,
          createdby: createdby,
        };
        document.getElementById("global-loader").style.display = "flex";

        setTimeout(async () => {
          try {
            // API call to update project status using 'await' since the function is now 'async'
            const response = await axios.post(
              `${API_URL}/api/entry_process/project-status/${id}`,
              updatedData
            );

            Swal.fire("Success!", "The assignee has been updated.", "success");
          } catch (error) {
            console.error("Error updating project status", error);
            Swal.fire("Error", "Failed to update the assignee", "error");
          } finally {
            document.getElementById("global-loader").style.display = "none";
          }
        }, 500);
      } else {
        console.log("Assignee change was canceled");
      }
    });
  };
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsListExpanded(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  //accept view show

  const [isAccepted, setIsAccepted] = useState(false);
  const [isRejected, setIsRejected] = useState(false);

  const handleAcceptClick = async () => {
    Swal.fire({
      title: "Are you sure?",
      text: "Do you want to accept this project?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, accept it!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        setIsAccepted(true);
        setIsRejected(false);
        const id_p = project_id;

        const updatedData = {
          project_id: project_id,
          type: "accepted",
          project_status: projectStatusVal,
          created_by: createdby,
          position: positionData,
        };
        // console.log("updatedData :", updatedData);

        document.getElementById("global-loader").style.display = "flex";
        setTimeout(async () => {
          try {
            const response = await axios.post(
              `${API_URL}/api/entry_process/project-status/${id_p}`,
              updatedData
            );

            Swal.fire({
              icon: "success",
              title: "Success",
              text: "Project accepted successfully!",
            });
            fetchShowData(id);
          } catch (error) {
            console.error("Error updating project status:", error);
          } finally {
            document.getElementById("global-loader").style.display = "none";
          }
        }, 500);
      }
    });
  };

  const handleRejectClick = async () => {
    Swal.fire({
      title: "Are you sure?",
      text: "Do you want to reject this project?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Yes, reject it!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        setIsRejected(true);
        setIsAccepted(false);
        setIsPopupVisible(true);

        // const id_p = project_id;
        // const updatedData = {
        //   project_status: "rejected",
        //   type: "rejected",
        //   status: projectStatusVal,
        //   created_by: createdby,
        // };

        //   try {
        //     const response = await axios.post(
        //       `${API_URL}/api/entry_process/project-status/${id_p}`,
        //       updatedData
        //     );
        //     fetchShowData(id);
        //   } catch (error) {
        //     console.error("Error updating project status:", error);
        //   }
      }
    });
  };

  // revert
  const [isPopupVisiblerevert, setIsPopupVisiblerevert] = useState(false);
  const [reasonrevert, setReasonrevert] = useState("");

  const handleCancelrevert = () => {
    setIsPopupVisiblerevert(false);
    setReasonrevert("");
  };

  const handleSubmitrevert = async () => {
    if (!reasonrevert.trim()) {
      setErrors({ reasonrevert: "Reason cannot be empty." });
      return;
    }

    const updatedData = {
      project_id: project_id,
      reason: reasonrevert,
      createdby: createdby,
      createdby_name: employee_name,
      type: "revert",
      project_status: projectStatusVal,
    };
    // console.log("createdby:", updatedData);
    document.getElementById("global-loader").style.display = "flex";
    setTimeout(async () => {
      try {
        const response = await axios.post(
          `${API_URL}/api/projects/rejectreason`,
          updatedData
        );
        Swal.fire("Success!", "Reason submitted successfully!", "success");
        setErrors({});
        setIsPopupVisiblerevert(false);
        setReasonrevert("");
        fetchShowData(id);
      } catch (error) {
        console.error("Error updating project status", error);
        Swal.fire("Error", "Failed to update", "error");
      } finally {
        document.getElementById("global-loader").style.display = "none";
      }
    }, 500);
  };

  const handleReasonChangerevert = (e) => {
    setReasonrevert(e.target.value);

    // Clear error when user starts typing
    if (errors.reasonrevert) {
      setErrors({});
    }
  };

  //reject fuction
  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const [reason, setReason] = useState("");

  const handleCancel = () => {
    setIsPopupVisible(false);
    setReason("");
  };

  const handleSubmit = async () => {
    if (!reason.trim()) {
      setErrors({ reason: "Reason cannot be empty." });
      return;
    }

    const updatedData = {
      project_id: project_id,
      reason: reason,
      createdby: createdby,
      createdby_name: employee_name,
      type: "rejected",
      project_status: projectStatusVal,
    };
    // console.log("createdby:", updatedData);
    document.getElementById("global-loader").style.display = "flex";
    setTimeout(async () => {
      try {
        const response = await axios.post(
          `${API_URL}/api/projects/rejectreason`,
          updatedData
        );
        Swal.fire("Success!", "Reason submitted successfully!", "success");
        setErrors({});
        setIsPopupVisible(false);
        setReason("");
        fetchShowData(id);
      } catch (error) {
        console.error("Error updating project status", error);
        Swal.fire("Error", "Failed to update", "error");
      } finally {
        document.getElementById("global-loader").style.display = "none";
      }
    }, 500);
  };

  const handleReasonChange = (e) => {
    setReason(e.target.value);

    // Clear error when user starts typing
    if (errors.reason) {
      setErrors({});
    }
  };

  //upload documents

  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [files, setFiles] = useState([]);
  const [file, setFile] = useState(null);
  const [submittedFiles, setSubmittedFiles] = useState([]);

  const [otherInput, setOtherInput] = useState("");

  const initialCategory = type_of_work;

  const togglePopup = () => {
    setIsPopupOpen((prev) => !prev);
  };

  // reject icon

  const [isrejectapp, setRejectapp] = useState(false);

  const rejectallicon = () => {
    setRejectapp((prev) => !prev);
  };

  const optionsMapping = {
    statistics: [
      { value: "sample_size", label: "Sample Size" },
      { value: "paper_statistics", label: "Paper Statistics" },
      {
        value: "thesis_statistics_with_text",
        label: "Thesis Statistics - With Text",
      },
      {
        value: "thesis_statistics_without_text",
        label: "Thesis Statistics - Without Text",
      },
    ],
    manuscript: [
      { value: "writing", label: "Writing" },
      { value: "with_statistics", label: "With Statistics" },
      { value: "with_publication", label: "With Publication" },
    ],
    thesis: [
      {
        value: "supporting_thesis_with_ms",
        label: "Supporting Thesis with MS",
      },
      {
        value: "supporting_thesis_without_ms",
        label: "Supporting Thesis without MS",
      },
      { value: "supporting_thesis_part1", label: "Supporting Thesis Part - 1" },
      { value: "supporting_thesis_part2", label: "Supporting Thesis Part - 2" },
      {
        value: "supporting_thesis_part_with_ms",
        label: "Supporting Thesis Part - With MS",
      },
      {
        value: "supporting_thesis_part_without_ms",
        label: "Supporting Thesis Part - Without MS",
      },
      { value: "thesis_reviewing", label: "Thesis Reviewing" },
    ],
    presentation: [
      { value: "conference_presentation", label: "Conference Presentation" },
      { value: "with_statistics", label: "With Statistics" },
      { value: "poster_presentation", label: "Poster Presentation" },
    ],
    others: [],
  };

  const handleOtherInputChange = (event) => {
    setOtherInput(event.target.value);
  };

  const [uploadfile, setFileData] = useState([]);

  const handleFileChange = (event) => {
    const selectedFiles = Array.from(event.target.files);
    setFileAcData(selectedFiles);

    setErrors((prevErrors) => ({
      ...prevErrors,
      file: "",
    }));
  };

  const [projectStatus, setProjectOption] = useState([]);
  const [isDropdowncheck, setIsDropdowncheck] = useState(false);

  const handleOptionChange = (event) => {
    const option = event.target.value;
    if (event.target.checked) {
      setProjectOption((prevStatus) => [...prevStatus, option]);
    } else {
      setProjectOption((prevStatus) =>
        prevStatus.filter((status) => status !== option)
      );
    }

    if (option !== "Other") {
      setOtherInput("");
    }
  };

  const toggleDropcheck = () => {
    setIsDropdowncheck(!isDropdownOpen);
  };
  const dropselectRef = useRef(null);
  const handleClickOutsideselect = (event) => {
    if (
      isDropdowncheck &&
      dropselectRef.current &&
      !dropselectRef.current.contains(event.target)
    ) {
      setIsDropdowncheck(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutsideselect);
    return () => {
      document.removeEventListener("mousedown", handleClickOutsideselect);
    };
  }, [isDropdowncheck]);

  const handleUploadSubmit = async () => {
    let validationErrors = {};
    if (uploadAfile.length === 0) {
      validationErrors.file = "Please upload a file.";
    }
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    const updatedData = {
      project_id: project_id,
      createdby: createdby,
      createdby_name: employee_name,
    };

    const formDataToSend = new FormData();
    for (const key in updatedData) {
      formDataToSend.append(key, updatedData[key]);
    }

    if (uploadAfile.length > 0) {
      uploadAfile.forEach((file) => {
        formDataToSend.append("activity_file[]", file);
      });
    }

    try {
      document.getElementById("global-loader").style.display = "flex";

      // Upload files
      await axios.post(
        `${API_URL}/api/projects/document_uploads`,
        formDataToSend,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      const statusUpdateData = {
        status: assigneeStatus,
        position: initialstatus,
        type: "assignstatus",
        created_by: createdby,
        createdby_name: employee_name,
      };

      try {
        await axios.post(
          `${API_URL}/api/entry_process/project-status/${project_id}`,
          statusUpdateData
        );

        setFileData([]);
        setSubmittedFiles([]);
        setProjectOption([]);
        setIsDropdowncheck(false);
        setFile(null);
        setErrors({});
        setReason("");
        setIsPopupOpen(false);

        setSelectedStatus(assigneeLStatus);
        setIsDropdownOpenAssigne(false);
        setSearchQueryAssigne("");
        fetchShowData(id);
        Swal.fire(
          "Success!",
          "The assignee status has been updated.",
          "success"
        );
      } catch (error) {
        console.error("Error updating project status", error);
        Swal.fire("Error", "Failed to update the assignee", "error");
      }
    } catch (error) {
      console.error("Error uploading files:", error);
      Swal.fire("Error", "Failed to upload files. Please try again.", "error");
    } finally {
      document.getElementById("global-loader").style.display = "none";
    }
  };

  //assigne status
  const [isDropdownOpenAssigne, setIsDropdownOpenAssigne] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState("");
  const [searchQueryAssigne, setSearchQueryAssigne] = useState("");
  const dropdownRefAssigne = useRef(null);

  const AssgineStatus = {
    writer: [
      { value: "on_going", label: "On Going" },
      { value: "completed", label: "Completed" },
      { value: "need_support", label: "Need Support" },
      { value: "revert", label: "Revert" },
    ],
    reviewer: [
      { value: "on_going", label: "On Going" },
      { value: "completed", label: "Completed" },
      { value: "need_support", label: "Need Support" },
      { value: "revert", label: "Revert" },
    ],
    statistican: [
      { value: "on_going", label: "On going" },
      { value: "completed", label: "Completed" },
      { value: "need_support", label: "Need Support" },
      { value: "revert", label: "Revert" },
    ],
  };

  const initialstatus = selectedOption?.position?.toLowerCase();
  // console.log("initialstatus", initialstatus);
  const filteredStatusOptions =
    AssgineStatus[initialstatus]?.filter((status) =>
      status.label.toLowerCase().includes(searchQueryAssigne.toLowerCase())
    ) || [];
  // console.log("filter", filteredStatusOptions);
  const toggleDropdownAssigne = () => {
    setIsDropdownOpenAssigne(!isDropdownOpenAssigne);
  };

  const [assigneeStatus, setAssigneeStatus] = useState("");
  const [assigneeLStatus, setAssigneeLStatus] = useState("");

  // revert status
  const handleStatusSelect = async (status) => {
    if (status.value === "revert") {
      // togglePopup();
      setIsPopupVisiblerevert(true);
      setAssigneeStatus(status.value);
      setAssigneeLStatus(status.label);
    } else {
      Swal.fire({
        title: "Are you sure?",
        text: "Do you want to change the assignee status?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, change it!",
        cancelButtonText: "Cancel",
      }).then(async (result) => {
        if (result.isConfirmed) {
          const id = project_id;
          const updatedData = {
            status: status.value,
            position: initialstatus,
            type: "assignstatus",
            created_by: createdby,
            createdby_name: employee_name,
          };
          document.getElementById("global-loader").style.display = "flex";
          setTimeout(async () => {
            try {
              const response = await axios.post(
                `${API_URL}/api/entry_process/project-status/${id}`,
                updatedData
              );

              setSelectedStatus(status.label);
              setIsDropdownOpenAssigne(false);
              setSearchQueryAssigne("");
              Swal.fire(
                "Success!",
                "The assignee status has been updated.",
                "success"
              );
              fetchShowData(id);
            } catch (error) {
              console.error("Error updating project status", error);
              Swal.fire("Error", "Failed to update the assignee", "error");
            } finally {
              document.getElementById("global-loader").style.display = "none";
            }
          }, 500);
        }
      });
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownRefAssigne.current &&
        !dropdownRefAssigne.current.contains(event.target)
      ) {
        setIsDropdownOpenAssigne(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  //reject reason
  const [isPopupVisibleReject, setIsRejectPopupVisible] = useState(false);
  const [rejectReasonData, setRejectReasonData] = useState([]);
  // console.log("rejectReasonData",rejectReasonData)

  const handleViewRejectReason = async (createduserid) => {
    setIsRejectPopupVisible(true);

    try {
      const response = await axios.post(
        `${API_URL}/api/projects/rejectreason-view`,
        {
          created_by: createduserid,
          project_id: project_id,
        }
      );
      setRejectReasonData(response.data?.reasonlist || []);
      setIsRejectPopupVisible(true);
    } catch (error) {
      console.error("Error fetching reject reasons:", error);
      setRejectReasonData([{ reason: "Unable to fetch reject reasons" }]);
      setIsRejectPopupVisible(true);
    }
  };

  const toggleRejectPopup = () => {
    setIsRejectPopupVisible((prev) => !prev);
  };

  const removeEmptyTags = (html) => {
    const div = document.createElement("div");
    div.innerHTML = html;

    // Loop through all child elements and remove empty tags
    const elements = div.querySelectorAll("*");
    elements.forEach((element) => {
      if (!element.innerHTML.trim()) {
        element.remove(); // Remove empty elements
      }
    });

    return div.innerHTML;
  };

  const [replyText, setReplyText] = useState("");
  const [activeReplyId, setActiveReplyId] = useState(null);

  const [replies, setReplies] = useState(reason.replies || []);

  const handleReplyClick = (id) => {
    setActiveReplyId(id === activeReplyId ? null : id);
  };

  const handleReplyChange = (e) => {
    setReplyText(e.target.value);
  };

  const handleReplySubmit = async (replyid) => {
    if (replyText.trim()) {
      setReplies((prevReplies) => ({
        ...prevReplies,
        [replyid]: [...(prevReplies[replyid] || []), replyText],
      }));
      setReplyText("");
      setActiveReplyId(null);

      const updatedData = {
        activity_id: replyid,
        project_id: project_id,
        createdby: createdby,
        createdby_name: employee_name,
        content: replyText,
      };

      try {
        const response = await axios.post(
          `${API_URL}/api/projects/project-reply-activity`,
          updatedData
        );
        Swal.fire("Success!", "Reply submitted successfully!", "success");

        // Clear errors, reset popup visibility, and fetch updated data
        setErrors({});
        setIsPopupVisible(false);
        setReason(""); // Assuming this is another state you're clearing
        fetchShowData(id); // Fetch updated data (ensure this works properly)
      } catch (error) {
        Swal.fire("Error", "Failed to submit reply", "error");
      }
    } else {
      Swal.fire("Warning", "Please enter a valid reply.", "warning");
    }
  };

  const removeHtmlTags = (html) => {
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = html;
    return tempDiv.textContent || tempDiv.innerText || "";
  };

  // writer dropdown all

  const [writter, setWritter] = useState([]);

  const [reviewerdrop, setReviewer] = useState([]);

  const [statistical, setStatistical] = useState([]);
  const [journal, setJournal] = useState([]);

  const [rejectedAssignIds, setRejectedAssignIds] = useState([]);
  // console.log("redata:", rejectedAssignIds);

  const fetchDataall = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/getEmployeeName`
      );
      const data = response.data;
      // console.log("datacdfd :", data);

      if (data) {
        // const assignIds = rejectUserData
        //   .map((item) => (item?.assign_id ? String(item.assign_id) : null))
        //   .filter((id) => id !== null);

        // setRejectedAssignIds(assignIds);

        const assignStatusData = rejectUserData
          .filter((item) => item?.assign_id && item?.status)
          .map((item) => ({
            id: String(item.assign_id),
            status: item.status.toLowerCase(), // assuming it's 'rejected' or 'revert'
          }));

        setRejectedAssignIds(assignStatusData);

        // Filter statisticans - keep only those not in rejected list
        const filteredStatisticans = (data.statistican || []).filter(
          (stat) => !rejectedAssignIds.includes(stat.id.toString())
        );

        // Filter reviewer - keep only those not in rejected list
        const filteredReviewer = (data.reviewer || []).filter(
          (stat) => !rejectedAssignIds.includes(stat.id.toString())
        );

        // Filter journal - keep only those not in rejected list
        const filteredournal = (data.journal || []).filter(
          (stat) => !rejectedAssignIds.includes(stat.id.toString())
        );

        // console.log('data.reviewer :',data.reviewer);
        // console.log('filteredReviewer :',filteredReviewer);

        // Update state with filtered data
        // setWritter(filteredWriters);
        setWritter(data.writer || []);
        setReviewer(data.reviewer || []);
        setStatistical(data.statistican || []);
        setJournal(filteredournal);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };


  const [showFilesModal, setShowFilesModal] = useState(false);
  const [modalFiles, setModalFiles] = useState([]);

  const openFilesModal = (files) => {

    // console.log("files:", files);
    setModalFiles(files);
    setShowFilesModal(true);
  };

  const closeFilesModal = () => {
    setShowFilesModal(false);
    setModalFiles([]);
  };


  useEffect(() => {
    fetchDataall();
  }, [rejectUserData]);

  //status change
  const [statisticanStatus, setStatisticanStatus] = useState("");
  const [writerStatus, setWriterStatus] = useState("");
  const [reviewerStatus, setReviewerStatus] = useState("");
  const [journalStatus, setJournalStatus] = useState("");
  const [smeStatus, setSmeStatus] = useState("");

  const [oldid, setoldid] = useState([]);
  // console.log("oldid:", oldid);
  // const [status ,setStatus] =useState([]);
  // console.log("assign:", newValue);

  const handleNeedChange = (
    event,
    setStatus,
    personId,
    assign_user,
    assign_date,
    status_date,
    tcStatus
  ) => {
    const newValue = event.target.value;
    setStatus(newValue);
    // console.log("assign:", newValue);
    setoldid(assign_user);
    const oldValue = tcStatus; // store current before change

    sendStatusToBackend(
      newValue,
      event.target.name,
      personId,
      assign_user,
      assign_date,
      status_date,

      newValue,
      oldValue,
      setStatus
    );
    console.log("assigndata:", sendStatusToBackend);
  };

  const sendStatusToBackend = async (
    statusValue,
    statusType,
    p_emdid,
    assign_user,
    assign_date,
    status_date,
    oldValue,
    newValue,
    setStatus
  ) => {
    const id_p = project_id;
    const payload = {
      status: statusValue,
      type: statusType,
      assign_user_type: statusType,
      createdby: createdby,
      project_id: id_p,
      p_emdid: p_emdid,
      assign_user: assign_user,
      projectid: projectId,
      assigned_date: assign_date,
      status_date: status_date,
      type_sme: dataValue,
      delete: "1",
    };

    // Conditionally add 'delete' property
    // if (dataValue === "Publication Manager") {
    //   payload.delete = '1';
    // }
    //  if (dataValue === "reviewer") {
    //   payload.delete = '1';
    // }
    //  if (dataValue === "statistican") {
    //   payload.delete = '1';
    // }

    //         if (["Publication Manager", "reviewer", "statistican"].includes(dataValue)) {
    //   payload.delete = "1";
    // }

    //  togglePopup();
    // console.log("payload1234", payload);

    const result = await Swal.fire({
      title: "Are you sure?",
      html: `Are you sure you want to change status to "<b>${statusValue}</b>"?`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, change it!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";
      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/project_sme_status/${id_p}`,
            payload
          );

          // console.log("response1", response);

          if (response.status === 200) {
            Swal.fire("Success", "Status updated successfully", "success");
            fetchShowData(id);
          } else {
            Swal.fire("Error", "Failed to update the status", "error");
            setStatus(oldValue);
          }
        } catch (error) {
          console.error("Error updating status:", error); // Log any errors here
          Swal.fire("Error", "Failed to update the status", "error");
          setStatus(oldValue);
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    } else {
      // Cancel clicked → reset to "Select Status"
      setStatus(oldValue);
      setTcStatus("");
      // fetchShowData()
    }
  };

  // writer

  const handleReassignWriter = async (new_employee_id, assign_id) => {
    const payload1 = {
      project_id: project_id,
      employee_id: assign_id,
      new_employee_id: new_employee_id,
    };
    console.log("payloadwriter:", payload1);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to reassign this writer?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, reassign!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/update_status`,
            payload1
          );

          if (response.status === 200) {
            Swal.fire(
              "Success",
              "Writer reassigned successfully",
              "success"
            ).then(() => {
              window.location.reload();
            });
            // Call any data-refreshing function here, e.g. fetchShowData(project_id);
          } else {
            Swal.fire("Error", "Failed to reassign writer", "error");
          }
        } catch (error) {
          console.error("Reassign error:", error);
          Swal.fire("Error", "Failed to reassign writer", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  const handleReassignReviwer = async (new_employee_id, assign_id) => {
    const payload1 = {
      project_id: project_id,
      employee_id: assign_id,
      new_employee_id: new_employee_id,
    };
    console.log("payloadwriter:", payload1);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to reassign this Reviwer?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, reassign!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/update_status`,
            payload1
          );

          if (response.status === 200) {
            Swal.fire(
              "Success",
              "Reviwer reassigned successfully",
              "success"
            ).then(() => {
              window.location.reload();
            });
            // Call any data-refreshing function here, e.g. fetchShowData(project_id);
          } else {
            Swal.fire("Error", "Failed to reassign writer", "error");
          }
        } catch (error) {
          console.error("Reassign error:", error);
          Swal.fire("Error", "Failed to reassign writer", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  const handleReassignstatistican = async (new_employee_id, assign_id) => {
    const payload1 = {
      project_id: project_id,
      employee_id: assign_id,
      new_employee_id: new_employee_id,
    };
    console.log("payloadwriter:", payload1);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to reassign this writer?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, reassign!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/update_status`,
            payload1
          );

          if (response.status === 200) {
            Swal.fire(
              "Success",
              "Writer reassigned successfully",
              "success"
            ).then(() => {
              window.location.reload();
            });
            // Call any data-refreshing function here, e.g. fetchShowData(project_id);
          } else {
            Swal.fire("Error", "Failed to reassign writer", "error");
          }
        } catch (error) {
          console.error("Reassign error:", error);
          Swal.fire("Error", "Failed to reassign writer", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  // revert condition

  const handleRevertWriter = async (new_employee_id, assign_id) => {
    const payload1 = {
      project_id: project_id,
      type: "revert",
      employee_id: assign_id,
      new_employee_id: new_employee_id,
    };
    // console.log("payloadwriter:", payload1);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to reassign this Reviwer?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, reassign!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/update_status`,
            payload1
          );

          if (response.status === 200) {
            Swal.fire(
              "Success",
              "Reviwer reassigned successfully",
              "success"
            ).then(() => {
              window.location.reload();
            });
            // Call any data-refreshing function here, e.g. fetchShowData(project_id);
          } else {
            Swal.fire("Error", "Failed to reassign writer", "error");
          }
        } catch (error) {
          console.error("Reassign error:", error);
          Swal.fire("Error", "Failed to reassign writer", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  const handleRevertReviwer = async (new_employee_id, assign_id) => {
    const payload1 = {
      project_id: project_id,
      type: "revert",
      employee_id: assign_id,
      new_employee_id: new_employee_id,
    };
    console.log("payloadwriter:", payload1);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to reassign this Reviwer?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, reassign!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/update_status`,
            payload1
          );

          if (response.status === 200) {
            Swal.fire(
              "Success",
              "Reviwer reassigned successfully",
              "success"
            ).then(() => {
              window.location.reload();
            });
            // Call any data-refreshing function here, e.g. fetchShowData(project_id);
          } else {
            Swal.fire("Error", "Failed to reassign writer", "error");
          }
        } catch (error) {
          console.error("Reassign error:", error);
          Swal.fire("Error", "Failed to reassign writer", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  const handleRevertstatistican = async (new_employee_id, assign_id) => {
    const payload1 = {
      project_id: project_id,
      type: "revert",
      employee_id: assign_id,
      new_employee_id: new_employee_id,
    };
    // console.log("payloadwriter:", payload1);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to reassign this Reviwer?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, reassign!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/update_status`,
            payload1
          );

          if (response.status === 200) {
            Swal.fire(
              "Success",
              "Reviwer reassigned successfully",
              "success"
            ).then(() => {
              window.location.reload();
            });
            // Call any data-refreshing function here, e.g. fetchShowData(project_id);
          } else {
            Swal.fire("Error", "Failed to reassign writer", "error");
          }
        } catch (error) {
          console.error("Reassign error:", error);
          Swal.fire("Error", "Failed to reassign writer", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  // Assign
  // const Duration = getTotalDuration(selectedOption, type_of_work)

  const handleAssignWriter = async (new_employee_id) => {
    // console.log("summacheck:", documentname, type_of_work);
    const Duration = getTotalDuration(documentname, type_of_work);
    // console.log("Duration :", Duration);

    const payloadwriter = {
      project_id: project_id,
      assign_user: new_employee_id,
      created_by: createdby,
      type: "writer",
      project_duration: Duration.writer,
    };
    // console.log("payloadwriter:", payloadwriter);

    // const result = await Swal.fire({
    //   title: "Are you sure?",
    //   text: "Do you want to Assign this writer?",
    //   icon: "warning",
    //   showCancelButton: true,
    //   confirmButtonText: "Yes, Assign!",
    //   cancelButtonText: "Cancel",
    // });

    // if (result.isConfirmed) {
    document.getElementById("global-loader").style.display = "flex";

    setTimeout(async () => {
      try {
        const response = await axios.post(
          `${API_URL}/api/entry_process/assign-user-tc`,
          payloadwriter
        );

        if (response.status === 200) {
          Swal.fire("Success", "Writer assigned successfully", "success").then(
            () => {
              window.location.reload();
            }
          );
          // Call any data-refreshing function here, e.g. fetchShowData(project_id);
        } else {
          Swal.fire("Error", "Failed to assign writer", "error");
        }
      } catch (error) {
        console.error("assign error:", error);
        Swal.fire("Error", "Failed to assign writer", "error");
      } finally {
        document.getElementById("global-loader").style.display = "none";
      }
    }, 500);
    // }
  };

  const handleAssignReviewer = async (new_employee_id) => {
    // console.log("summacheck:", documentname, type_of_work);
    const Duration = getTotalDuration(documentname, type_of_work);
    // console.log("Duration :", Duration);

    const payloadwriter = {
      project_id: project_id,
      assign_user: new_employee_id,
      created_by: createdby,
      type: "reviewer",
      project_duration: Duration.reviewer,
    };
    // console.log("payloadwriter:", payloadwriter);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to Assign this reviewer?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Assign!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/assign-user-tc`,
            payloadwriter
          );

          if (response.status === 200) {
            Swal.fire(
              "Success",
              "Reviewer assigned successfully",
              "success"
            ).then(() => {
              window.location.reload();
            });
            // Call any data-refreshing function here, e.g. fetchShowData(project_id);
          } else {
            Swal.fire("Error", "Failed to assign writer", "error");
          }
        } catch (error) {
          console.error("assign error:", error);
          Swal.fire("Error", "Failed to assign writer", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  const handleAssignStatistican = async (new_employee_id) => {
    // console.log("summacheck:", documentname, type_of_work);
    const Duration = getTotalDuration(documentname, type_of_work);
    // console.log("Duration :", Duration);

    const payloadwriter = {
      project_id: project_id,
      assign_user: new_employee_id,
      created_by: createdby,
      type: "statistican",
      project_duration: Duration.statistician,
    };
    // console.log("payloadwriter:", payloadwriter);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to Assign this statistican?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Assign!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/assign-user-tc`,
            payloadwriter
          );

          if (response.status === 200) {
            Swal.fire(
              "Success",
              "statistican Assigned successfully",
              "success"
            ).then(() => {
              window.location.reload();
            });
            // Call any data-refreshing function here, e.g. fetchShowData(project_id);
          } else {
            Swal.fire("Error", "Failed to assign writer", "error");
          }
        } catch (error) {
          console.error("assign error:", error);
          Swal.fire("Error", "Failed to assign writer", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  const [isSubmenuOpen, setIsSubmenuOpen] = useState(false);

  const toggleSubmenu = () => {
    setIsSubmenuOpen((prev) => !prev);
  };
  const closeSidebar = () => {
    setIsSubmenuOpen(false);
  };

  // useEffect(() => {
  //   const handleLoad = () => {
  //     setTimeout(() => {
  //       setLoading(false);
  //     }, 5000);
  //   };

  //   if (document.readyState === "complete") {
  //     handleLoad();
  //   } else {
  //     window.addEventListener("load", handleLoad);
  //   }

  //   return () => window.removeEventListener("load", handleLoad);
  // }, []);

  // if (loading) {
  //   return <Loader />;
  // }

  const getFileIcon = (type) => {
    const imageFormats = [
      "jpg",
      "png",
      "gif",
      "jpeg",
      "svg",
      "txt",
      "PNG",
      "JPG",
      "SVG",
    ];
    const excelFormats = ["xlsx", "xls", "csv"];
    const wordFormats = ["docx", "doc", "word"];
    const pptFormats = ["ppt", "pptx"];
    const SavFormats = ["sav"];
    const ZipFormats = ["zip"];

    if (imageFormats.includes(type)) {
      return <img src={Image} className="img-view" alt="Image" />;
    }
    if (SavFormats.includes(type)) {
      return <img src={Sav} className="img-view" alt="Image" />;
    }

    if (excelFormats.includes(type)) {
      return <img src={Excel} className="img-view" alt="Excel" />;
    }

    if (wordFormats.includes(type)) {
      return <img src={Word} className="img-view" alt="Word" />;
    }

    if (pptFormats.includes(type)) {
      return <img src={ppt} className="img-view" alt="ppt" />;
    }
     if (ZipFormats.includes(type)) {
      return <img src={Zip} className="img-view" alt="zip" />;
    }

    if (type === "pdf") {
      return <img src={PDF} className="img-view" alt="PDF" />;
    }

    return null;
  };

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div className="app-background">
          <section className="container d-flex flex-column justify-content-between min-vh-100">
            <div className="row mt-4">
              <div className="col-12">
                <Header />
                <div className="col-12  mt-3 project-manage-view pb-3 w-100">
                  <div className=" row mt-3 d-flex   w-100 ">
                    <div className="col-12 col-md-6  px-4 ">
                      <p className="view-heading mt-3">
                        {" "}
                        {CapitalizeCase(fetchData.project_id)}
                      </p>
                    </div>
                    {(positionData === "Admin" || positionData === "13") && (
                      <div className="col-6 pt-3 px-2 d-none d-md-block text-end">
                        <Breadcrumbs />
                      </div>
                    )}
                    {(positionData !== "Admin" || positionData !== "13") && (
                      <div className="col-6 pt-3 px-2 d-none d-md-block text-end">
                        {rolename.includes(28) && (
                          <div>
                            <Link
                              to="/sme-dashboard"
                              className="breadcrumbs-project"
                            >
                              Home
                              <span className="arrow mx-1">
                                <FontAwesomeIcon icon={faChevronRight} />
                              </span>
                              {id}
                            </Link>
                          </div>
                        )}
                        {rolename.includes(27) && (
                          <div>
                            <Link
                              to="/publication-dashboard"
                              className="breadcrumbs-project"
                            >
                              Home
                              <span className="arrow mx-1">
                                <FontAwesomeIcon icon={faChevronRight} />
                              </span>
                              {id}
                            </Link>
                          </div>
                        )}
                        {rolename.includes(14) && (
                          <div>
                            <Link
                              to="/team-coordinator-dashboard"
                              className="breadcrumbs-project"
                            >
                              Home
                              <span className="arrow mx-1">
                                <FontAwesomeIcon icon={faChevronRight} />
                              </span>
                              {id}
                            </Link>
                          </div>
                        )}
                        {emp_type === "freelancers" && (
                          <div>
                            <Link
                              to="/freelancer-dashboard"
                              className="breadcrumbs-project"
                            >
                              Home
                              <span className="arrow mx-1">
                                <FontAwesomeIcon icon={faChevronRight} />
                              </span>
                              {id}
                            </Link>
                          </div>
                        )}
                        {(emp_type === "full_time" ||
                          emp_type === "part_time") &&
                          !rolename.includes("Admin") &&
                          !rolename.includes(13) &&
                          !rolename.includes(14) &&
                          !rolename.includes(23) &&
                          !rolename.includes(28) &&
                          !rolename.includes(27) && (
                            <div>
                              <Link
                                to="/internal-dashboard"
                                className="breadcrumbs-project"
                              >
                                Home{" "}
                                <span className="arrow mx-1">
                                  <FontAwesomeIcon icon={faChevronRight} />
                                </span>
                                {id}
                              </Link>
                            </div>
                          )}
                      </div>
                    )}
                  </div>

                  <div className="row">
                    <section className="col-7 view-border-div">
                      <section className="pt-1">
                        <div className="file-table-container mt-0 ">
                          <table className="file-table">
                            <thead>
                              <tr className="text-center tr-head">
                                <th className="table-task-view">Date</th>
                                <th className="table-task-view" colSpan={2}>
                                  Created by
                                </th>

                                <th className="table-task-view">Files</th>
                                <th className="table-task-view " rowSpan={5}>
                                  Comments
                                </th>
                                {/* <th className="table-task-view">ACTIONS</th> */}
                              </tr>
                            </thead>
                            <tbody>
                              {createdbyFiles.length === 0 ? (
                                <tr className="text-center">
                                  <td colSpan="6">No records found</td>
                                </tr>
                              ) : (
                                createdbyFiles.map((file, index) => (
                                  <tr
                                    key={index}
                                    className="text-center tr-head"
                                  >
                                    <td className="task-view-table-name">
                                      {/* {getTimeDateFormate(file.added_at)} */}
                                      {getTimeDateFormate(file.added_at)}
                                    </td>

                                    <td className="task-view-table-name">
                                      {CapitalizeCase(file.employee_name)}
                                    </td>
                                    <td className="task-view-table-name">
                                      {(file.role_name || "")
                                        .split(",")
                                        .map(
                                          (role) =>
                                          ({ 7: "Writer", 8: "Reviewer" }[
                                            role.trim()
                                          ] || role.trim())
                                        )
                                        .join(", ")}
                                    </td>

                                    {/* <td className="task-view-table-name">
                                      <div className="d-flex flex-row gap-2">
                                        {file.files?.map(
                                          (singleFile, fileIndex) => (
                                            <div
                                              key={fileIndex}
                                              title={`${singleFile.file_name}\nUploaded: ${singleFile.created_at}\nType`}
                                              style={{ position: "relative" }}
                                            >
                                              <span
                                                onClick={() =>
                                                  handleDownload(
                                                    singleFile.file_path,
                                                    singleFile.file_name
                                                  )
                                                }
                                                style={{ cursor: "pointer" }}
                                              >
                                                {getFileIcon(
                                                  singleFile.extension
                                                )}
                                              </span>
                                            
                                            </div>
                                          )
                                        )}
                                      </div>
                                    </td> */}

                                    <td className="task-view-table-name">
                                      <div className="d-flex flex-row gap-2 align-items-center">
                                        {file.files?.slice(0, 2).map((singleFile, fileIndex) => (
                                          <span
                                            key={fileIndex}
                                            title={singleFile.file_name}
                                            onClick={() =>
                                              handleDownload(singleFile.file_path, singleFile.file_name)
                                            }
                                            style={{ cursor: "pointer" }}
                                          >
                                            {getFileIcon(singleFile.extension)}
                                          </span>
                                        ))}

                                        {/* Show ... if more than 2 files */}
                                        {file.files?.length > 2 && (
                                          <span
                                            className="fw-bold cursor-pointer"
                                            style={{ cursor: "pointer" }}
                                            onClick={() => openFilesModal(file.files)}
                                          >
                                            ...
                                          </span>
                                        )}
                                      </div>
                                    </td>

                                    <td className="task-view-table-name-scroll">
                                      <div className="task-view-table-content commend-width">
                                        <div key={index}>
                                          <span
                                            // className="span-view-task"
                                            dangerouslySetInnerHTML={{
                                              __html: file.comments,
                                            }}
                                          />
                                        </div>
                                      </div>
                                    </td>
                                    {/* <td>
                                    <button
                                      className="download-button-file"
                                      onClick={() => handleDownload(file.files)}
                                    >
                                      <FiDownload />
                                    </button>
                                  </td> */}
                                  </tr>
                                ))
                              )}
                            </tbody>
                          </table>
                        </div>
                      </section>
                      {widthdraw === "withdrawal" && (
                        <div class="withdrawn-style">Withdrawn</div>
                      )}
                    </section>

                    {showFilesModal && (
                      <>
                        <div className="custom-modal-box">
                          <div className="modal-dialog-box modal-dialog-centered">
                            <div className="modal-content">
                              <div className="modal-header">
                                <h5 className="modal-title">Files</h5>
                                <button
                                  type="button"
                                  className="btn-close"
                                  onClick={closeFilesModal}
                                ></button>
                              </div>

                              <div className="modal-body pdf-modal-body">
                                {modalFiles
                                  .filter((file) => file.extension)
                                  .map((file, index) => (
                                    <div
                                      key={index}
                                      className="pdf-row"
                                      onClick={() =>
                                        handleDownload(file.file_path, file.file_name)
                                      }
                                    >
                                      <div className="pdf-icon">
                                        {getFileIcon(file.extension)}
                                      </div>

                                      <div className="pdf-name">
                                        {file.file_name}
                                      </div>
                                    </div>
                                  ))}
                              </div>


                              <div className="modal-footer">
                                <button
                                  className="btn btn-secondary"
                                  onClick={closeFilesModal}
                                >
                                  Close
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="custom-backdrop" onClick={closeFilesModal}></div>
                      </>
                    )}


                    <section className="col-sm-12 col-md-5 ">
                      <div>
                        <div className="row ">
                          <div className="col-12 float-start">
                            <div className="col-12 ">
                              <div className="view-heading-title ">
                                Project Title:
                                <span className="view-project-title mx-2 ">
                                  {CapitalizeCase(fetchData.title)}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="col-12 d-flex justify-content-start gap-3 px-3 mt-2">
                          {widthdraw !== "withdrawal" &&
                            projectStatusCheck !== "accepted" &&
                            projectStatusCheck !== "rejected" &&
                            // reviewer !== "revert" &&
                            // writer !== "revert" &&
                            // statistician !== "revert" &&
                            // rejectreason?.length === 0 &&
                            rolename !== "Admin" &&
                            rolename !== "13" &&
                            rolename !== "14" &&
                            rolename !== "28" && (
                              <button
                                className="view-rej "
                                onClick={handleRejectClick}
                              >
                                Reject
                              </button>
                            )}

                          {widthdraw !== "withdrawal" &&
                            // reviewer !== "revert" &&
                            // writer !== "revert" &&
                            // statistician !== "revert" &&
                            projectStatusCheck !== "rejected" &&
                            projectStatusCheck !== "accepted" &&
                            rolename !== "Admin" &&
                            rolename !== "13" &&
                            rolename !== "14" &&
                            rolename !== "28" && (
                              <button
                                className="view-accept "
                                onClick={handleAcceptClick}
                              >
                                Accept
                              </button>
                            )}
                        </div>
                        {rolename !== "Admin" &&
                          rolename !== "13" &&
                          rolename !== "14" &&
                          rolename !== "28" && (
                            <div className="file-container m-0 mt-3">
                              <div className="view-heading-title">
                                Project Comments:
                                <span className="command-project mx-2">
                                  {/* Render project comments with formatting */}
                                  {projectcomments.map((comment, index) => (
                                    <div key={index} className="px-2">
                                      {removeHtmlTags(
                                        comment.commend_box || ""
                                      )}
                                    </div>
                                  ))}
                                </span>
                              </div>

                              <div className="view-heading-title mt-2">
                                {projectcommetnsR.map((comment, index) => {
                                  return (
                                    <div
                                      key={index}
                                      className="command-project"
                                    >
                                      <div className="d-flex align-items-center mt-3 view-heading-title">
                                        <div>Notes:</div>{" "}
                                        <span className="command-project mx-2">
                                          {comment.comments}
                                        </span>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                              <div className="view-heading-title ">
                                Project Requirement:
                                <span className="mx-1">
                                  {alldocumnts.map((item, index) => (
                                    <span key={index} className="mx-1">
                                      {CapitalizeCase(item)}
                                      {index !== alldocumnts.length - 1 && ","}
                                    </span>
                                  ))}
                                </span>
                              </div>

                              <div className="row  pb-0">
                                <div className="col-12  pb-0">
                                  <div className="view-heading-title mt-3 ">
                                    Common Files :
                                  </div>
                                  <div className="d-flex flex-row gap-2">
                                    {commonFiles.map((fileGroup, groupIndex) =>
                                      // For each group, render all files in that group
                                      Object.values(fileGroup).map(
                                        (singleFile, fileIndex) =>
                                          singleFile &&
                                          singleFile.file && (
                                            <div
                                              key={`${groupIndex}-${fileIndex}`}
                                              title={`${singleFile.original_name}\nUploaded`}
                                              style={{ position: "relative" }}
                                            >
                                              <span
                                                onClick={() =>
                                                  handleCommonFileDownload(
                                                    singleFile.file,
                                                    singleFile.original_name
                                                  )
                                                }
                                                style={{ cursor: "pointer" }}
                                              >
                                                {getFileIcon(
                                                  singleFile.original_name
                                                    .split(".")
                                                    .pop()
                                                )}
                                              </span>
                                            </div>
                                          )
                                      )
                                    )}
                                  </div>
                                </div>
                              </div>
                              {/* Popup */}
                              {isPopupOpen && (
                                <div className="modal-container-view">
                                  <div className="modal-box">
                                    <div className="d-flex justify-content-end">
                                      <span
                                        className="modal-close"
                                        onClick={togglePopup}
                                      >
                                        &times;
                                      </span>
                                    </div>
                                    <div className="modal-body">
                                      <p className="view-project-title1 w-100">
                                        {CapitalizeCase(id)}
                                      </p>
                                      <input
                                        type="file"
                                        accept="file/*"
                                        multiple
                                        className="pt-3 mt-3 file-upload-input dropdown-header-view  "
                                        onChange={(e) => {
                                          handleFileChange(e);
                                          setErrors((prevErrors) => ({
                                            ...prevErrors,
                                            file: "",
                                          }));
                                        }}
                                      />
                                      {errors.file && (
                                        <p className="error-text">
                                          {errors.file}
                                        </p>
                                      )}
                                    </div>
                                    <div className="modal-footer gap-2 mt-3">
                                      <button
                                        className="view-rej"
                                        onClick={togglePopup}
                                      >
                                        Cancel
                                      </button>
                                      <button
                                        className="view-accept"
                                        onClick={handleUploadSubmit}
                                      >
                                        Submit
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              )}

                              {/* revert popup */}
                            </div>
                          )}

                        {/* popup */}
                        {isPopupVisible && (
                          <div className="modal-container-view">
                            <div className="modal-box">
                              <div className="d-flex justify-content-end">
                                <span
                                  className="modal-close"
                                  onClick={handleCancel}
                                >
                                  &times;
                                </span>
                              </div>
                              <div className="modal-body">
                                <p className=" view-project-title1  w-100">
                                  {CapitalizeCase(id)}
                                </p>
                                <textarea
                                  value={reason}
                                  onChange={handleReasonChange}
                                  placeholder="Enter your reason here"
                                  className="textarea-field"
                                ></textarea>

                                {errors.reason && (
                                  <p className="warning-text">
                                    {errors.reason}
                                  </p>
                                )}
                              </div>
                              <div className="modal-footer gap-2 mt-2 ">
                                <button
                                  className="view-rej"
                                  onClick={handleCancel}
                                >
                                  Cancel
                                </button>

                                <button
                                  className="view-accept"
                                  onClick={handleSubmit}
                                >
                                  Submit
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* revert */}

                        {isPopupVisiblerevert && (
                          <div className="modal-container-view">
                            <div className="modal-box">
                              <div className="d-flex justify-content-end">
                                <span
                                  className="modal-close"
                                  onClick={handleCancelrevert}
                                >
                                  &times;
                                </span>
                              </div>
                              <div className="modal-body">
                                <p className=" view-project-title1  w-100">
                                  {CapitalizeCase(id)}
                                </p>
                                <textarea
                                  value={reasonrevert}
                                  onChange={handleReasonChangerevert}
                                  placeholder="Enter your reason here"
                                  className="textarea-field"
                                ></textarea>

                                {errors.reasonrevert && (
                                  <p className="warning-text">
                                    {errors.reasonrevert}
                                  </p>
                                )}
                              </div>
                              <div className="modal-footer gap-2 mt-2 ">
                                <button
                                  className="view-rej"
                                  onClick={handleCancelrevert}
                                >
                                  Cancel
                                </button>

                                <button
                                  className="view-accept"
                                  onClick={handleSubmitrevert}
                                >
                                  Submit
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* {projectStatusCheck === "accepted" &&
                        rolename !== "Admin" &&
                        rolename !== "13" &&
                        rolename !== "14" &&
                        rolename !== "28" && (
                          <>
                            {((allrole_type === "Writer" &&
                              writer !== "completed") ||
                              (allrole_type === "Reviewer" &&
                                reviewer !== "completed") ||
                              (allrole_type === "Statistican" &&
                                statistician !== "completed")) && (
                                  */}
                        <>
                          {projectStatusCheck === "accepted" && (
                            <div className="row  pb-0">
                              <div className="col-12   pb-0">
                                <div className="view-heading-title mt-3  ">
                                  Activity
                                  {/* summa test */}
                                </div>
                              </div>
                            </div>
                          )}
                          {projectStatusCheck === "accepted" && (
                            <section className="">
                              <div className="px-2  all-boder">
                                <div className="col-10  pt-0 box-line mt-2">
                                  <Editor
                                    key={editorKey}
                                    placeholder="Type your comment..."
                                    name="commandbox"
                                    value={formData.commandbox}
                                    onTextChange={handleTextChange}
                                    className={
                                      editorError ? "editor-error" : ""
                                    }
                                  />
                                </div>

                                {editorError && (
                                  <div className="error-text">
                                    This field is required
                                  </div>
                                )}

                                <section className="mt-2">
                                  <div className="d-flex gap-2 align-items-center">
                                    <div className="view-heading-title">
                                      Files Upload :
                                    </div>{" "}
                                    <input
                                      ref={fileInputRef}
                                      type="file"
                                      multiple
                                      className="input-file-upload"
                                      onChange={(e) => {
                                        handleActivityFileChange(e);
                                      }}
                                    />
                                  </div>
                                  <div>
                                    <button
                                      className="save-form-task mb-2 mt-1 pt-1"
                                      onClick={handleEditorChange}
                                    >
                                      Submit
                                    </button>
                                  </div>
                                </section>
                              </div>
                            </section>
                          )}
                        </>
                        {/* )}
                          </>
                        )} */}

                        {/*assign people       */}

                        {(rolename === "Admin" ||
                          rolename === "13" ||
                          rolename === "14" ||
                          rolename === "28") && (
                            <>
                              <div className="file-container m-0 ">
                                <div className="view-heading-title mt-2 ">
                                  Project Comments:
                                  <span className="command-project mx-2">
                                    {projectcomments.map((comment, index) => (
                                      <div key={index} className="px-2">
                                        {removeHtmlTags(
                                          comment.commend_box || ""
                                        )}
                                      </div>
                                    ))}
                                  </span>
                                </div>
                                <div className="view-heading-title mt-2">
                                  <div className="command-project ">
                                    {/* Writer Notes */}
                                    {fetchData.writer_data &&
                                      fetchData.writer_data.length > 0 && (
                                        <>
                                          {fetchData.writer_data.map(
                                            (writer, index) => (
                                              <div
                                                key={index}
                                                className="d-flex align-items-center mt-3"
                                              >
                                                <div>
                                                  {/* Writer Notes-{index + 1} : */}
                                                  {
                                                    writer.user_date
                                                      ?.employee_name
                                                  }{" "}
                                                  Notes :
                                                </div>{" "}
                                                {writer.comments}
                                              </div>
                                            )
                                          )}
                                        </>
                                      )}

                                    {/* Reviewer Notes */}
                                    {fetchData.reviewer_data &&
                                      fetchData.reviewer_data.length > 0 && (
                                        <>
                                          {fetchData.reviewer_data.map(
                                            (reviewer, index) => (
                                              <div
                                                key={index}
                                                className="d-flex align-items-center mt-3"
                                              >
                                                <div>
                                                  {/* Reviewer Notes-{index + 1} : */}
                                                  {
                                                    reviewer.user_date
                                                      ?.employee_name
                                                  }{" "}
                                                  Notes :
                                                </div>{" "}
                                                {reviewer.comments}
                                              </div>
                                            )
                                          )}
                                        </>
                                      )}

                                    {/* Statistician Notes */}
                                    {fetchData.statistican_data &&
                                      fetchData.statistican_data.length > 0 && (
                                        <>
                                          {fetchData.statistican_data.map(
                                            (statistican, index) => (
                                              <div
                                                key={index}
                                                className="d-flex align-items-center mt-3"
                                              >
                                                <div>
                                                  {/* Statistician Notes-{index + 1} : */}
                                                  {
                                                    statistican.user_date
                                                      ?.employee_name
                                                  }{" "}
                                                  Notes :
                                                </div>{" "}
                                                {statistican.comments}
                                              </div>
                                            )
                                          )}
                                        </>
                                      )}

                                    {/* Journal Notes */}
                                    {fetchData.journal_data &&
                                      fetchData.journal_data.length > 0 && (
                                        <>
                                          {fetchData.journal_data.map(
                                            (journal, index) => (
                                              <div
                                                key={index}
                                                className="d-flex align-items-center mt-3"
                                              >
                                                <div>
                                                  Journal Notes-{index + 1} :
                                                </div>{" "}
                                                {journal.comments}
                                              </div>
                                            )
                                          )}
                                        </>
                                      )}
                                  </div>

                                  {/* Popup */}
                                  {isPopupOpen && (
                                    <div className="modal-container-view">
                                      <div className="modal-box">
                                        <div className="d-flex justify-content-end">
                                          <span
                                            className="modal-close"
                                            onClick={togglePopup}
                                          >
                                            &times;
                                          </span>
                                        </div>
                                        <div className="modal-body">
                                          <p className="view-project-title1 w-100">
                                            {CapitalizeCase(id)}
                                          </p>

                                          {/* Dropdown for project status */}
                                          {initialCategory !== "others" && (
                                            <>
                                              <div
                                                ref={dropselectRef}
                                                className="dropdown-container position-relative"
                                              >
                                                <div
                                                  className="form-select dropdown-header-view pt-2 px-2"
                                                  onClick={toggleDropcheck}
                                                >
                                                  {projectStatus.length > 0
                                                    ? projectStatus.join(", ")
                                                    : "Select Options"}
                                                </div>
                                                {isDropdowncheck && (
                                                  <div className="dropdown-list">
                                                    {optionsMapping[
                                                      initialCategory
                                                    ]?.map((option) => (
                                                      <label
                                                        key={option.value}
                                                        className="checkbox-label"
                                                      >
                                                        <input
                                                          type="checkbox"
                                                          value={option.value}
                                                          checked={projectStatus.includes(
                                                            option.value
                                                          )}
                                                          onChange={
                                                            handleOptionChange
                                                          }
                                                          onMouseDown={(e) =>
                                                            e.preventDefault()
                                                          } // Prevent focus loss
                                                        />
                                                        {option.label}
                                                      </label>
                                                    ))}
                                                  </div>
                                                )}
                                                {errors.projectStatus && (
                                                  <p className="error-text">
                                                    {errors.projectStatus}
                                                  </p>
                                                )}
                                              </div>
                                            </>
                                          )}

                                          {/* Input for 'Other' */}
                                          {(projectStatus.includes("Other") ||
                                            initialCategory === "others") && (
                                              <div>
                                                <input
                                                  type="text"
                                                  className="dropdown-header-view"
                                                  value={otherInput}
                                                  onChange={handleOtherInputChange}
                                                  placeholder="Please specify"
                                                />
                                              </div>
                                            )}

                                          {/* File Upload */}
                                          <input
                                            type="file"
                                            accept="file/*"
                                            multiple
                                            className="pt-3 mt-3 file-upload-input dropdown-header-view"
                                            onChange={(e) => {
                                              handleFileChange(e);
                                              setErrors((prevErrors) => ({
                                                ...prevErrors,
                                                file: "",
                                              }));
                                            }}
                                          />
                                          {errors.file && (
                                            <p className="error-text">
                                              {errors.file}
                                            </p>
                                          )}
                                        </div>

                                        {/* Modal Footer */}
                                        <div className="modal-footer gap-2 mt-3">
                                          <button
                                            className="view-rej"
                                            onClick={togglePopup}
                                          >
                                            Cancel
                                          </button>
                                          <button
                                            className="view-accept"
                                            onClick={handleUploadSubmit}
                                          >
                                            Submit
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                </div>
                                <div className="row  pb-0 mt-3">
                                  <div className="view-heading-title ">
                                    Project Requirement:
                                    <span className="mx-1">
                                      {alldocumnts.map((item, index) => (
                                        <span key={index} className="mx-1">
                                          {CapitalizeCase(item)}
                                          {index !== alldocumnts.length - 1 &&
                                            ","}
                                        </span>
                                      ))}{" "}
                                    </span>
                                  </div>
                                </div>

                                <div className="row   pb-0 mt-3">
                                  <div className="col-12  pb-0">
                                    <div className="view-heading-title  ">
                                      Common Files :
                                    </div>
                                    <div className="d-flex flex-row gap-2">
                                      {commonFiles.map((fileGroup, groupIndex) =>
                                        // For each group, render all files in that group
                                        Object.values(fileGroup).map(
                                          (singleFile, fileIndex) =>
                                            singleFile &&
                                            singleFile.file && (
                                              <div
                                                key={`${groupIndex}-${fileIndex}`}
                                                title={`${singleFile.original_name}\nUploaded`}
                                                style={{ position: "relative" }}
                                              >
                                                <span
                                                  onClick={() =>
                                                    handleCommonFileDownload(
                                                      singleFile.file,
                                                      singleFile.original_name
                                                    )
                                                  }
                                                  style={{ cursor: "pointer" }}
                                                >
                                                  {getFileIcon(
                                                    singleFile.original_name
                                                      .split(".")
                                                      .pop()
                                                  )}
                                                </span>
                                              </div>
                                            )
                                        )
                                      )}
                                    </div>
                                  </div>
                                </div>

                                <div className="row  pb-0">
                                  <div className="col-12  pb-0">
                                    <div className="view-heading-title mt-3 ">
                                      Activity
                                    </div>
                                  </div>
                                </div>

                                <section className="">
                                  <div className="px-2   all-boder">
                                    <div className="col-10  pt-0 box-line mt-2">
                                      <Editor
                                        key={editorKey}
                                        placeholder="Type your comment..."
                                        name="commandbox"
                                        value={formData.commandbox}
                                        onTextChange={handleTextChange}
                                        className={
                                          editorError ? "editor-error" : ""
                                        }
                                      />
                                    </div>
                                    {editorError && (
                                      <div className="error-text">
                                        This field is required
                                      </div>
                                    )}

                                    <section className="mt-2">
                                      <div className="d-flex gap-2 align-items-center">
                                        <div className="view-heading-title">
                                          Files Upload :
                                        </div>{" "}
                                        <input
                                          ref={fileInputRef}
                                          type="file"
                                          multiple
                                          className="input-file-upload"
                                          onChange={(e) => {
                                            handleActivityFileChange(e);
                                          }}
                                        />
                                      </div>
                                      <div>
                                        <button
                                          className="save-form-task mb-2 mt-1 pt-1"
                                          onClick={handleEditorChange}
                                        >
                                          Submit
                                        </button>
                                      </div>
                                    </section>
                                  </div>
                                </section>
                              </div>
                            </>
                          )}

                        {/* reject */}
                        {projectStatusCheck === "rejected" && (
                          <section>
                            <div className="d-flex flex-wrap gap-2 px-3 mt-3">
                              {rolename !== "Admin" &&
                                rolename !== "13" &&
                                rolename !== "14" &&
                                rolename !== "28" && (
                                  <div className="view-rej">Rejected</div>
                                )}
                            </div>
                            {rejectreason.map((reason) => {
                              const createdDate = new Date(reason.created_date);
                              const isRecent =
                                Date.now() - createdDate.getTime() <
                                7 * 24 * 60 * 60 * 1000;

                              return (
                                <div
                                  key={reason.id}
                                  className="w-100 d-flex px-3 gap-3 mt-2"
                                >
                                  <div className="align-items-center  mt-3">
                                    <img
                                      src={
                                        reason.created_by_user?.profile_image
                                          ? `${HRMS_API_URL}/${reason.created_by_user.profile_image}`
                                          : Profile
                                      }
                                      className="dropdown-selected-img me-2"
                                      alt="Profile"
                                    />
                                  </div>
                                  <div>
                                    <div className="d-flex project-head gap-2 mt-2">
                                      <div className="view-names1 pt-2">
                                        {CapitalizeCase(reason.createdby_name)}
                                      </div>
                                      <div className="created-min pt-2">
                                        {/* Display relative time for recent dates, or formatted date otherwise */}
                                        {isRecent
                                          ? formatDistanceToNow(createdDate, {
                                            addSuffix: true,
                                          }) // e.g., "5 min ago"
                                          : format(
                                            createdDate,
                                            "MMM d, yyyy"
                                          )}{" "}
                                        {/* e.g., "July 22, 2024" */}
                                        {format(
                                          reason.created_date,
                                          "MMM d, yyyy"
                                        )}{" "}
                                        at {format(createdDate, "h:mm a")}
                                      </div>
                                    </div>
                                    <div>
                                      <p className="view-project-title1 mt-2">
                                        {CapitalizeCase(reason.content)}{" "}
                                        {/* Display the rejection reason content */}
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </section>
                        )}

                        {/* revert */}

                        {((allrole_type === "Writer" && writer === "revert") ||
                          (allrole_type === "Reviewer" &&
                            reviewer === "revert") ||
                          (allrole_type === "Statistican" &&
                            statistician === "revert")) && (
                            <section>
                              <div className="d-flex flex-wrap gap-2 px-3 mt-3">
                                {rolename !== "Admin" &&
                                  rolename !== "13" &&
                                  rolename !== "14" &&
                                  rolename !== "28" && (
                                    <div className="view-pending">Reverted</div>
                                  )}
                              </div>
                              {rejectreason.map((reason) => {
                                const createdDate = new Date(reason.created_date);
                                const isRecent =
                                  Date.now() - createdDate.getTime() <
                                  7 * 24 * 60 * 60 * 1000;

                                return (
                                  <div
                                    key={reason.id}
                                    className="w-100 d-flex px-3 gap-3 mt-2"
                                  >
                                    <div className="align-items-center  mt-3">
                                      <img
                                        src={
                                          reason.created_by_user?.profile_image
                                            ? `${HRMS_API_URL}/${reason.created_by_user.profile_image}`
                                            : Profile
                                        }
                                        className="dropdown-selected-img me-2"
                                        alt="Profile"
                                      />
                                    </div>
                                    <div>
                                      <div className="d-flex project-head gap-2 mt-2">
                                        <div className="view-names1 pt-2">
                                          {CapitalizeCase(reason.createdby_name)}
                                        </div>
                                        <div className="created-min pt-2">
                                          {/* Display relative time for recent dates, or formatted date otherwise */}
                                          {isRecent
                                            ? formatDistanceToNow(createdDate, {
                                              addSuffix: true,
                                            }) // e.g., "5 min ago"
                                            : format(
                                              createdDate,
                                              "MMM d, yyyy"
                                            )}{" "}
                                          {/* e.g., "July 22, 2024" */}
                                          {format(
                                            reason.created_date,
                                            "MMM d, yyyy"
                                          )}{" "}
                                          at {format(createdDate, "h:mm a")}
                                        </div>
                                      </div>
                                      <div>
                                        <p className="view-project-title1 mt-2">
                                          {CapitalizeCase(reason.content)}{" "}
                                          {/* Display the rejection reason content */}
                                        </p>
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </section>
                          )}

                        {/* rejecticon */}
                        {(rolename === "13" ||
                          rolename === "14" ||
                          rolename === "28" ||
                          rolename === "Admin") && (
                            <div className="d-flex justify-content-end">
                              {/* add form teamcoordinator  */}

                              {(rolename === "14" || rolename === "28") && (
                                <div className="d-flex justify-content-end">
                                  <Link
                                    to={`/entry-process/entryprocess-update-form?id=${project_id}`}
                                    target="_blank"
                                  >
                                    <div
                                      className="reject-icon mt-2 pt-2"
                                      title="Add form"
                                    >
                                      <IoIosAddCircleOutline size={"30px"} />
                                    </div>
                                  </Link>
                                </div>
                              )}
                              {/* ///////////////// */}

                              {rolename !== "28" && (
                                <div
                                  className="reject-icon mt-2 pt-2"
                                  title="Rejected List"
                                  onClick={rejectallicon}
                                >
                                  <CiCircleInfo size={"30px"} />
                                </div>
                              )}
                              {isrejectapp && (
                                <div className="modal-container-view">
                                  <div className="modal-box-rejected">
                                    <div className="d-flex justify-content-end">
                                      <div className="view-project-title1 pt-2 w-100">
                                        {CapitalizeCase(id)}
                                      </div>
                                      <div
                                        className="modal-close"
                                        onClick={rejectallicon}
                                      >
                                        &times;
                                      </div>
                                    </div>
                                    <div className="modal-body">
                                      <div class="mt-3 table-responsive  table-wrapper-scroll-y my-custom-scrollbar1  ">
                                        <table className="table-head">
                                          <thead className="text-center tr-head">
                                            <tr>
                                              <th>Name</th>
                                              <th>Role</th>
                                              <th>Status</th>
                                              <th>Date</th>
                                              <th>Reason</th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                            {rejectlist.length > 0 ? (
                                              rejectlist.map((item, index) => (
                                                <tr key={index}>
                                                  <td>{item.employee_name}</td>
                                                  <td>{item.name}</td>
                                                  <td className="rejected-text">
                                                    {item.status}
                                                  </td>
                                                  <td>{item.updated_at}</td>
                                                  <td>{item.reason}</td>
                                                </tr>
                                              ))
                                            ) : (
                                              <tr>
                                                <td
                                                  colSpan="5"
                                                  className="text-center"
                                                >
                                                  No Reject data available
                                                </td>
                                              </tr>
                                            )}
                                          </tbody>
                                        </table>
                                      </div>
                                    </div>

                                    {/* Modal Footer */}
                                    <div className="modal-footer gap-2 mt-3">
                                      <button
                                        className="view-rej"
                                        onClick={rejectallicon}
                                      >
                                        Cancel
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                          )}

                        {/* ............................. */}

                        {/* Popup Reject Reason */}
                        {isPopupVisibleReject &&
                          rejectReasonData?.length > 0 && (
                            <div className="modal-container-view">
                              <div className="modal-box">
                                <div className="d-flex justify-content-end">
                                  <span
                                    className="modal-close"
                                    onClick={toggleRejectPopup}
                                  >
                                    &times;
                                  </span>
                                </div>
                                <div className="modal-body">
                                  <p className="view-heading w-100">
                                    {CapitalizeCase(id)}
                                  </p>

                                  <div className="d-flex align-items-center gap-1">
                                    <p className="created-by pt-1">
                                      Created Date :
                                    </p>
                                    <p className="create-min pt-0">
                                      {rejectReasonData[0]?.created_date ||
                                        "N/A"}
                                    </p>
                                  </div>

                                  <p className="created-by">Reason:</p>
                                  <p>
                                    {rejectReasonData.map(
                                      (item, index) =>
                                        item.content || "No reason provided"
                                    )}
                                  </p>
                                </div>

                                <div className="modal-footer gap-2 mt-3">
                                  <button
                                    className="view-rej"
                                    onClick={toggleRejectPopup}
                                  >
                                    Cancel
                                  </button>
                                </div>
                              </div>
                            </div>
                          )}
                      </div>
                      <div className="row px-0 ">
                        {rolename !== "13" &&
                          rolename !== "14" &&
                          rolename !== "Admin" &&
                          rolename !== "28" &&
                          selectedOption && (
                            <div className="d-flex  align-items-center mt-3 ">
                              <p className="created-by mb-0">Time line</p>
                              {projectcommetnsR.map((comment, index) => (
                                <p key={index} className="view-names mb-0">
                                  {getDateFormate(comment.assign_date)}
                                  {comment.project_duration &&
                                    ` to ${getDateFormate(
                                      comment.project_duration
                                    )}`}
                                </p>
                              ))}
                            </div>
                          )}

                        {(rolename === "13" ||
                          rolename === "14" ||
                          rolename === "Admin" ||
                          rolename === "28") && (
                            <>
                              <div className="d-flex   ">
                                <p className="created-by pt-2">Reporter</p>
                                <div className="create-view d-flex align-items-center gap-2 px-1 ">
                                  <img
                                    src={empimages}
                                    className="pro-view-img"
                                    alt=""
                                  />
                                  <p className="view-names text-center">
                                    {empData?.employee_name || "Default Name"}
                                  </p>
                                </div>
                              </div>
                            </>
                          )}
                        <div className="d-flex  align-items-center mt-3 ">
                          <p className="created-by mb-0 ">Priority</p>
                          {fetchData.hierarchy_level === "urgent_important" && (
                            <button className="urgentpriority">
                              {CapitalizeCase(fetchData.hierarchy_level)}
                            </button>
                          )}

                          {fetchData.hierarchy_level ===
                            "important_not_urgent" && (
                              <button className="importantpriority">
                                {CapitalizeCase(fetchData.hierarchy_level)}
                              </button>
                            )}
                          {fetchData.hierarchy_level ===
                            "urgent_not_important" && (
                              <button className="urgentnotpriority">
                                {CapitalizeCase(fetchData.hierarchy_level)}
                              </button>
                            )}
                          {fetchData.hierarchy_level ===
                            "not_urgent_not_important" && (
                              <button className="urgentnotimppriority">
                                {CapitalizeCase(fetchData.hierarchy_level)}
                              </button>
                            )}
                        </div>

                        {/* assgine status */}
                        {rolename !== "13" &&
                          rolename !== "14" &&
                          rolename !== "Admin" &&
                          rolename !== "28" &&
                          projectStatusCheck === "accepted" && (
                            <>
                              {alltype === "reviewer" &&
                                writesdetails.map((writer) => {
                                  if (writer.status === "completed") {
                                    // console.log("writer 1235 :", writer);
                                    return (
                                      <div
                                        className="d-flex mt-2"
                                        key={writer.id}
                                      >
                                        <p className="created-by mb-0">
                                          Writers Status
                                        </p>
                                        <div className="dropdown-container1 w-50">
                                          {writer.user_date?.employee_name ||
                                            "-"}
                                          <select
                                            className="form-select dropdown-header-view pt-1"
                                            name="writer"
                                            value={writer.status}
                                            onChange={(e) =>
                                              handleNeedChange(
                                                e,
                                                setWriterStatus,
                                                writer.id,
                                                writer.assign_user,
                                                writer.assign_date,
                                                writer.status_date
                                              )
                                            }
                                            disabled={
                                              rolename === "13" ||
                                              rolename === "14" ||
                                              rolename === "Admin"
                                            }
                                          >
                                            <option value="" disabled>
                                              Select Status
                                            </option>
                                            <option value="completed">
                                              Completed
                                            </option>
                                            <option value="correction">
                                              Correction
                                            </option>
                                          </select>
                                        </div>
                                      </div>
                                    );
                                  }
                                  return null;
                                })}

                              <div className=" w-100 d-flex align-items-center mt-3">
                                <p className="created-by mb-0">
                                  Assignee Status
                                </p>

                                <div
                                  className="dropdown-container1 w-50"
                                  ref={dropdownRefAssigne}
                                >
                                  <div
                                    className={`form-select dropdown-header-view pt-2 ${errors.status ? "error" : ""
                                      }`}
                                    onClick={
                                      rolename !== "Admin" && isReadOnly
                                        ? toggleDropdownAssigne
                                        : null
                                    }
                                  // onClick={toggleDropdownAssigne}
                                  >
                                    {CapitalizeCase(selectedStatus) ||
                                      "Select Status"}
                                  </div>

                                  {isDropdownOpenAssigne && (
                                    <div className="dropdown-assign position-absolute ">
                                      <input
                                        type="text"
                                        className="form-control1 mt-1 "
                                        placeholder="Search..."
                                        value={searchQueryAssigne}
                                        onChange={(e) =>
                                          setSearchQueryAssigne(e.target.value)
                                        } // Update search term
                                        // readOnly={isReadOnly}
                                        readOnly={widthdraw === "completed"}
                                      />
                                      <div className="dropdown-options">
                                        {filteredStatusOptions.length > 0 ? (
                                          filteredStatusOptions.map(
                                            (status, index) => (
                                              <div
                                                key={index}
                                                className="dropdown-option"
                                                onClick={() =>
                                                  handleStatusSelect(status)
                                                }
                                                style={{ cursor: "pointer" }}
                                              >
                                                {status.label}
                                              </div>
                                            )
                                          )
                                        ) : (
                                          <div className="dropdown-no-options">
                                            No options found
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </>
                          )}

                        {(rolename === "13" ||
                          rolename === "14" ||
                          rolename === "28" ||
                          rolename === "Admin") && (
                            <>
                              {/* Writer status */}

                              {Array.isArray(fetchData.writer_data) &&
                                fetchData.writer_data.length === 0 &&
                                rolename !== "28" && (
                                  <div className="d-flex mt-3  ">
                                    <p className="created-by mb-0">
                                      Writers Status
                                    </p>

                                    <div className="w-50">
                                      <div className="dropdown-container1 ">
                                        <select
                                          className="form-select dropdown-header-view"
                                          onChange={(e) => {
                                            const newId = e.target.value;
                                            if (newId) {
                                              handleAssignWriter(newId);
                                            }
                                          }}
                                          disabled={
                                            commonStatus?.trim().toLowerCase() ===
                                            "completed"
                                          }
                                        >
                                          <option value="">Assign writer</option>
                                          {(writter || []).map((writer) => {
                                            const isRejected =
                                              rejectedAssignIds.includes(
                                                writer.id.toString()
                                              );
                                            return (
                                              <option
                                                key={writer.id}
                                                value={writer.id}
                                                disabled={isRejected}
                                                className={
                                                  isRejected
                                                    ? "hierarchy-red"
                                                    : ""
                                                }
                                              >
                                                {writer.name
                                                  .charAt(0)
                                                  .toUpperCase() +
                                                  writer.name.slice(1)}
                                                {isRejected ? " (Rejected)" : ""}
                                              </option>
                                            );
                                          })}
                                        </select>
                                      </div>
                                    </div>
                                  </div>
                                )}

                              {fetchData.writer_data &&
                                fetchData.writer_data.length > 0 && (

                                  <>
                                    <div className="d-flex  mt-2">
                                      <p className="created-by mb-0">
                                        Writers Status
                                      </p>
                                      <div className="w-50 ">
                                        {fetchData.writer_data.map(
                                          (writer, index) => (

                                            <div key={index} className="pb-2">
                                              <div className="view-project-title d-flex align-items-center w-100">
                                                {writer.status !== "rejected" &&
                                                  writer.status !== "revert" &&
                                                  writer.status !==
                                                  "need_support" && (
                                                    <>
                                                      {writer.user_date
                                                        ?.employee_name || "-"}
                                                    </>
                                                  )}

                                                {writer.status &&
                                                  writer.status ===
                                                  "need_support" && rolename !== "28" && (
                                                    <>
                                                      {" / "}
                                                      <span className="text-color-pend">
                                                        {CapitalizeCase(
                                                          writer.status
                                                        ) || "-"}
                                                      </span>
                                                    </>
                                                  )}
                                              </div>

                                              {/* Show dropdown only if status is neither completed nor rejected */}
                                              {writer.status !== "completed" &&
                                                writer.status !== "rejected" &&
                                                writer.status !== "revert" &&
                                                writer.status !== "need_support" && (
                                                  <div className="dropdown-container1 ">
                                                    <select
                                                      className="form-select dropdown-header-view pt-2"
                                                      name="writer"
                                                      value={writer.status}
                                                      onChange={(e) =>
                                                        handleNeedChange(
                                                          e,
                                                          setWriterStatus,
                                                          writer.id,
                                                          writer.assign_user,
                                                          writer.assign_date,
                                                          writer.status_date
                                                        )
                                                      }
                                                      disabled={
                                                        rolename === "13" ||
                                                        rolename === "28" ||
                                                        rolename === "Admin"
                                                      }
                                                    >
                                                      <option value="" disabled>
                                                        Select Status
                                                      </option>
                                                      <option value="to_do">
                                                        TO DO
                                                      </option>
                                                      <option value="plag_correction">
                                                        Plag Correction
                                                      </option>
                                                      <option value="correction">
                                                        Correction
                                                      </option>
                                                    </select>
                                                  </div>
                                                )}

                                              {writer.status === "completed" && (
                                                <div className="dropdown-container1 ">
                                                  <select
                                                    className="form-select dropdown-header-view pt-2"
                                                    name="writer"
                                                    value={writer.status}
                                                    onChange={(e) =>
                                                      handleNeedChange(
                                                        e,
                                                        setWriterStatus,
                                                        writer.id,
                                                        writer.assign_user,
                                                        writer.assign_date,
                                                        writer.status_date
                                                      )
                                                    }
                                                    disabled={
                                                      rolename === "13" ||
                                                      // rolename === "14" ||
                                                      rolename === "Admin" ||
                                                      widthdraw === "completed"
                                                    }
                                                  // disabled
                                                  >
                                                    <option value="" disabled>
                                                      Select Status
                                                    </option>
                                                    <option value="completed">
                                                      Completed
                                                    </option>
                                                    <option value="correction">
                                                      Correction
                                                    </option>
                                                  </select>
                                                </div>
                                              )}

                                              {/* rejected */}

                                              {writer.status === "rejected" &&
                                                rolename !== "28" && (
                                                  <div className="dropdown-container1">
                                                    <select
                                                      className="form-select dropdown-header-view pt-2"
                                                      onChange={(e) => {
                                                        const newId =
                                                          e.target.value;
                                                        if (newId)
                                                          handleReassignWriter(
                                                            newId,
                                                            writer.assign_user
                                                          );
                                                      }}
                                                      disabled={
                                                        commonStatus
                                                          ?.trim()
                                                          .toLowerCase() ===
                                                        "completed"
                                                      }
                                                    >
                                                      <option value="">
                                                        Select Reassign writer
                                                      </option>
                                                      {/* {(writter || []).map(
                                                    (writer) => {
                                                      const isRejected =
                                                        rejectedAssignIds.includes(
                                                          writer.id.toString()
                                                        );
                                                      return (
                                                        <option
                                                          key={writer.id}
                                                          value={writer.id}
                                                          disabled={isRejected}
                                                          className={
                                                            isRejected
                                                              ? "hierarchy-red"
                                                              : ""
                                                          }
                                                        >
                                                          {writer.name
                                                            .charAt(0)
                                                            .toUpperCase() +
                                                            writer.name.slice(
                                                              1
                                                            )}
                                                          {isRejected
                                                            ? " (Rejected)"
                                                            : ""}
                                                        </option>
                                                      );
                                                    }
                                                  )} */}

                                                      {(writter || []).map(
                                                        (writer) => {
                                                          const matched =
                                                            rejectedAssignIds.find(
                                                              (item) =>
                                                                item.id ===
                                                                writer.id.toString()
                                                            );

                                                          const statusLabel =
                                                            matched?.status ===
                                                              "rejected"
                                                              ? " (Rejected)"
                                                              : matched?.status ===
                                                                "revert"
                                                                ? " (Reverted)"
                                                                : "";

                                                          const optionClass =
                                                            matched?.status ===
                                                              "rejected"
                                                              ? "hierarchy-red"
                                                              : matched?.status ===
                                                                "revert"
                                                                ? "hierarchy-orange" // Optional: for reverted status
                                                                : "";

                                                          // const isDisabled = matched?.status === "rejected" || matched?.status === "revert";

                                                          return (
                                                            <option
                                                              key={writer.id}
                                                              value={writer.id}
                                                              // disabled={isDisabled}
                                                              className={
                                                                optionClass
                                                              }
                                                            >
                                                              {writer.name
                                                                .charAt(0)
                                                                .toUpperCase() +
                                                                writer.name.slice(
                                                                  1
                                                                )}
                                                              {statusLabel}
                                                            </option>
                                                          );
                                                        }
                                                      )}
                                                    </select>
                                                  </div>
                                                )}

                                              {/* revert */}

                                              {writer.status === "revert" &&
                                                rolename !== "28" && (
                                                  <div className="dropdown-container1">
                                                    <select
                                                      className="form-select dropdown-header-view pt-2"
                                                      onChange={(e) => {
                                                        const newId =
                                                          e.target.value;
                                                        if (newId)
                                                          handleRevertWriter(
                                                            newId,
                                                            writer.assign_user
                                                          );
                                                      }}
                                                      disabled={
                                                        commonStatus
                                                          ?.trim()
                                                          .toLowerCase() ===
                                                        "completed"
                                                      }
                                                    >
                                                      <option value="">
                                                        Select Reassign writer
                                                      </option>

                                                      {(writter || []).map(
                                                        (writer) => {
                                                          const matched =
                                                            rejectedAssignIds.find(
                                                              (item) =>
                                                                item.id ===
                                                                writer.id.toString()
                                                            );

                                                          const statusLabel =
                                                            matched?.status ===
                                                              "rejected"
                                                              ? " (Rejected)"
                                                              : matched?.status ===
                                                                "revert"
                                                                ? " (Reverted)"
                                                                : "";

                                                          const optionClass =
                                                            matched?.status ===
                                                              "rejected"
                                                              ? "hierarchy-red"
                                                              : matched?.status ===
                                                                "revert"
                                                                ? "hierarchy-orange" // Optional: for reverted status
                                                                : "";

                                                          // const isDisabled = matched?.status === "rejected" || matched?.status === "revert";

                                                          return (
                                                            <option
                                                              key={writer.id}
                                                              value={writer.id}
                                                              // disabled={isDisabled}
                                                              className={
                                                                optionClass
                                                              }
                                                            >
                                                              {writer.name
                                                                .charAt(0)
                                                                .toUpperCase() +
                                                                writer.name.slice(
                                                                  1
                                                                )}
                                                              {statusLabel}
                                                            </option>
                                                          );
                                                        }
                                                      )}
                                                    </select>
                                                  </div>
                                                )}
                                            </div>
                                          )

                                        )}
                                      </div>
                                    </div>
                                  </>
                                )}

                              {/* Reviewer status */}

                              {Array.isArray(fetchData.reviewer_data) &&
                                fetchData.reviewer_data.length === 0 &&
                                rolename !== "28" && (
                                  <div className="d-flex mt-3  w-100">
                                    <p className="created-by mb-0">
                                      Reviewers Status
                                    </p>

                                    <div className="w-50">
                                      <div className="dropdown-container1 ">
                                        <select
                                          className="form-select dropdown-header-view"
                                          onChange={(e) => {
                                            const newId = e.target.value;
                                            if (newId) {
                                              handleAssignReviewer(newId); // No assign_user yet
                                            }
                                          }}
                                          disabled={
                                            commonStatus?.trim().toLowerCase() ===
                                            "completed"
                                          }
                                        >
                                          <option value="">
                                            Assign Reviewer
                                          </option>
                                          {(reviewerdrop || []).map(
                                            (reviewer) => {
                                              const isRejected =
                                                rejectedAssignIds.includes(
                                                  reviewer.id.toString()
                                                );
                                              return (
                                                <option
                                                  key={reviewer.id}
                                                  value={reviewer.id}
                                                  disabled={isRejected}
                                                  className={
                                                    isRejected
                                                      ? "hierarchy-red"
                                                      : ""
                                                  }
                                                >
                                                  {reviewer.name
                                                    .charAt(0)
                                                    .toUpperCase() +
                                                    reviewer.name.slice(1)}
                                                  {isRejected
                                                    ? " (Rejected)"
                                                    : ""}
                                                </option>
                                              );
                                            }
                                          )}
                                        </select>
                                      </div>
                                    </div>
                                  </div>
                                )}

                              {fetchData.reviewer_data &&
                                fetchData.reviewer_data.length > 0 && (
                                  <>
                                    <div className="w-100 d-flex  mt-3">
                                      <p className="created-by mb-0">
                                        Reviewer Status
                                      </p>
                                      <div className="w-50">
                                        {fetchData.reviewer_data.map(
                                          (reviewer, index) => (
                                            <div key={index} className="pb-2">
                                              <div className="view-project-title d-flex align-items-center w-100">
                                                {reviewer.status !== "rejected" &&
                                                  reviewer.status !==
                                                  "revert" &&
                                                  reviewer.status !== "need_support" && (
                                                    <>
                                                      {reviewer.user_date
                                                        ?.employee_name || "-"}
                                                      {reviewer.status ===
                                                        "need_support" && rolename !== "28" && (
                                                          <>
                                                            {" / "}
                                                            <span className="text-color-pend">
                                                              {CapitalizeCase(
                                                                reviewer.status
                                                              ) || "-"}
                                                            </span>
                                                          </>
                                                        )}
                                                    </>
                                                  )}
                                              </div>

                                              {![
                                                "rejected",
                                                "completed",
                                                "revert",
                                                "need_support",
                                              ].includes(reviewer.status) && (
                                                  <div className="dropdown-container1 w-100">
                                                    <select
                                                      className="form-select dropdown-header-view pt-2"
                                                      name="reviewer"
                                                      value={reviewer.status}
                                                      onChange={(e) =>
                                                        handleNeedChange(
                                                          e,
                                                          setReviewerStatus,
                                                          reviewer.id,
                                                          reviewer.assign_user,
                                                          reviewer.assign_date,
                                                          reviewer.status_date
                                                        )
                                                      }
                                                      disabled={
                                                        rolename === "13" ||
                                                        rolename === "28" ||
                                                        rolename === "Admin"
                                                      }
                                                    >
                                                      <option value="" disabled>
                                                        Select Status
                                                      </option>
                                                      <option value="to_do">
                                                        TO DO
                                                      </option>
                                                      <option value="plag_correction">
                                                        Plag Correction
                                                      </option>
                                                      <option value="correction">
                                                        Correction
                                                      </option>
                                                    </select>
                                                  </div>
                                                )}
                                              {reviewer.status ===
                                                "completed" && (
                                                  <div className="dropdown-container1 w-100">
                                                    <select
                                                      className="form-select dropdown-header-view pt-2"
                                                      name="reviewer"
                                                      value={reviewer.status}
                                                      onChange={(e) =>
                                                        handleNeedChange(
                                                          e,
                                                          setReviewerStatus,
                                                          reviewer.id,
                                                          reviewer.assign_user,
                                                          reviewer.assign_date,
                                                          reviewer.status_date
                                                        )
                                                      }
                                                      disabled={
                                                        rolename === "13" ||
                                                        rolename === "Admin" ||
                                                        widthdraw === "completed"
                                                      }
                                                    >

                                                      <option value="completed">
                                                        Completed
                                                      </option>
                                                      <option value="correction">
                                                        Correction
                                                      </option>
                                                    </select>
                                                  </div>
                                                )}
                                              {/* rejected */}
                                              {reviewer.status === "rejected" &&
                                                rolename !== "28" && (
                                                  <div className="dropdown-container1">
                                                    <select
                                                      className="form-select dropdown-header-view pt-2"
                                                      onChange={(e) => {
                                                        const newId =
                                                          e.target.value;
                                                        if (newId)
                                                          handleReassignReviwer(
                                                            newId,
                                                            reviewer.assign_user
                                                          );
                                                      }}
                                                      disabled={
                                                        commonStatus
                                                          ?.trim()
                                                          .toLowerCase() ===
                                                        "completed"
                                                      }
                                                    >
                                                      <option value="">
                                                        Select Reassign Reviewer
                                                      </option>

                                                      {(reviewerdrop || []).map(
                                                        (reviewer) => {
                                                          const matched =
                                                            rejectedAssignIds.find(
                                                              (item) =>
                                                                item.id ===
                                                                reviewer.id.toString()
                                                            );

                                                          const statusLabel =
                                                            matched?.status ===
                                                              "rejected"
                                                              ? " (Rejected)"
                                                              : matched?.status ===
                                                                "revert"
                                                                ? " (Reverted)"
                                                                : "";

                                                          const optionClass =
                                                            matched?.status ===
                                                              "rejected"
                                                              ? "hierarchy-red"
                                                              : matched?.status ===
                                                                "revert"
                                                                ? "hierarchy-orange"
                                                                : "";

                                                          return (
                                                            <option
                                                              key={reviewer.id}
                                                              value={reviewer.id}
                                                              className={
                                                                optionClass
                                                              }
                                                            >
                                                              {reviewer.name
                                                                .charAt(0)
                                                                .toUpperCase() +
                                                                reviewer.name.slice(
                                                                  1
                                                                )}
                                                              {statusLabel}
                                                            </option>
                                                          );
                                                        }
                                                      )}
                                                    </select>
                                                  </div>
                                                )}
                                              {/* revert */}

                                              {reviewer.status === "revert" &&
                                                rolename !== "28" && (
                                                  <div className="dropdown-container1">
                                                    <select
                                                      className="form-select dropdown-header-view pt-2"
                                                      onChange={(e) => {
                                                        const newId =
                                                          e.target.value;
                                                        if (newId)
                                                          handleRevertReviwer(
                                                            newId,
                                                            reviewer.assign_user
                                                          );
                                                      }}
                                                      disabled={
                                                        commonStatus
                                                          ?.trim()
                                                          .toLowerCase() ===
                                                        "completed"
                                                      }
                                                    >
                                                      <option value="">
                                                        Select Reassign Reviewer
                                                      </option>

                                                      {(reviewerdrop || []).map(
                                                        (reviewer) => {
                                                          const matched =
                                                            rejectedAssignIds.find(
                                                              (item) =>
                                                                item.id ===
                                                                reviewer.id.toString()
                                                            );

                                                          const statusLabel =
                                                            matched?.status ===
                                                              "rejected"
                                                              ? " (Rejected)"
                                                              : matched?.status ===
                                                                "revert"
                                                                ? " (Reverted)"
                                                                : "";

                                                          const optionClass =
                                                            matched?.status ===
                                                              "rejected"
                                                              ? "hierarchy-red"
                                                              : matched?.status ===
                                                                "revert"
                                                                ? "hierarchy-orange"
                                                                : "";

                                                          return (
                                                            <option
                                                              key={reviewer.id}
                                                              value={reviewer.id}
                                                              className={
                                                                optionClass
                                                              }
                                                            >
                                                              {reviewer.name
                                                                .charAt(0)
                                                                .toUpperCase() +
                                                                reviewer.name.slice(
                                                                  1
                                                                )}
                                                              {statusLabel}
                                                            </option>
                                                          );
                                                        }
                                                      )}
                                                    </select>
                                                  </div>
                                                )}
                                            </div>
                                          )
                                        )}
                                      </div>
                                    </div>
                                  </>
                                )}

                              {/* Statistican status */}

                              {Array.isArray(fetchData.statistican_data) &&
                                fetchData.statistican_data.length === 0 &&
                                rolename !== "28" && (
                                  <div className="d-flex mt-3 w-100 ">
                                    <p className="created-by mb-0">
                                      Statistican Status
                                    </p>

                                    <div className="w-50">
                                      <div className="dropdown-container1 ">
                                        <select
                                          className="form-select dropdown-header-view "
                                          onChange={(e) => {
                                            const newId = e.target.value;
                                            if (newId) {
                                              handleAssignStatistican(newId); // No assign_user to pass
                                            }
                                          }}
                                          disabled={
                                            commonStatus?.trim().toLowerCase() ===
                                            "completed"
                                          }
                                        >
                                          <option value="">
                                            Assign Statistician
                                          </option>
                                          {(statistical || []).map(
                                            (statistican) => (
                                              <option
                                                key={statistican.id}
                                                value={statistican.id}
                                              >
                                                {statistican.name
                                                  .charAt(0)
                                                  .toUpperCase() +
                                                  statistican.name.slice(1)}
                                              </option>
                                            )
                                          )}
                                        </select>
                                      </div>
                                    </div>
                                  </div>
                                )}

                              {fetchData.statistican_data &&
                                fetchData.statistican_data.length > 0 && (
                                  <>
                                    <div className="w-100 d-flex  mt-3">
                                      <p className="created-by mb-0">
                                        Statistician Status
                                      </p>
                                      <div className="w-50">
                                        {fetchData.statistican_data.map(
                                          (statistican, index) => (
                                            <div key={index} className="pb-2">
                                              <div className="view-project-title d-flex align-items-center w-100">
                                                {statistican.status !==
                                                  "rejected" &&
                                                  statistican.status !==
                                                  "revert" && statistican.status !==
                                                  "need_support" && (
                                                    <>
                                                      {statistican.user_date
                                                        ?.employee_name || "-"}
                                                      {statistican?.status ===
                                                        "need_support" && rolename !== "28" && (
                                                          <>
                                                            {" / "}
                                                            <span className="text-color-pend">
                                                              {CapitalizeCase(
                                                                statistican?.status
                                                              ) || "-"}
                                                            </span>
                                                          </>
                                                        )}
                                                    </>
                                                  )}
                                              </div>

                                              {statistican.status !==
                                                "completed" &&
                                                statistican.status !==
                                                "rejected" &&
                                                statistican.status !==
                                                "revert" &&
                                                statistican.status !== "need_support" && (
                                                  <div className="dropdown-container1 w-100">
                                                    <select
                                                      className="form-select dropdown-header-view pt-2"
                                                      name="statistican"
                                                      value={statistican.status}
                                                      onChange={(e) =>
                                                        handleNeedChange(
                                                          e,
                                                          setStatisticanStatus,
                                                          statistican.id,
                                                          statistican.assign_user,
                                                          statistican.assign_date,
                                                          statistican.status_date
                                                        )
                                                      }
                                                      disabled={
                                                        rolename === "13" ||
                                                        rolename === "28" ||
                                                        rolename === "Admin"
                                                      }
                                                    >
                                                      <option value="" disabled>
                                                        Select Status
                                                      </option>
                                                      <option value="to_do">
                                                        TO DO
                                                      </option>
                                                      <option value="correction">
                                                        Correction
                                                      </option>
                                                    </select>
                                                  </div>
                                                )}

                                              {statistican.status ===
                                                "completed" && (
                                                  <div className="dropdown-container1 w-100">
                                                    <select
                                                      className="form-select dropdown-header-view pt-2"
                                                      name="statistican"
                                                      value={statistican.status}
                                                      onChange={(e) =>
                                                        handleNeedChange(
                                                          e,
                                                          setStatisticanStatus,
                                                          statistican.id,
                                                          statistican.assign_user,
                                                          statistican.assign_date,
                                                          statistican.status_date
                                                        )
                                                      }
                                                      disabled={
                                                        rolename === "13" ||
                                                        // rolename === "14" ||
                                                        rolename === "Admin" ||
                                                        widthdraw === "completed"
                                                      }
                                                    >
                                                      <option value="" disabled>
                                                        Select Status
                                                      </option>
                                                      <option value="completed">
                                                        Completed
                                                      </option>
                                                      <option value="correction">
                                                        Correction
                                                      </option>
                                                    </select>
                                                  </div>
                                                )}

                                              {/* rejected */}

                                              {statistican.status ===
                                                "rejected" &&
                                                rolename !== "28" && (
                                                  <div className="dropdown-container1 ">
                                                    <select
                                                      className="form-select dropdown-header-view pt-2"
                                                      onChange={(e) => {
                                                        const newId =
                                                          e.target.value;
                                                        if (newId)
                                                          handleReassignstatistican(
                                                            newId,
                                                            statistican.assign_user
                                                          );
                                                      }}
                                                      disabled={
                                                        commonStatus
                                                          ?.trim()
                                                          .toLowerCase() ===
                                                        "completed"
                                                      }
                                                    >
                                                      <option value="">
                                                        Select Reassign
                                                        Statistician
                                                      </option>
                                                      {/* {(statistical || []).map(
                                                    (statistican) => {
                                                      const isRejected =
                                                        rejectedAssignIds.includes(
                                                          statistican.id.toString()
                                                        );
                                                      return (
                                                        <option
                                                          key={statistican.id}
                                                          value={statistican.id}
                                                          disabled={isRejected}
                                                          className={
                                                            isRejected
                                                              ? "hierarchy-red"
                                                              : ""
                                                          }
                                                        >
                                                          {statistican.name
                                                            .charAt(0)
                                                            .toUpperCase() +
                                                            statistican.name.slice(
                                                              1
                                                            )}
                                                          {isRejected
                                                            ? " (Rejected)"
                                                            : ""}
                                                        </option>
                                                      );
                                                    }
                                                  )} */}
                                                      {(statistical || []).map(
                                                        (statistican) => {
                                                          const matched =
                                                            rejectedAssignIds.find(
                                                              (item) =>
                                                                item.id ===
                                                                statistican.id.toString()
                                                            );

                                                          const statusLabel =
                                                            matched?.status ===
                                                              "rejected"
                                                              ? " (Rejected)"
                                                              : matched?.status ===
                                                                "revert"
                                                                ? " (Reverted)"
                                                                : "";

                                                          const optionClass =
                                                            matched?.status ===
                                                              "rejected"
                                                              ? "hierarchy-red"
                                                              : matched?.status ===
                                                                "revert"
                                                                ? "hierarchy-orange" // optional
                                                                : "";

                                                          // const isDisabled = matched?.status === "rejected" || matched?.status === "revert";

                                                          return (
                                                            <option
                                                              key={statistican.id}
                                                              value={
                                                                statistican.id
                                                              }
                                                              // disabled={isDisabled}
                                                              className={
                                                                optionClass
                                                              }
                                                            >
                                                              {statistican.name
                                                                .charAt(0)
                                                                .toUpperCase() +
                                                                statistican.name.slice(
                                                                  1
                                                                )}
                                                              {statusLabel}
                                                            </option>
                                                          );
                                                        }
                                                      )}
                                                    </select>
                                                  </div>
                                                )}

                                              {/* revert */}

                                              {statistican.status === "revert" &&
                                                rolename !== "28" && (
                                                  <div className="dropdown-container1 ">
                                                    <select
                                                      className="form-select dropdown-header-view pt-2"
                                                      onChange={(e) => {
                                                        const newId =
                                                          e.target.value;
                                                        if (newId)
                                                          handleRevertstatistican(
                                                            newId,
                                                            statistican.assign_user
                                                          );
                                                      }}
                                                      disabled={
                                                        commonStatus
                                                          ?.trim()
                                                          .toLowerCase() ===
                                                        "completed"
                                                      }
                                                    >
                                                      <option value="">
                                                        Select Reassign
                                                        Statistician
                                                      </option>
                                                      {/* {(statistical || []).map(
                                                    (statistican) => {
                                                      const isRejected =
                                                        rejectedAssignIds.includes(
                                                          statistican.id.toString()
                                                        );
                                                      return (
                                                        <option
                                                          key={statistican.id}
                                                          value={statistican.id}
                                                          disabled={isRejected}
                                                          className={
                                                            isRejected
                                                              ? "hierarchy-red"
                                                              : ""
                                                          }
                                                        >
                                                          {statistican.name
                                                            .charAt(0)
                                                            .toUpperCase() +
                                                            statistican.name.slice(
                                                              1
                                                            )}
                                                          {isRejected
                                                            ? " (Rejected)"
                                                            : ""}
                                                        </option>
                                                      );
                                                    }
                                                  )} */}
                                                      {(statistical || []).map(
                                                        (statistican) => {
                                                          const matched =
                                                            rejectedAssignIds.find(
                                                              (item) =>
                                                                item.id ===
                                                                statistican.id.toString()
                                                            );

                                                          const statusLabel =
                                                            matched?.status ===
                                                              "rejected"
                                                              ? " (Rejected)"
                                                              : matched?.status ===
                                                                "revert"
                                                                ? " (Reverted)"
                                                                : "";

                                                          const optionClass =
                                                            matched?.status ===
                                                              "rejected"
                                                              ? "hierarchy-red"
                                                              : matched?.status ===
                                                                "revert"
                                                                ? "hierarchy-orange" // optional
                                                                : "";

                                                          // const isDisabled = matched?.status === "rejected" || matched?.status === "revert";

                                                          return (
                                                            <option
                                                              key={statistican.id}
                                                              value={
                                                                statistican.id
                                                              }
                                                              // disabled={isDisabled}
                                                              className={
                                                                optionClass
                                                              }
                                                            >
                                                              {statistican.name
                                                                .charAt(0)
                                                                .toUpperCase() +
                                                                statistican.name.slice(
                                                                  1
                                                                )}
                                                              {statusLabel}
                                                            </option>
                                                          );
                                                        }
                                                      )}
                                                    </select>
                                                  </div>
                                                )}
                                            </div>
                                          )
                                        )}
                                      </div>
                                    </div>
                                  </>
                                )}

                              {/* journal status */}
                            </>
                          )}
                        {rolename === "14" && (
                          <div className="w-100 d-flex align-items-center mt-3">
                            <p className="created-by mb-0">TC Status</p>
                            <div className="dropdown-container1 w-50">
                              {/* {tcdetails !== "completed" &&(
                                <span className="text-color-pend">
                                  {CapitalizeCaseU(tcdetails)}
                                </span>
                                )}  */}
                              {tcData !== "completed" && (
                                <p className="created-by mb-0">{tcData}</p>
                              )}
                              {/* <select
                                    className="form-select dropdown-header-view pt-2"
                                    name="team_coordinator"
                                    value={tcData}
                                    disabled
                                    // defaultValue=""
                                  >
                                  </select> */}
                            </div>
                          </div>
                        )}
                        {/* SME status */}
                        {rolename === "14" && (
                          <div className="w-100 d-flex align-items-center mt-3">
                            <p className="created-by mb-0">SME Status</p>
                            <div className="dropdown-container1 w-50">
                              <select
                                className="form-select dropdown-header-view pt-2"
                                name="sme"
                                value={smeStatus}
                                onChange={(e) =>
                                  handleNeedChange(e, setSmeStatus)
                                }
                              >
                                <option value="" disabled selected>
                                  Select Status
                                </option>
                                <option value="need_support">
                                  Need Support
                                </option>
                              </select>
                            </div>
                          </div>
                        )}

                        {(rolename === "28" ||
                          rolename === "13" ||
                          rolename === "Admin") && (
                            <>
                              <>
                                {(docmentData ===
                                  '["with_statistics","with_publication"]' ||
                                  docmentData ===
                                  '["writing","with_statistics","with_publication"]' ||
                                  docmentData ===
                                  '["writing","with_publication"]' ||
                                  docmentData === '["with_publication","writing"]' ||
                                  docmentData === '["with_statistics","writing"]' ||

                                  docmentData === '["with_publication"]') && (
                                    <div className="w-100 d-flex  mt-3">
                                      <p className="created-by mb-0">
                                        Publication Status
                                      </p>
                                      {fetchData.journal_data[0] &&
                                        fetchData.journal_data[0].length > 0 ? (
                                        fetchData.journal_data[0].map(
                                          (journal, index) => (
                                            <div className="w-50">
                                              <div className="pb-2" key={index}>
                                                <div className="view-project-title d-flex align-items-center w-100">
                                                  {/* <span>
                                              {journal.assign_user ? (
                                                <>
                                                  {journal.assign_user} /
                                                  <span className="text-color-pend">
                                                    {CapitalizeCase(
                                                      journal.status
                                                    ) || "-"}
                                                  </span>
                                                </>
                                              ) : (
                                                " "
                                              )}
                                            </span> */}
                                                  {/* <span>
                                                    {typeof journal.assign_user ===
                                                      "string" &&
                                                      /[a-zA-Z]/.test(
                                                        journal.assign_user
                                                      ) && (
                                                        <>{journal.assign_user} /</>
                                                      )}
                                                    <span className="text-color-pend">
                                                      {CapitalizeCase(
                                                        journal.status
                                                      ) || "-"}
                                                    </span> */}
                                                  {/* </span> */}
                                                </div>
                                                <p className="text-black">
                                                  {fetchData?.journal_data?.[0]
                                                    ?.assign_user &&
                                                    /[a-zA-Z]/.test(
                                                      fetchData.journal_data[0]
                                                        .assign_user
                                                    )
                                                    ? fetchData.journal_data[0]
                                                      .assign_user
                                                    : ""}
                                                </p>
                                                <div className="dropdown-container1 w-100">
                                                  <select
                                                    className="form-select dropdown-header-view pt-2"
                                                    name="publication_manager"
                                                    onChange={(e) =>
                                                      handleNeedChange(
                                                        e,
                                                        setJournalStatus,
                                                        journal.id,
                                                        journal.assign_user,
                                                        journal.assign_date,
                                                        journal.status_date
                                                      )
                                                    }
                                                    disabled={[
                                                      "13",
                                                      "14",
                                                      "Admin",
                                                    ].includes(rolename)}
                                                    // defaultValue=""
                                                    value={publicationStatus || ""}
                                                  >
                                                    <option value="" disabled selected>
                                                      Select Status
                                                    </option>
                                                    <option value="submit_to_journal">
                                                      Submit To Journal
                                                    </option>
                                                    <option value="pending_author">
                                                      Pending Author
                                                    </option>
                                                    <option value="rejected">
                                                      Rejected
                                                    </option>
                                                    <option value="resubmission">
                                                      Resubmission
                                                    </option>
                                                    <option value="reviewer_comments">
                                                      Reviewer Comments
                                                    </option>
                                                    <option value="withdrawal">
                                                      Withdrawn
                                                    </option>
                                                    <option value="submitted">
                                                      Submitted
                                                    </option>
                                                    <option value="published">
                                                      Published
                                                    </option>
                                                  </select>
                                                </div>
                                              </div>
                                            </div>
                                          )
                                        )
                                      ) : (
                                        <div className="w-50">
                                          <div className="pb-1">
                                            <p className="text-black">
                                              {fetchData?.journal_data?.[0]
                                                ?.assign_user &&
                                                /[a-zA-Z]/.test(
                                                  fetchData.journal_data[0]
                                                    .assign_user
                                                )
                                                ? fetchData.journal_data[0]
                                                  .assign_user
                                                : ""}
                                            </p>
                                            <div className="dropdown-container1 w-100">
                                              <select
                                                className="form-select dropdown-header-view pt-2 "
                                                name="publication_manager"
                                                onChange={(e) =>
                                                  handleNeedChange(
                                                    e,
                                                    setJournalStatus,
                                                    journal.id,
                                                    journal.assign_user,
                                                    journal.assign_date,
                                                    journal.status_date
                                                  )
                                                }
                                                disabled={[
                                                  "13",
                                                  "14",
                                                  "Admin",
                                                ].includes(rolename)}
                                                // defaultValue=""
                                                value={publicationStatus || ""}
                                              >
                                                <option value="" disabled selected>
                                                  Select Status
                                                </option>
                                                <option value="submit_to_journal">
                                                  Submit To Journal
                                                </option>
                                                <option value="pending_author">
                                                  Pending Author
                                                </option>
                                                <option value="rejected">
                                                  Rejected
                                                </option>
                                                <option value="resubmission">
                                                  Resubmission
                                                </option>
                                                <option value="reviewer_comments">
                                                  Reviewer Comments
                                                </option>
                                                <option value="withdrawal">
                                                  Withdrawn
                                                </option>
                                                <option value="submitted">
                                                  Submitted
                                                </option>
                                                <option value="published">
                                                  Published
                                                </option>
                                              </select>
                                            </div>
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  )}
                              </>

                              {/* Statistican status */}
                              {(rolename === "28" || rolename === "13") && (
                                <>
                                  {fetchData.statistican_data &&
                                    fetchData.statistican_data.filter(
                                      (statistican) =>
                                        statistican.status === "need_support"
                                    ).length > 0 && (
                                      <>
                                        <div className="w-100 d-flex  mt-3">
                                          <p className="created-by mb-0">
                                            Statistician Status
                                          </p>
                                          <div className="w-50">
                                            {fetchData.statistican_data.map(
                                              (statistican, index) => (
                                                <div key={index} className="pb-2">
                                                  <div className="view-project-title d-flex align-items-center w-100">
                                                    {statistican.status &&
                                                      statistican.status ===
                                                      "need_support" && (
                                                        <>
                                                          {statistican.user_date
                                                            ?.employee_name ||
                                                            "-"}
                                                          {statistican.status ===
                                                            "need_support" && (
                                                              <>
                                                                {" / "}
                                                                <span className="text-color-pend">
                                                                  {CapitalizeCase(
                                                                    statistican.status
                                                                  ) || "-"}
                                                                </span>
                                                              </>
                                                            )}
                                                        </>
                                                      )}
                                                  </div>
                                                  {statistican.status ===
                                                    "need_support" && (
                                                      <div className="dropdown-container1 w-100">
                                                        <select
                                                          className="form-select dropdown-header-view pt-2"
                                                          onChange={(e) =>
                                                            handleNeedChange(
                                                              e,
                                                              setStatisticanStatus,
                                                              statistican.id,
                                                              statistican.assign_user,
                                                              statistican.assign_date,
                                                              statistican.status_date
                                                            )
                                                          }
                                                          name="statistican"
                                                          value={statisticanStatus}
                                                          disabled={[
                                                            "13",
                                                            "14",
                                                            "Admin",
                                                          ].includes(rolename)}
                                                          defaultValue=""
                                                        >
                                                          <option
                                                            value=""
                                                            disabled
                                                            selected
                                                          >
                                                            Select Status
                                                          </option>
                                                          <option value="correction">
                                                            Correction
                                                          </option>
                                                        </select>
                                                      </div>
                                                    )}
                                                </div>
                                              )
                                            )}
                                          </div>
                                        </div>
                                      </>
                                    )}
                                </>
                              )}

                              {/* Writer status */}

                              {(rolename === "28" || rolename === "13") && (
                                <>
                                  {fetchData.writer_data &&
                                    fetchData.writer_data.filter(
                                      (writer) => writer.status === "need_support"
                                    ).length > 0 && (
                                      <>
                                        <div className="w-100 d-flex  mt-3">
                                          <p className="created-by mb-0">
                                            Writer Status
                                          </p>
                                          <div className="w-50">
                                            {fetchData.writer_data.map(
                                              (writer, index) => (
                                                <div key={index} className="pb-2">
                                                  <div className="view-project-title d-flex align-items-center w-100">
                                                    {writer.status &&
                                                      writer.status ===
                                                      "need_support" && (
                                                        <>
                                                          {writer.user_date
                                                            ?.employee_name ||
                                                            "-"}
                                                          {writer.status ===
                                                            "need_support" && (
                                                              <>
                                                                {" / "}
                                                                <span className="text-color-pend">
                                                                  {CapitalizeCase(
                                                                    writer.status
                                                                  ) || "-"}
                                                                </span>
                                                              </>
                                                            )}
                                                        </>
                                                      )}
                                                  </div>
                                                  {writer.status ===
                                                    "need_support" && (
                                                      <div className="dropdown-container1 w-100">
                                                        <select
                                                          className="form-select dropdown-header-view pt-2"
                                                          name="writer"
                                                          value={
                                                            writer.status ===
                                                              "need_support"
                                                              ? writerStatus
                                                              : writer.status
                                                          }
                                                          disabled={
                                                            writer.status !==
                                                            "need_support"
                                                          }
                                                          onChange={(e) =>
                                                            writer.status ===
                                                            "need_support" &&
                                                            handleNeedChange(
                                                              e,
                                                              setWriterStatus,
                                                              writer.id,
                                                              writer.assign_user,
                                                              writer.assign_date,
                                                              writer.status_date
                                                            )
                                                          }
                                                        >
                                                          {writer.status ===
                                                            "need_support" ? (
                                                            <>
                                                              <option
                                                                value=""
                                                                disabled
                                                              >
                                                                Select Status
                                                              </option>
                                                              <option value="correction">
                                                                Correction
                                                              </option>
                                                            </>
                                                          ) : (
                                                            <option
                                                              value={writer.status}
                                                            >
                                                              {writer.status}
                                                            </option>
                                                          )}
                                                        </select>
                                                      </div>
                                                    )}
                                                </div>
                                              )
                                            )}
                                          </div>
                                        </div>
                                      </>
                                    )}
                                </>
                              )}

                              {/* Reviewer status */}
                              {/* {fetchData.reviewer_data &&
                            fetchData.reviewer_data.length > 0 && (
                              <>
                                <div className="w-100 d-flex align-items-center mt-3">
                                  <p className="created-by mb-0">
                                    Reviewer Status
                                  </p>
                                  <div className="dropdown-container1 w-50">
                                    <select
                                      className="form-select dropdown-header-view pt-2"
                                      name="reviewer"
                                      value={reviewerStatus}
                                      onChange={(e) =>
                                        handleNeedChange(e, setReviewerStatus)
                                      }
                                    >
                                      <option value="" disabled selected>
                                        Select Status
                                      </option>
                                      <option value="correction">
                                        Correction
                                      </option>
                                    </select>
                                  </div>
                                </div>
                              </>
                            )} */}
                              {(rolename === "28" || rolename === "13") && (
                                <>
                                  {fetchData.reviewer_data &&
                                    fetchData.reviewer_data.filter(
                                      (reviewer) =>
                                        reviewer.status === "need_support"
                                    ).length > 0 && (
                                      <>
                                        <div className="w-100 d-flex  mt-3">
                                          <p className="created-by mb-0">
                                            Reviewer Status
                                          </p>

                                          <div className="w-50">
                                            {fetchData.reviewer_data.map(
                                              (reviewer, index) => (
                                                <div key={index} className="pb-2">
                                                  <div className="view-project-title d-flex align-items-center w-100">
                                                    {reviewer.status &&
                                                      reviewer.status ===
                                                      "need_support" && (
                                                        <>
                                                          {reviewer.user_date
                                                            ?.employee_name ||
                                                            "-"}
                                                          {reviewer.status ===
                                                            "need_support" && (
                                                              <>
                                                                {" / "}
                                                                <span className="text-color-pend">
                                                                  {CapitalizeCase(
                                                                    reviewer.status
                                                                  ) || "-"}
                                                                </span>
                                                              </>
                                                            )}
                                                        </>
                                                      )}
                                                  </div>
                                                  {reviewer.status ===
                                                    "need_support" && (
                                                      <div className="dropdown-container1 w-100">
                                                        <select
                                                          className="form-select dropdown-header-view pt-2"
                                                          name="reviewer"
                                                          value={
                                                            reviewer.status ===
                                                              "need_support"
                                                              ? reviewerStatus
                                                              : reviewer.status
                                                          }
                                                          disabled={
                                                            reviewer.status !==
                                                            "need_support"
                                                          }
                                                          onChange={(e) =>
                                                            reviewer.status ===
                                                            "need_support" &&
                                                            handleNeedChange(
                                                              e,
                                                              setReviewerStatus,
                                                              reviewer.id,
                                                              reviewer.assign_user,
                                                              reviewer.assign_date,
                                                              reviewer.status_date
                                                            )
                                                          }
                                                        >
                                                          {reviewer.status ===
                                                            "need_support" ? (
                                                            <>
                                                              <option
                                                                value=""
                                                                disabled
                                                              >
                                                                Select Status
                                                              </option>
                                                              <option value="correction">
                                                                Correction
                                                              </option>
                                                            </>
                                                          ) : (
                                                            <option
                                                              value={
                                                                reviewer.status
                                                              }
                                                            >
                                                              {reviewer.status}
                                                            </option>
                                                          )}
                                                        </select>
                                                      </div>
                                                    )}
                                                </div>
                                              )
                                            )}
                                          </div>
                                        </div>
                                      </>
                                    )}
                                </>
                              )}

                              {/* TC status */}
                              {/* {tcData.map((tc) => (
                            <div className="w-100 d-flex align-items-center mt-3">
                              <p className="created-by mb-0">TC Status</p>
                              <div className="dropdown-container1 w-50">
                                {tc.status !== "correction" ? (
                                  <select
                                    className="form-select dropdown-header-view pt-2"
                                    name="team_coordinator"
                                    value={tcStatus}
                                    onChange={(e) =>
                                      handleNeedChange(e, setTcStatus)
                                    }
                                  >
                                    <option value="" disabled selected>
                                      Select Status
                                    </option>
                                    <option value="correction">
                                      Correction
                                    </option>
                                  </select>
                                ) : (
                                  <select
                                    className="form-select dropdown-header-view pt-2"
                                    name="team_coordinator"
                                    value={tc.status}
                                    // onChange={(e) =>
                                    //   handleNeedChange(e, setTcStatus)
                                    // }
                                    disabled
                                  >
                                  <option value={tc.status}>{tc.status || "-"}</option>
                                  </select>
                                )}
                              </div>
                            </div>
                          ))} */}

                              <div className="w-100 d-flex align-items-center mt-3">
                                <p className="created-by mb-0">TC Status</p>
                                <div className="dropdown-container1 w-50">
                                  {/* {tcdetails !== "completed" &&(
                                <span className="text-color-pend">
                                  {CapitalizeCaseU(tcdetails)}
                                </span>
                                )}  */}
                                  <select
                                    className="form-select dropdown-header-view pt-2"
                                    name="team_coordinator"
                                    value={tcData}
                                    onChange={(e) =>
                                      handleNeedChange(e, setTcStatus)
                                    }
                                    disabled={
                                      ["13", "14", "Admin"].includes(rolename) ||
                                      widthdraw === "completed"
                                    }
                                    defaultValue=""
                                  >
                                    <option value="">Select Status</option>{" "}
                                    {/* empty string for default */}
                                    <option value="correction">Correction</option>
                                  </select>
                                </div>
                              </div>

                              {/* payment */}

                              <div className="w-100 d-flex align-items-center mt-3">
                                <p className="created-by mb-0">
                                  Payment Record Status
                                </p>
                                <div className="dropdown-container1 w-50">
                                  {/* <span className="text-color-pend">
                                  {CapitalizeCaseU(payStatus)}
                                </span> */}
                                  <select
                                    className="form-select dropdown-header-view pt-2"
                                    name="payment"
                                    // value={payStatus}
                                    onChange={(e) =>
                                      handleNeedChange(e, setPayStatus)
                                    }
                                    disabled={
                                      ["13", "14", "Admin"].includes(rolename) ||
                                      widthdraw === "completed"
                                    }
                                    defaultValue=""
                                    value={
                                      allowedValuespay.includes(payStatus)
                                        ? payStatus
                                        : ""
                                    }
                                  >
                                    <option value="" disabled selected>
                                      Select Status
                                    </option>
                                    <option value="completed">Completed</option>
                                    <option value="advance_pending">
                                      Advance Pending
                                    </option>
                                    <option value="partial_payment_pending">
                                      Partial payment pending
                                    </option>
                                    <option value="final_payment_pending">
                                      Final payment pending
                                    </option>
                                  </select>
                                </div>
                              </div>

                              <div className="w-100 d-flex align-items-center mt-3">
                                <p className="created-by mb-0">Common Status</p>
                                <div className="dropdown-container1 w-50">
                                  {/* <span className="text-color-pend">
                                  {CapitalizeCaseU(commonStatus)}
                                </span> */}
                                  <select
                                    className="form-select dropdown-header-view pt-2"
                                    onChange={(e) =>
                                      handleNeedChange(e, setCommonStatus)
                                    }
                                    disabled={
                                      ["13", "14", "Admin"].includes(rolename) &&
                                      widthdraw === "completed"
                                    }
                                    // defaultValue=""
                                    name="commonStatus"
                                    // value={commonStatus}
                                    value={
                                      allowedValues.includes(commonStatus)
                                        ? commonStatus
                                        : ""
                                    }
                                  >
                                    <option value="" disabled selected>
                                      Select Status
                                    </option>
                                    <option value="client_review">
                                      Client Review
                                    </option>
                                    <option value="completed">Completed</option>
                                    <option value="pending_author">
                                      Pending - Author
                                    </option>
                                  </select>
                                </div>
                              </div>
                            </>
                          )}
                      </div>
                    </section>
                  </div>





                </div>
              </div>
            </div>
            <div>
              <Footer />
            </div>
          </section>
        </div>
      )}
    </>
  );
}

export default Project_management_view;
