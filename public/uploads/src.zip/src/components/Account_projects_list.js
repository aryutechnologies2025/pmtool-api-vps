import React from "react";
import "../assests/css/entryprocess.css";
import { API_URL } from "../config.js";
import { IoIosSearch } from "react-icons/io";
// import { IoFilter } from "react-icons/io5";
import { IoMdAdd } from "react-icons/io";
import { VscGitStashPop } from "react-icons/vsc";
import { VscEye } from "react-icons/vsc";
import { NavLink } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
// import { MdKeyboardArrowDown } from "react-icons/md";
import axios from "axios";
// import axios from '../api/axiosConfig.js';

import Sider from "./Sider";
import { FaBookReader } from "react-icons/fa";
import Swal from "sweetalert2";

import DatePicker from "react-datepicker";
import Breadcrumbs from "../routes/Breadcrumbs";

import "react-datepicker/dist/react-datepicker.css";
import Header from "./Header";

import ReactDOM from "react-dom";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { TfiPencilAlt } from "react-icons/tfi";
import { RiDeleteBin6Line } from "react-icons/ri";
import { TbClockExclamation } from "react-icons/tb";
import { Capitalize } from "../campsCase.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { IoIosMailOpen } from "react-icons/io";

import Tooltip from "@mui/material/Tooltip";
import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";
import { getDateFormate } from "../dateFormate.js";
import { saveAs } from "file-saver";
import Papa from "papaparse";
import { Link } from "react-router-dom";
import { FaIndianRupeeSign } from "react-icons/fa6";

import { LuBadgeDollarSign } from "react-icons/lu";
import { format, parseISO } from "date-fns";
import Loader from "../components/Loader.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";

DataTable.use(DT);
function Entryprocess() {
  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const [data, setData] = useState([]);
  const [startDate, setStartDate] = useState("");

  const [endDate, setEndDate] = useState("");
  const [showData, setShowData] = useState({});
  const [selectedId, setSelectedId] = useState(null);
  const [filteredData, setFilteredData] = useState([]);
  const [typeofwork, setTypeOfWork] = useState([]);
  const [institutions, setInstitutions] = useState([]);
  const [filterIntitution, getInstitution] = useState("all");
  const [createdby, setcreatedby] = useState("");
  const [filtertypeofwork, getTypeOfwork] = useState("all");
  //author name
  console.log('filteredData :',filteredData);
  // console.log('typeofwork :',typeofwork);
  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const created_by = parsedDetails ? parsedDetails.id : null;

  const [formData, setFormData] = useState({});
  // const [showData, setShowData] = useState({});

  const fetchData = async (params = {}) => {
    try {
      const response = await axios.get(`${API_URL}/api/entry_process/list`, {
        params: {
          start_date: params.start_date ?? startDate,
          end_date: params.end_date ?? endDate,
          type_of_work: params.type_of_work ?? filtertypeofwork,
          institutions: params.institutions ?? filterIntitution,
        },
      });
      console.log("response :", response);
      setData(response.data.details);
      setFilteredData(response.data.details);
      const uniqueTypes = response.data.typeofwork.filter(
        (item, index, self) =>
          index === self.findIndex((t) => t.type_of_work === item.type_of_work)
      );

      setTypeOfWork(uniqueTypes); // Stores unique objects
      setInstitutions(
        response.data.institutions ? response.data.institutions : []
      );
      // setAuthorName(response.data.authorname ? response.data.authorname : []);
      setcreatedby(response.data.details[0].created_by);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const fetchShowData = async (id) => {
    try {
      const responseShow = await axios.get(
        `${API_URL}/api/entry_process/filter/${id}`
      );

      setShowData(responseShow.data);
      setFormData(responseShow.data); // Initialize formData with fetched data
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  //delete function
  const handleDeleteClick = async (id) => {
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to delete this item?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "Cancel",
      reverseButtons: true,
    });
    if (result.isConfirmed) {
      try {
        const responseShow = await axios.delete(
          `${API_URL}/api/entry_process/delete/${id}`
        );
        setShowData(responseShow.data);
        fetchData();
        Swal.fire({
          icon: "success",
          title: "Deleted!",
          text: "Item deleted successfully.",
          confirmButtonText: "OK",
        });
      } catch (error) {
        if (error.response?.data?.status === "error") {
          Swal.fire({
            icon: "error",
            title: "Deletion Not Allowed",
            text: error.response?.data?.message,
            confirmButtonText: "OK",
          });
          return;
        }
      }
    } else {
      Swal.fire("Cancelled", "The item was not deleted.", "info");
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(
        `${API_URL}/api/entry_process/update/${selectedId}`,
        formData
      );
      fetchData();
      setIsOpen(false);
      setIsReadOnly(true);
    } catch (error) {
      console.error("Error updating data", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFilterClick = () => {
    fetchData();
  };

  const [isReadOnly, setIsReadOnly] = React.useState(true);
  const [isOpen, setIsOpen] = useState(false);

  const openPopup = (id) => {
    setIsOpen(true);
    setSelectedId(id);
    fetchShowData(id);
  };
  const closePopup = () => setIsOpen(false);
  // table/
  const navigate = useNavigate();

  const handleEditClick = (id) => {
    navigate("/entry-process/entryprocess-update-form", {
      state: { rowId: id },
    });
  };

  const handlePaymentViewClick = (id) => {
    navigate("/entry-process/payment-form", {
      state: { rowId: id },
    });
  };




  const handleViewClick = (id) => {
    navigate("/entry-process/process-view-details", {
      state: { rowId: id },
    });
  };

  const handlePendingClick = (id) => {
    navigate("/entry-process/pending-form", {
      state: { rowId: id },
    });
  };

  const handleChange = (event) => {
    const selectedValue = event.target.value;
    getTypeOfwork(selectedValue);
  };

  const handleInsChange = (event) => {
    const selectedValue = event.target.value;
    getInstitution(selectedValue);
  };

  // const handleAuthChange = (event) => {
  //   const selectedValue = event.target.value;
  //   getAuthorName(selectedValue);
  // };

  //exprt
  const exportToCSV = () => {
    // Define custom headers and map them to data fields
    const headers = [
      { label: "Project ID", value: "project_id" },
      { label: "Project Title", value: "title", transform: Capitalize },
      { label: "Type of Work", value: "type_of_work", transform: Capitalize },
      { label: "Entry Date", value: "entry_date", transform: getDateFormate },
      {
        label: "Process Status",
        value: "process_status",
        transform: CapitalizeCaseU,
      },
      {
        label: "Department",
        value: "department",
        transform: (data) => (data?.name ? Capitalize(data.name) : "-"),
      },
      {
        label: "Institution",
        value: "institute",
        transform: (data) => (data?.name ? Capitalize(data.name) : "-"),
      },
      { label: "Client Name", value: "client_name", transform: Capitalize },
      {
        label: "Duration",
        value: "projectduration",
        transform: getDateFormate,
      },
      {
        label: "Payment Status",
        value: "paymentStatus",
        transform: CapitalizeCaseU,
      },
    ];
    // Prepare data with headers
    const csv = Papa.unparse({
      fields: headers.map((header) => header.label),
      data: filteredData.map((row) => {
        return headers.map((header) => {
          if (header.value === "paymentStatus") {
            // Ensure payment_process exists before accessing payment_status
            const paymentStatus = row.payment_process?.payment_status || "-";
            return header.transform
              ? header.transform(paymentStatus)
              : paymentStatus;
          }

          return header.transform
            ? header.transform(row[header.value])
            : row[header.value];
        });
      }),
    });

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });

    const currentDate = new Date();
    const formattedCurrentDate = currentDate.toISOString().split("T")[0];

    const formattedStartDate = formattedCurrentDate.replace(/-/g, "");
    const formattedEndDate = formattedCurrentDate.replace(/-/g, "");
    const fileName = `entryprocess_${formattedStartDate}_to_${formattedEndDate}.csv`;

    // Use FileSaver to save the file
    saveAs(blob, fileName);
  };

  //edit payment
  const handleEditPayment = (id) => {
    navigate("/entry-process/payment-edit-form", {
      state: { rowId: id },
    });
  };

  const truncateText = (text, limit) => {
    if (text && text.length > limit) {
      return text.slice(0, limit) + "..."; // Truncate and add ellipsis if text is longer
    }
    return text;
  };
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const submenuRef = useRef(null);
  const mails = [
    { id: 1, name: "Project Entry Email", value: "project_entry_email" },
    { id: 2, name: "Project Status Email", value: "project_status_email" },
    {
      id: 3,
      name: "Project Payment Status Email",
      value: "project_payment_status_email",
    },
    { id: 4, name: "Advance", value: "advance_payment" },
    { id: 5, name: "Partial Payment", value: "partial_payment" },
    { id: 6, name: "Final Payment", value: "final_payment" },
  ];
  useEffect(() => {
    const handleClickOutside = (event) => {
      // Check if the click is outside the submenu and the icon itself
      if (submenuRef.current && !submenuRef.current.contains(event.target)) {
        setIsMenuOpen(false);
      }
    };

    // Add event listener for clicks
    document.addEventListener("mousedown", handleClickOutside);

    // Clean up the event listener on component unmount
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const [project_not_id, setProjectNotID] = useState("");

  const handleMenuToggle = (id) => {
    setIsMenuOpen((prev) => {
      const newState = !prev;
      // console.log("isMenuOpen:", newState);
      return newState;
    });
    setProjectNotID(id);
  };

  const handleNotificationViewClick = (projectv, pid) => {
    // Show confirmation dialog before proceeding

    // console.log("check projectv", projectv);

    const projctid = project_not_id;
    Swal.fire({
      title: CapitalizeCaseU(projectv),
      text: "Do you want to send the notification to the client?",
      // icon: "warning",
      html: `
          <div class="mb-3 text-start">
              <label for="swal-textarea" class="form-label ">Mail Content</label>
              <textarea id="swal-textarea" class="form-control border border-secondary" 
                        rows="3" placeholder="Enter your message..."></textarea>
          </div>
      `,
      showCancelButton: true,
      confirmButtonText: "Send Email",
      cancelButtonText: "No, cancel",
      preConfirm: () => {
        const message = document.getElementById("swal-textarea").value;
        if (!message) {
          Swal.showValidationMessage("Message cannot be empty");
        }
        return message;
      },
    }).then((result) => {
      if (result.isConfirmed) {
        // If user confirms, send the notification
        axios
          .get(
            `${API_URL}/api/entry_process/project_client_notification/${pid}`,
            {
              params: {
                created_by: created_by,
                notification_v: projectv,
              },
            }
          )

          .then((response) => {
            Swal.fire({
              icon: "success",
              title: "Notification Sent",
              text: "The email notification was sent successfully.",
            });
          })
          .catch((error) => {
            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Failed to send the notification.",
            });
          });
      } else {
        // If user cancels, show a cancellation message (optional)
        Swal.fire({
          icon: "info",
          title: "Cancelled",
          text: "The notification was not sent.",
        });
      }
    });
  };



  function handleInvoiceViewClick(id) {
  // If using React Router:
  window.location.href = `/accounts-task-view/${id}`;

  // OR if using plain JS:
  // navigate(`/accounts-task-view/${id}`);  <-- won't work unless navigate is global
}

  const columns = [
    {
      title: " Project ID".toUpperCase(),
      data: "project_id",
      render: (data) => Capitalize(data),
    },
   {
         title: "DATE",
         data: "entry_date",
         render: (data, type) => {
           if (!data) return "";
   
           if (type === "sort" || type === "filter") {
             return new Date(data).getTime();
           }
   
           return getDateFormate(data);
         },
       },
    {
      title: "Department".toUpperCase(),
      data: null,
      render: (data) =>
        data?.department?.name ? Capitalize(data.department.name) : "-",
    },
    {
      title: "Institution".toUpperCase(),
      data: null,
      render: (data) =>
        data?.institute?.name ? Capitalize(data.institute.name) : "-",
    },
    {
      title: "Client Name".toUpperCase(),
      data: "client_name",
      render: (data) => `Dr.${Capitalize(data)}`,
    },
    {
      title: "Profession".toUpperCase(),
      data: null,
      render: (data) =>
        data?.profession?.name ? Capitalize(data.profession.name) : "-",
    },
   {
        title: "TITLE",
        data: null,
        render: (data, type, row) => {
          if (type === 'filter' || type === 'sort') {
        // Return plain text for DataTables filtering/sorting
        return row.title || '';
      }
          const id = `title-${row.sno || Math.random()}`;
  
          setTimeout(() => {
            const container = document.getElementById(id);
            if (container && !container.hasChildNodes()) {
              ReactDOM.render(
                <div
                  className="d-flex justify-content-center"
                  // onClick={togglePopuptitle}
                  onMouseEnter={() => row.title} // Pass title dynamically
                  // onMouseLeave={handleMouseLeave}
                  id={`title-${row.sno || Math.random()}`}
                >
                  {truncateText(row.title, 10)}
                </div>,
  
                container
              );
            }
          }, 0);
  
          return `<div id="${id}"></div>`;
        },
      },
    {
      title: "Process Status".toUpperCase(),
      data: null,
      render: (data) => {
        const status = data.process_status?.toLowerCase() || "";
        const classMap = {
          in_progress: "status-in-progress",
          completed: "status-completed",
          not_assigned: "status-not-assigned",
          pending_author: "status-pending-author",
          withdrawal: "status-withdrawn-author",
          client_review: "status-client-review",
        };

        const className = `status-badge ${classMap[status] || ""}`;

        // Utility to convert snake_case or lowercase to Capitalized Words
        const formatStatus = (str) =>
          str.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());

        return `<div class="${className}">${formatStatus(status)}</div>`;
      },
    },
    {
      title: "Duration".toUpperCase(),
      data: "projectduration",
      // render: (data) => getDateFormate(data),
    },
    {
      title: "PAYMENTs".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;

        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="">
                {row.payment_process !== null && (
                  <>
                    <div className="d-flex justify-content-around mt-1">
                      <button
                        className="payment-notification pt-1"
                        onClick={() => handleEditPayment(row.id)}
                      >
                        Update
                      </button>
                    </div>
                    <div className="mt-2 paymentstatusv">
                      {CapitalizeCaseU(row.payment_process?.payment_status)}
                    </div>
                  </>
                )}
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  {
    title: "INVOICE",
    data: null,
    createdCell: (td, cellData, rowData) => {
      if (rowData.payment_process?.payment_status === "completed") {
        ReactDOM.render(
          <button
            className="btn btn-sm btn-outline-primary"
            onClick={() => handleInvoiceViewClick(rowData.project_id)}
          >
            View Invoice
          </button>,
          td
        );
      } else {
        td.innerText = "-";
      }
    },
  },




    // {
    //   title: "MAIL NOTIFICATION",
    //   data: null,
    //   render: (data, type, row) => {
    //     if (row.email) {
    //       const id = `process-${row.sno || Math.random()}`;

    //       setTimeout(() => {
    //         const container = document.getElementById(id);
    //         if (container && !container.hasChildNodes()) {
    //           container.innerHTML = `
    //             <div class="position-relative view-pending" id="mailMenu-${
    //               row.id
    //             }">
    //               Select Mail
    //               <i class="fa fa-chevron-down"></i>
    //               <div class="dropdown-menu position-absolute" style="display: none;">
    //                 ${mails
    //                   .map(
    //                     (mail) =>
    //                       `<div class="dropdown-item" data-value="${mail.value}">
    //                         ${mail.name}
    //                       </div>`
    //                   )
    //                   .join("")}
    //               </div>
    //             </div>
    //           `;
    //         }

    //         // Event Delegation for Handling Submenu Click
    //         const mailMenu = document.getElementById(`mailMenu-${row.id}`);
    //         if (mailMenu) {
    //           mailMenu.addEventListener("click", (e) => {
    //             const dropdownMenu = mailMenu.querySelector(".dropdown-menu");
    //             dropdownMenu.style.display =
    //               dropdownMenu.style.display === "none" ? "block" : "none";

    //             // If dropdown item is clicked
    //             if (e.target.classList.contains("dropdown-item")) {
    //               const selectedValue = e.target.getAttribute("data-value");
    //               handleNotificationViewClick(selectedValue, row.id);

    //               dropdownMenu.style.display = "none";
    //             }
    //           });

    //           // Close submenu when clicking outside
    //           document.addEventListener("click", (e) => {
    //             if (!mailMenu.contains(e.target)) {
    //               const dropdownMenu = mailMenu.querySelector(".dropdown-menu");
    //               dropdownMenu.style.display = "none";
    //             }
    //           });
    //         }
    //       }, 0);

    //       return `<div id="${id}"></div>`;
    //     } else {
    //       return "<div>No client email added</div>";
    //     }
    //   },
    // },
    // {
    //   title: "ACTIONS",
    //   data: null,
    //   render: (data, type, row) => {
    //     const id = `process-${row.sno || Math.random()}`;
    //     setTimeout(() => {
    //       const container = document.getElementById(id);
    //       if (container && !container.hasChildNodes()) {
    //         ReactDOM.render(
    //           <div className="">
    //             <div className="d-flex  justify-content-around modula-main-table mt-1  ">
    //               <div className="" title="View">
    //                 <span>
    //                   <VscEye
    //                     onClick={() => handleViewClick(row.id)}
    //                     className="open-icon"
    //                   />
    //                 </span>
    //               </div>
    //               <div className="border border-1"></div>

    //               <div className="" title="Task View">
    //                 <span>
    //                   <FaBookReader
    //                     onClick={() =>
    //                       navigate(`/project-view/${row.project_id}`)
    //                     }
    //                     className="view-icon-task"
    //                   />
    //                 </span>
    //               </div>
    //               <div className="border border-1"></div>
    //               <div className=" " title="Update">
    //                 <span>
    //                   <TfiPencilAlt onClick={() => handleEditClick(row.id)} />
    //                 </span>
    //               </div>

    //               <div className="border border-1"></div>
    //               <div className="modula-icon-del " title="Delete">
    //                 <span>
    //                   <RiDeleteBin6Line
    //                     onClick={() => handleDeleteClick(row.id)}
    //                   />
    //                 </span>
    //               </div>
    //             </div>
    //           </div>,

    //           container
    //         );
    //       }
    //     }, 0);
    //     return `<div id="${id}"></div>`;
    //   },
    // },
  ];

  const handleStartDateChange = (date) => {
    setStartDate(date ? format(date, "yyyy-MM-dd") : null);
  };

  const handleEndDateChange = (date) => {
    setEndDate(date ? format(date, "yyyy-MM-dd") : null);
  };

  const handleTypeOfWorkChange = (event) => {
    getTypeOfwork(event.target.value);
  };

  const handleInstitutionChange = (event) => {
    getInstitution(event.target.value);
  };

  // const handleAuthorNameChange = (event) => {
  //   getAuthorName(event.target.value);
  // };

  const handleClearClick = () => {
    setStartDate("");
    setEndDate("");
    getTypeOfwork("all");
    getInstitution("all");
    // getAuthorName("all");
    fetchData({
      start_date: "",
      end_date: "",
      type_of_work: "all",
      institutions: "all",
      // author_name: "all",
    }); // Send empty values to the backend on the first click
  };

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }

  return (
    <section className="container d-flex flex-column justify-content-between min-vh-100">
      <div className=" row mt-4">
        {/* <div className=" col-1   d-flex justify-content-center">
          <Sider></Sider>
        </div> */}

        <div className="col-12  ">
          <div className="col-12">
            <Header></Header>
          </div>

          <div className="col-12 mt-3 pt-1 wapper w-100 py-5">
            {/* <div className=" row mt-3 d-flex w-100 ">
              <div className="pt-2 px-2 d-none d-md-block">
                <Breadcrumbs></Breadcrumbs>
              </div>

              <div className="col-7 col-md-5 d-flex mt-2 px-4 ">
                <p className="heading-entr">Entry Process</p>
              </div>


              <div className="col-5 col-md-2 text-center mt-2 ">
                <div className=" d-flex justify-content-center    ">
                  <Tooltip title="Add Project" >
                    <div className="add-icon">
                      <NavLink to="/entry-process/enter_process_form">
                        <IoMdAdd className="add1-icon" />
                      </NavLink>
                    </div>
                  </Tooltip>
                  <div className="add-icon">
                    <VscGitStashPop className="exit-icon" onClick={exportToCSV} />
                  </div>
                </div>
              </div>
              <div className="container  col-12  col-md-5 col-lg-5 col-xl-5 ">
                <div className="row ">
                  <div className=" col-6  col-md-6 col-lg-6 col-xl-3 ">
                    <label htmlFor="start-date" className="px-2 site-name ms-3 ms-md-0">Start-Date</label>
                    <DatePicker
                      id="start-date"
                      className="form-control ms-3 ms-md-0"
                      selected={new Date(startDate)}
                      value={startDate}
                      onChange={(date) => setStartDate(date.toISOString().split("T")[0])} // Convert to yyyy-mm-dd format
                    />
                  </div>

                  <div className="col-6 col-md-6 col-lg-6 col-xl-3 ">
                    <label htmlFor="end-date" className="px-2 site-name">End-Date</label>
                    <DatePicker
                      id="end-date"
                      className="form-control "
                      selected={new Date(endDate)}
                      value={endDate}
                      onChange={(date) => setEndDate(date.toISOString().split("T")[0])} // Convert to yyyy-mm-dd format
                    />
                  </div>
                  <div className="col-6 col-md-6 col-lg-6 col-xl-3 ">

                    <select className=" form-select mt-4 ms-3 ms-md-0 " value={filtertypeofwork} onChange={handleChange}>
                      <option value="all">Type Of Work</option>
                      {typeofwork.map((work) => (
                        <option key={work.type_of_work} value={work.type_of_work}>
                          {Capitalize(work.type_of_work)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="col-6 col-md-6 col-lg-6 col-xl-3 ">
                    <label htmlFor="end-date" className="px-2 site-name">Institutions</label>

                    <select className=" form-select mt-4 ms-3 ms-md-0 " value={filterIntitution} onChange={handleInsChange}>
                      <option value="all">Institutions</option>
                      {institutions.map((work) => (
                        <option key={work.id} value={work.id}>
                          {Capitalize(work.name)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="col-6 col-md-6 col-lg-6 col-xl-3 ">
                    <label htmlFor="end-date" className="px-2 site-name">Author Name</label>

                    <select className=" form-select mt-4 ms-3 ms-md-0 " value={filterAuthorName} onChange={handleAuthChange}>
                      <option value="all">Select an author</option>
                      {authorname.map((work) => (
                        <option key={work.id} value={work.id}>
                          {Capitalize(work.employee_name)}
                        </option>
                      ))}
                    </select>
                  </div>


                  <div className="col-6 col-md-6 col-lg-6 col-xl  d-flex justify-content-center align-items-end">
                    <button className="save-form-add " onClick={fetchData}>
                      Filter
                    </button>
                  </div>
                </div>


              </div>

              <Tooltip title="Add Payment" >

                <div className="d-flex justify-content-end"><NavLink to="/entry-process/payment-form">
                  <button className="save-form-save mt-1">Add Payment</button>
                </NavLink></div>

              </Tooltip>
            </div> */}

            <div className=" row mt-3 d-flex   w-100 ">
              <div className="col-12 col-md-9  px-4 ">
                <p className="heading-entr">Project List</p>
              </div>
              <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>

            {/* <div className="row p-3">
              <div className="col-12 d-flex justify-content-between">
                <div className="col">
                  <label htmlFor="start-date mx-2" className="site-name">
                    Start-Date
                  </label>
                  <DatePicker
                    id="start-date"
                    className="form-control-date"
                    selected={new Date(startDate)}
                    onChange={(date) =>
                      setStartDate(date.toISOString().split("T")[0])
                    }
                  />
                </div>

                <div className="col">
                  <label htmlFor="end-date mx-2" className="site-name">
                    End-Date
                  </label>
                  <DatePicker
                    id="end-date"
                    className="form-control-date"
                    selected={new Date(endDate)}
                    onChange={(date) =>
                      setEndDate(date.toISOString().split("T")[0])
                    }
                  />
                </div>

                <div className="col mt-4 mx-3">

                  <select
                    id="type-of-work"
                    className="form-select-date"
                    value={filtertypeofwork}
                    onChange={handleChange}
                  >
                    <option value="all">Type Of Work</option>
                    {typeofwork.map((work) => (
                      <option key={work.type_of_work} value={work.type_of_work}>
                        {Capitalize(work.type_of_work)}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="col mx-2 ">
                  <label htmlFor="institutions" className="px-2 site-name">Institutions</label>
                  <select id="institutions" className=" form-select-date  ms-3 ms-md-0 " value={filterIntitution} onChange={handleInsChange}>
                    <option value="all">Institutions</option>
                    
                    {institutions.length>0 && institutions.map((work) => (
                      <option key={work.id} value={work.id}>
                        {Capitalize(work.name)}
                      </option>
                    ))}
                  </select>
                </div>


                <div className="col mx-2 ">
                  <label htmlFor="end-date" className="px-2 site-name">Author Name</label>

                  <select className="form-select-date ms-3 ms-md-0 " value={filterAuthorName} onChange={handleAuthChange}>
                    <option value="all">Select an author</option>
                    {authorname.map((work) => (
                      <option key={work.id} value={work.id}>
                        {Capitalize(work.employee_name)}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="col mt-4 px-4">
                  <button className="button-primary" onClick={fetchData}>
                    Filter
                  </button>
                </div>
              </div>
              <div className="row">

                <div className="col-5 d-flex justify-content-end mt-3">
                  <div className="col d-flex justify-content-center align-items-end">
                    <Link
                      to="/entry-process/enter_process_form"
                      className="text-decoration-none process-icon"
                    >
                      <IoMdAdd className="mb-1 icon-style" />
                      <span className="process-label mx-1">PROCESS</span>
                    </Link>
                  </div>
                  <div className="col d-flex justify-content-center align-items-end">
                    <Link
                      to="/entry-process/payment-form"
                      className="text-decoration-none"
                    >
                      <IoMdAdd mb-1 className="mb-1 icon-style" />
                      <span className="process-label mx-1">ADD PAYMENT</span>
                    </Link>
                  </div>

                  <div className="col d-flex justify-content-center align-items-end">
                    <div
                      className="text-decoration-none"
                      onClick={exportToCSV}
                    >
                      <VscGitStashPop className="mb-1 icon-style" />
                      <span className="process-label mx-1">EXPORT</span>
                    </div>
                  </div>
                </div>
              </div>
            </div> */}

            <div className="row px-5 d-flex justify-content-end">
              <div className=" d-flex justify-content-end ">
                {/* <div className="col d-flex justify-content-center align-items-end">
                    <Link
                      to="/entry-process/enter_process_form"
                      className="text-decoration-none process-icon"
                    >
                      <IoMdAdd className="mb-1 icon-style" />
                      <span className="process-label mx-1">PROCESS</span>
                    </Link>
                  </div> */}
                {/* <div className=" text-center ">
                  <div className=" d-flex justify-content-center    ">
                    <Tooltip title="Add Project">
                      <div className="add-icon">
                        <NavLink to="/entry-process/enter_process_form">
                          <IoMdAdd className="add1-icon" />
                        </NavLink>
                      </div>
                    </Tooltip>
                    <Tooltip title="Export">
                      <div className="add-icon">
                        <VscGitStashPop
                          className="add1-icon"
                          onClick={exportToCSV}
                        />
                      </div>
                    </Tooltip>
                  </div>
                </div> */}

                {/* <div className="col d-flex justify-content-center align-items-end">
                    <div
                      className="text-decoration-none"
                      onClick={exportToCSV}
                    >
                      <VscGitStashPop className="mb-1 icon-style" />
                      <span className="process-label mx-1">EXPORT</span>
                    </div>
                  </div> */}
              </div>
            </div>
            {/* <div className="row px-5 ">
              <div className="col d-flex justify-content-end align-items-end">
                <Link
                  to="/entry-process/payment-form"
                  className="text-decoration-none process-btn mt-1"
                >
                  <IoMdAdd mb-1 className="mb-1 icon-style" />
                  <span className="process-label mx-1">ADD PAYMENT</span>
                </Link>
              </div>
            </div> */}

            {/* */}

            <div className="row p-2">
              <div className="col-12 d-flex flex-wrap justify-content-between gap-3">
                <div className="d-flex flex-wrap justify-content-left gap-3">
                  <div className="width-default">
                    <label htmlFor="start-date" className="mx-2">
                      Start-Date
                    </label>
                    <DatePicker
                      type="date"
                      id="start-date"
                      className="form-control-date"
                      selected={startDate ? parseISO(startDate) : null}
                      onChange={handleStartDateChange}
                      autoComplete="off"
                      isClearable
                      dateFormat="yyyy-MM-dd"
                    />
                  </div>

                  <div className="width-default">
                    <label htmlFor="end-date" className="mx-2">
                      End-Date
                    </label>
                    <DatePicker
                      type="date"
                      id="end-date"
                      className="form-control-date"
                      selected={endDate ? parseISO(endDate) : null}
                      onChange={handleEndDateChange}
                      autoComplete="off"
                      isClearable
                      dateFormat="yyyy-MM-dd"
                    />
                  </div>

                  <div className="mt-4 width-default">
                    <select
                      id="type-of-work"
                      className="form-select-date"
                      value={filtertypeofwork}
                      onChange={handleTypeOfWorkChange}
                    >
                      <option value="all">Type Of Work</option>
                      {typeofwork.map((work) => (
                        <option
                          key={work.type_of_work}
                          value={work.type_of_work}
                        >
                          {Capitalize(work.type_of_work)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="width-default">
                    <label htmlFor="institutions" className="px-2">
                      Institutions
                    </label>
                    <select
                      id="institutions"
                      className="form-select-date ms-3 ms-md-0"
                      value={filterIntitution}
                      onChange={handleInstitutionChange}
                    >
                      <option value="all">Institutions</option>
                      {institutions.length > 0 &&
                        institutions.map((work) => (
                          <option key={work.id} value={work.id}>
                            {Capitalize(work.name)}
                          </option>
                        ))}
                    </select>
                  </div>

                  {/* <div className="width-default">
                    <label htmlFor="author-name" className="px-2">
                      Author Name
                    </label>
                    <select
                      id="author-name"
                      className="form-select-date ms-3 ms-md-0"
                      value={filterAuthorName}
                      onChange={handleAuthorNameChange}
                    >
                      <option value="all">Select an author</option>
                      {authorname.map((work) => (
                        <option key={work.id} value={work.id}>
                          {Capitalize(work.employee_name) +
                            "/" +
                            Capitalize(work.employee_type)}
                        </option>
                      ))}
                    </select>
                  </div> */}

                  <div className="mt-4">
                    <button
                      className="button-primary"
                      onClick={handleFilterClick}
                    >
                      Filter
                    </button>
                  </div>

                  <div className="mt-4 ">
                    <button
                      className="button-primary-all"
                      onClick={handleClearClick}
                    >
                      All Clear
                    </button>
                  </div>
                </div>

                <div className="d-flex justify-content-end">
                  <div className="text-center mt-3">
                    <div className="d-flex justify-content-center gap-2">
                      <Tooltip title="Export">
                        <div className="add-icon">
                          <VscGitStashPop
                            className="add1-icon"
                            onClick={exportToCSV}
                          />
                        </div>
                      </Tooltip>
                    </div>
                  </div>

                  {/* <div className="d-flex justify-content-center mt-3 mx-1">
                    <Tooltip title="Add Payment">
                      <div className="add-icon">
                        <NavLink to="/entry-process/payment-form">
                          <FaIndianRupeeSign className="add1-icon mx-2" />
                        </NavLink>
                      </div>
                    </Tooltip>
                  </div> */}
                </div>
              </div>
            </div>
            <div className="p-2">
              {/* <DataTable
                id="example"
                data={filteredData}
                columns={columns}
                className="display"
                options={{ scrollX: true, select: true,pageLength:10,lengthMenu:[[10,20,30,50]] }}
                
              /> */}
              <DataTable
                id="example"
                data={filteredData}
                columns={columns}
                className="display"
                options={{
                  scrollX: true,
                  select: true,
                  pageLength: 20, // Default number of rows per page
                  lengthMenu: [
                    [20, 30, 50],
                    [20, 30, 50],
                  ],
                  order: [],
                   columnDefs: [{ width: "100px", targets: "_all" }],
                  columnDefs: [
                    {
                      targets: 1,
                      searchable: false,
                    },
                  ],
                  // columnDefs: [
                  //   {
                  //     targets: 0,
                  //     orderable: false,
                  //   },
                  // ],
                }}
              />

              {/* {isHovered && (
                <div
                  className="modal-container-view position-fixed"
                  // onMouseEnter={() => handleMouseEnter(row.title)}
                  onMouseLeave={handleMouseLeave}
                >
                  {" "}
                  <div className="modal-box">
                    <div className="d-flex justify-content-end">
                      <span
                        className="modal-close"
                        onClick={() => setIsHovered(false)}
                      >
                        &times;
                      </span>
                    </div>
                    <div className="modal-body">
                      <div className="row mb-3">
                        <div className="col-12 text-start project-account">
                          TITLE :
                        </div>
                        <div className="col-12 text-start view-project-title1">
                          {hoveredTitle || "No Title"}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )} */}
            </div>
          </div>
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </section>
  );
}

export default Entryprocess;
