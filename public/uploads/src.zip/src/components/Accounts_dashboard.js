import React, { useState, useEffect } from "react";
import Header from "../components/Header.js";
// import { AiOutlineAlert } from "react-icons/ai";
// import { MdDoNotDisturb } from "react-icons/md";
import { FaFileInvoiceDollar } from "react-icons/fa6";
// import { GiPiggyBank } from "react-icons/gi";
import DataTable from "datatables.net-react";
// import DT from "datatables.net-dt";
import { FaHandHoldingDollar } from "react-icons/fa6";
import ReactDOM from "react-dom";
import { IoTimer } from "react-icons/io5";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { FaMoneyCheckAlt } from "react-icons/fa";
import axios from "axios";
import { API_URL } from "../config.js";
import Swal from "sweetalert2";
import $ from "jquery";
import { Capitalize } from "../campsCase.js";
import { getDateFormate } from "../dateFormate.js";
import Breadcrumbs from "../routes/Breadcrumbs";
import Footer from "../components/Footer";
import Loader from "../components/Loader.js";
import { Navigate } from "react-router";
import { formatIndianCurrency } from "../AmountFormet.js";
import { useLocation } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import { CapitalizeCaseU } from "../capsUnderCaseU.js";


function Accounts_dashboard() {
  const [data, setData] = useState(null);

  // const sampleData = [
  //   {
  //     clientname: "Alice Johnson",
  //     projectid: "PRJ001",
  //     projectname: "Manuscript01",
  //     paymentdate: "2025-01-01",
  //     paymentstatus: "Completed",
  //   },
  //   {
  //     clientname: "Bob Smith",
  //     projectid: "PRJ002",
  //     projectname: "Manuscript02",
  //     paymentdate: "2025-02-15",
  //     paymentstatus: "Pending",
  //   },
  //   {
  //     clientname: "Carol Davis",
  //     projectid: "PRJ003",
  //     projectname: "Research Paper",
  //     paymentdate: "2025-01-25",
  //     paymentstatus: "pending",
  //   },
  //   {
  //     clientname: "David Brown",
  //     projectid: "PRJ004",
  //     projectname: "Thesis Review",
  //     paymentdate: "2025-03-10",
  //     paymentstatus: "completed",
  //   },
  //   {
  //     clientname: "Evelyn Green",
  //     projectid: "PRJ005",
  //     projectname: "Journal Submission",
  //     paymentdate: "2025-04-05",
  //     paymentstatus: "Completed",
  //   },
  // ];
  const navigate = useNavigate();

  
  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;

  const [isOpen, setIsOpen] = useState(false);
  const [modalData, setModalData] = useState({
    paymentStatus: "",
    totalCost: 0,
    projectId: "",
  });

  const togglePopup = (paymentStatus, total_cost, projectid) => {
    setModalData({
      paymentStatus,
      totalCost: total_cost,
      projectId: projectid,
    });
    setIsOpen(!isOpen);
  };

  //verify check
  const paymentVerify = async (
    paymentStatus,
    payment_id,
    project_id,
    rowIndex
  ) => {
    try {
      // console.log("paymentStatus :", paymentStatus);
      if (paymentStatus === "completed") {
        const result = await Swal.fire({
          icon: "question",
          title: "Are you sure?",
          text: "Do you want to change the payment status?",
          showCancelButton: true,
          confirmButtonText: "Yes, proceed",
          cancelButtonText: "No, cancel",
        });

        if (!result.isConfirmed) {
          // If the user clicks "No", exit without making the request
          return;
        }
        // Make the request to the backend
        const response = await axios.post(
          `${API_URL}/api/payment_processes/payment-status`,
          {
            payment_id: payment_id,
            project_id: project_id,
            created_by: createdby,
          }
        );
        // Display success message
        Swal.fire({
          icon: "success",
          title: "Payment Status Updated!",
          text: "The payment status has been successfully updated.",
          confirmButtonText: "OK",
        });

        fetchPayementProject();
        console.log("Payment status updated successfully", response.data);
      } else {
        await Swal.fire({
          icon: "question",
          title: "Payment Pending",
          text: "Your payment is still pending. Verification will be available once the payment is completed.",
          confirmButtonText: "OK",
        });
      }
    } catch (error) {
      console.error("Error updating payment status", error);

      // Display error message
      Swal.fire({
        icon: "error",
        title: "Error!",
        text: error.response
          ? error.response.data.message
          : "There was an issue updating the payment status.",
        confirmButtonText: "Try Again",
      });
    }
  };

  const[paymentId, setPaymentId] = useState([]);
  const[advanceId, setAdvanceId] = useState([]);
  const[partialIds, setPartialId] = useState([]);
  const[finalIds, setFinalId] = useState([]);
  const handleCardClick = (value) => (e) => {
    e.preventDefault();
    localStorage.setItem('paymentStatus', value);
    if(value === 'advance_pending'){
    localStorage.setItem('projectallid', JSON.stringify(advanceId));
    } else if(value === 'completed'){
     localStorage.setItem('projectallid', JSON.stringify(paymentId));
    }
    else if(value === 'partial_payment_pending'){
     localStorage.setItem('projectallid', JSON.stringify(partialIds));
    }
    else if(value === 'final_payment_pending'){
     localStorage.setItem('projectallid', JSON.stringify(finalIds));
    }

    window.open('/projectlist', '_blank');
  };

  // const handleidClick = (projectallid) => {
  //   navigate('/nextpage', { state: { projectallid } });
  // }

  
  // window. handleidClick = (projectallid) => {
  //   // Store the projectType in localStorage
  //   localStorage.setItem('projectType', projectallid);
  //   console.log("proud:",projectallid)
  //   // Open the new tab with the projectlist URL
  //   window.open('/projectlist', '_blank', 'noopener,noreferrer');
  // };

  window.handleidClick = function(value1, value2) {
    // console.log("Clicked value1:", value1);  
    // console.log("Clicked value2:", value2);  
  
    // Set the first value in localStorage
    localStorage.setItem('empname', value1);
  
    // Set the second value in localStorage
    localStorage.setItem('projectallid', value2);
  
    // Open the new page in a new tab
    window.open('/projectlist', '_blank');
  };



  const columns = [
    { title: "Client Name".toUpperCase(), data: null,
            render: (data) => `Dr.${CapitalizeCaseU(data.client_name)}`,
      
     },
    { title: "Project ID".toUpperCase(), data: null,
                  render: (data) => CapitalizeCaseU(data.project_id),

     },
    // { title: "Project Name", data: "title" },
    {
      title: "Payment Date".toUpperCase(),
      data: "paymentdate",
      render: (data) => {
        // Check if data is valid (not null, undefined, empty, or '-')
        return data && data !== "-" ? getDateFormate(data) : "-";
      },
    },
    {
      title: "Payment Status".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        const id = `actions-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            const paymentStatus = row.paymentstatus;
            const total_cost = row.total_cost;
            const projectid = row.project_id;

            // Determine the class based on payment status
            let statusClass = "status-other";
            let handleClick = null;
            let displayText = "";

            if (paymentStatus === "completed") {
              statusClass = "status-completed-account ";
              displayText = "Completed";
            } else if (paymentStatus === "-") {
              displayText = "-";
            } else {
              statusClass = "status-pending";
              handleClick = () =>
                togglePopup(paymentStatus, total_cost, projectid);
              displayText = "Pending";
            }

            // Only render if paymentStatus is not "-"
            if (paymentStatus !== "-") {
              ReactDOM.render(
                <div className="d-flex justify-content-center">
                  <div className="">
                    <div className={`${statusClass}`} onClick={handleClick}>
                      {displayText}
                    </div>
                  </div>
                </div>,
                container
              );
            } else {
              // If paymentStatus is "-", render nothing or some specific content for that case
              ReactDOM.render(
                <div className="d-flex justify-content-center">
                  <div className="">
                    <div className="status-other">{displayText}</div>
                  </div>
                </div>,
                container
              );
            }
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
    // {
    //   title: "Actions".toUpperCase(),
    //   data: null,
    //   render: (data, type, row, meta) => {
    //     const id = `actions-${row.sno || Math.random()}`;
    //     const paymentdate = row.paymentdate;
    //     const is_verify = row.is_verify;
    //     const rowIndex = meta.row; // Get the row index
    //     setTimeout(() => {
    //       const container = document.getElementById(id);
    //       if (container && !container.hasChildNodes()) {
    //         ReactDOM.render(
    //           <div className="d-flex justify-content-center">
    //             {paymentdate && paymentdate !== "-" ? (
    //               <div className="">
    //                 {is_verify === 0 ? (
    //                   // Pass a function to the onClick handler
    //                   <button
    //                     className="verify-button"
    //                     onClick={() =>
    //                       paymentVerify(
    //                         row.paymentstatus,
    //                         row.payment_id,
    //                         row.id,
    //                         rowIndex
    //                       )
    //                     }
    //                   >
    //                     Verify
    //                   </button>
    //                 ) : (
    //                   <button className="verify-button">Verified</button>
    //                   // <span></span>
    //                 )}
    //               </div>
    //             ) : (
    //               <div className="">{"-"}</div>
    //             )}
    //           </div>,
    //           container
    //         );
    //       }
    //     }, 0);
    //     return `<div id="${id}"></div>`;
    //   },
    // },
  ];


 
  let currentOpenRowId = null;

  document.addEventListener("click", (event) => {
    if (currentOpenRowId) {
      const isClickInside =
        event.target.closest("tr") || event.target.closest(".full-info-row");

      if (!isClickInside) {
        const openRow = document.getElementById(currentOpenRowId);
        if (openRow) {
          openRow.style.display = "none"; // Close the open detail row
        }
        currentOpenRowId = null; // Reset the current open row
      }
    }
  });

  // const [freelancerData, setPaymentDataDetails] = useState([]);
  const [freelancerData, setPaymentDataDetails] = useState([]);


  // console.log("freelancerData :", freelancerData);

  


  const fetchClientDetails = async (clientId, type) => {
    try {
      const response = await axios.get(
        `${API_URL}/api/payment_processes/get-client-details/${clientId}`,
        {
          params: { type },
        }
      );
      const tableData = response.data.projects;
      
      return tableData;
    } catch (error) {
      console.error("Error fetching client details:", error);
      return []; // Return an empty array if the fetch fails
    }
  };
  // const freelancerId = localStorage.getItem('empname');  
  // console.log("Freelancer ID:", freelancerId);
  // console.log("Project IDs:", projectIds);
  
  window.handleidClick = function(freelancerId, projectIdsJson) {
    const projectIds = JSON.parse(projectIdsJson);
  
    // console.log("Clicked freelancerId:", freelancerId);  
    // console.log("Clicked projectIds:", projectIds);  
  
    // Store values in localStorage
    localStorage.setItem('empname', freelancerId);
    localStorage.setItem('projectallid', JSON.stringify(projectIds));
  
    // Navigate to another page
    window.open('/projectlist', '_blank');
  };

  const columns1 = [
    {
      title: "Freelancer Name".toUpperCase(),
      data: "freelancer_name",
    },
    //  { title: "Total Project  ", data: "freelancer_project_count",
    //       render: function (data, type, row, meta) {
    //         return `<span class="my-clickable-span" onclick="handleidClick( '${row.freelid}')">${data}</span>`;
    //       }
    //      },

    {
      title: "Total Project",
      data: "freelancer_project_count",
      render: function (data, type, row, meta) {
        const freelancerId = row.freelancer_id;
        const projectIds = row.freelancer_project_id.map(item => item.project_id);
        return `<span class="my-clickable-span" onclick='handleidClick(${freelancerId}, ${JSON.stringify(JSON.stringify(projectIds))})'>${data}</span>`;
      }
    },
    // { title: "Total Project".toUpperCase(), data: "freelancer_project_count" },
    {
      title: "Total Amount".toUpperCase(), // Column title in uppercase
      data: "freelancer_total_payment", // Data key to access in each row
      render: (data) => formatIndianCurrency(Number(data) || 0)
    },
    {
      title: "Paid Amount".toUpperCase(), // Column title in uppercase
      data: "freelancerPaidAmount", // Data key to access in each row
      render: (data) => formatIndianCurrency(Number(data) || 0)
    },
    {
      title: "Balance Amount".toUpperCase(), // Column title in uppercase
      data: "freelancerPendingAmount", // Data key to access in each row
      render: (data) => formatIndianCurrency(Number(data) || 0)
    },

    // { title: "Payment Status", data: "payment_status", render: (data) => Capitalize(data) },
  ];
  //fetch data

  const [paymentData, setPaymentData] = useState({
    totalPaymentPendingCount: 0,
    totalAdvancePendingCount: 0,
    totalPartialPaymentPendingCount: 0,
    totalPaymentPending: 0,
    totalAdvancePending: 0,
    totalPartialPaymentPending: 0,
  });

  const fetchPayementProject = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/payment_processes/payment-list`
      );

      const responsedata = response.data;
      console.log("responsedata : ", responsedata);
      setPaymentData(responsedata);
      setData(response.data.projects);
      setPaymentId(response.data.completedPaymentsIds);
      setAdvanceId(response.data.advancePendingIds);
      setPartialId(response.data.partialPaymentPendingIds);
      setFinalId(response.data.paymentPendingIds);
      // setPaymentDataDetails(response.data.paymentProjectDetails);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  const [freelid,setFreeid]=useState([]);

  console.log("freeid:",freelid)
  const fetchFreelancerProject = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/payment_processes/getfreelancerdetails`
      );

      const responsedata = response.data;
      console.log("responseFreelancerdata : ", responsedata);
      setPaymentDataDetails(responsedata);
      

      const flattenedToData = responsedata.map((item) => {
        return {
          projectid: item
        }
      });
      setFreeid(flattenedToData);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  useEffect(() => {
    fetchPayementProject();
    fetchFreelancerProject();
  }, []);

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }

  return (
    <section className="container">
      <div className="row mt-4">
        <div className="col-12">
          <Header />
          <div className="col-12 mt-3 pt-1 wapper w-100 ">
            <div className=" row mt-3 d-flex   w-100 ">
              <div className="col-12 col-md-9  px-4 ">
                <h className="heading-entr">Internal</h>
              </div>
              <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>

            <section className="col-12">
              {/* <div className="row px-3">
                <div className="col-12 mt-4">
                  <p className="heading-entr">Internal</p>
                </div>
              </div> */}
              <div className="row  py-3 px-2 gap-2">
                {/* Task Count Boxes */}
                <div
                  className="col project-task pb-1 px-1 pt-2"
                  onClick={handleCardClick("advance_pending")}
                  style={{ cursor: "pointer" }}
                >
                  <div className="text-center account-name">
                    Advance Pending
                  </div>
                  <div className="d-flex justify-content-start gap-2 align-items-center  p-1">
                    <FaHandHoldingDollar className="project-icon2" />
                    <div className="d-flex  align-items-center mt-1">
                      <p className="project-account mb-0 ">Total projects</p>
                      <p className="count-value mb-1">
                        {paymentData.totalAdvancePendingCount}
                      </p>
                    </div>
                  </div>

                  <div className="d-flex justify-content-start gap-2 align-items-center  p-1">
                    <FaHandHoldingDollar className="project-icon2" />
                    <div className="d-flex   align-items-center mt-1">
                      <p className="project-account mb-0 ">Total Payment </p>
                      <p className="count-value mb-1">
                        {formatIndianCurrency(
                          paymentData.totalAdvancePending
                        )}
                      </p>
                    </div>
                  </div>
                </div>

                <div
                  className="col project-task pb-1 px-1 pt-2"
                  onClick={handleCardClick("partial_payment_pending")}
                  style={{ cursor: "pointer" }}
                >
                  <div className="text-center account-name">
                    Parital Payment Pending
                  </div>
                  <div className="d-flex justify-content-start gap-2 align-items-center p-1">
                    <IoTimer className="project-icon2" />
                    <div className="d-flex  align-items-center mt-1">
                      <p className="project-account mb-0 ">Total project</p>
                      <p className="count-value mb-1">
                        {paymentData.totalPartialPaymentPendingCount}
                      </p>
                    </div>
                  </div>

                  <div className="d-flex justify-content-start gap-2 align-items-center p-1 ">
                    <IoTimer className="project-icon2" />
                    <div className="d-flex   align-items-center mt-1">
                      <p className="project-account mb-0 ">Total Payment </p>
                      <p className="count-value mb-1">
                        {/* {paymentData.totalPartialPaymentPending} */}
                        {/* {new Intl.NumberFormat('en-US', { style: 'decimal' }).format(paymentData.totalPartialPaymentPending)} */}
                        {formatIndianCurrency(
                          paymentData.totalPartialPaymentPending
                        )}
                      </p>
                    </div>
                  </div>
                </div>
                <div
                  className="col project-task pb-1 px-1 pt-2"
                  onClick={handleCardClick("final_payment_pending")}
                  style={{ cursor: "pointer" }}
                >
                  <div className="text-center account-name">
                    Final Payment Pending
                  </div>
                  <div className="d-flex justify-content-start gap-2 align-items-center p-1">
                    <FaFileInvoiceDollar className="project-icon2" />
                    <div className="d-flex  align-items-center mt-1">
                      <p className="project-account mb-0 ">Total project</p>
                      <p className="count-value mb-1">
                        {paymentData.totalPaymentPendingCount}
                      </p>
                    </div>
                  </div>

                  <div className="d-flex justify-content-start gap-2 align-items-center p-1">
                    <FaFileInvoiceDollar className="project-icon2" />
                    <div className="d-flex   align-items-center mt-1">
                      <p className="project-account mb-0 ">Total Payment </p>
                      <p className="count-value mb-1">
                        {formatIndianCurrency(
                          paymentData.totalPaymentPending
                        )}
                      </p>
                    </div>
                  </div>
                </div>
                <div
                  className="col project-task pb-1 px-1 pt-2"
                  onClick={handleCardClick("completed")}
                  style={{ cursor: "pointer" }}
                >
                  <div className="text-center account-name-full">
                    Total Completed Payment Verified
                  </div>
                  <div className="d-flex justify-content-start gap-2 align-items-center p-1">
                    <FaMoneyCheckAlt className="project-icon2" />
                    <div className="d-flex  align-items-center mt-1">
                      <p className="project-account mb-0 ">Total project</p>
                      <p className="count-value mb-1">
                        {paymentData.totalCompletedPaymentCount}
                      </p>
                    </div>
                  </div>

                  <div className="d-flex justify-content-start gap-2 align-items-center p-1">
                    <FaMoneyCheckAlt className="project-icon2" />
                    <div className="d-flex   align-items-center mt-1">
                      <p className="project-account mb-0 ">Total Payment </p>
                      <p className="count-value mb-1">
                        {/* {paymentData.totalCompletedPaymentCount} */}
                        {/* {new Intl.NumberFormat('en-US', { style: 'decimal' }).format(paymentData.totalCompletedPaymentCount)} */}
                        {formatIndianCurrency(
                          paymentData.totalCompletedPayment
                        )}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
          <section className=" mt-2 project-manage w-100 py-0">
            <div className="row  p-3">
              <div className="col-12 ">
                <h className="heading-entr">Internal </h>
              </div>
              <div className="px-1">
                <DataTable
                  id="example"
                  data={data}
                  columns={columns}
                  className="display"
                  options={{
                    paging: true,
                    pageLength: 20,
                    lengthMenu: [
                      [20, 30, 50],
                      [20, 30, 50],
                    ],
                    scrollX: true,
                  }}
                />
              </div>
            </div>
          </section>
          {isOpen && (
            <div className="modal-container-view">
              <div className="modal-box">
                <div className="d-flex justify-content-end">
                  <span className="modal-close " onClick={togglePopup}>
                    &times;
                  </span>
                </div>
                <div className="modal-body">
                  <div className="row mb-3">
                    <div className="col-6 text-end project-account">
                      Project ID :
                    </div>
                    <div className="col-6 text-start view-project-title1">
                      {CapitalizeCaseU(modalData.projectId)}
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-6 text-end project-account">
                      Status :
                    </div>
                    <div className="col-6 text-start view-project-title1">
                      {CapitalizeCaseU(modalData.paymentStatus)}
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-6 text-end project-account">
                      Amount :
                    </div>
                    <div className="col-6 text-start view-project-title1">
                      {modalData.totalCost}
                    </div>
                  </div>
                </div>
                {/* <hr></hr>
                <div className="col text-center view-project-title">
                  Once Project Will Completed After 21 days Amount Will Be
                  Credited
                </div> */}
              </div>
            </div>
          )}
          <section className=" mt-2 project-manage w-100 py-0">
            <div className="row  p-3">
              <div className="col-12 ">
                <h className="heading-entr">Freelancer </h>
              </div>
              <div className="px-1">
                <DataTable
                  id="projectview"
                  data={freelancerData}
                  columns={columns1}
                  className="display"
                  options={{
                    paging: true,
                    pageLength: 20,
                    lengthMenu: [
                      [20, 30, 50],
                      [20, 30, 50],
                    ],
                    scrollX: true,
                  }}
                />
              </div>
            </div>
            <div></div>
          </section>
        </div>
      </div>
      <div>
        <Footer></Footer>
      </div>
    </section>
  );
}

export default Accounts_dashboard;
