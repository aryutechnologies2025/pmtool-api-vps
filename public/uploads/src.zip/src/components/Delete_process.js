import React from "react";
import "../assests/css/entryprocess.css";
import { API_URL } from "../config.js";
import { IoIosSearch } from "react-icons/io";
// import { IoFilter } from "react-icons/io5";
import { IoMdAdd } from "react-icons/io";
import { VscGitStashPop } from "react-icons/vsc";
import { VscEye } from "react-icons/vsc";
import { NavLink } from "react-router-dom";
import { useState, useEffect,useRef } from "react";
// import { MdKeyboardArrowDown } from "react-icons/md";
import axios from "axios";
// import axios from '../api/axiosConfig.js';

import Sider from "./Sider";
import { FaBookReader } from "react-icons/fa";
import Swal from "sweetalert2";

import DatePicker from "react-datepicker";
import Breadcrumbs from "../routes/Breadcrumbs";

import "react-datepicker/dist/react-datepicker.css";
import Header from "./Header";

import ReactDOM from "react-dom";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { TfiPencilAlt } from "react-icons/tfi";
import { RiDeleteBin6Line } from "react-icons/ri";
import { TbClockExclamation } from "react-icons/tb";
import { Capitalize } from "../campsCase.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { IoIosMailOpen } from "react-icons/io";

import Tooltip from "@mui/material/Tooltip";
import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";
import { getDateFormate } from "../dateFormate.js";
import { saveAs } from "file-saver";
import Papa from "papaparse";
import { Link } from "react-router-dom";
import { FaIndianRupeeSign } from "react-icons/fa6";

import { LuBadgeDollarSign } from "react-icons/lu";
import { format, parseISO } from "date-fns";
import Loader from "../components/Loader.js";


import { MdRestorePage } from "react-icons/md";



DataTable.use(DT);
function Entryprocess() {
  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const [data, setData] = useState([]);
  const [startDate, setStartDate] = useState("");

  const [endDate, setEndDate] = useState("");
  const [showData, setShowData] = useState({});
  const [selectedId, setSelectedId] = useState(null);
  const [filteredData, setFilteredData] = useState([]);
  const [typeofwork, setTypeOfWork] = useState([]);
  const [institutions, setInstitutions] = useState([]);
  const [filterIntitution, getInstitution] = useState("all");
  const [createdby, setcreatedby] = useState("");
  const [filtertypeofwork, getTypeOfwork] = useState("all");
  //author name
  const [authorname, setAuthorName] = useState([]);
  const [filterAuthorName, getAuthorName] = useState("all");

  const [formData, setFormData] = useState({});
  // const [showData, setShowData] = useState({});

  const navigate = useNavigate();
  const fetchData = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/entry_process/deleted-list`, {
       
      });
      setData(response.data.details);
      setFilteredData(response.data.details);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

 
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFilterClick = () => {
    fetchData();
  };

  const [isReadOnly, setIsReadOnly] = React.useState(true);
  const [isOpen, setIsOpen] = useState(false);

  const openPopup = (id) => {
    setIsOpen(true);
    setSelectedId(id);
  };

  const handleRestoreClick = (id) => {
    Swal.fire({
      title: "Are you sure?",
      text: "Do you want to restore the project?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, send it!",
      cancelButtonText: "No, cancel",
    }).then((result) => {
      if (result.isConfirmed) {
        // If user confirms, send the notification
        axios
          .get(`${API_URL}/api/entry_process/project_status_change/${id}`)
          .then((response) => {
            Swal.fire({
              icon: "success",
              title: "Project Status Changed",
              text: "The project status was updated successfully.",
            });
            fetchData();
          })
          .catch((error) => {
            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Failed to the project status.",
            });
          });
      } else {
        // If user cancels, show a cancellation message (optional)
        Swal.fire({
          icon: "info",
          title: "Cancelled",
          text: "Action cancelled! The project remains unchanged.",
        });
      }
    });
  };

  const handleViewClick = (id) => {
    navigate("/entry-process/process-view-details", {
      state: { rowId: id },
    });
  };

  const truncateText = (text, limit) => {
    if (text && text.length > limit) {
      return text.slice(0, limit) + "..."; // Truncate and add ellipsis if text is longer
    }
    return text;
  };
const [isMenuOpen, setIsMenuOpen] = useState(false);
 const submenuRef = useRef(null);
 useEffect(() => {
     const handleClickOutside = (event) => {
       // Check if the click is outside the submenu and the icon itself
       if (submenuRef.current && !submenuRef.current.contains(event.target)) {
         setIsMenuOpen(false);
       }
     };
 
     // Add event listener for clicks
     document.addEventListener("mousedown", handleClickOutside);
 
     // Clean up the event listener on component unmount
     return () => {
       document.removeEventListener("mousedown", handleClickOutside);
     };
   }, []);
  const handleMenuToggle = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const columns = [
   
    { title: "ID", data: "project_id", render: (data) => Capitalize(data) },
    {
      title: "DATE",
      data: "entry_date",
      render: (data) => getDateFormate(data),
    },
    {
      title: "TITLE",
      data: null,
      render: (data, type, row) => {
        const id = `title-${row.sno || Math.random()}`;

        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div
                className="d-flex justify-content-center"
                // onClick={togglePopuptitle}
                onMouseEnter={() => (row.title)} // Pass title dynamically
                // onMouseLeave={handleMouseLeave}
                id={`title-${row.sno || Math.random()}`}
              >
                {truncateText(row.title, 10)}
              </div>,

              container
            );
          }
        }, 0);

        return `<div id="${id}"></div>`;
      },
    },
    {
      title: "TYPE OF WORK",
      data: "type_of_work",
      render: (data) => Capitalize(data),
    },
    {
      title: "ACTIONS",
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                <div className="d-flex gap-1 justify-content-around mt-1  ">
                <div className="" title="View">
                                    <span>
                                      <VscEye
                                        onClick={() => handleViewClick(row.id)}
                                        className="open-icon"
                                      />
                                    </span>
                                  </div>
                <div className="" title="Retrive">
                    <span>
                      <MdRestorePage
                        onClick={() => handleRestoreClick(row.id)}
                        className="restore-icon"
                      />
                    </span>
                  </div>                  
                </div>
            

              </div>,
              
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];


  // const handleStartDateChange = (date) => {
  //   setStartDate(date ? date.toISOString().split('T')[0] : null);
  // };

  // const handleEndDateChange = (date) => {
  //   setEndDate(date ? date.toISOString().split('T')[0] : null);
  // };
  const handleStartDateChange = (date) => {
    setStartDate(date ? format(date, "yyyy-MM-dd") : null); 
  };

  const handleEndDateChange = (date) => {
    setEndDate(date ? format(date, "yyyy-MM-dd") : null); 
  };

  const handleTypeOfWorkChange = (event) => {
    getTypeOfwork(event.target.value);
  };

  const handleInstitutionChange = (event) => {
    getInstitution(event.target.value);
  };

  const handleAuthorNameChange = (event) => {
    getAuthorName(event.target.value);
  };

  const handleClearClick = () => {
    setStartDate("");
    setEndDate("");
    getTypeOfwork("all");
    getInstitution("all");
    getAuthorName("all");
    fetchData({ start_date: "", end_date: "", type_of_work: "all",
      institutions: "all",
      author_name: "all" });  // Send empty values to the backend on the first click
  };

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false); 
      }, 1000); 
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />; 
  }

  return (
    <section className="container d-flex flex-column justify-content-between min-vh-100">
      <div className=" row mt-4">
        {/* <div className=" col-1   d-flex justify-content-center">
          <Sider></Sider>
        </div> */}

        <div className="col-12  ">
          <div className="col-12">
            <Header></Header>
          </div>

          <div className="col-12 mt-3 pt-1 wapper w-100 py-5">
          

            <div className=" row mt-3 d-flex   w-100 ">
              <div className="col-12 col-md-6  px-4 ">
                <p className="heading-entr">Deleted List</p>
              </div>
              <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>

            <div className="row px-5 d-flex justify-content-end">
              <div className=" d-flex justify-content-end ">
                
              </div>
            </div>
           

        
            <div className="p-2">
            
              <DataTable
                id="example"
                data={filteredData}
                columns={columns}
                className="display"
                options={{
                  scrollX: true,
                  select: true,
                  pageLength: 20, // Default number of rows per page
                  lengthMenu: [
                    [20, 30, 50],
                    [20, 30, 50],
                  ],
                }}
              />
                  {isMenuOpen && (
                      <div className="submenu-mail"ref={submenuRef}>
                        <div>Mail1</div>
                        <div>Mail2</div>
                        <div>Mail3</div>
                      </div>
                      
                    )}
              {/* {isHovered && (
                <div
                  className="modal-container-view position-fixed"
                  // onMouseEnter={() => handleMouseEnter(row.title)}
                  onMouseLeave={handleMouseLeave}
                >
                  {" "}
                  <div className="modal-box">
                    <div className="d-flex justify-content-end">
                      <span
                        className="modal-close"
                        onClick={() => setIsHovered(false)}
                      >
                        &times;
                      </span>
                    </div>
                    <div className="modal-body">
                      <div className="row mb-3">
                        <div className="col-12 text-start project-account">
                          TITLE :
                        </div>
                        <div className="col-12 text-start view-project-title1">
                          {hoveredTitle || "No Title"}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )} */}
            </div>
           
          </div>
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </section>
  );
}

export default Entryprocess;
