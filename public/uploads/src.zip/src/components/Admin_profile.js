import "../assests/css/setting.css";
// import { PencilSquare } from "react-bootstrap-icons";
import { FaPencilAlt } from "react-icons/fa";
import Profile from "..//assests/images/profile.png";

import Settingpic from "../assests/images/setting.png";

import React, { useState, useEffect } from "react";
import Header from "./Header";
import {  HRMS_API_URL } from "../config.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";

import Breadcrumbs from "../routes/Breadcrumbs";
import Footer from "../components/Footer";
import { getDateFormate } from "../dateFormate.js";

function Admin_profile() {

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const position = parsedDetails ? parsedDetails.position : "";

  const employee_name = parsedDetails ? parsedDetails.employee_name : "";
  const email_address = parsedDetails ? parsedDetails.email_address : "";
  const employee_type = parsedDetails ? parsedDetails.employee_type : "";
  const rolename_n = localStorage.getItem("medicsroleName") || "Admin";

  const medicsroleName = rolename_n;
  const phone_number = parsedDetails ? parsedDetails.phone_number : "";
  const date_of_joining = parsedDetails ? parsedDetails.date_of_joining : "";


   let profileimage_f = parsedDetails && parsedDetails.profile_image ? parsedDetails.profile_image : "";
  
    let profileimage; // Declare the variable outside the condition
  
    if (profileimage_f) {
      profileimage = `${HRMS_API_URL}/${profileimage_f}`;
    } else {
      profileimage = Profile; // Use the fallback profile image
    }

  const [profileImage, setProfileImage] = useState(Settingpic);
  const [full_name, setEmployeeName] = useState("");
  const [email, setEmployeeEmail] = useState("");
  const [city, setEmployeeNo] = useState("");
  const [departmentv, setEmployeeDep] = useState("");
  const [phonev, setPhoneNumber] = useState("");
  const [joindatev, setJoinDate] = useState("");

  useEffect(() => {
    setProfileImage(profileimage);
    setEmployeeName(employee_name);
    setEmployeeEmail(email_address);
    setEmployeeNo(employee_type);
    setEmployeeDep(medicsroleName);
    setPhoneNumber(phone_number);
    setJoinDate(date_of_joining);
  }, [profileimage, employee_name, email_address, employee_type, medicsroleName, phone_number, date_of_joining]);


  return (
    <>
      <section className="container ">
        <div className="row mt-4 ">
          {/* <div className="col-1 d-flex justify-content-center">
            <Sider />
          </div> */}
          <div className="col-12 ">
            <div className="col-12">
              <Header></Header>
            </div>

            <div className="col-11 pt-1 mt-3 wapper w-100 py-5 p-3">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className="col-12 col-md-9  px-4 ">
                  <p className="heading-entr">Profile</p>
                </div>
                <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>

              <div className="row mt-2  ">
                <div className="col-2 mx-3 ">
                  <div className="col-12 profile-container position-relative   d-inline d-flex justify-content-center">
                    <img
                      src={profileImage || Settingpic}
                      alt="Profile"
                      className="profile-image rounded-circle"
                    />

                    <input
                      type="file"
                      accept="image/*"
                      id="profileImageInput"
                      className="file-input"
                    />

                    <label htmlFor="profileImageInput" className="edit-icon ">
                      <FaPencilAlt className="pencil-icon-size" />
                    </label>
                  </div>
                </div>

                <div className="col-md-9">
                    <div className="row mt-0 w-100">
                      <div className="col-md-6 float-start  ">
                        <label htmlFor="site-title" className="site-name px-2">
                          Your Name
                        </label>
                        <input
                          id="site-title"
                          type="text"
                          name="full_name"
                          className={`setting-input`}
                          placeholder="Enter your Name"
                          value={CapitalizeCaseU(full_name)}
                        />
                      </div>
                      
                      <div className="col-md-6 float-start pt-3 ">
                        <label htmlFor="set-admin" className="site-name px-2">
                          Email
                        </label>
                        <input
                          type="email"
                          id="set-admin"
                          name="email"
                          className={"setting-input "}
                          value={email}
                          placeholder="Enter your Email"
                        />
                      </div>
                      <div className="col-md-6 float-start pt-3 ">
                        <label htmlFor="set-mail" className="site-name px-2">
                          Employee Type
                        </label>
                        <input
                          type="text"
                          id="set-mail"
                          name="present_address"
                          className={`setting-input`}
                          value={CapitalizeCaseU(city)}
                          placeholder="Employee Type"
                        />
                      </div>
                      <div className="col-md-6 float-start pt-3 ">
                        <label htmlFor="set-mail" className="site-name px-2">
                          Employee Department
                        </label>
                        <input
                          type="text"
                          id="set-mail"
                          name="present_address"
                          className={`setting-input`}
                          value={departmentv}
                          placeholder="Employee Type"
                        />
                      </div>
                      <div className="col-md-6 float-start pt-3 ">
                        <label htmlFor="set-mail" className="site-name px-2">
                          Contact Number
                        </label>
                        <input
                          type="text"
                          id="set-mail"
                          name="phone_number"
                          className={`setting-input`}
                          value={phonev}
                          placeholder="Phone number"
                        />
                      </div>
                      {position !=='Admin' && (
                      <div className="col-md-6 float-start pt-3 ">
                        <label htmlFor="set-mail" className="site-name px-2">
                          Join Date
                        </label>
                        <input
                          type="text"
                          id="set-mail"
                          name="date_of_joining"
                          className={`setting-input`}
                          value={getDateFormate(joindatev)}
                          placeholder="Phone number"
                        />
                      </div>
                      )}
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div>
        <Footer />
      </div>
      </section>
    </>
  );
}

export default Admin_profile;

{
  /* <div className="row   pt-3   p-3 ">
<div className="col-12 col-md-4 ">
  <label className="statis-name">Select Document</label>
  <select className="form-select " name="select_document" >
    <option value="" disabled selected>
      Select an option
    </option>
    <option value="1">Aim</option>
    <option value="2">Title</option>
    <option value="3">objective</option>
    <option value="4">Primary Outcome</option>
    <option value="5">Parent Paper</option>
    <option value="6">Master sheet</option>
    <option value="7">protocol</option>
    <option value="8">Ethical Committee Approval</option>
    <option value="9">Full Thesis</option>
    <option value="10">Study desgin</option>
    <option value="11">Statistics Result</option>
    <option value="12">Unorganized thesis</option>
    <option value="13">Last Year completedn Thesis</option>
    <option value="14">Guidelines</option>
  </select>
</div>
<div className="col-12 col-md-4">
  <label className="statis-name">File</label>

  <div className="form-control d-flex justify-content-end">
    <input
      type="file"
      name="file"
      id="fileupload"
      accept="file/*"
      className="file-upload-input"
      value={formData.file}
      onChange={handleFileChange}
    />
    {!fileUploaded && (
      <label htmlFor="fileupload" className="file-icon">
        <PiCloudArrowUpLight />
      </label>
    )}
    {fileUploaded && (
      <RiDeleteBin6Line
        className="file-del-icon"
        onClick={handleFileDelete}
      />
    )}
  </div>
</div>

<div className="col d-flex justify-content-start py-4 mt-2">
  <button
    type="button"
    className="save-form-add"
    onClick={handleButtonClick}
  >
    Add +
  </button>
</div>
</div>
{fields.map(
(field) =>
  field.isVisible && (
    <div key={field.id} className="row pt-1 p-3">
      <div className="col-12 col-md-4">
        <label className="statis-name">
          Select Document
        </label>
        <select className="form-select" name="select_document">
          <option value="" disabled selected>
            Select an option
          </option>
          <option value="1">Aim</option>
          <option value="2">Title</option>
          <option value="3">Objective</option>
          <option value="4">Primary Outcome</option>
          <option value="5">Parent Paper</option>
          <option value="6">Master Sheet</option>
          <option value="7">Protocol</option>
          <option value="8">
            Ethical Committee Approval
          </option>
          <option value="9">Full Thesis</option>
          <option value="10">Study desgin</option>
          <option value="11">Statistics Result</option>
          <option value="12">Unorganized thesis</option>
          <option value="13">Last Year completedn Thesis</option>
          <option value="14">Guidelines</option>
        </select>
      </div>
      <div className="col-12 col-md-4">
        <label className="statis-name">File</label>
        <div className="form-control d-flex justify-content-end">
          <input
            type="file"
            id="fileupload"
            accept=".jpg,.png,.pdf"
            className="file-upload-input"
            value={formData.file}
            onChange={handleFileChange}
          />
          {!fileUploaded ? (
            <label
              htmlFor="fileupload"
              className="file-icon"
            >
              <PiCloudArrowUpLight />
            </label>
          ) : (
            <RiDeleteBin6Line
              className="file-del-icon"
              onClick={handleFileDelete}
            />
          )}
        </div>
      </div>
      <div className="col d-flex justify-content-start py-4 mt-2">
        <button
          type="button"
          className="save-form-del"
          onClick={() => handleDeleteField(field.id)} // Delete specific field
        >
          Delete
        </button>
      </div>
    </div>
  )
)}   "correct the value and name"  */
}
