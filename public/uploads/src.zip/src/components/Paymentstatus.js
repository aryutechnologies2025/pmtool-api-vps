import React from "react";
import Header from "./Header";
import Sider from "./Sider";
import { IoMdAdd } from "react-icons/io";
import { VscGitStashPop } from "react-icons/vsc";
import { VscEye } from "react-icons/vsc";
import { TfiPencilAlt } from "react-icons/tfi";

import Vector from "..//assests/images/Vector.svg";
import { IoIosSearch } from "react-icons/io";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

import axios from "axios";
import { Link } from "react-router-dom";
import ReactDOM from "react-dom";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import Breadcrumbs from "../routes/Breadcrumbs";
import { API_URL } from "../config.js";
import Footer from "../components/Footer";
import { getDateFormate } from "../dateFormate.js";
import { Capitalize } from "../campsCase.js";

function Paymentstatus() {
  const navigate = useNavigate();

  const [date, setDate] = useState(null);
  const [date1, setDate1] = useState(null);
  const [showDatas, setShowData] = useState({});

  // console.log('showDatas :', showDatas.project_data.title);

  const [selectedId, setSelectedId] = useState(null);
  const [formData, setFormData] = useState({});
  const [data, setData] = useState([]);
  const [isReadOnly, setIsReadOnly] = useState(true);
  const [isOpen, setIsOpen] = useState(false);

  const handleDateChange = (date) => {
    setDate(date);
  };

  const handleDateChange1 = (date1) => {
    setDate1(date1);
  };

  const fetchData = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/payment_processes/list`);
      const formattedData = response.data.map((item, index) => ({
        ...item,
        "s.no": (index + 1).toString().padStart(3, '0')
      }));

      setData(formattedData);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };


  const fetchShowData = async (id) => {
    try {
      const responseShow = await axios.get(`${API_URL}/api/payment_processes/view/${id}`);

      console.log('responseShow', responseShow.data);
      setShowData(responseShow.data);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  useEffect(() => {
    fetchData();
  }, []);

  const openPopup = (id) => {
    navigate('/paymentStatus/payment-view',{
      state: { rowId: id }
    })
    // setIsOpen(true);
    setSelectedId(id);
    fetchShowData(id);
  };

  const closePopup = () => setIsOpen(false);

  const handleEditClick = (id) => {
    navigate('/paymentstatus/payment-edit-form', {
      state: { rowId: id }
    });
  };

  const columns = [
    {

      title: "S.NO",
      data: null,
      render: (_, __, ___, meta) => meta.row + 1,
    },
    { title: "PROJECT ID", data: "project_id", render: (data) => Capitalize(data) },
    {
      title: "DATE",
      data: "entry_date",
      render: (data) => getDateFormate(data),
    },
    { title: "BUDGET", data: "budget" },
    { title: "WRITER PAYMENT", data: "writer_payment" },
    { title: "REVIEWER PAYMENT", data: "reviewer_payment" },
    { title: "STATISTICAN PAYMENT", data: "statistican_payment" },
    { title: "JOURNAL PAYMENT", data: "journal_payment" },
    {
      title: "ACTIONS",
      data: null,
      render: (data, type, row) => {
        const id = `actions-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                <div className="d-flex justify-content-evenly modula-main mt-1">
                  <div className="">
                    <VscEye onClick={() => openPopup(row.id)} className="open-icon" />
                  </div>

                  <div className="border border-1"></div>
                  <div className="modula-icon-edit" >
                    <TfiPencilAlt onClick={() => handleEditClick(row.id)} />
                  </div>

                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  if (!showDatas) return null;

  const { payment_data, payment_status, writer_payment, writer_payment_date, reviewer_payment, reviewer_payment_date, statistican_payment, statistican_payment_date, journal_payment, journal_payment_date } = showDatas;

  return (
    <>
      <section className="container">
        <div className="row mt-4">
          {/* <div className="col-1   d-flex justify-content-center">
            <Sider></Sider>
          </div> */}
          <div className="col-12">
            <div className="col-12">
              <Header></Header>
            </div>

            <div className="col-11  mt-3 wapper w-100 pb-5 ">
              <div className="pt-2 px-2 d-none d-md-block">
                <Breadcrumbs></Breadcrumbs>
              </div>

              <div className=" row mt-3 d-flex w-100  ">
                <div className="col-5 d-flex mt-2 px-4 ">
                  <p className="heading-entr "> Payment Status</p>
                </div>

                <div className="col-2 text-center mt-2 ">
                  <div className=" d-flex justify-content-center   ">
                    <div className="add-icon">
                      <Link to="payment-form">
                        <IoMdAdd className="add1-icon" />
                      </Link>
                    </div>
                    <div className="add-icon">
                      <VscGitStashPop className="exit-icon" />
                    </div>
                  </div>
                </div>
                <div className="d-flex  col-5   col-md-5   col-lg-5   justify-content-between align-items-center  gap-2 date-sel">
                
                  <DatePicker
                    className="input-butn2 mx-2"
                    selected={date}
                    onChange={handleDateChange}
                    dateFormat="dd/MM/yyyy"
                    showMonthDropdown
                    showYearDropdown
                    dropdownMode="select"
                    placeholderText="Date From"
                    popperPlacement="bottom"
                  />
                  <DatePicker
                    className="input-butn4 mx-2"
                    selected={date1}
                    onChange={handleDateChange1}
                    dateFormat="dd/MM/yyyy"
                    showMonthDropdown
                    showYearDropdown
                    dropdownMode="select"
                    placeholderText="Date To"
                    popperPlacement="bottom"
                  />

                  <select className=" input-butn3 ">
                    <option value="">Department</option>
                    <option>one</option>
                    <option>2</option>
                    <option>one</option>
                  </select>
                </div>
              </div>

              <div className="px-1">
                <DataTable
                  id="example"
                  data={data}
                  columns={columns}
                  className="display"
                  options={{ scrollX: true, select: true }}
                />
              </div>

              {isOpen && (
                <div className="popup-container">
                  <div className="popup">
                    <div className="popup-content">
                      <span className="close" onClick={closePopup}>
                        &times;
                      </span>
                      {/* <img className="pop " src={popup} alt="img" /> */}

                      <div className="popup-content1 px-5 ">
                        <div className="row  mt-4 mx-2 py-4 ">
                          <div className="col-md-4 float-start pt-2">
                            <label className="statis-name ">Project Title</label>
                            <input
                              type="text"
                              className="form-control1"
                              value={showDatas?.project_data?.title || ''}
                              readOnly={isReadOnly}
                            />
                          </div>
                          <div className=" col-md-4 float-start pt-2">
                            <label className="statis-name ">Buget</label>
                            <input
                              type="text"
                              className="form-control1"
                              value={showDatas.project_data?.budget || ''}
                              readOnly={isReadOnly}
                            />

                          </div>
                          <div className="col-md-4 float-start pt-2 ">
                            <label className="statis-name  ">Project ID</label>
                            <input
                              type="text"
                              className="form-control1"
                              value={showDatas.project_data?.project_id || ''}
                              readOnly={isReadOnly}
                            />
                          </div>
                          {/* Payment Data */}
                          {payment_data?.length > 0 ? (
                            payment_data.map((payment, index) => (
                              <div className="row" key={payment.id}>
                                <div className="col-md-4">
                                  <label className="statis-name">Payment {index + 1}</label>
                                  <input
                                    type="text"
                                    className="form-control1"
                                    value={payment.payment}
                                    readOnly={isReadOnly}
                                  />
                                </div>
                                <div className="col-md-4">
                                  <label className="statis-name">Payment Date {index + 1}</label>
                                  <input
                                    type="text"
                                    className="form-control1"
                                    value={payment.payment_date}
                                    readOnly={isReadOnly}
                                  />
                                </div>
                              </div>
                            ))
                          ) : (
                            <p>No payment data available</p>
                          )}

                          <div className="row">
                            <div className=" col-md-4 float-start pt-3  ">
                              <label className="statis-name ">Payment Status</label>
                              <input
                                type="text"
                                className="form-control1"
                                value={payment_status}
                                readOnly={isReadOnly}
                              />
                            </div>
                          </div>

                          {/* Payments Details */}
                          {[
                            { label: 'Writer Payment', value: writer_payment, date: writer_payment_date },
                            { label: 'Reviewer Payment', value: reviewer_payment, date: reviewer_payment_date },
                            { label: 'Statistican Payment', value: statistican_payment, date: statistican_payment_date },
                            { label: 'Journal Payment', value: journal_payment, date: journal_payment_date }
                          ].map((item, index) => (
                            <div className="row" key={index}>
                              <div className="col-md-4">
                                <label className="statis-name">{item.label}</label>
                                <input
                                  type="text"
                                  className="form-control1"
                                  value={item.value}
                                  readOnly={isReadOnly}
                                />
                              </div>
                              <div className="col-md-4">
                                <label className="statis-name">{item.label} Date</label>
                                <input
                                  type="text"
                                  className="form-control1"
                                  value={item.date}
                                  readOnly={isReadOnly}
                                />
                              </div>
                            </div>
                          ))}
                          {/* <div className="col-12 d-flex justify-content-end  mt-5 ">
                            <div className="popup-edit ">
                              <button className="save-form">Edit</button>
                            </div>
                          </div> */}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

            </div>
          </div>
        </div>
        <div>

          <Footer />
        </div>
      </section>
    </>
  );
}

export default Paymentstatus;
