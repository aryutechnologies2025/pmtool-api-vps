import "../assests/css/dashboard.css";
import Sider from "./Sider";
import React from "react";
import "react-datepicker/dist/react-datepicker.css";
import Header from "./Header";
import { BsBarChartLine } from "react-icons/bs";
import axios from "axios";
import { useState, useEffect } from "react";
import Loader from "../components/Loader.js";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip as RechartsTooltip,
  Label,
} from "recharts";
import { VscGitStashPop } from "react-icons/vsc";

import { IoMdAdd } from "react-icons/io";

import { Link } from "react-router-dom";
import { AiOutlineAlert } from "react-icons/ai";
import { GiPiggyBank } from "react-icons/gi";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import Breadcrumbs from "../routes/Breadcrumbs";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { Tooltip as MUI_Tooltip } from "@mui/material";
import { MdDoNotDisturb } from "react-icons/md";
import { FaFileInvoiceDollar } from "react-icons/fa6";
// import Tooltip from "@mui/material/Tooltip";
import { render } from "@testing-library/react";
import { useNavigate } from "react-router-dom";
import ReactDOM from "react-dom";
import { VscEye } from "react-icons/vsc";
import Footer from "../components/Footer";

// icon
import { TbHourglassLow } from "react-icons/tb";
import { SiFreelancer } from "react-icons/si";
import { formatIndianCurrency } from "../AmountFormet.js";

DataTable.use(DT);

function Dashboard() {
  const navigate = useNavigate();

  const [data, setData] = useState([]);
  const [dasCount, setCountVal] = useState([]);
  const [dataFoot, setDataFoot] = useState([]);
  const [dataPeople, setDataPeople] = useState([]);
  const [dataPeopleInhouse, setDataPeopleInHouse] = useState([]);

  const [dataPeopleExtranel, setDataPeopleExternal] = useState([]);
  const [dataPeopleWriterExtranel, setdataPeopleWriterExtranel] = useState([]);
  const [loading, setLoading] = useState(true);

  const handleNavigate = (type, createdby, month) => {
    // navigate(`/employee-project-list`, { state: { type, createdby } });
    navigate(`/employe-project-list`, { state: { type, createdby, month } });
  };

  const handleNavigateinhouse = (type, createdby, month) => {
    // navigate(`/employee-project-list`, { state: { type, createdby } });
    navigate(`/inhouse-project-list`, { state: { type, createdby, month } });
  };

  const handleNavigatethesis = (type, createdby, employee_type, month) => {
    navigate(`/employee-project-list`, {
      state: { type, createdby, employee_type, month },
    });
    // navigate(`/employe-project-list`, { state: { type, createdby } });
  };

  const handleProNavigate = (params) => {
    navigate(`/project-view`, { state: params });
  };

  const handlePaymentStatusNavigate = (params) => {
    navigate(`/payment-status-list`, { state: params });
  };

  // table api
  const columns = [
    { title: "MONTH".toUpperCase(), data: "month" },
    { title: "Manuscript".toUpperCase(), data: "manuscript" },
    { title: "Statistics".toUpperCase(), data: "statistics" },
    { title: "Thesis".toUpperCase(), data: "thesis" },
    { title: "Others".toUpperCase(), data: "others" },
    { title: "NA", data: "not_assigned" },
    { title: "WD", data: "withdrawn" },
    { title: "Total".toUpperCase(), data: "total" },
    {
      title: "Manuscript (%)".toUpperCase(),
      data: "manuscript_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "Statistics (%)".toUpperCase(),
      data: "statistics_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "Thesis (%)".toUpperCase(),
      data: "thesis_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "Others (%)".toUpperCase(),
      data: "others_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "TARGET (%)",
      data: "target_percentage",
      render: (data) => {
        if (data !== null && data !== undefined) {
          return `${Number(data).toLocaleString()}%`;
        }
        return "N/A"; // Handle null or undefined values
      },
    },
  ];
  window.handleidClick = function (value1, value2) {
    console.log("Clicked value1:", value1);
    console.log("Clicked value2:", value2);

    // Set the first value in localStorage
    localStorage.setItem("empname", value1);

    // Set the second value in localStorage
    localStorage.setItem("projectallid", value2);

    // Open the new page in a new tab
    window.open("/projectlist", "_blank");
  };

  const freelancerId = localStorage.getItem("empname");
  const projectIds = JSON.parse(localStorage.getItem("projectallid"));

  //   useEffect(() => {
  //   console.log("Freelancer ID:", freelancerId);
  // }, [freelancerId]);
  //   console.log("Project IDs:", projectIds);

  const handleidClick = function (freelancerId, projectIdsJson) {
    const projectIds = JSON.parse(projectIdsJson);

    // console.log("Clicked freelancerId:", freelancerId);
    // console.log("Clicked projectIds:", projectIds);

    // Store values in localStorage
    localStorage.setItem("empname", freelancerId);
    localStorage.setItem("projectallid", JSON.stringify(projectIds));

    // Navigate to another page
    window.open("/projectlist", "_blank");
  };

  const columnsPeople = [
    {
      title: "Team".toUpperCase(),
      data: "employee_name",
      render: (data) => data.charAt(0).toUpperCase() + data.slice(1),
    },
    {
      title: "Type of work".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex ">
              <div class="table-row-width"><div>Writing</div></div>
  
   </div>
            
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
           <div class="d-flex ">
              <div class="table-row-width"><div>Reviewing</div></div>
  
   </div>
            
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex ">
              <div class="table-row-width"><div>statistician</div></div>

   </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex ">
              <div class="table-row-width"><div>Journal</div></div>

   </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Total Projects".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;
        const freelancerId = row.id;
        const projectIdsSource =
          row.reviewer_project_ids ||
          row.statistican_project_ids ||
          row.writer_project_ids ||
          [];
        const projectIds = Array.isArray(projectIdsSource)
          ? projectIdsSource.map((item) => item)
          : [];
        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center ">
              
   <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${writerCount}</div>
   </div>
            
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
           <div class="d-flex justify-content-center">
           
   <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${reviewerCount}</div>
   </div>
            
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
   <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${statisticianCount}</div>
   </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
   <div class="mx-2">${journalCount}</div>
   </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Pending".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerPendingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerPendingCount || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journalPendingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanPendingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${writerCount}</div>
            </div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex justify-content-center">
              <div>${reviewerCount}</div>
            </div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${statisticianCount}</div>
            </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
   <div class="mx-2">${journalCount}</div>
   </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "On going".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerOngoingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerOngoingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanOngoingCount || 0
          : 0;
        let journalCount = positions.includes("8")
          ? row.journalOngoingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${writerCount}</div>
            </div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex justify-content-center">
              <div>${reviewerCount}</div>
            </div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${statisticianCount}</div>
            </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
   <div class="mx-2">${journalCount}</div>
   </div>
          `;
        }
        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "need support".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerNeedCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerNeedCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanNeedCount || 0
          : 0;
        let journalCount = "-";

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${writerCount}</div>
            </div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex justify-content-center">
              <div>${reviewerCount}</div>
            </div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${statisticianCount}</div>
            </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "plag & correction".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerCorrectionCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerCorrectionCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanCorrectionCount || 0
          : 0;
        let journalCount = "-";
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${writerCount}</div>
            </div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex justify-content-center">
              <div>${reviewerCount}</div>
            </div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${statisticianCount}</div>
            </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "<4 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_4_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_4_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_4_days || 0
          : 0;
        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="box-pad">
            <div class="d-flex justify-content-center   ${
              writerCount >= 1 ? "highlight-green  text-white" : ""
            }">
              ${writerCount}
            </div></div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center ${
               reviewerCount >= 1 ? "highlight-green text-white" : ""
             }">
              ${reviewerCount}
            </div></div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
           <div class="box-pad">
            <div class="d-flex justify-content-center ${
              statisticianCount >= 1 ? "highlight-green text-white" : ""
            }">
              ${statisticianCount}
            </div></div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "5-8 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_5_to_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_5_to_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_5_to_8_days || 0
          : 0;

        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
           <div class="box-pad">
            <div class="d-flex justify-content-center ${
              writerCount >= 1 ? "highlight-yellow " : ""
            }">
              ${writerCount}
            </div></div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
          <div class="box-pad">
             <div class="d-flex justify-content-center ${
               reviewerCount >= 1 ? "highlight-yellow" : ""
             }">
              ${reviewerCount}
            </div>
            </div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center ${
              statisticianCount >= 1 ? "highlight-yellow" : ""
            }">
              ${statisticianCount}
            </div>
            </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: ">9 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_more_than_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_more_than_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_more_than_8_days || 0
          : 0;

        let journalCount = "-";

        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center ${
              writerCount >= 1 ? "highlight-red text-white" : ""
            }">
              ${writerCount}
            </div></div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider-last"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
        <div class="box-pad">
             <div class="d-flex justify-content-center ${
               reviewerCount >= 1 ? "highlight-red text-white" : ""
             }">
              ${reviewerCount}
            </div></div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center ${
              statisticianCount >= 1 ? "highlight-red text-white" : ""
            }">
              ${statisticianCount}
            </div></div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    // {
    //   title: "View Details".toUpperCase(),
    //   data: null,
    //   render: (data, type, row) => {
    //     const id = `process-${row.sno || Math.random()}`;
    //     setTimeout(() => {
    //       const container = document.getElementById(id);
    //       if (container && !container.hasChildNodes()) {
    //         ReactDOM.render(
    //           <div className="d-flex justify-content-center">
    //             {/* <div className="d-flex justify-content-around  mt-1  ">
    //                       <button className="view-details" onClick={() => handleNavigate(row.position, row.id)}>
    //                         View details
    //                       </button>
    //                   </div> */}
    //             <div className="" title="View">
    //               <span>
    //                 <VscEye
    //                   onClick={() =>
    //                     handleNavigateinhouse(row.position, row.id, selectedMonth)
    //                   }
    //                   className="open-icon"
    //                 />
    //               </span>
    //             </div>
    //           </div>,
    //           container
    //         );
    //       }
    //     }, 0);
    //     return `<div id="${id}"></div>`;
    //   },
    // },

    {
      title: "VIEW DETAILS",
      data: null,
      render: (data, renderType, row) => {
        const id = `process-${row.sno || Math.random()}`;

        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                <div title="View">
                  <VscEye
                    className="open-icon"
                    onClick={() =>
                      handleNavigateinhouse(row.position, row.id, selectedMonth)
                    }
                  />
                </div>
              </div>,
              container
            );
          }
        }, 0);

        return `<div id="${id}"></div>`;
      },
    },
  ];

  const columnsPeople2 = [
    {
      title: "Team".toUpperCase(),
      data: "employee_name",
      render: (data) => data.charAt(0).toUpperCase() + data.slice(1),
    },
    {
      title: "Type of work".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex ">
              <div class="table-row-width"><div>Writing</div></div>
  
   </div>
            
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
           <div class="d-flex ">
              <div class="table-row-width"><div>Reviewing</div></div>
  
   </div>
            
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex ">
              <div class="table-row-width"><div>statistician</div></div>

   </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex ">
              <div class="table-row-width"><div>Journal</div></div>

   </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Total Projects".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        const freelancerId = row.id;
        const projectIdsSource =
          row.reviewer_project_ids ||
          row.statistican_project_ids ||
          row.writer_project_ids ||
          [];
        const projectIds = Array.isArray(projectIdsSource)
          ? projectIdsSource.map((item) => item)
          : [];

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center ">
              
   <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${writerCount}</div>
   </div>
            
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
           <div class="d-flex justify-content-center">
           
   <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${reviewerCount}</div>
   </div>
            
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
  <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${statisticianCount}</div>
   </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
   <div class="mx-2">${journalCount}</div>
   </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Pending".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerPendingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerPendingCount || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journalPendingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanPendingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${writerCount}</div>
            </div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex justify-content-center">
              <div>${reviewerCount}</div>
            </div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${statisticianCount}</div>
            </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
   <div class="mx-2">${journalCount}</div>
   </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "On going".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerOngoingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerOngoingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanOngoingCount || 0
          : 0;
        let journalCount = positions.includes("8")
          ? row.journalOngoingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${writerCount}</div>
            </div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex justify-content-center">
              <div>${reviewerCount}</div>
            </div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${statisticianCount}</div>
            </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
   <div class="mx-2">${journalCount}</div>
   </div>
          `;
        }
        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "need support".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerNeedCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerNeedCount || 0
          : 0;
        let statisticianCount = "-";
        let journalCount = "-";

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${writerCount}</div>
            </div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex justify-content-center">
              <div>${reviewerCount}</div>
            </div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${statisticianCount}</div>
            </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "plag & correction".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerCorrectionCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerCorrectionCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanCorrectionCount || 0
          : 0;
        let journalCount = "-";
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${writerCount}</div>
            </div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex justify-content-center">
              <div>${reviewerCount}</div>
            </div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${statisticianCount}</div>
            </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "<4 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_4_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_4_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_4_days || 0
          : 0;
        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center   ${
              writerCount >= 1 ? "highlight-green  text-white" : ""
            }">
              ${writerCount}
            </div></div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
          <div class="box-pad">
             <div class="d-flex justify-content-center ${
               reviewerCount >= 1 ? "highlight-green text-white" : ""
             }">
              ${reviewerCount}
            </div></div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center ${
              statisticianCount >= 1 ? "highlight-green text-white" : ""
            }">
              ${statisticianCount}
            </div></div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
          <div class="box-pad">
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div></div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "5-8 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_5_to_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_5_to_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_5_to_8_days || 0
          : 0;

        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center ${
              writerCount >= 1 ? "highlight-yellow " : ""
            }">
              ${writerCount}
            </div></div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
          <div class="box-pad">
             <div class="d-flex justify-content-center ${
               reviewerCount >= 1 ? "highlight-yellow" : ""
             }">
              ${reviewerCount}
            </div></div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center ${
              statisticianCount >= 1 ? "highlight-yellow" : ""
            }">
              ${statisticianCount}
            </div></div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
          <div class="box-pad">
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div></div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: ">9 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_more_than_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_more_than_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_more_than_8_days || 0
          : 0;

        let journalCount = "-";

        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center ${
              writerCount >= 1 ? "highlight-red text-white" : ""
            }">
              ${writerCount}
            </div></div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider-last"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
          <div class="box-pad">
             <div class="d-flex justify-content-center ${
               reviewerCount >= 1 ? "highlight-red text-white" : ""
             }">
              ${reviewerCount}
            </div></div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center ${
              statisticianCount >= 1 ? "highlight-red text-white" : ""
            }">
              ${statisticianCount}
            </div></div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "View Details".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                {/* <div className="d-flex justify-content-around  mt-1  ">
                          <button className="view-details" onClick={() => handleNavigate(row.position, row.id)}>
                            View details
                          </button>
                      </div> */}
                <div className="" title="View">
                  <span>
                    <VscEye
                      onClick={() =>
                        handleNavigate(row.position, row.id, selectedMonth)
                      }
                      className="open-icon"
                    />
                  </span>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  const columnsThesisPeople1 = [
    {
      title: "Team".toUpperCase(),
      data: "employee_name",
      render: (data) => data.charAt(0).toUpperCase() + data.slice(1),
    },
    {
      title: "Type of work".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex ">
              <div class="table-row-width"><div>Writing</div></div>
  
   </div>
            
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
           <div class="d-flex ">
              <div class="table-row-width"><div>Reviewing</div></div>
  
   </div>
            
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex ">
              <div class="table-row-width"><div>statistician</div></div>

   </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex ">
              <div class="table-row-width"><div>Journal</div></div>

   </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Total Projects".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;
        const freelancerId = row.id;
        const projectIdsSource =
          row.reviewer_project_ids ||
          row.statistican_project_ids ||
          row.writer_project_ids ||
          [];
        const projectIds = Array.isArray(projectIdsSource)
          ? projectIdsSource.map((item) => item)
          : [];

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center ">
              
   <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${writerCount}</div>
   </div>
            
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
           <div class="d-flex justify-content-center">
           
   <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${reviewerCount}</div>
   </div>
            
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
   <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${statisticianCount}</div>
   </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
   <div class="mx-2">${journalCount}</div>
   </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Pending".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerPendingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerPendingCount || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journalPendingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanPendingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${writerCount}</div>
            </div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex justify-content-center">
              <div>${reviewerCount}</div>
            </div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${statisticianCount}</div>
            </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
   <div class="mx-2">${journalCount}</div>
   </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "On going".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerOngoingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerOngoingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanOngoingCount || 0
          : 0;
        let journalCount = positions.includes("8")
          ? row.journalOngoingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${writerCount}</div>
            </div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex justify-content-center">
              <div>${reviewerCount}</div>
            </div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${statisticianCount}</div>
            </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
   <div class="mx-2">${journalCount}</div>
   </div>
          `;
        }
        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "need support".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerNeedCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerNeedCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanNeedCount || 0
          : 0;
        let journalCount = positions.includes("8")
          ? row.journalOngoingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${writerCount}</div>
            </div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex justify-content-center">
              <div>${reviewerCount}</div>
            </div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${statisticianCount}</div>
            </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "plag & correction".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerCorrectionCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerCorrectionCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanCorrectionCount || 0
          : 0;
        let journalCount = "-";
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${writerCount}</div>
            </div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex justify-content-center">
              <div>${reviewerCount}</div>
            </div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
            <div class="d-flex justify-content-center">
              <div>${statisticianCount}</div>
            </div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "<4 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_4_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_4_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_4_days || 0
          : 0;
        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center   ${
              writerCount >= 1 ? "highlight-green  text-white" : ""
            }">
              ${writerCount}
            </div></div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
          <div class="box-pad">
             <div class="d-flex justify-content-center ${
               reviewerCount >= 1 ? "highlight-green text-white" : ""
             }">
              ${reviewerCount}
            </div></div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center ${
              statisticianCount >= 1 ? "highlight-green text-white" : ""
            }">
              ${statisticianCount}
            </div></div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
          <div class="box-pad">
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div></div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "5-8 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_5_to_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_5_to_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_5_to_8_days || 0
          : 0;

        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center ${
              writerCount >= 1 ? "highlight-yellow " : ""
            }">
              ${writerCount}
            </div></div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
          <div class="box-pad">
             <div class="d-flex justify-content-center ${
               reviewerCount >= 1 ? "highlight-yellow" : ""
             }">
              ${reviewerCount}
            </div></div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center ${
              statisticianCount >= 1 ? "highlight-yellow" : ""
            }">
              ${statisticianCount}
            </div></div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
          <div class="box-pad">
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div></div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: ">9 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_more_than_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_more_than_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_more_than_8_days || 0
          : 0;

        let journalCount = "-";

        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center ${
              writerCount >= 1 ? "highlight-red text-white" : ""
            }">
              ${writerCount}
            </div></div>
          `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider-last"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
          <div class="box-pad">
             <div class="d-flex justify-content-center ${
               reviewerCount >= 1 ? "highlight-red text-white" : ""
             }">
              ${reviewerCount}
            </div></div>
          `;
        }

        if (positions.includes("11")) {
          tableContent += `
          <div class="box-pad">
            <div class="d-flex justify-content-center ${
              statisticianCount >= 1 ? "highlight-red text-white" : ""
            }">
              ${statisticianCount}
            </div></div>
          `;
        }

        if (positions.includes("10")) {
          tableContent += `
          <div class="box-pad">
             <div class="d-flex justify-content-center">
           
      <div class="mx-2">${journalCount}</div>
      </div></div>
          `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "View Details".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                {/* <div className="d-flex justify-content-around  mt-1  ">
                          <button className="view-details" onClick={() => handleNavigate(row.position, row.id)}>
                            View details
                          </button>
                      </div> */}
                <div className="" title="View">
                  <span>
                    <VscEye
                      onClick={() =>
                        handleNavigatethesis(
                          row.position,
                          row.id,
                          row.employee_type,
                          selectedMonth
                        )
                      }
                      className="open-icon"
                    />
                  </span>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  //dashboard list
  const [works, setTypeOfWork] = useState([]);
  const [totalProjects, setProjectCount] = useState(0);

  const [processStatus, setProcessStatus] = useState(0);
  const [journalStatus, setJournalStatus] = useState(0);
  // console.log("totalProjects:", totalProjects);
  const [completed, setCompleted] = useState(0);
  const [paymentStatus, setPaymentStatus] = useState(0);
  const [selectedMonths, setSelectedMonths] = useState(
    new Date().toISOString().slice(0, 7) // "YYYY-MM"
  );
  console.log("selectedMonths:", selectedMonths);
  const fetchProjectManagerData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/adminDashboard`,
        {
          params: {
            position: "admin",
            month: selectedMonth,
          },
        }
      );

      const responsedata = response.data;
      console.log("responsedata : ", response);
      // console.log('responsedata.peopleInhouse : ',responsedata.peopleInhouse);
      setCountVal(responsedata);
      setTypeOfWork(responsedata.typeofwork);
      setProjectCount(responsedata.total_count);
      setProcessStatus(responsedata.process_staus);
      setJournalStatus(responsedata.journal_status);
      setPaymentStatus(responsedata.paymentStatusCounts);
      setCompleted(responsedata.completedCount);
      setData(responsedata.monthWiseTable.monthlyData);
      setDataFoot(responsedata.monthWiseTable.footerTotals);
      setDataPeople(responsedata.peoplewise);
      setDataPeopleInHouse(responsedata.inhouseExternal.peopleInhouse);
      setDataPeopleExternal(responsedata.inhouseExternal.peopleExternal);
      setdataPeopleWriterExtranel(
        responsedata.inhouseExternal.peopleWriterExternal
      );
      setLoading(false);

      // console.log("dataPeopleExternal :", responsedata.peopleExternal);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  const date = new Date();
  const [selectedMonth, setSelectedMonth] = useState(
    `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`
  );
  console.log("selectedMonth", selectedMonth);

  useEffect(() => {
    // fetchProjectManagerData();

    fetchProjectManagerData();
  }, [selectedMonth]);

  console.log("selected", selectedMonth);
  const [year, month] = selectedMonth.split("-");

  const handleMonthChange = (e) => {
    setSelectedMonth(e.target.value);
    // You can add additional logic here if needed
  };
  const handleMonthChanges = (e) => {
    setSelectedMonths(e.target.value);
    // You can add additional logic here if needed
  };

  // const [selectedMonth1, setSelectedMonth1] = useState(
  //   `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`
  // );
  const [selectedMonth1, setSelectedMonth1] = useState(
    `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`
  );
  const [year1, month1] = selectedMonth1.split("-");

  // const handleMonthChange1 = (event) => {
  //   setSelectedMonth1(event.target.value);
  // };

  const handleMonthChange1 = (event) => {
    setSelectedMonth1(event.target.value);
  };

  const [incomeExpence, setIncomeExpenceData] = useState([]);
  const [budgetData, setBudgetData] = useState([]);
  const monthName = new Date(`${year1}-${month1}-01`).toLocaleString("en-US", {
    month: "short",
  });
  // console.log('incomeExpence :',incomeExpence);
  // console.log('budgetData :',budgetData);
  // const fetchIncomeExpenseData = async () => {
  //   const response = await axios.get(`${API_URL}/api/projects/income-expense`, {
  //     params: {
  //       year: year1,
  //       month: currentMonth,
  //        months: month1
  //     },
  //   });
  //   setIncomeExpenceData(response.data);
  //   return response.data; // You probably want to return the data
  // };

  const fetchIncomeExpenseData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/projects/income-expense`,
        {
          params: {
            year: year1,
            month: monthName, // dynamically selected short month (e.g. Jan, Feb)
            months: month1, // numeric month (01, 02, etc.)
          },
        }
      );
      setIncomeExpenceData(response.data);
      return response.data;
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  const fetchBudgetData = async () => {
    const response = await axios.get(`${API_URL}/api/projects/budget-chat`, {
      params: {
        year: year,
        month: month,
      },
    });
    setBudgetData(response.data.details);
    return response.data; // You probably want to return the data
  };
  const datapie1 = [
    { name: "statistics", value: budgetData.statistics },
    { name: "manuscript", value: budgetData.manuscript },
    { name: "thesis", value: budgetData.thesis },
    { name: "others", value: budgetData.others },
  ];

  const COLORS1 = ["#7c73e6", "#008080", "#400080", "#ff0000"];

  const isDataEmpty = datapie1.every((item) => !item.value);

  const CustomLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    percent,
    value,
    index,
    payload,
  }) => {
    const RADIAN = Math.PI / 180;

    const startRadius = outerRadius + 10;
    const endRadius = outerRadius + 60; // spacing outward

    // Starting point (just outside pie)
    const sx = cx + startRadius * Math.cos(-midAngle * RADIAN);
    const sy = cy + startRadius * Math.sin(-midAngle * RADIAN);

    // End point (label position)
    const ex = cx + endRadius * Math.cos(-midAngle * RADIAN);
    const ey = cy + endRadius * Math.sin(-midAngle * RADIAN);

    const textAnchor = ex > cx ? "start" : "end";

    return (
      <>
        {/* Connector Line */}
        <path
          d={`M${sx},${sy} L${ex},${ey}`}
          stroke={COLORS1[index % COLORS1.length]}
          strokeWidth={2}
          fill="none"
        />

        {/* Label */}
        <text
          x={ex + (ex > cx ? 10 : -10)}
          y={ey}
          textAnchor={textAnchor}
          fontSize={14}
          fontWeight={600}
          fill={COLORS1[index % COLORS1.length]}
          dominantBaseline="central"
        >
          {formatIndianCurrency(value)}
        </text>
      </>
    );
  };

  const datapie2 = [
    { name: "Journal", value: incomeExpence.journal_details },
    { name: "Salary", value: incomeExpence.total_payroll },
    { name: "Freelancer", value: incomeExpence.freelancer_details },
    { name: "Office Expende", value: incomeExpence.office_expenses },
  ];
  const COLORS2 = ["#c084fc", "#2563EB", "#FB923C", "#22C55E"];

  const isData2Empty = datapie2.every((item) => !item.value);

  // useEffect(() => {
  //   fetchIncomeExpenseData();
  //   fetchBudgetData();
  // }, [selectedMonth, selectedMonth1]);
  useEffect(() => {
    const timeout = setTimeout(() => {
      fetchIncomeExpenseData();
      fetchBudgetData();
    }, 500);
    return () => clearTimeout(timeout);
  }, [selectedMonth, selectedMonth1]);

  // useEffect(() => {
  //   const handleLoad = () => {
  //     setTimeout(() => {
  //       setLoading(false);
  //     }, 5000);
  //   };
  //   if (document.readyState === "complete") {
  //   handleLoad();
  // } else {
  //   window.addEventListener("load", handleLoad);
  // }
  //       return () => window.removeEventListener("load", handleLoad);

  // }, []);
  // //  useEffect(() => {
  // //   setLoading(true)
  // // }, []);
  // if (loading) {
  //     return <Loader />;
  //   }
  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <section className="container">
          <div className="row mt-4 ">
            {/* <div className="col-1 d-flex    justify-content-center">
            <Sider />
          </div> */}
            <div className="col-12 ">
              <div className="col-12">
                <Header></Header>
              </div>

              {/* <section className="col-12 pb-3 mt-3  project-manage w-100 "> */}
              <section className="col-12 mt-3 pt-1 wapper w-100 ">
                <div className=" row mt-3 d-flex   w-100 ">
                  <div className="col-12 col-md-5  px-4 ">
                    <h className="heading-entr">Dashboard</h>
                  </div>
                  <div className="col-2 text-center  pb-2">
                    <div className="d-flex justify-content-center ">
                      <MUI_Tooltip title="Add Project">
                        <div className="add-div-icon">
                          <Link to="/entry-process/enter_process_form">
                            <IoMdAdd className="add-dash-icon" />
                          </Link>
                        </div>
                      </MUI_Tooltip>
                    </div>
                  </div>
                  <div className=" col-5 pt-3 px-2 d-none d-md-block text-end">
                    <Breadcrumbs></Breadcrumbs>
                  </div>
                </div>
                <div className="mt-4 px-4 gap-3 d-flex flex-wrap justify-content-end">
                  <div className="">
                    <input
                      type="month"
                      id="monthInput"
                      className="people-select px-1"
                      value={selectedMonth}
                      onChange={handleMonthChange}
                      placeholder="YYYY-MM"
                    />
                  </div>
                </div>

                <div className="d-flex flex-wrap p-2 gap-2 ">
                  <div className=" col total-project ">
                    <div className=" w-100 d-flex px-3  mt-3">
                      <div className="graphic-box  mt-2 ">
                        <BsBarChartLine className=" graphic-icon m-2" />
                      </div>
                      <div>
                        <div className=" d-flex mx-2 project-head gap-3 ">
                          <p className=" text-muted dash-year ">
                            {new Date().getFullYear()}
                          </p>
                          <p className=" text-muted dash-project ">
                            Total Projects
                          </p>
                        </div>
                        <div className=" h1  px-2">{totalProjects}</div>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3  d-flex justify-content-around mt-1"
                      onClick={() =>
                        handleProNavigate({
                          type: "manuscript",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">Manuscript</p>
                      <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2">{works.manuscript}</p>
                        <p className="p-tag3">
                          {/* {((works.manuscript / totalProjects) * 100).toFixed(2)}% */}
                          {totalProjects !== 0
                            ? (
                                (works.manuscript / totalProjects) *
                                100
                              ).toFixed(2) + "%"
                            : "0%"}
                        </p>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3"
                      onClick={() =>
                        handleProNavigate({
                          type: "thesis",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">Thesis</p>
                      <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">{works.thesis}</p>
                        <p className="p-tag3 ">
                          {/* {((works.thesis / totalProjects) * 100).toFixed(2)}% */}
                          {totalProjects !== 0
                            ? ((works.thesis / totalProjects) * 100).toFixed(
                                2
                              ) + "%"
                            : "0%"}
                        </p>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                      onClick={() =>
                        handleProNavigate({
                          type: "statistics",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">Statistician</p>
                      <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">{works.statistics}</p>
                        <p className="p-tag3 ">
                          {/* {((works.statistics / totalProjects) * 100).toFixed(2)}% */}
                          {totalProjects !== 0
                            ? (
                                (works.statistics / totalProjects) *
                                100
                              ).toFixed(2) + "%"
                            : "0%"}
                        </p>
                      </div>
                    </div>
                    {/* <div className="manage-title  mx-3 d-flex justify-content-around mt-3" onClick={() => handleProNavigate({ type: 'presentation' })}>
                    <p className="mt-1 pt-2 px-2 p-tag">Presentation</p>
                    <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">{works.presentation}</p>
                      <p className="p-tag3 ">
                       
                        {totalProjects !== 0 ? ((works.presentation / totalProjects) * 100).toFixed(2) + '%' : '0%'}
                      </p>
                    </div>
                  </div> */}
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3"
                      onClick={() =>
                        handleProNavigate({
                          type: "others",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">Others</p>
                      <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">{works.others}</p>
                        <p className="p-tag3 ">
                          {/* {((works.others / totalProjects) * 100).toFixed(2)}% */}
                          {totalProjects !== 0
                            ? ((works.others / totalProjects) * 100).toFixed(
                                2
                              ) + "%"
                            : "0%"}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className=" col total-project   ">
                    <div className=" w-100 d-flex px-3 mt-3">
                      <div className="graphic-box  mt-2 ">
                        <BsBarChartLine className=" graphic-icon m-2" />
                      </div>
                      <div>
                        <div className="status-title px-2 mt-3 mx-3">
                          Process Status
                        </div>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-4"
                      onClick={() =>
                        handleProNavigate({
                          process_status: "not_assigned",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">Not Assigned</p>
                      <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2">{processStatus.not_assigned}</p>
                        <p className="p-tag3">
                          {/* {(
                          (processStatus.not_assigned / totalProjects) *
                          100
                        ).toFixed(2)}
                        % */}
                          {totalProjects !== 0
                            ? (
                                (processStatus.not_assigned / totalProjects) *
                                100
                              ).toFixed(2) + "%"
                            : "0%"}
                        </p>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3"
                      onClick={() =>
                        handleProNavigate({
                          process_status: "in_progress",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">In Progress</p>
                      <div className="manage-num mt-1    pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">{processStatus.in_progress}</p>
                        <p className="p-tag3 ">
                          {/* {(
                          (processStatus.in_progress / totalProjects) *
                          100
                        ).toFixed(2)}
                        % */}
                          {totalProjects !== 0
                            ? (
                                (processStatus.in_progress / totalProjects) *
                                100
                              ).toFixed(2) + "%"
                            : "0%"}
                        </p>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3"
                      onClick={() =>
                        handleProNavigate({
                          process_status: "pending_author",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">Pending-Author</p>
                      <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">
                          {processStatus.pending_author}
                        </p>
                        <p className="p-tag3 ">
                          {/* {(
                          (processStatus.pending_author / totalProjects) *
                          100
                        ).toFixed(2)}
                        % */}
                          {totalProjects !== 0
                            ? (
                                (processStatus.pending_author / totalProjects) *
                                100
                              ).toFixed(2) + "%"
                            : "0%"}
                        </p>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                      onClick={() =>
                        handleProNavigate({
                          process_status: "withdrawal",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">Withdrawn</p>
                      <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">{processStatus.withdrawal}</p>
                        <p className="p-tag3 ">
                          {/* {(
                          (processStatus.withdrawal / totalProjects) *
                          100
                        ).toFixed(2)}
                        % */}
                          {totalProjects !== 0
                            ? (
                                (processStatus.withdrawal / totalProjects) *
                                100
                              ).toFixed(2) + "%"
                            : "0%"}
                        </p>
                      </div>
                    </div>

                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3"
                      onClick={() =>
                        handleProNavigate({
                          process_status: "completed",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">
                        completed {new Date().getFullYear()}
                      </p>
                      <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">{processStatus.completed}</p>
                        <p className="p-tag3 ">
                          {/* {(
                          (processStatus.completed / totalProjects) *
                          100
                        ).toFixed(2)}
                        % */}
                          {totalProjects !== 0
                            ? (
                                (processStatus.completed / totalProjects) *
                                100
                              ).toFixed(2) + "%"
                            : "0%"}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className=" col total-project   mx-2">
                    <div className=" w-100 d-flex px-3 mt-3">
                      <div className="graphic-box  mt-2 ">
                        <BsBarChartLine className=" graphic-icon m-2" />
                      </div>
                      <div>
                        <div className="status-title px-2 mt-3 mx-3">
                          Journal Status
                        </div>
                      </div>
                    </div>
                    <div className="manage-title  mx-3 d-flex justify-content-around mt-4">
                      <p className="mt-1 pt-2 px-2 p-tag">
                        Waiting for Submission
                      </p>
                      <div
                        className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center"
                        onClick={() =>
                          handleidClick(
                            freelancerId,
                            JSON.stringify(
                              journalStatus?.submit_to_journal?.ids || []
                            )
                          )
                        }
                      >
                        <p className="p-tag2 ">
                          {journalStatus?.submit_to_journal?.count}
                        </p>
                        <p className="p-tag3 ">
                          {works.manuscript !== 0
                            ? (
                                (journalStatus?.submit_to_journal?.count /
                                  works.manuscript) *
                                100
                              ).toFixed(2) + "%"
                            : "0%"}
                        </p>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                      onClick={() =>
                        handleidClick(
                          freelancerId,
                          JSON.stringify(
                            journalStatus?.submitted_peer_review?.ids || []
                          )
                        )
                      }
                    >
                      <p className="mt-1 px-2 pt-2 p-tag">Submit/Peer Review</p>
                      <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">
                          {journalStatus?.submitted_peer_review?.count}
                        </p>
                        <p className="p-tag3 ">
                          {works.manuscript !== 0
                            ? (
                                (journalStatus?.submitted_peer_review?.count /
                                  works.manuscript) *
                                100
                              ).toFixed(2) + "%"
                            : "0%"}
                        </p>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3"
                      onClick={() =>
                        handleidClick(
                          freelancerId,
                          JSON.stringify(
                            journalStatus?.reviewer_comments?.ids || []
                          )
                        )
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">Reviewer Comment</p>
                      <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">
                          {journalStatus?.reviewer_comments?.count}
                        </p>
                        <p className="p-tag3 ">
                          {works.manuscript !== 0
                            ? (
                                (journalStatus?.reviewer_comments?.count /
                                  works.manuscript) *
                                100
                              ).toFixed(2) + "%"
                            : "0%"}
                        </p>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3"
                      onClick={() =>
                        handleidClick(
                          freelancerId,
                          JSON.stringify(
                            journalStatus?.resubmission_rejected?.ids || []
                          )
                        )
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">
                        Resubmission/Reject
                      </p>
                      <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">
                          {journalStatus?.resubmission_rejected?.count}
                        </p>
                        <p className="p-tag3 ">
                          {works.manuscript !== 0
                            ? (
                                (journalStatus?.resubmission_rejected?.count /
                                  works.manuscript) *
                                100
                              ).toFixed(2) + "%"
                            : "0%"}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className=" col total-project   ">
                    <div className=" w-100 d-flex px-3 mt-3">
                      <div className="graphic-box  mt-2 ">
                        <BsBarChartLine className=" graphic-icon m-2" />
                      </div>
                      <div>
                        <div className="status-title px-2 mt-3 mx-3">
                          Payment Status
                        </div>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-4"
                      onClick={() =>
                        handlePaymentStatusNavigate({
                          payment_status: "advance_pending",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 px-2 pt-2 p-tag">Advance Pending</p>
                      <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2">
                          {paymentStatus.advance_pending}
                        </p>
                        <p className="p-tag3 ">
                          {/* {(
                          (paymentStatus.advance_pending / totalProjects) *
                          100
                        ).toFixed(2)} */}
                          {totalProjects !== 0
                            ? (
                                (paymentStatus.advance_pending /
                                  totalProjects) *
                                100
                              ).toFixed(2)
                            : 0}
                          %
                        </p>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3"
                      onClick={() =>
                        handlePaymentStatusNavigate({
                          payment_status: "partial_payment_pending",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">
                        Partial Payment Pending
                      </p>
                      <div className="manage-num mt-1 pt-3  mx-1 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">
                          {paymentStatus.partial_payment_pending}
                        </p>
                        <p className="p-tag3 ">
                          {/* {(
                          (paymentStatus.payment_pending / totalProjects) *
                          100
                        ).toFixed(2)} */}
                          {totalProjects !== 0
                            ? (
                                (paymentStatus.partial_payment_pending /
                                  totalProjects) *
                                100
                              ).toFixed(2)
                            : 0}
                          %
                        </p>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                      onClick={() =>
                        handlePaymentStatusNavigate({
                          payment_status: "final_payment_pending",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 px-2 pt-2 p-tag">
                        Final Payment Pending
                      </p>
                      <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">
                          {paymentStatus.final_payment_pending}
                        </p>
                        <p className="p-tag3 ">
                          {/* {(
                          (paymentStatus.partial_payment_pending / totalProjects) *
                          100
                        ).toFixed(2)} */}
                          {totalProjects !== 0
                            ? (
                                (paymentStatus.final_payment_pending /
                                  totalProjects) *
                                100
                              ).toFixed(2)
                            : 0}
                          %
                        </p>
                      </div>
                    </div>
                    <div
                      className="manage-title mx-3 d-flex justify-content-around mt-3"
                      onClick={() =>
                        handlePaymentStatusNavigate({
                          payment_status: "completed",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">
                        Full Payment Received
                      </p>
                      <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">{paymentStatus.completed}</p>
                        <p className="p-tag3">
                          {totalProjects !== 0
                            ? (
                                (paymentStatus.completed / totalProjects) *
                                100
                              ).toFixed(2)
                            : 0}
                          %
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className=" col total-project">
                    <div className=" w-100 d-flex px-3 mt-3">
                      <div className="graphic-box  mt-2 ">
                        <BsBarChartLine className=" graphic-icon m-2" />
                      </div>
                      <div>
                        <div className="status-title px-2 mt-3 mx-3">
                          Completed Count
                        </div>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-4"
                      onClick={() =>
                        handleProNavigate({
                          completed_count: "manuscript",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 px-2 pt-2 p-tag">Manuscript</p>
                      <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2">{completed.manuscript}</p>
                        <p className="p-tag3">
                          {works.manuscript &&
                          completed.manuscript &&
                          works.manuscript !== 0
                            ? (
                                (completed.manuscript / works.manuscript) *
                                100
                              ).toFixed(2)
                            : 0}{" "}
                          %
                        </p>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3"
                      onClick={() =>
                        handleProNavigate({
                          completed_count: "thesis",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">Thesis</p>
                      <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">{completed.thesis}</p>
                        <p className="p-tag3">
                          {works.thesis &&
                          completed.thesis &&
                          works.thesis !== 0
                            ? ((completed.thesis / works.thesis) * 100).toFixed(
                                2
                              )
                            : 0}{" "}
                          %
                        </p>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                      onClick={() =>
                        handleProNavigate({
                          completed_count: "statistics",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 px-2 pt-2 p-tag">Statistician</p>
                      <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">{completed.statistics}</p>
                        {/* <p className="p-tag3 ">{(works.statistics !== 0 ? (completed.statistics / works.statistics * 100).toFixed(2) : 0)} %</p> */}
                        <p className="p-tag3">
                          {works.statistics &&
                          completed.statistics &&
                          works.statistics !== 0
                            ? (
                                (completed.statistics / works.statistics) *
                                100
                              ).toFixed(2)
                            : 0}{" "}
                          %
                        </p>
                      </div>
                    </div>
                    <div
                      className="manage-title  mx-3 d-flex justify-content-around mt-3"
                      onClick={() =>
                        handleProNavigate({
                          completed_count: "others",
                          month: selectedMonth,
                        })
                      }
                    >
                      <p className="mt-1 pt-2 px-2 p-tag">Others</p>
                      <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                        <p className="p-tag2 ">{completed.others}</p>
                        <p className="p-tag3">
                          {works.others &&
                          completed.others &&
                          works.others !== 0
                            ? ((completed.others / works.others) * 100).toFixed(
                                2
                              )
                            : 0}{" "}
                          %
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <section className="col-12">
                  <div className="row mx-3 py-2 gap-4 d-flex  flex-wrap">
                    {/* Task Count Boxes */}

                    <div
                      className="col project-task-project1 px-1 align-items-center d-flex justify-content-around"
                      onClick={() =>
                        handleProNavigate({
                          count_type: "emergency_work",
                          month: selectedMonth,
                        })
                      }
                    >
                      {/* <div className="task-box-dash align-items-center pt-3"> */}
                      <AiOutlineAlert className="project-icon" />
                      {/* </div> */}
                      <div className="project-writer-dashboard mt-1 ">
                        Emergency work
                      </div>
                      <div className="project-writer-dashboard-font mt-1 ">
                        {dasCount.urgentDataListCount}
                        {/* {dasCount.emergencywork} */}
                      </div>
                    </div>
                    <div
                      className="col project-task-project2 px-1 align-items-center d-flex justify-content-around"
                      onClick={() =>
                        handleProNavigate({
                          count_type: "not_assigned_work",
                          month: selectedMonth,
                        })
                      }
                    >
                      {/* <div className="task-box1-dash align-items-center pt-2"> */}
                      <MdDoNotDisturb className="project-icon3 " />
                      {/* </div> */}
                      {/* <div className="align-items-center"> */}
                      <div className="project-writer-dashboard-black mt-1 ">
                        Not Assgined Work
                      </div>
                      <div className="project-writer-dashboard-font-black mt-1">
                        {dasCount.not_assigned}
                      </div>
                      {/* </div> */}
                    </div>
                    <div
                      className="col project-task-project-orange px-1 align-items-center d-flex justify-content-around"
                      onClick={() =>
                        handleProNavigate({
                          count_type: "project_delay",
                          month: selectedMonth,
                        })
                      }
                    >
                      {/* <div className="task-box2-dash-orange align-items-center pt-1"> */}
                      <TbHourglassLow className="project-icon3" />
                      {/* </div> */}
                      {/* <div className="align-items-center"> */}
                      <div className="project-writer-dashboard-black mt-1 ">
                        Project Delay
                      </div>
                      <div className="project-writer-dashboard-font-black mt-1">
                        {dasCount.projectdelayDataCount}
                      </div>
                      {/* </div> */}
                    </div>
                    <div
                      className="col  project-task-project-blue px-1 align-items-center d-flex justify-content-around"
                      onClick={() =>
                        handleProNavigate({
                          count_type: "freelancer_count",
                          month: selectedMonth,
                        })
                      }
                    >
                      {/* <div className="task-box3-dash align-items-center pt-3"> */}
                      <SiFreelancer className="project-icon" />
                      {/* </div> */}
                      {/* <div className="align-items-center"> */}
                      <div className="project-writer-dashboard mt-1">
                        Freelancer
                      </div>
                      <div className="project-writer-dashboard-font mt-1">
                        {dasCount.freelancet_payment_count}
                      </div>
                      {/* </div> */}
                    </div>
                  </div>
                </section>
              </section>

              {/* <section className=" pt-1 mt-2 project-manage w-100 py-5">
              <div className="row px-3">
                <div className="col-12 mt-4">
                  <p className="heading-entr">People wise projects status </p>
                </div>
                <div className="px-1">
                  <DataTable
                    id="example"
                    data={dataPeople}
                    columns={columnsPeople}
                    className="display"
                    options={{ scrollX: true, select: true }}
                  />
                </div>
              </div>
            </section> */}

              <section className="  mt-2 project-manage w-100 py-0">
                <div className="row p-3">
                  <div className="col-12 ">
                    <h className="heading-entr">Inhouse projects status </h>
                  </div>
                  <div className="px-1">
                    <DataTable
                      id="example"
                      data={dataPeopleInhouse}
                      columns={columnsPeople}
                      className="display"
                      options={{
                        paging: true,
                        pageLength: 20,
                        lengthMenu: [
                          [20, 30, 50],
                          [20, 30, 50],
                        ],
                        scrollX: true,
                      }}
                    />
                  </div>
                </div>
              </section>

              <section className="  mt-2 project-manage w-100 py-0">
                <div className="row p-3">
                  <div className="col-12 ">
                    <h className="heading-entr">External projects status </h>
                  </div>
                  <div className="px-1">
                    <DataTable
                      id="example"
                      data={dataPeopleExtranel}
                      columns={columnsPeople2}
                      className="display"
                      options={{
                        paging: true,
                        pageLength: 20,
                        lengthMenu: [
                          [20, 30, 50],
                          [20, 30, 50],
                        ],
                        scrollX: true,
                      }}
                    />
                  </div>
                </div>
              </section>

              <section className="  mt-2 project-manage w-100 py-0">
                <div className="row p-3">
                  <div className="col-12 ">
                    <h className="heading-entr">Thesis Status </h>
                  </div>
                  <div className="px-1">
                    <DataTable
                      id="example"
                      data={dataPeopleWriterExtranel}
                      columns={columnsThesisPeople1}
                      className="display"
                      options={{
                        paging: true,
                        pageLength: 20,
                        lengthMenu: [
                          [20, 30, 50],
                          [20, 30, 50],
                        ],
                        scrollX: true,
                      }}
                    />
                  </div>
                  {/* <div className="col-12 px-2 table-responsive  table-wrapper-scroll-y my-custom-scrollbar  ">
                  <table className="table-head">
                    <thead>
                      <tr className="text-center tr-head">
                        <th>SI No</th>
                        {columns.map((col, index) => (
                          <th key={index}>{col.title}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {data.map((row, rowIndex) => (
                        <tr key={rowIndex} className="text-center tr-head">
                          <td>{rowIndex + 1}</td>
                          {columns.map((col, colIndex) => (
                            <td key={colIndex}>
                              {col.render
                                ? col.render(row[col.data])
                                : row[col.data]}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div> */}
                </div>
              </section>

              <section className="  project-manage w-100 mt-2 py-0">
                <div className="row  p-3">
                  <div className="col-12 ">
                    <h className="heading-entr">Month wise projects status </h>
                  </div>

                  <div className="col-12 px-2 table-responsive  table-wrapper-scroll-y my-custom-scrollbar  ">
                    <table className="table-head">
                      <thead>
                        <tr className="text-center tr-head">
                          {/* <th>SI No</th> */}
                          {columns.map((col, index) => (
                            <th key={index}>{col.title}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {data.map((row, rowIndex) => (
                          <tr key={rowIndex} className="text-center tr-head">
                            {/* <td>{rowIndex + 1}</td> */}
                            {columns.map((col, colIndex) => (
                              <td key={colIndex}>
                                {col.render
                                  ? col.render(row[col.data])
                                  : row[col.data]}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="text-center tr-foot">
                          <td className="total-name-table" colSpan={1}>
                            Total
                          </td>
                          <td>{dataFoot.manuscript}</td>
                          <td>{dataFoot.statistics}</td>
                          <td>{dataFoot.thesis}</td>
                          <td>{dataFoot.others}</td>
                          <td>{dataFoot.not_assigned}</td>
                          <td>{dataFoot.withdrawn}</td>
                          <td>{dataFoot.total}</td>
                          <td>
                            {Number(dataFoot.manuscript_percentage).toFixed(2)}%
                          </td>
                          <td>
                            {Number(dataFoot.statistics_percentage).toFixed(2)}%
                          </td>
                          <td>
                            {Number(dataFoot.thesis_percentage).toFixed(2)}%
                          </td>
                          <td>
                            {Number(dataFoot.others_percentage).toFixed(2)}%
                          </td>
                          {/* <td >{dataFoot.target_percentage}%</td> */}
                          <td>
                            {dataFoot.target_percentage
                              ? Number(
                                  dataFoot.target_percentage
                                ).toLocaleString() + "%"
                              : "N/A"}
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </section>

              <section className="row  mt-2">
                <div className="col-12 col-xxl-6   ">
                  <div className="col-12 pt-1 py-4 mt-1 project-manage">
                    <div className="row  ">
                      <div className="col-9 mt-3 px-4">
                        <p className="heading-entr">Income </p>
                      </div>
                      <div className="mt-4 px-4 gap-3 d-flex flex-wrap justify-content-end">
                        <div className="">
                          <input
                            type="month"
                            id="monthInput"
                            className="people-select px-1"
                            value={selectedMonth}
                            onChange={handleMonthChange}
                            placeholder="YYYY-MM"
                            hidden
                          />
                        </div>
                      </div>
                    </div>
                    <div className="d-flex justify-content-center gap-3 mt-2">
                      <div className="d-flex gap-1">
                        <div className="stat-dash-color"></div>
                        <div className="pie-text">Statistician</div>
                      </div>
                      <div className="d-flex gap-1">
                        <div className="pap-dash-color"></div>
                        <div className="pie-text">Manuscript</div>
                      </div>

                      <div className="d-flex gap-1">
                        <div className="thesi-dash-color"></div>
                        <div className="pie-text">Thesis</div>
                      </div>
                      {/* <div className="d-flex gap-1">
                      <div className="pre-dash-color"></div>
                      <div className="pie-text">presentation</div>
                    </div> */}
                      <div className="d-flex gap-1">
                        <div className="others-dash-color"></div>
                        <div className="pie-text">Others</div>
                      </div>
                      {/* <div className="d-flex gap-1">
                      <div className="total-dash-color"></div>
                      <div className="pie-text">Total</div>
                    </div> */}
                    </div>
                    <div className="row ">
                      <div className="col d-flex   justify-content-center ">
                        <div className="position-relative   ">
                          {/* {datapie1 && datapie1.length > 0 ? (
                      <PieChart width={500} height={270}>
                          <Pie
                            data={datapie1}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            // paddingAngle={2}
                            outerRadius={75}
                            labelLine={true}
                            label={({ value }) => formatIndianCurrency(value || 0)}
                          >
                            {datapie1.map((entry, index) => (
                              <Cell
                                key={`cell-${index}`}
                                fill={COLORS1[index % COLORS1.length]}
                              />
                            ))}
                          </Pie>
                        </PieChart>
                        ) : (
                          <PieChart width={500} height={270}>
                            <Pie
                              data={[{ name: "No Data", value: 1 }]}
                              dataKey="value"
                              nameKey="name"
                              cx="50%"
                              cy="50%"
                              outerRadius={75}
                              labelLine={false}
                              label={() => "No Data"}
                            >
                              <Cell fill="#000000" />
                            </Pie>
                          </PieChart>
                        )} */}

                          {isDataEmpty ? (
                            <PieChart width={500} height={270}>
                              <Pie
                                data={[{ name: "No Data", value: 1 }]}
                                dataKey="value"
                                nameKey="name"
                                cx="50%"
                                cy="50%"
                                outerRadius={75}
                                labelLine={false}
                                label={() => "No Data"}
                              >
                                <Cell fill="#666666" />
                              </Pie>
                            </PieChart>
                          ) : (
                            <PieChart width={500} height={270}>
                              <Pie
                                data={datapie1}
                                dataKey="value"
                                nameKey="name"
                                cx="50%"
                                cy="50%"
                                outerRadius={75}
                                labelLine={true}
                                // label={({ value }) =>
                                //   formatIndianCurrency(value || 0)
                                // }
                                label={(props) => <CustomLabel {...props} />}
                              >
                                {datapie1.map((entry, index) => (
                                  <Cell
                                    key={`cell-${index}`}
                                    fill={COLORS1[index % COLORS1.length]}
                                  />
                                ))}
                              </Pie>
                            </PieChart>
                          )}
                        </div>
                      </div>
                      <div className="col-12 col-lg-6 ">
                        {/* <div className="position-relative   ">
                        <PieChart width={300} height={250}>
                          <Pie
                            data={pieData2}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            outerRadius={75}
                            labelLine={!allValuesZero2}
                            label={({ value }) =>
                              !allValuesZero2 ? `${value}%` : ""
                            }
                          >
                            {pieData2.map((entry, index) => (
                              <Cell
                                key={`cell-${index}`}
                                fill={
                                  allValuesZero2
                                    ? "#3D99B4"
                                    : COLORS1[index % COLORS1.length]
                                }
                              />
                            ))}
                          </Pie>
                        </PieChart>
                      </div> */}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12 col-xxl-6  ">
                  <div className="col-12 pt-1 py-4 mt-1 project-manage">
                    <div className="row  ">
                      <div className="col-9 mt-2 px-4">
                        <p className="heading-entr">Expence</p>
                      </div>
                      <div className="col-3 mt-4 px-4 gap-3 d-flex flex-wrap justify-content-end">
                        <div className="col">
                          <input
                            type="month"
                            id="monthInput"
                            className="people-select px-1"
                            value={selectedMonth1}
                            onChange={handleMonthChange1}
                            placeholder="YYYY-MM"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="d-flex justify-content-center gap-3 mt-1">
                      <div className="d-flex gap-1">
                        <div className="journal-dash-color"></div>
                        <div className="pie-text">Journal</div>
                      </div>
                      <div className="d-flex gap-1">
                        <div className="salary-dash-color"></div>
                        <div className="pie-text">Salary</div>
                      </div>
                      <div className="d-flex gap-1">
                        <div className="freelancer-dash-color"></div>
                        <div className="pie-text">Freelancer</div>
                      </div>
                      <div className="d-flex gap-1">
                        <div className="office-dash-color"></div>
                        <div className="pie-text">Office Expende</div>
                      </div>
                    </div>
                    <div className="row ">
                      <div className="col d-flex  mt-1 justify-content-center ">
                        <div className="position-relative   ">
                          {isData2Empty ? (
                            <PieChart width={500} height={270}>
                              <Pie
                                data={[{ name: "No Data", value: 1 }]}
                                dataKey="value"
                                nameKey="name"
                                cx="50%"
                                cy="50%"
                                outerRadius={75}
                                labelLine={false}
                                label={() => "No Data"}
                              >
                                <Cell fill="#666666" />
                              </Pie>
                            </PieChart>
                          ) : (
                            <PieChart width={500} height={270}>
                              <Pie
                                data={datapie2}
                                dataKey="value"
                                nameKey="name"
                                cx="50%"
                                cy="50%"
                                // paddingAngle={2}
                                outerRadius={75}
                                labelLine={true}
                                label={({ value }) =>
                                  formatIndianCurrency(value || 0)
                                }
                              >
                                {datapie2.map((entry, index) => (
                                  <Cell
                                    key={`cell-${index}`}
                                    fill={COLORS2[index % COLORS2.length]}
                                  />
                                ))}
                              </Pie>
                            </PieChart>
                          )}

                          {/* <PieChart width={500} height={270}>
                          <Pie
                            data={
                              isData2Empty
                                ? [{ name: "No Data", value: 1 }]
                                : datapie2
                            }
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            outerRadius={75}
                            labelLine={!isData2Empty}
                            label={
                              isData2Empty
                                ? () => "No Data"
                                : ({ value }) =>
                                    formatIndianCurrency(value || 0)
                            }
                          >
                            {(isData2Empty ? [{}, {}, {}, {}] : datapie2).map(
                              (entry, index) => (
                                <Cell
                                  key={`cell-${index}`}
                                  fill={
                                    isData2Empty
                                      ? "#000000"
                                      : COLORS2[index % COLORS2.length]
                                  }
                                />
                              )
                            )}
                          </Pie>
                        </PieChart> */}

                          {/* ;<p className="position-absolute pie-infom1">100</p>
                   <p className="position-absolute pie-infom-exp1">3000</p> */}
                        </div>
                      </div>
                      <div className="col-12 col-lg-6 ">
                        {/* <div className="position-relative   ">
                        <PieChart width={300} height={270}>
                          <Pie
                            data={datapie3}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            // paddingAngle={2}
                            outerRadius={75}
                            labelLine={true}
                            label={({ value }) => ` ${value}%`}
                          >
                            {datapie.map((entry, index) => (
                              <Cell
                                key={`cell-${index}`}
                                fill={COLORS3[index % COLORS3.length]}
                              />
                            ))}
                          </Pie>
                        </PieChart>
                      </div> */}
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              {/* <section className="col-12 pt-1 mt-2 project-manage w-100 py-5">
              <div className="row  px-3">
                <div className="col-12 mt-4">
                  <p className="heading-entr">Comparison Of Journal </p>
                </div>
                <div className="col-12 px-2 table-responsive  table-wrapper-scroll-y my-custom-scrollbar  ">
                  <table className=" table-head    ">
                    <thead>
                      <tr className="text-center tr-head   ">
                        <th className="">2023</th>
                        <th className="">Count</th>
                        <th className="">2024</th>
                        <th className="">Count</th>
                      </tr>
                    </thead>
                    <React.Fragment>
                      {data.map((item) => (
                        <tbody>
                          <tr className=" text-center tr-head ">
                            <td>{item["s.no"]}</td>
                            <td>{item.id}</td>
                            <td>{item.date}</td>
                            <td>{item.department}</td>
                          </tr>
                        </tbody>
                      ))}
                    </React.Fragment>
                  </table>
                </div>
              </div>
            </section> */}
            </div>
          </div>
          <div>
            <Footer />
          </div>
        </section>
      )}
    </>
  );
}

export default Dashboard;
