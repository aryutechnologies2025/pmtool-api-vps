import React from "react";
import { API_URL } from "../config.js";
import Header from "./Header";
import Sider from "./Sider";
import { IoMdAdd } from "react-icons/io";
import { VscGitStashPop } from "react-icons/vsc";
import { VscEye } from "react-icons/vsc";

import { IoIosSearch } from "react-icons/io";
import { useState, useEffect } from "react";
import Breadcrumbs from "../routes/Breadcrumbs";

import DatePicker from "react-datepicker";
import axios from "axios";
import { Link } from "react-router-dom";
import "react-datepicker/dist/react-datepicker.css";
import ReactDOM from "react-dom";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";

DataTable.use(DT);

function ProcessStatus() {
  const [date, setDate] = useState(null);
  const [date1, setDate1] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [data, setData] = useState([]);
  const [formData, setFormData] = useState({});
  const [isReadOnly, setIsReadOnly] = useState(true);
  const [isOpen, setIsOpen] = useState(false);

  const handleDateChange = (date) => {
    setDate(date);
  };

  const handleDateChange1 = (date1) => {
    setDate1(date1);
  };

  const fetchData = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/processes/list`);
      const formattedData = response.data.map((item, index) => ({
        ...item,
        "s.no": (index + 1).toString().padStart(3, '0')
      }));
      setData(formattedData);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const fetchShowData = async (id) => {
    try {
      const responseShow = await axios.get(`${API_URL}/api/processes/view/${id}`);
      setFormData(responseShow.data);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const handleEditClick = () => {
    setIsReadOnly(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFormSubmit = async () => {
    try {
      await axios.put(`${API_URL}/api/processes/update/${selectedId}`, formData);
      fetchData();
      setIsOpen(false);
      setIsReadOnly(true);
      setFormData({});
    } catch (error) {
      console.error("Error updating data", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const openPopup = (id) => {
    setIsOpen(true);
    setSelectedId(id);
    fetchShowData(id);
  };

  const closePopup = () => setIsOpen(false);
  const getCurrentDate = () => {
    const date = new Date();
    return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
  };

  const columns = [
    {
      title: "S.NO",
      data: null,
      render: (_, __, ___, meta) => meta.row + 1,
    },
    { title: "ID", data: "id" },
    { 
      title: "DATE", 
      data: null, 
      render: () => getCurrentDate() 
    },
    { title: "PROCESS TITLE", data: "process_title" },
    { title: "STATISTICAN", data: "statistican" },
    { title: "WRITER", data: "writer" },
    { title: "REVIEWER", data: "reviewer" },
    {
      title: "",
      data: null,
      render: (data, type, row) => {
        const id = `actions-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                <VscEye onClick={() => openPopup(row.id)} className="open-icon" />
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    }
  ];

 
  return (
    <section className="main w-100">
      <div className="row mt-4 w-100">
        {/* <div className="col-1 d-flex justify-content-center">
          <Sider />
        </div> */}
        <div className="col-11">
          <div className="col-12">
            <Header />
          </div>
          <div className="col-11 wapper w-100 mt-3 pt-1 py-5">
          <div className="pt-2 px-2 d-none d-md-block">
                <Breadcrumbs></Breadcrumbs>
              </div>
            <div className="row mt-3 d-flex w-100">
              <div className="col-5 d-flex mt-2 px-4">
                <p className="heading-entr">Process Status</p>
              </div>
              <div className="col-2 text-center mt-2">
                <div className="d-flex justify-content-center">
                  <div className="add-icon">
                    <Link to="/processstatus/process-status-form">
                      <IoMdAdd onClick={() => {
                      setFormData({});
                      openPopup();
                      }}
                      
                      className="add1-icon" />
                    </Link>
                  </div>
                  <div className="add-icon">
                    <VscGitStashPop className="exit-icon" />
                  </div>
                </div>
              </div>
              <div className="d-flex col-5 col-md-5 col-lg-5 justify-content-between align-items-center gap-2 date-sel">
                <input type="text" className="input-butn1" placeholder="ID" />
                <DatePicker
                  className="input-butn2 mx-2"
                  selected={date}
                  onChange={handleDateChange}
                  dateFormat="dd/MM/yyyy"
                  showMonthDropdown
                  showYearDropdown
                  dropdownMode="select"
                  placeholderText="Date From"
                  popperPlacement="bottom"
                />
                <DatePicker
                  className="input-butn4 mx-2"
                  selected={date1}
                  onChange={handleDateChange1}
                  dateFormat="dd/MM/yyyy"
                  showMonthDropdown
                  showYearDropdown
                  dropdownMode="select"
                  placeholderText="Date To"
                  popperPlacement="bottom"
                />
                <select className="input-butn3">
                  <option value="">Department</option>
                  <option value="HR">HR</option>
                  <option value="Finance">Finance</option>
                  <option value="IT">IT</option>
                </select>
              </div>
            </div>
            <div className="px-1">
              <DataTable
                id="example"
                data={data}
                columns={columns}
                className="display"
                options={{ scrollX: true, select: true }}
              />
            </div>
            {isOpen && (
              <div className="popup-container">
                <div className="popup">
                  <div className="popup-content">
                    <span className="close" onClick={closePopup}>
                      &times;
                    </span>
                    <div className="popup-content1">
                      <div className="row mt-3 mx-2 py-4">
                        <div className="col-md-3 float-start pt-2">
                          <h5 className="statis-name">Process Title</h5>
                          <input
                            type="text"
                            name="process_title"
                            className="client-info1"
                            value={formData.process_title || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-2">
                          <h5 className="statis-name">Process Status</h5>
                          <input
                            type="text"
                            name="process_status"
                            className="client-info1"
                            value={formData.process_status || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-2">
                          <h5 className="statis-name">Process Status Date</h5>
                          <input
                            type="text"
                            name="process_status_date"
                            className="client-info1"
                            value={formData.process_status_date || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-2">
                          <h5 className="statis-name">Commands Box</h5>
                          <input
                            type="text"
                            name="process_commands"
                            className="client-info1"
                            value={formData.process_commands || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-4">
                          <h5 className="statis-name">Writer</h5>
                          <input
                            type="text"
                            name="writer"
                            className="client-info1"
                            value={formData.writer || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-4">
                          <h5 className="statis-name">Writer Assigned Date</h5>
                          <input
                            type="text"
                            name="writer_assigned_date"
                            className="client-info1"
                            value={formData.writer_assigned_date || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-4">
                          <h5 className="statis-name">Writer Status</h5>
                          <input
                            type="text"
                            name="writer_status"
                            className="client-info1"
                            value={formData.writer_status || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-4">
                          <h5 className="statis-name">Writer Status Date</h5>
                          <input
                            type="text"
                            name="writer_status_date"
                            className="client-info1"
                            value={formData.writer_status_date || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-4">
                          <h5 className="statis-name">Reviewer</h5>
                          <input
                            type="text"
                            name="reviewer"
                            className="client-info1"
                            value={formData.reviewer || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-4">
                          <h5 className="statis-name">Reviewer Assigned Date</h5>
                          <input
                            type="text"
                            name="reviewer_assigned_date"
                            className="client-info1"
                            value={formData.reviewer_assigned_date || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-4">
                          <h5 className="statis-name">Reviewer Status</h5>
                          <input
                            type="text"
                            name="reviewer_status"
                            className="client-info1"
                            value={formData.reviewer_status || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-4">
                          <h5 className="statis-name">Reviewer Status Date</h5>
                          <input
                            type="text"
                            name="reviewer_status_date"
                            className="client-info1"
                            value={formData.reviewer_status_date || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-4">
                          <h5 className="statis-name">Statistican</h5>
                          <input
                            type="text"
                            name="statistican"
                            className="client-info1"
                            value={formData.statistican || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-4">
                          <h5 className="statis-name">Statistican Assigned Date</h5>
                          <input
                            type="text"
                            name="statistican_assigned_date"
                            className="client-info1"
                            value={formData.statistican_assigned_date || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-4">
                          <h5 className="statis-name">Statistican Status</h5>
                          <input
                            type="text"
                            name="statistican_status"
                            className="client-info1"
                            value={formData.statistican_status || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-3 float-start pt-4">
                          <h5 className="statis-name">Statistican Status Date</h5>
                          <input
                            type="text"
                            name="statistican_status_date"
                            className="client-info1"
                            value={formData.statistican_status_date || ''}
                            readOnly={isReadOnly}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="col-md-11 float-start d-flex justify-content-end pt-2 mt-5">
                          {!isReadOnly ? (
                            <button className="save-btn1" onClick={handleFormSubmit}>
                              Save
                            </button>
                          ) : (
                            <button className="save-btn1" onClick={handleEditClick}>
                              Edit
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

export default ProcessStatus;
