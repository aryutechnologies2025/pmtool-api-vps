import React from "react";
import "../assests/css/footer.css";
// import { Icon } from "react-icons-kit";
// import { globe } from "react-icons-kit/feather/globe";
import Aryulogo from "../assests/images/aryulogo.svg";

function Footer() {
  return (
    <div>
     <div className="container d-flex flex-wrap gap-1 justify-content-center align-items-center mt-3 pb-2">
        <p className="aryu-name mt-2 mb-0 text-center">Copyright © {new Date().getFullYear()}</p>
        <span className="mt-1">•</span>
        <p className="aryu-name mt-2 mb-0 text-center">Medics Research</p>
        <span className="mt-1">•</span>
        <p className="aryu-name mt-2 mb-0 text-center">
          Powered by Aryu Technologies
        </p>
        <img
          className="img-fluid mt-2"
          src={Aryulogo}
          alt="Aryu Technologies Logo"
        />
      </div>
    </div>
  );
}

export default Footer;
