
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Sider from "./Sider";
import Header from "./Header";
import "../assests/css/project_management.css";
import { AiOutlineAlert } from "react-icons/ai";
import { MdDoNotDisturb } from "react-icons/md";
import { FaFileInvoiceDollar } from "react-icons/fa6";
import { GiPiggyBank } from "react-icons/gi";
import { Link } from "react-router-dom";
import Breadcrumbs from "../routes/Breadcrumbs";
const ProjectManagementTool = () => {

  return (
    <>
      <section className="main">
        <div className="row mt-4 w-100">
          {/* <div className="col-1 d-flex justify-content-center">
            <Sider />
          </div> */}
          <div className="col-11">
            <Header />
            <div className="col-12  mt-3 project-manage pb-3 w-100">
            <div className="pt-2 px-2 d-none d-md-block"><Breadcrumbs></Breadcrumbs></div>

              <section className="col-12">
                <div className="row px-3">
                

                
                  <div className="col-12 mt-4">
                    <p className="heading-entr">Project Management</p>
                  </div>
                </div>
                <div className="row px-5 py-3 gap-3">
                  {/* Task Count Boxes */}
                  <div className="col project-task px-1 align-items-center d-flex justify-content-center gap-3">
                    <div className="task-box align-items-center pt-3">
                      <AiOutlineAlert className="project-icon" />
                    </div>
                    <div className="align-items-center">
                      <p className="project-writer pt-2">
                        Emergency work count
                      </p>
                      <div className="h4">5</div>
                    </div>
                  </div>
                  <div className="col project-task px-1 align-items-center d-flex justify-content-center gap-3">
                    <div className="task-box1 align-items-center pt-1">
                      <MdDoNotDisturb className="project-icon1 mt-3" />
                    </div>
                    <div className="align-items-center">
                      <p className="project-writer pt-2">
                        Not Assgined Work Count
                      </p>
                      <div className="h4">825</div>
                    </div>
                  </div>
                  <div className="col project-task px-1 align-items-center d-flex justify-content-center gap-3">
                    <div className="task-box2 align-items-center pt-1">
                      <FaFileInvoiceDollar className="project-icon2 mt-3" />
                    </div>
                    <div className="align-items-center">
                      <p className="project-writer pt-2">
                        Project Delay Count
                      </p>
                      <div className="h4">502</div>
                    </div>
                  </div>
                  <div className="col project-task px-1 align-items-center d-flex justify-content-center gap-3">
                    <div className="task-box3 align-items-center pt-3">
                      <GiPiggyBank className="project-icon3" />
                    </div>
                    <div className="align-items-center">
                      <p className="project-writer pt-2">
                        Freelancer Payment count
                      </p>
                      <div className="h4">5</div>
                    </div>
                  </div>
                </div>
              </section>

              <section className="col-12 px-3  ">
                <div className="d-flex flex-wrap  p-3 wapper  ">
                  <div className="col  ">
                    <div className="">TODO</div>
                    <div className="task-list ">
                      <Link to="/project-view " className="text-decoration-none">
                        <div className=" task-details m-2 p-2">
                          <p className="m-0 task-name-todo">Rabina</p>
                          <p className="task-comments">
                            lorem ipsum dolor sit amet, consectetur adip id
                            nncbuyg kjnsdguw hjwhbduyugfys dhjwhdiu
                          </p>
                          <div className="d-flex justify-content-between">
                            <div className="task-thesis-head">
                              <p className="task-thesis">Manuscript</p>
                            </div>
                            <div className="task-thesis-head1">
                              <p className="task-thesis1">Writer</p>
                            </div>
                            <div className="task-thesis-head2">
                              <p className="task-thesis2">Completed</p>
                            </div>
                          </div>
                        </div>
                      </Link>
                      <Link to="project-view " className="text-decoration-none">
                        <div className=" task-details m-2 p-2">
                          <p className="m-0 task-name-todo">Rabina</p>
                          <p className="task-comments">
                            
                            lorem ipsum dolor sit amet, consectetur adip id
                            nncbuyg kjnsdguw hjwhbduyugfys dhjwhdiu
                          </p>
                          <div className="d-flex justify-content-between">
                            <div className="task-thesis-head">
                              <p className="task-thesis">Manuscript</p>
                            </div>
                            <div className="task-thesis-head1">
                              <p className="task-thesis1">Writer</p>
                            </div>
                            <div className="task-thesis-head2">
                              <p className="task-thesis2">Completed</p>
                            </div>
                          </div>
                        </div>
                      </Link>
                    </div>
                    
                  </div>
                  <div className="col ">
                    <div>IN WORK</div>
                    <div className="task-list ">
                    <Link to="project-view " className="text-decoration-none">
                        <div className=" task-details m-2 p-2">
                          <p className="m-0 task-name-todo">Rabina</p>
                          <p className="task-comments">
                            
                            lorem ipsum dolor sit amet, consectetur adip id
                            nncbuyg kjnsdguw hjwhbduyugfys dhjwhdiu
                          </p>
                          <div className="d-flex justify-content-between">
                            <div className="task-thesis-head">
                              <p className="task-thesis">Manuscript</p>
                            </div>
                            <div className="task-thesis-head1">
                              <p className="task-thesis1">Writer</p>
                            </div>
                            <div className="task-thesis-head2">
                              <p className="task-thesis2">Completed</p>
                            </div>
                          </div>
                        </div>
                      </Link>
                      <Link to="project-view " className="text-decoration-none">
                        <div className=" task-details m-2 p-2">
                          <p className="m-0 task-name-todo">Rabina</p>
                          <p className="task-comments">
                            
                            lorem ipsum dolor sit amet, consectetur adip id
                            nncbuyg kjnsdguw hjwhbduyugfys dhjwhdiu
                          </p>
                          <div className="d-flex justify-content-between">
                            <div className="task-thesis-head">
                              <p className="task-thesis">Manuscript</p>
                            </div>
                            <div className="task-thesis-head1">
                              <p className="task-thesis1">Writer</p>
                            </div>
                            <div className="task-thesis-head2">
                              <p className="task-thesis2">Completed</p>
                            </div>
                          </div>
                        </div>
                      </Link>
                    </div>
                  </div>
                  <div className="col ">
                    <div>Reviews</div>
                    <div className="task-list ">
                    <Link to="project-view " className="text-decoration-none">
                        <div className=" task-details m-2 p-2">
                          <p className="m-0 task-name-todo">Rabina</p>
                          <p className="task-comments">
                            
                            lorem ipsum dolor sit amet, consectetur adip id
                            nncbuyg kjnsdguw hjwhbduyugfys dhjwhdiu
                          </p>
                          <div className="d-flex justify-content-between">
                            <div className="task-thesis-head">
                              <p className="task-thesis">Manuscript</p>
                            </div>
                            <div className="task-thesis-head1">
                              <p className="task-thesis1">Writer</p>
                            </div>
                            <div className="task-thesis-head2">
                              <p className="task-thesis2">Completed</p>
                            </div>
                          </div>
                        </div>
                      </Link>
                      <Link to="project-view " className="text-decoration-none">
                        <div className=" task-details m-2 p-2">
                          <p className="m-0 task-name-todo">Rabina</p>
                          <p className="task-comments">
                            
                            lorem ipsum dolor sit amet, consectetur adip id
                            nncbuyg kjnsdguw hjwhbduyugfys dhjwhdiu
                          </p>
                          <div className="d-flex justify-content-between">
                            <div className="task-thesis-head">
                              <p className="task-thesis">Manuscript</p>
                            </div>
                            <div className="task-thesis-head1">
                              <p className="task-thesis1">Writer</p>
                            </div>
                            <div className="task-thesis-head2">
                              <p className="task-thesis2">Completed</p>
                            </div>
                          </div>
                        </div>
                      </Link>
                    </div>
                  </div>
                  <div className="col ">
                    <div>Correction</div>
                    <div className="task-list ">
                    <Link to="project-view " className="text-decoration-none">
                        <div className=" task-details m-2 p-2">
                          <p className="m-0 task-name-todo">Rabina</p>
                          <p className="task-comments">
                            
                            lorem ipsum dolor sit amet, consectetur adip id
                            nncbuyg kjnsdguw hjwhbduyugfys dhjwhdiu
                          </p>
                          <div className="d-flex justify-content-between">
                            <div className="task-thesis-head">
                              <p className="task-thesis">Manuscript</p>
                            </div>
                            <div className="task-thesis-head1">
                              <p className="task-thesis1">Writer</p>
                            </div>
                            <div className="task-thesis-head2">
                              <p className="task-thesis2">Completed</p>
                            </div>
                          </div>
                        </div>
                      </Link>
                      <Link to="project-view " className="text-decoration-none">
                        <div className=" task-details m-2 p-2">
                          <p className="m-0 task-name-todo">Rabina</p>
                          <p className="task-comments">
                            
                            lorem ipsum dolor sit amet, consectetur adip id
                            nncbuyg kjnsdguw hjwhbduyugfys dhjwhdiu
                          </p>
                          <div className="d-flex justify-content-between">
                            <div className="task-thesis-head">
                              <p className="task-thesis">Manuscript</p>
                            </div>
                            <div className="task-thesis-head1">
                              <p className="task-thesis1">Writer</p>
                            </div>
                            <div className="task-thesis-head2">
                              <p className="task-thesis2">Completed</p>
                            </div>
                          </div>
                        </div>
                      </Link>
                    </div>
                  </div>
                  <div className="col ">
                    <div>COMPLETED</div>
                    <div className="task-list ">
                    <Link to="project-view " className="text-decoration-none">
                        <div className=" task-details m-2 p-2">
                          <p className="m-0 task-name-todo">Rabina</p>
                          <p className="task-comments">
                            
                            lorem ipsum dolor sit amet, consectetur adip id
                            nncbuyg kjnsdguw hjwhbduyugfys dhjwhdiu
                          </p>
                          <div className="d-flex justify-content-between">
                            <div className="task-thesis-head">
                              <p className="task-thesis">Manuscript</p>
                            </div>
                            <div className="task-thesis-head1">
                              <p className="task-thesis1">Writer</p>
                            </div>
                            <div className="task-thesis-head2">
                              <p className="task-thesis2">Completed</p>
                            </div>
                          </div>
                        </div>
                      </Link>
                      <Link to="project-view " className="text-decoration-none">
                        <div className=" task-details m-2 p-2">
                          <p className="m-0 task-name-todo">Rabina</p>
                          <p className="task-comments">
                            
                            lorem ipsum dolor sit amet, consectetur adip id
                            nncbuyg kjnsdguw hjwhbduyugfys dhjwhdiu
                          </p>
                          <div className="d-flex justify-content-between">
                            <div className="task-thesis-head">
                              <p className="task-thesis">Manuscript</p>
                            </div>
                            <div className="task-thesis-head1">
                              <p className="task-thesis1">Writer</p>
                            </div>
                            <div className="task-thesis-head2">
                              <p className="task-thesis2">Completed</p>
                            </div>
                          </div>
                        </div>
                      </Link>
                    </div>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ProjectManagementTool;
