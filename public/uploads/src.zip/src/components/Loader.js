// import React from 'react'
// import { TailSpin } from "react-loader-spinner";


// function Loader() {
//   return (
//     <div className="loader-container" style={{ backgroundColor: "transparent" }}>
//     <TailSpin
//       visible={true}
//       height="80"
//       width="80"
//       color="#3E99B5"
//       ariaLabel="tail-spin-loading"
//       radius="1"
//       wrapperStyle={{
//         display: "flex",
//         justifyContent: "center",
//         alignItems: "center",
//         height: "100vh", 
//       }}
//       wrapperClass="tailspin-loader"
//     />
//   </div>

//   )
// }

// export default Loader

import { TailSpin } from "react-loader-spinner";
import React from 'react'
import Vector from "../assests/images/Vector.svg";
const Loader = () => {
  return (
    <div className="loader-container">
      <img src={Vector} alt="Logo" className="loader-logo" />
      <TailSpin
        visible={true}
        height="80"
        width="80"
        color="#3E99B5"
        ariaLabel="tail-spin-loading"
        radius="1"
      />
    </div>
  );
};
export default Loader;



