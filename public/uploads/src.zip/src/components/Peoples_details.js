import React from "react";
import Sider from "./Sider";
import Profile from "..//assests/images/profile.png";
import "../assests/css/people_details.css";
import { useState, useEffect } from "react";
import axios from "axios";

import Header from "./Header";
import Breadcrumbs from "../routes/Breadcrumbs";
import { Link } from "react-router-dom";
import Footer from "../components/Footer";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";

function Peoples() {
  const [data, setData] = useState([]);

  const fetchData = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/peoples/list`);

      setData(response.data.details);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);

  return (
    <>
      <section className="container ">
        <div className="row mt-4">
          {/* <div className="col-1 d-flex   justify-content-center">
            <Sider />
          </div> */}
          <div className="col-12">
            <div className="col-12">
              <Header></Header>
            </div>
            <section className="col-12  mt-3 pt-1 project-manage w-100">
            <div className=" row mt-3 d-flex   w-100 ">
              <div className="col-12 col-md-9  px-4 ">
                <p className="heading-entr">Total Projects Status</p>
              </div>
              <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>

              <div className="row  px-3">

                {/* <div className="col-12 mt-4 px-4">
                  <p className="heading-entr">Total Projects Status </p>
                </div> */}
              </div>
              <div className="px-4 py-4 ">
                <div className="col-12  table-responsive table-wrapper-scroll-y my-custom-scrollbar1   ">
                  <table className=" table-head   ">
                    <tbody>
                      <tr className="text-center">
                        <div className=" people-info d-flex align-items-center my-2">
                        
                          <div className="col text-center">
                            <p className="people-name">Name</p>
                          </div>
                          <div className="col text-center">
                            <p className="people-writer">Position</p>
                          </div>
                          <div className="col text-center">
                            <p className="people-name">Total Projects</p>
                          </div>
                          <div className="col text-center">
                            <p className="people-name">Pending</p>
                          </div>
                          <div className="col text-center">
                            <p className="people-green">{`<4 days`}</p>
                          </div>
                          <div className="col text-center">
                            <p className="people-orange">5-8 days</p>
                          </div>
                          <div className="col text-center">
                            <p className="people-red">{`>9 days`}</p>
                          </div>
                          <div className="col text-center"></div>
                        </div>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="col-12  table-responsive table-wrapper-scroll-y my-custom-scrollbar   ">
                  <table className=" table-head   ">
                    <tbody>
                      {data.map((item, index) => (
                        <tr className="text-center">
                          <div className=" people-info d-flex align-items-center my-2">
                            <div className="col-1 ">
                              {/* <p className="people-name">{item.name}</p>
                              */}
                              <p className="people-name">{index + 1}</p>
                            </div>
                            <div className="col mt-3 text-center  ">
                              <p className="people-name">{Capitalize(item.employee_name)}</p>
                            </div>
                            <div className="col  mt-3 text-center">
                              <p className="people-writer">{Capitalize(item.created_by_user?.name) || ''}</p>
                            </div>
                            <div className="col mt-2 text-center">
                              {item.position === '7' && (
                                <p className="people-name ">
                                  {item.writer_count}
                                </p>
                              )}
                                {item.position === '8' && (
                                <p className="people-name ">
                                  {item.reviewer_count}
                                </p>
                              )}
                                {item.position === '10' && (
                                <p className="people-name ">
                                  {item.journal_count}
                                </p>
                              )}
                                {item.position === '11' && (
                                <p className="people-name ">
                                  {item.statistican_count}
                                </p>
                              )}
                            </div>
                            <div className="col mt-2 text-center">
                              {/* <p className="people-name">{item.pending}</p> */}
                              {item.position === '7' && (
                                <p className="people-name ">
                                  {item.writerPendingCount}
                                </p>
                              )}
                                {item.position === '8' && (
                                <p className="people-name ">
                                  {item.reviewerPendingCount}
                                </p>
                              )}
                                {item.position === '10' && (
                                <p className="people-name ">
                                  {item.statisticanPendingCount}
                                </p>
                              )}
                                {item.position === '11' && (
                                <p className="people-name ">
                                  {item.journalPendingCount}
                                </p>
                              )}
                            </div>
                            <div className="col mt-2 text-center">
                              <p className="people-green">{item.fourdays}</p>
                            </div>
                            <div className="col mt-2 text-center">
                              <p className="people-orange">{item.fivedays}</p>
                            </div>
                            <div className="col mt-2 text-center">
                              <p className="people-red">{item.ninedays}</p>
                            </div>

                            {/* <Link
                              to="people_view_details"
                              className="text-decoration-none"
                            >
                              <div className="col view-details text-center mx-3">
                                <p className="mt-1 m-0">View Details</p>
                              </div>
                            </Link> */}
                          </div>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>
          </div>
        </div>
        <div>

          <Footer />
        </div>
      </section>
    </>
  );
}

export default Peoples;





