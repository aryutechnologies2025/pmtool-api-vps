// export default Sider;
import { NavLink, Link, useNavigate } from "react-router-dom";
import "../assests/css/sider.css";
import Tooltip from '@mui/material/Tooltip';

// import { RiDashboardLine } from "react-icons/ri";
import { MdEditNote } from "react-icons/md";
import { RiSoundModuleLine } from "react-icons/ri";

import { RiDashboardLine } from 'react-icons/ri';
import { IoCalendarOutline, IoSettingsOutline, IoExitOutline } from 'react-icons/io5';
import { GrGroup } from 'react-icons/gr';
import { TiThMenu } from "react-icons/ti";
import React, { useState } from 'react';
import Cookies from 'js-cookie';

function Sidebar() {

  const navigate = useNavigate();

  const rolename = localStorage.getItem('medocsrolename') || 'Admin';


  const handleLogout = async () => {
    try {
      // await axios.post('http://localhost:8000/api/logoutcheck', {}, {
      //   headers: {
      //     'Authorization': `Bearer ${Cookies.get('token')}`,  // Send the token stored in cookies
      //   },
      //   withCredentials: true
      // });

      // Remove the token from local storage and cookies
      localStorage.removeItem('medicsuser');
      localStorage.removeItem('medicspermission');
      localStorage.removeItem('medocsrolename');
      localStorage.removeItem('medicsroleName');
      Cookies.remove('token', { path: '/' });

      // Redirect to the homepage after logout
      navigate('/');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const handleDashboardNavigation = () => {
    switch (rolename) {
      case 'Admin':
        navigate('/dashboard');
        break;
      case '13':
        navigate('/project-manager-dashboard');
        break;
      case '14':
        navigate('/team-coordinator-dashboard');
        break;
      case '7':
        navigate('/freelancer-dashboard');
        break;
      case '8':
        navigate('/internal-dashboard');
        break;
    }
  };

  return (
    <section className="position-fixed">
      <div className="text-center d- d-none d-lg-block mt-5 ">
        <Tooltip title="Dashboard">

          {/* <NavLink to="/dashboard"> */}
          <div onClick={handleDashboardNavigation} style={{ cursor: 'pointer' }}>
            <RiDashboardLine className="ico-side" />
          </div>
          {/* </NavLink> */}

        </Tooltip>

        {rolename === 'Admin' && (
          <Tooltip title="Project List">

            <NavLink to="/entry-process">
              <div className=" mt-4 ">
                <MdEditNote className="ico-side" />
              </div>
            </NavLink>
          </Tooltip>
        )}
        {rolename === 'Admin' && (
          <Tooltip title="Modula">
            <NavLink to="/modula-institution">
              <div className=" mt-4">
                <RiSoundModuleLine className="ico-side" />
              </div>
            </NavLink>
          </Tooltip>
        )}

        {(rolename === '14') && (
          <Tooltip title="Project Status ">
            <NavLink to="/people-details">
              <div className="mt-4">
                <GrGroup className="ico-side" />
              </div>
            </NavLink>
          </Tooltip>
        )}
       
        <div className="position-relative side2-icon ">
        {(rolename === 'Admin') && (
          <Tooltip title="Settings">
            <NavLink to="/settings">
              <div className="">
                <IoSettingsOutline className="ico-side" />
              </div>
            </NavLink>
          </Tooltip>
          )}
          <Tooltip title="Log Out">
            <NavLink to="/" onClick={handleLogout}>
              <div className="group-icon mt-5">
                <IoExitOutline className="ico" />
              </div>
            </NavLink>
          </Tooltip>
        </div>
      </div>

      {/* lg */}
      {/* <div className="  d-lg-none ">
        <div className="header-menu">menu</div>

        <div className="groupsider-icon mt-4 ">
          <RiDashboardLine className="ico" />
        </div>
        <div className="groupsider-icon mt-4">
          <RiDashboardLine className="ico" />
        </div>
        <div className="groupsider-icon">
          <IoCalendarOutline className="ico" />
        </div>
        <div className="groupsider-icon">
          <GrGroup className="ico " />
        </div>
        <div className="position-relative side2-icon">
          <div className="groupsider-icon ">
            <IoSettingsOutline className="ico" />
          </div>
          <div className="groupsider-icon ">
            <IoExitOutline className="ico" />
          </div>
        </div>
      </div>
        */}



    </section>
  );
}

export default Sidebar;
