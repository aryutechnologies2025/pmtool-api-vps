export const capitalizeFirstLetter = string => {
    if (!string) return '';
    // Check if the first letter is lowercase, and change it to uppercase
    if (string.charAt(0) === string.charAt(0).toLowerCase()) {
      return string.charAt(0).toUpperCase() + string.slice(1);
    }
    return string;  // If the first letter is already uppercase, return as is
  };