import React, { useState, useEffect } from "react";
import "../assests/css/payment_form.css";
import Sider from "../components/Sider.js";
import Header from "../components/Header.js";
import { Link } from "react-router-dom";
import Breadcrumbs from "../routes/Breadcrumbs.js";
import { useLocation } from "react-router-dom";
import axios from "axios";
import { API_URL } from "../config.js";
import { BASE_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import { useNavigate } from "react-router-dom";

import { CapitalizeCase } from "../capsUnderCase.js";
import PDF from "../assests/images/pdf.svg";

import Excel from "../assests/images/excel.svg";

import Word from "../assests/images/word.svg";
import Image from "../assests/images/image.svg";
import Footer from "../components/Footer";
import { getDateFormate } from "../dateFormate.js";
import { VscEye } from "react-icons/vsc";
import Tooltip from "@mui/material/Tooltip";
import Loader from "../components/Loader.js";

function Process_details() {
  const location = useLocation();
  const { rowId } = location.state || {};

  const [formData, setFormData] = useState({
    myFee: "",
    writerPendingDays: "",
    reviewerPendingDays: "",
    projectPendingDays: "",
    writerDueDate: "",
    reviewerDueDate: "",
    entrydate: getDateFormate() || "",
    typeofwork: "",
    projectid: "",
    clientName: "",
    profession: "",
    title: "",
    institute: "",
    contactNo: "",
    department: "",
    email: "",
    hierarchy: "",
    writer: "",
    writerDate: getDateFormate() || "",
    writerStatus: "",
    writerStatusDate: getDateFormate() || "",
    reviwer: "",
    reviwerAssignedDate: getDateFormate() || "",
    reviwerStatus: "",
    reviwerStatusdate: getDateFormate() || "",
    statistican: "",
    statisticanDate: getDateFormate() || "",
    statisticanStatus: "",
    statisticanStatusDate: getDateFormate() || "",
    journal: "",
    journalDate: getDateFormate() || "",
    journalStatus: "",
    journalStatusDate: getDateFormate() || "",
    duration: "",
    reviwerduration: "",
    statisticanduration: "",
    journalduration: "",
    processStatus: "",
    budget: "",
    journaldurationUnit: "",
    writerdurationUnit: "",
    reviwerdurationUnit: "",
    statisticandurationUnit: "",
    commandbox: "",
    processStatusDate: getDateFormate() || "",
    else_project_manager: false,
    payment_status: "",
    reference_number: "",
    project_duration: "",
  });

  // State to store validation errors
  const [errors, setErrors] = useState({});

  // Handle input changes
  const handleChangepending = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  const [isReadOnly, setIsReadOnly] = React.useState(true);
  const [customId, setCustomId] = useState("");

  // Validate form before submission
  const validateForm = () => {
    let formErrors = {};

    if (!formData.myFee) formErrors.myFee = "Fee is required";
    if (!formData.projectId) formErrors.projectId = "Project ID is required";
    if (!formData.clientName) formErrors.clientName = "Client Name is required";
    if (!formData.profession) formErrors.profession = "Profession is required";
    if (!formData.writerPendingDays)
      formErrors.writerPendingDays = "Writer Pending Days is required";
    if (!formData.reviewerPendingDays)
      formErrors.reviewerPendingDays = "Reviewer Pending Days is required";
    if (!formData.projectPendingDays)
      formErrors.projectPendingDays = "Project Pending Days is required";
    if (!formData.writerDueDate)
      formErrors.writerDueDate = "Writer Due Date is required";
    if (!formData.reviewerDueDate)
      formErrors.reviewerDueDate = "Reviewer Due Date is required";

    setErrors(formErrors);
    return Object.keys(formErrors).length === 0;
  };

  // Handle form submission
  useEffect(() => {
    if (rowId) {
      fetchShowData(rowId);
      fetchPendingData(rowId);
    }
  }, [rowId]);

  const [checkboxes, setCheckboxes] = useState({
    writer: false,
    reviewer: false,
    statistican: false,
    journal: false,
  });

  const [writter, setWritter] = useState([]);
  const [reviewer, setReviewer] = useState([]);
  const [statistical, setStatistical] = useState([]);
  const [journal, setJournal] = useState([]);

  useEffect(() => {
    // Fetch data from the API when the component mounts
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${API_URL}/api/entry_process/getEmployeeName`
        );
        const data = response.data;

        // Update the state with the received data
        if (data) {
          setWritter(data.writer || []);
          setReviewer(data.reviewer || []);
          setStatistical(data.statistican || []);
          setJournal(data.journal || []);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);
  const navigate = useNavigate();

  const handleEditClick = (id) => {
    navigate("/entry-process/entryprocess-update-form", {
      state: { rowId: id },
    });
  };

  const [paymentData, setPaymentData] = useState([]);
  const [selecteddocuments, setSelectedDocument] = useState([]);
  const [projectcomments, setProjectcomments] = useState([]);

  const removeEmptyTags = (html) => {
    const div = document.createElement("div");
    div.innerHTML = html;

    // Loop through all child elements and remove empty tags
    const elements = div.querySelectorAll("*");
    elements.forEach((element) => {
      if (!element.innerHTML.trim()) {
        element.remove(); // Remove empty elements
      }
    });

    return div.innerHTML;
  };

  const fetchShowData = async (id) => {
    try {
      const responseShow = await axios.get(
        `${API_URL}/api/entry_process/view/${id}`
      );
      const fetchData = responseShow.data;

      setFormData((prevFormData) => ({
        ...prevFormData,
        entrydate: fetchData.entry_date || "",
        title: fetchData.title || "",
        typeofwork: fetchData.type_of_work || "",
        projectid: fetchData.project_id || "",
        clientName: fetchData.client_name || "",
        email: fetchData.email || "",
        contactNo: fetchData.contact_number || "",
        institute: fetchData.institute?.name || "",
        department: fetchData.department?.name || "",
        profession: fetchData.profession?.name || "",
        budget: fetchData.budget || "",
        processStatus: fetchData.process_status || "",
        processStatusDate: fetchData.process_date || "",
        hierarchy: fetchData.hierarchy_level || "",
        else_project_manager: fetchData.else_project_manager || "",
        commandbox: fetchData.comment_box || "",

        //writer
        writer: fetchData.writer || "",
        writerDate: fetchData.writer_assigned_date || "",
        writerStatus: fetchData.writer_status || "",
        writerStatusDate: fetchData.writer_status_date || "",
        duration: fetchData.writer_project_duration || "",
        writerdurationUnit: fetchData.writer_duration_unit || "",
        project_duration: fetchData.projectduration || "",
        //reviewer
        reviwer: fetchData.reviewer || "",
        reviwerAssignedDate: fetchData.reviewer_assigned_date || "",
        reviwerStatus: fetchData.reviewer_status || "",
        reviwerStatusdate: fetchData.reviewer_status_date || "",
        reviwerduration: fetchData.reviewer_project_duration || "",
        reviwerdurationUnit: fetchData.reviewer_duration_unit || "",

        //statistican
        statistican: fetchData.statistican || "",
        statisticanDate: fetchData.statistican_assigned_date || "",
        statisticanStatus: fetchData.statistican_status || "",
        statisticanStatusDate: fetchData.statistican_status_date || "",
        statisticanduration: fetchData.statistican_project_duration || "",
        statisticandurationUnit: fetchData.statistican_duration_unit || "",

        //journal
        journal: fetchData.journal || "",
        journalDate: fetchData.journal_assigned_date || "",
        journalStatus: fetchData.journal_status || "",
        journalStatusDate: fetchData.journal_status_date || "",
        journalduration: fetchData.journal_project_duration || "",
        journaldurationUnit: fetchData.journal_duration_unit || "",
        payment_status: fetchData.payment_process?.payment_status || "",
        writer_payment: fetchData.payment_process?.writer_payment || "",
        writer_payment_date:
          fetchData.payment_process?.writer_payment_date || "",
        reviewer_payment: fetchData.payment_process?.reviewer_payment || "",
        reviewer_payment_date:
          fetchData.payment_process?.reviewer_payment_date || "",
        statistican_payment:
          fetchData.payment_process?.statistican_payment || "",
        statistican_payment_date:
          fetchData.payment_process?.statistican_payment_date || "",
        journal_payment: fetchData.payment_process?.journal_payment || "",
        journal_payment_date:
          fetchData.payment_process?.journal_payment_date || "",
        reference_number: fetchData.payment_process?.reference_number || "",
      }));

      setProjectcomments(fetchData?.projectcomment || []);

      setSelectedDocument((fetchData?.documents_title || []).join(", "));
      const paymentProcess = fetchData?.payment_process || {};

      const referenceFiles = Array.isArray(paymentProcess.reference_number_file)
        ? paymentProcess.reference_number_file
        : paymentProcess.reference_number_file
        ? [paymentProcess.reference_number_file]
        : [];

      const dynamicFiles1 = referenceFiles.map((file, index) => {
        if (!file) {
          console.warn(`Skipping invalid file at index ${index}`);
          return null;
        }

        const fileType = file.split(".").pop();
        const relativePath = file.replace(/\\/g, "/");

        return {
          img: getFileIcon(fileType),
          type: fileType,
          fileName: file.split("/").pop(),
          url: `${API_URL}/payment_screenshots/${relativePath}`,
          id: index,
        };
      });

      // Update state with new files while avoiding duplicates
      setFiles1((prevFiles) => {
        const newFiles = dynamicFiles1.filter(
          (newFile) =>
            !prevFiles.some((existingFile) => existingFile.id === newFile.id)
        );
        return [...prevFiles, ...newFiles];
      });

      setPaymentData(paymentProcess.payment_data || []);
      setCustomId(fetchData.project_id);
      const dynamicFiles = fetchData.documents.flatMap((doc) => {
        return doc.file.map((file) => {
          const fileType = file.file.split(".").pop(); // Extract file extension
          const relativePath = file.file.replace(/\\/g, "/"); // Handle backslashes

          // // Parse the select_document JSON string into an array
          // const documentTitles = JSON.parse(doc.select_document);
          // const title = documentTitles.join(", ");
          // setSelectedDocument(title);

          return {
            title: file.original_name.split("/").pop() || "Untitled Document", // Use document title or default
            img: getFileIcon(fileType), // Get corresponding file icon
            type: fileType, // File type/extension
            fileName: file.original_name.split("/").pop(), // Extract filename
            url: `${BASE_URL}uploads/${relativePath}`, // Construct file URL
            id: file.id, // Use the unique file ID
          };
        });
      });

      setFiles((prevFiles) => {
        const newFiles = dynamicFiles.filter(
          (newFile) =>
            !prevFiles.some((existingFile) => existingFile.id === newFile.id)
        );
        return [...prevFiles, ...newFiles];
      });
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const [pendingData, setPendingData] = useState([]);

  const fetchPendingData = async (id) => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/getPendingList/${id}`
      );
      const responsedata = response.data.data;
      setPendingData(responsedata);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  const [files, setFiles] = useState([]);

  const [files1, setFiles1] = useState([]);

  const getFileIcon = (type) => {
    // Define file format groups
    const imageFormats = ["jpg", "png", "gif", "jpeg", "svg", "txt"];
    const excelFormats = ["xlsx", "xls", "csv"];
    const wordFormats = ["docx", "doc", "word"];

    if (imageFormats.includes(type)) {
      return <img src={Image} className="img-view" alt="Image" />;
    }

    if (excelFormats.includes(type)) {
      return <img src={Excel} className="img-view" alt="Excel" />;
    }

    if (wordFormats.includes(type)) {
      return <img src={Word} className="img-view" alt="Word" />;
    }

    if (type === "pdf") {
      return <img src={PDF} className="img-view" alt="PDF" />;
    }

    return null;
  };
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }

  return (
    <>
      <section className="container">
        <div className="row mt-4">
          {/* <div className="col-1 d-flex justify-content-center">
            <Sider />
          </div> */}
          <div className="col-12">
            <div className="col-12">
              <Header></Header>
            </div>

            <div className="col-12 pt-1 wapper w-100 mt-3">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className=" col-12 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>
              <div className="row w-100 mt-0 px-3">
                <div className="col-12  d-flex flex-wrap justify-content-between">
                  <div className="col-12 col-md-4 d-flex flex-column">
                    <div className="col-md-12 float-start  ">
                      <label className="client-name-pop mx-2 ">
                        Enter Details
                      </label>
                    </div>

                    <div className="col-md-12 float-start pt-2 d-flex  ">
                      <div className=" statis-name-details">Entry Date</div>
                      <div className="view-details-data">
                        : {getDateFormate(formData.entrydate)}
                      </div>
                    </div>
                    <div className="col-md-12 float-start pt-2 d-flex">
                      <div className=" statis-name-details">Title</div>
                      <div className="view-details-data">
                        : {CapitalizeCase(formData.title)}
                      </div>
                    </div>
                    <div className="col-md-12 float-start pt-2 d-flex ">
                      <div className=" statis-name-details">Type Of work</div>
                      <div className="view-details-data">
                        : {CapitalizeCase(formData.typeofwork)}
                      </div>
                    </div>
                    <div className="col-md-12 float-start pt-2 d-flex ">
                      <div className=" statis-name-details">Project ID</div>
                      <div className="view-details-data">
                        : {CapitalizeCase(customId)}
                      </div>
                    </div>

                    <div className="col-md-12 float-start pt-2 d-flex ">
                      <div className=" statis-name-details">
                        Project Requirement
                      </div>
                      <div className="view-details-data">
                        : {CapitalizeCaseU(selecteddocuments)}
                      </div>
                    </div>
                  </div>

                  <div className="col-12 col-md-8 d-flex flex-column">
                    <div className="col-md-12 float-start px-2 ">
                      <label className="client-name-pop ">
                        Client Informations
                      </label>
                    </div>
                    <div className="row">
                      <div className="col-6">
                        <div className="col-12 col-md-12 float-start pt-2 d-flex  ">
                          <div className=" statis-name-details-client">
                            Client Name
                          </div>
                          <div className="view-details-data">
                            : {CapitalizeCase(formData.clientName)}
                          </div>
                        </div>
                        <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                          <div className="statis-name-details-client  ">
                            Email ID
                          </div>
                          <div className="view-details-data">
                            : {formData.email}
                          </div>
                        </div>
                        <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                          <div className="statis-name-details-client  ">
                            Contact No
                          </div>
                          <div className="view-details-data">
                            : {formData.contactNo}
                          </div>
                        </div>

                        <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                          <div className="statis-name-details-client ">
                            Institute
                          </div>

                          <div className="view-details-data">
                            : {formData.institute}
                          </div>
                        </div>

                        <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                          <div className="statis-name-details-client  ">
                            Department
                          </div>

                          <div className="view-details-data">
                            : {formData.department}
                          </div>
                        </div>
                      </div>
                      <div className="col-12 col-md-6">
                        <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                          <div className="statis-name-details ">Profession</div>

                          <div className="view-details-data">
                            : {formData.profession}
                          </div>
                        </div>
                        <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                          <div className="statis-name-details ">Budget</div>

                          <div className="view-details-data">
                            :{" "}
                            {new Intl.NumberFormat("en-US").format(
                              formData.budget || 0
                            )}
                          </div>
                        </div>

                        <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                          <div className="statis-name-details  ">
                            Process Status
                          </div>

                          <div className="view-details-data">
                            : {CapitalizeCase(formData.processStatus)}
                          </div>
                        </div>
                        <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                          <div className="statis-name-details ">
                            Process Status Date
                          </div>

                          <div className="view-details-data">
                            : {getDateFormate(formData.processStatusDate)}
                          </div>
                        </div>
                        <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                          <div className="statis-name-details ">
                            Project Completion
                          </div>

                          <div className="view-details-data">
                            : {formData.project_duration}
                          </div>
                        </div>

                        <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                          <div className="statis-name-details ">
                            Hierarchical
                          </div>

                          <div className="view-details-data">
                            : {CapitalizeCase(formData.hierarchy)}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="container">
                  <label className="statis-name">Uploaded Files</label>
                  <div className="d-flex gap-2 flex-wrap p-1 px-2 ">
                    {files.map((file, index) => (
                      <div className="images-box-all-view " key={index}>
                        <div className=" view-files p-3">
                          <div className="d-flex justify-content-between gap-1">
                            <div className=" text-center  file-title-card">
                              {CapitalizeCase(file.title)}
                            </div>
                            <Tooltip title="View">
                              <button
                                className=" file-view-button1 "
                                onClick={() => window.open(file.url, "_blank")}
                              >
                                <VscEye />
                              </button>
                            </Tooltip>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="row px-4 pt-1">
                  <label className="statis-name">Comments</label>
                  <div>
                    {projectcomments.map((comment, index) => (
                      <div key={index} className="pt-2">
                        {" "}
                        {/* Key moved to the outer div */}
                        <div className="d-flex gap-2">
                          <div className="view-names1-command">
                            {comment.created_by_user?.employee_name}
                          </div>
                          <div className="created-min">
                            {comment.created_date}
                          </div>
                        </div>
                        <span
                          dangerouslySetInnerHTML={{
                            __html: removeEmptyTags(
                              CapitalizeCaseU(comment.commend_box || "")
                            ),
                          }}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* {formData.writer ||
                  formData.reviwer ||
                  formData.statistican ||
                  (formData.journal && (
                    <div className="col-12">
                      <label className="client-name-pop  mt-4 ">
                        PROCESS STATUS
                      </label>
                    </div>
                  ))} */}

                {formData.writer && (
                  <div className="col-12  pt-1">
                    <label className="statis-name-title">
                      Writer Informations
                    </label>
                    <div className="  pt-2 d-flex">
                      <label className="statis-name-details-write">
                        Writer Name
                      </label>
                      <div className="view-details-data">
                        : {formData.writer}
                      </div>
                    </div>

                    <div className="d-flex pt-2">
                      <label className="statis-name-details-write">
                        Writer Assigned Date
                      </label>

                      <div className="view-details-data">
                        : {getDateFormate(formData.writerDate)}
                      </div>
                    </div>

                    <div className="d-flex  pt-2">
                      <label className="statis-name-details">
                        Writer Status
                      </label>

                      <div className="view-details-data">
                        : {CapitalizeCase(formData.writerStatus)}
                      </div>
                    </div>
                    <div className="d-flex   pt-2">
                      <label className="statis-name-details">
                        Writer Status Date
                      </label>

                      <div className="view-details-data">
                        : {getDateFormate(formData.writerStatusDate) || ""}
                      </div>
                    </div>
                    <div className="d-flex  pt-2">
                      <label className="statis-name-details">
                        Writer Project Duration
                      </label>

                      <div className="view-details-data">
                        : {formData.duration}
                      </div>
                    </div>
                  </div>
                )}

                {formData.reviwer && (
                  <div className="col-12  pt-1">
                    <label className="statis-name-title">
                      Reviewer Informations
                    </label>
                    <div className=" d-flex pt-2">
                      <label className="statis-name-details-write ">
                        Reviwer
                      </label>
                      {/* <select
                        className="form-control1"
                        name="writer"
                        value={formData.reviwer || ""}
                        disabled={isReadOnly}
                      >
                      
                        <option value="" disabled selected>
                          Select reviewer
                        </option>
                        {reviewer.map((writer, index) => (
                          <option key={writer.id} value={writer.id}>
                            {writer.name.charAt(0).toUpperCase() +
                              writer.name.slice(1)}
                          </option>
                        ))}
                      </select> */}
                      <div className="view-details-data">
                        : {formData.reviwer || ""}
                      </div>
                    </div>

                    <div className="d-flex  pt-2">
                      <label className="statis-name-details-write">
                        Reviwer Assigned Date
                      </label>
                      {/* <input
                        type="text"
                        className="form-control1"
                        value={
                          getDateFormate(formData.reviwerAssignedDate) || ""
                        }
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        : {getDateFormate(formData.reviwerAssignedDate) || ""}
                      </div>
                    </div>

                    <div className="d-flex   pt-2">
                      <label className="statis-name-details">
                        Reviwer Status
                      </label>
                      {/* <input
                        type="text"
                        className="form-control1"
                        value={CapitalizeCase(formData.reviwerStatus) || ""}
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        :{CapitalizeCase(formData.reviwerStatus) || ""}
                      </div>
                    </div>
                    <div className="d-flex   pt-2">
                      <label className="statis-name-details-write">
                        Reviwer Status Date
                      </label>
                      {/* <input
                        type="text"
                        value={getDateFormate(formData.reviwerStatusdate) || ""}
                        className="form-control1"
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        : {getDateFormate(formData.reviwerStatusdate) || ""}
                      </div>
                    </div>
                    <div className="d-flex  pt-2">
                      <label className="statis-name-details-write">
                        Reviwer Project Duration
                      </label>
                      {/* <input
                        type="text"
                        className="form-control1"
                        value={formData.reviwerduration}
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        : {formData.reviwerduration}
                      </div>
                    </div>
                  </div>
                )}

                {formData.statistican && (
                  <div className="col-12  pt-1">
                    <label className="statis-name-title">
                      Statistican Informations
                    </label>
                    <div className="d-flex pt-2">
                      <label className="statis-name-details">Statistican</label>
                      <div
                        className="view-details-data"
                        // name="writer"
                        // value={formData.statistican || ""}
                        // disabled={isReadOnly}
                      >
                        {/* {statistical.map((writer, index) => (
                          <option key={writer.id} value={writer.id}>
                            :{writer.name.charAt(0).toUpperCase() +
                              writer.name.slice(1)}
                          </option>
                        ))} */}
                        :{formData.statistican || ""}
                      </div>
                    </div>

                    <div className="d-flex  pt-2">
                      <label className="statis-name-details-write ">
                        Statistican Assigned Date
                      </label>
                      {/* <input
                        type="text"
                        className="form-control1"
                        value={getDateFormate(formData.statisticanDate)}
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        : {getDateFormate(formData.statisticanDate)}
                      </div>
                    </div>

                    <div className="d-flex pt-2">
                      <label className="statis-name-details-write   ">
                        Statistican Status
                      </label>
                      {/* <input
                        type="text"
                        className="form-control1"
                        value={CapitalizeCase(formData.statisticanStatus)}
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        :{CapitalizeCase(formData.statisticanStatus)}
                      </div>
                    </div>
                    <div className="d-flex   pt-2">
                      <label className="statis-name-details-write">
                        Statistican Status Date
                      </label>

                      <div className="view-details-data">
                        : {getDateFormate(formData.statisticanStatusDate) || ""}
                      </div>
                    </div>
                    <div className="d-flex  pt-2">
                      <div className="statis-name-details-write">
                        Statistican Project Duration
                      </div>
                      {/* <input
                        type="email"
                        className="form-control1"
                        value={formData.statisticanduration}
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        : {formData.statisticanduration}
                      </div>
                    </div>
                  </div>
                )}
                {formData.journal && (
                  <div className="col-12 pt-1">
                    <label className="statis-name-title">
                      Journal Informations
                    </label>
                    <div className="d-flex  pt-2">
                      <label className="statis-name-details-write">
                        Journal
                      </label>
                      <select
                        className="form-control1"
                        name="writer"
                        value={formData.journal || ""}
                        disabled={isReadOnly}
                      >
                        <option value="" disabled selected>
                          Select journal
                        </option>
                        {journal.map((writer, index) => (
                          <option key={writer.id} value={writer.id}>
                            {/* {writer.name} */}
                            {writer.name.charAt(0).toUpperCase() +
                              writer.name.slice(1)}
                          </option>
                        ))}
                      </select>
                      <div className="view-details-data">
                        : {formData.journal || ""}
                      </div>
                    </div>

                    <div className="d-flex   pt-2">
                      <label className="statis-name-details-write ">
                        Journal Assigned Date
                      </label>
                      {/* <input
                        type="text"
                        className="form-control1"
                        value={getDateFormate(formData.journalDate)}
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        : {getDateFormate(formData.journalDate)}
                      </div>
                    </div>

                    <div className="d-flex pt-2">
                      <label className="statis-name-details-write ">
                        Journal Status
                      </label>
                      {/* <input
                        type="text"
                        className="form-control1"
                        value={CapitalizeCase(formData.journalStatus)}
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        : {CapitalizeCase(formData.journalStatus)}
                      </div>
                    </div>
                    <div className="d-flex pt-2">
                      <label className="statis-name-details-write">
                        Journal Status Date
                      </label>
                      {/* <input
                        type="text"
                        className="form-control1"
                        value={getDateFormate(formData.journalStatusDate) || ""}
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        : {getDateFormate(formData.journalStatusDate) || ""}
                      </div>
                    </div>
                    <div className="d-flex  pt-2">
                      <label className="statis-name-details-write">
                        Journal Project Duration
                      </label>
                      {/* <input
                        type="email"
                        className="form-control1"
                        value={formData.journalduration}
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        : {formData.journalduration}
                      </div>
                    </div>
                  </div>
                )}

                <div className="col-12">
                  <label className="client-name-pop mt-1 px-2 ">PENDING</label>
                </div>
                <div className="col-12">
                  <div className="col-md-6 d-flex pt-2">
                    <label className="statis-name-details ">
                      Writer Delay Days
                    </label>
                    {/* <input
                    type="text"
                    className="form-control1"
                    value={pendingData.writer_days_count}
                    readOnly={isReadOnly}
                  /> */}
                    <div className="view-details-data">
                      : {pendingData.writer_days_count}
                    </div>
                  </div>

                  <div className="col-md-6 d-flex  pt-2">
                    <label className="statis-name-details ">
                      Reviewer Delay Days
                    </label>
                    {/* <input
                    type="text"
                    className="form-control1"
                    value={pendingData.reviewer_days_count}
                    readOnly={isReadOnly}
                  /> */}
                    <div className="view-details-data">
                      : {pendingData.reviewer_days_count}
                    </div>
                  </div>

                  <div className="col-md-6 d-flex pt-2">
                    <label className="statis-name-details ">
                      Statistican Delay Days
                    </label>
                    {/* <input
                    type="text"
                    className="form-control1"
                    value={pendingData.statistican_days_count}
                    readOnly={isReadOnly}
                  /> */}
                    <div className="view-details-data">
                      : {pendingData.statistican_days_count}
                    </div>
                  </div>

                  <div className="col-md-6 d-flex pt-2">
                    <label className="statis-name-details  ">
                      Project Delay Days
                    </label>
                    {/* <input
                    type="text"
                    className="form-control1"
                    value={pendingData.project_delay_count}
                    readOnly={isReadOnly}
                  /> */}
                    <div className="view-details-data">
                      : {pendingData.project_delay_count}
                    </div>
                  </div>
                  <div className="col-md-6 d-flex pt-2">
                    <label className="statis-name-details">
                      Writer Payment Due Date
                    </label>
                    {/* <input
                    type="email"
                    className="form-control1"
                    readOnly={isReadOnly}
                    value={
                      pendingData.writerPaymentDueDate
                        ? getDateFormate(pendingData.writerPaymentDueDate)
                        : ""
                    }
                  /> */}
                    <div className="view-details-data">
                      :
                      {pendingData.writerPaymentDueDate
                        ? getDateFormate(pendingData.writerPaymentDueDate)
                        : ""}
                    </div>
                  </div>

                  <div className="col-md-6 d-flex pt-2">
                    <label className="statis-name-details ">
                      Reviewer Payment Due Date
                    </label>
                    {/* <input
                    type="text"
                    className="form-control1"
                    readOnly={isReadOnly}
                    value={
                      pendingData.reviewerPaymentDueD
                        ? getDateFormate(pendingData.reviewerPaymentDueD)
                        : ""
                    }
                  /> */}
                    <div className="view-details-data">
                      :{" "}
                      {pendingData.reviewerPaymentDueD
                        ? getDateFormate(pendingData.reviewerPaymentDueD)
                        : ""}
                    </div>
                  </div>
                </div>
                <div className="col-12">
                  <label className="client-name-pop  mt-3 ">
                    PAYMENT STATUS
                  </label>
                </div>

                {/* {paymentData.length > 0 && ( */}
                <div className="col-12">
                  <div className=" col-md-6 d-flex pt-2  ">
                    <label className="statis-name-details ">
                      Payment Status
                    </label>
                    {/* <input
                      type="text"
                      className="form-control1"
                      value={CapitalizeCase(formData?.payment_status || "")}
                      readOnly={isReadOnly}
                    /> */}
                    <div className="view-details-data">
                      : {CapitalizeCase(formData?.payment_status || "")}
                    </div>
                  </div>
                  <div className="col-6 d-flex pt-2">
                    <label className="statis-name-details">
                      Payment Reference Number
                    </label>
                    {/* <input
                      type="text"
                      className={`form-control1`}
                      name="reference_number"
                      value={formData?.reference_number}
                      readOnly={isReadOnly}
                    /> */}
                    <div className="view-details-data">
                      : {formData?.reference_number}
                    </div>
                  </div>

                  {/*  update document view */}
                  <div className="container mt-4">
                    <div className="row g-2">
                      {files1.map((file, index) => (
                        <div className="col-2" key={index}>
                          <div className="view-files pt-3">
                            <div>
                              <div className="text-center">
                                {getFileIcon(file.type)}
                              </div>
                              <h5 className="text-center mt-2 file-title-card">
                                {Capitalize(file.title)}
                              </h5>
                              <div className="d-flex justify-content-center">
                                <button
                                  className="mt-1 file-view-button mb-1"
                                  onClick={() =>
                                    window.open(file.url, "_blank")
                                  }
                                >
                                  View
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                {/* )} */}

                {formData.writer_payment && (
                  <div className="">
                    <div className="col-md-6 d-flex pt-3 ">
                      <label className="statis-name-details  ">
                        Writer Payment
                      </label>
                      {/* <input
                        type="text"
                        className="form-control1"
                        value={formData.writer_payment}
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        : {formData.writer_payment}
                      </div>
                    </div>
                    <div className="col-md-6 d-flex pt-3 ">
                      <label className="statis-name-details">Writer Payment Date</label>
                      {/* <input
                        type="email"
                        className="form-control1"
                        value={getDateFormate(formData.writer_payment_date)}
                        readOnly={isReadOnly}
                      /> */}
                       <div className="view-details-data">
                        : {getDateFormate(formData.writer_payment_date)}
                      </div>
                    </div>
                  </div>
                )}
                {formData.reviewer_payment && (
                  <div className="">
                    <div className="col-md-6 d-flex pt-3 ">
                      <label className="statis-name-details">Reviewer Payment</label>
                      {/* <input
                        type="text"
                        className="form-control1"
                        value={formData.reviewer_payment}
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        : {formData.reviewer_payment}
                      </div>
                    </div>
                    <div className="col-md-6 d-flex pt-3 ">
                      <label className="statis-name-details">
                        Reviewer Payment Date
                      </label>
                      {/* <input
                        type="email"
                        className="form-control1"
                        value={getDateFormate(formData.reviewer_payment_date)}
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        : {getDateFormate(formData.reviewer_payment_date)}
                      </div>
                    </div>
                  </div>
                )}
                {formData.statistican_payment && (
                  <div className="">
                    <div className="col-md-6 d-flex  pt-3 ">
                      <label className="statis-name-details  ">
                        Statistican Payment
                      </label>
                      {/* <input
                        type="text"
                        className="form-control1"
                        value={formData.statistican_payment}
                        readOnly={isReadOnly}
                      /> */}
                       <div className="view-details-data">
                        : {formData.statistican_payment}
                      </div>
                    </div>
                    <div className="col-md-6 d-flex  pt-3 ">
                      <label className="statis-name-details">
                        Statistican Payment Date
                      </label>
                      {/* <input
                        type="email"
                        className="form-control1"
                        value={getDateFormate(
                          formData.statistican_payment_date
                        )}
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        : {getDateFormate(
                          formData.statistican_payment_date
                        )}
                      </div>
                    </div>
                  </div>
                )}
                {formData.journal_payment && (
                  <div className="">
                    <div className="col-md-6  d-flex pt-3 ">
                      <label className="statis-name-details  ">Journal Payment</label>
                      {/* <input
                        type="text"
                        className="form-control1"
                        value={formData.journal_payment}
                        readOnly={isReadOnly}
                      /> */}
                       <div className="view-details-data">
                       :{formData.journal_payment}
                      </div>
                    </div>
                    <div className="col-md-4  pt-3 ">
                      <label className="statis-name-details">
                        Journal Payment Date
                      </label>
                      {/* <input
                        type="email"
                        className="form-control1"
                        value={getDateFormate(formData.journal_payment_date)}
                        readOnly={isReadOnly}
                      /> */}
                      <div className="view-details-data">
                        : {getDateFormate(formData.journal_payment_date)}
                      </div>
                    </div>
                  </div>
                )}

                <div className="">
                  {paymentData.length > 0 &&
                    paymentData.map((payment, index) => (
                      <div key={index} className="col-md-6 d-flex pt-2">
                        <label className="statis-name-details">
                          {`Payment-${index + 1} / ${getDateFormate(
                            payment.payment_date
                          )}`}
                        </label>
                        {/* <input
                          type="text"
                          className="form-control1"
                          value={`Amount: ${payment.payment}`}
                          readOnly
                        /> */}
                        <div className="view-details-data">
                        : {`Amount: ${payment.payment}`}
                      </div>
                      </div>
                    ))}
                </div>

                <div className="col-md-12 d-flex justify-content-end float-start pt-5 gap-3 ">
                  <Link to="/entry-process">
                    <button className="save-form">Back</button>
                  </Link>
                  <button
                    type="submit"
                    onClick={() => handleEditClick(rowId)}
                    className="save-form-save"
                  >
                    Edit
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div>
          <Footer />
        </div>
      </section>
    </>
  );
}

export default Process_details;
