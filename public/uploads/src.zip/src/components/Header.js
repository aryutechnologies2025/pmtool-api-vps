import "../assests/css/header.css";
import Sider from "../components/Sider.js";
import React, {
  useState,
  useRef,
  useEffect,
  useContext,
  useCallback,
} from "react";
import Tooltip from "@mui/material/Tooltip";

import { IoSearch } from "react-icons/io5";
import { TiMessage } from "react-icons/ti";
import { FaRegBell } from "react-icons/fa";
import Profile from "..//assests/images/sample1.png";
import { TiThMenu } from "react-icons/ti";
import { Capitalize } from "../campsCase.js";
import { IoExitOutline, IoSettingsOutline } from "react-icons/io5";
import { NavLink, Link, useNavigate, useLocation } from "react-router-dom";
import Vector from "../assests/images/Vector.svg";
import Cookies from "js-cookie";
import { VscEye } from "react-icons/vsc";
import axios from "axios";
import { API_URL, HRMS_API_URL } from "../config.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
// import Loader from "./Loader";
import { SettingsContext } from "../components/SettingsContext.js";
import Swal from "sweetalert2";
import { FaChevronDown } from "react-icons/fa"; // Import down arrow icon
import Loader from "../components/Loader.js";

function Header() {
  const navigate = useNavigate();

  const { logoImage } = useContext(SettingsContext);

  const token = Cookies.get("token");

  // console.log("cokies:",token)

  const storedUserDetails = localStorage.getItem("medicspermission");

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;
  const Position = parsedDetails ? parsedDetails.position : null;

  // const logingname = parsedDetails ? parsedDetails.employee_name : null;
  const logingname = parsedDetails ? parsedDetails.employee_name : null;
  let profileimage_f =
    parsedDetails && parsedDetails.profile_image
      ? parsedDetails.profile_image
      : "";

  let profileimage;

  if (profileimage_f) {
    profileimage = `${HRMS_API_URL}/${profileimage_f}`;
  } else {
    profileimage = Profile;
  }
  const rolename = localStorage.getItem("medocsrolename") || "Admin";

  const rolename_n = localStorage.getItem("medicsroleName") || "Admin";
  const employee_type = localStorage.getItem("medicsEmpName");

  const allrole_type = localStorage.getItem("medicsroleName");
  let userPermissions = [];

  // Parse stored details safely
  if (storedUserDetails) {
    try {
      const parsedDetails = JSON.parse(storedUserDetails);
      userPermissions = Array.isArray(parsedDetails) ? parsedDetails : [];
    } catch (error) {
      console.error("Error parsing storedUserDetails:", error);
    }
  }

  const showAllMenus = rolename === "Admin" || userPermissions.length === 0;
  const hasPermission = (permission) => {
    if (rolename === "Admin") {
      return true;
    } else if (userPermissions.length === 0) {
      return false;
    } else {
      return userPermissions.includes(permission);
    }
  };

  const [showMenu, setShowMenu] = useState(false);

  const toggleMenu = () => {
    setShowMenu((prevState) => !prevState);
  };
  const [loading, setLoading] = useState(false);

  const handleLogout = async () => {
    setLoading(true);
    // const token = localStorage.getItem("token");
    // console.log('tootoototo :',token)
    try {
      // const response = await axios.post(
      //   `${API_URL}/api/logoutcheck`,
      //   {
      //     headers: {
      //       Authorization: token,
      //     },
      //   }
      // );

      //   console.log("Logout response:", response);

      // Remove the token from local storage and cookies
      localStorage.removeItem("medicsuser");
      localStorage.removeItem("medicspermission");
      localStorage.removeItem("medocsrolename");
      localStorage.removeItem("medicsroleName");
      localStorage.removeItem("medicsEmpName");

      window.location.reload();

      Cookies.remove("token", { path: "/" });
      await new Promise((res) => setTimeout(res, 1500));
    } catch (error) {
      console.error("Logout failed:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDashboardNavigation = () => {
    if (rolename.includes("Admin")) {
      navigate("/dashboard");
    } else if (rolename.includes(13)) {
      navigate("/project-manager-dashboard");
    } else if (rolename.includes(14)) {
      navigate("/team-coordinator-dashboard");
    } else if (rolename.includes(28)) {
      navigate("/sme-dashboard");
    } else if (rolename.includes(27)) {
      navigate("/publication-dashboard");
    } else if (employee_type === "freelancers") {
      navigate("/freelancer-dashboard");
    } else if (
      (employee_type === "full_time" || employee_type === "part_time") &&
      !rolename.includes(13) &&
      !rolename.includes(14) &&
      !rolename.includes(23)
    ) {
      navigate("/internal-dashboard");
    } else if (
      rolename.includes("Admin") ||
      rolename.includes(13) ||
      rolename.includes(23)
    ) {
      navigate("/accounts-main-dashboard");
    }
  };

  const handleLogoClick = () => {
    if (rolename.includes("Admin")) {
      navigate("/dashboard");
    } else if (rolename.includes(13)) {
      navigate("/project-manager-dashboard");
    } else if (rolename.includes(28)) {
      navigate("/sme-dashboard");
    } else if (rolename.includes(27)) {
      navigate("/publication-dashboard");
    } else if (rolename.includes(14)) {
      navigate("/team-coordinator-dashboard");
    } else if (employee_type === "freelancers") {
      navigate("/freelancer-dashboard");
    } else if (
      (employee_type === "full_time" || employee_type === "part_time") &&
      !rolename.includes(13) &&
      !rolename.includes(14) &&
      !rolename.includes(23)
    ) {
      navigate("/internal-dashboard");
    } else if (
      rolename.includes("Admin") ||
      rolename.includes(13) ||
      rolename.includes(23)
    ) {
      navigate("/accounts-main-dashboard");
    }
  };

  //notification

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const submenuRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      // Check if the click is outside the submenu and the icon itself
      if (submenuRef.current && !submenuRef.current.contains(event.target)) {
        setIsMenuOpen(false);
      }
    };

    // Add event listener for clicks
    document.addEventListener("mousedown", handleClickOutside);

    // Clean up the event listener on component unmount
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Toggle Notification Menu
  const handleMenuToggle = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const [activities, setActivities] = useState([]);
  // console.log('activities :',activities);
  const [actityreply, setActivitiesReply] = useState([]);

  const [activitiesLength, setActivitiesLength] = useState(0);
  const [activitiesLength1, setActivitiesLength1] = useState(0);
  const [assigneeStatus, setAssignStatus] = useState([]);
  // console.log('activitiesxxcdc :',assigneeStatus);
  // console.log('activitiesLength :',activitiesLength);
  // Fetch Activity Data
  // const fetchActivities = useCallback(async () => {
  //   try {
  //     const response = await axios.get(
  //       `${API_URL}/api/projects/project-activity`,
  //       {
  //         params: { createdby: createdby },
  //       }
  //     );

  //     if (response.data.success) {
  //       setActivities(response.data.data?.activities);
  //       setActivitiesReply(response.data.data.replies);
  //       setAssignStatus(response.data.data?.statuslist);
  //       const notificationLength = response.data.data.totalcount;
  //       setActivitiesLength(notificationLength);
  //     }
  //   } catch (error) {
  //     console.error("Error fetching activity data:", error);
  //   }
  // }, [createdby]);

  const fetchAndMergeData = useCallback(async () => {
    try {
      // Make both API calls in parallel
      const pos_id = Position === "Admin" ? 9 : Position;
      const [activitiesRes, notificationsRes] = await Promise.all([
        axios.get(`${API_URL}/api/projects/project-activity`, {
          params: { createdby: createdby },
        }),
        axios.get(`${API_URL}/api/projects/notification-view`, {
          params: { position_id: pos_id },
        }),
      ]);
      // console.log('activitiesRes :',activitiesRes);
      // console.log('notificationsRes :',notificationsRes);

      const notificationLength = activitiesRes.data.data.totalcount;
      // console.log('notificationLength :',notificationLength);
      setActivitiesLength(notificationLength);
      // Transform activities data
      const activitiesData = activitiesRes.data.success
        ? activitiesRes.data.data?.statuslist.map((item) => ({
            id: item.id || item.activity_id || "",
            project: item.status_data?.project_id || "",
            project_id: item.status_data?.project_id || "",
            message: item.activity || "",
            project_number: item.project_id || "",
            name: item.createdby_name || "",
            type: "statusassign",
            timestamp: item.created_at || "",
          })) || []
        : [];

      const activities2Data = activitiesRes.data.success
        ? activitiesRes.data.data?.activities.map((item) => ({
            id: item.id || item.activity_id || "",
            project: item.activity_data?.project_id || "",
            project_id: item.activity_data?.project_id || "",
            message: item.activity || "",
            project_number: item.activity_data?.id || "",
            name: item.createdby_name || "",
            type: "statusassign",
            timestamp: item.created_at || "",
          })) || []
        : [];

      // Transform notifications data
      const notificationsData = notificationsRes.data.success
        ? notificationsRes.data.data?.notification.map((item) => ({
            id: item.id || "",
            project: item.project_id?.project_id || "",
            project_id: item.project_id?.project_id || "",
            message: item.message || "",
            project_number: item.project_id || "",
            name: item.project || "",
            type: "notification",
            timestamp: item.created_at || item.sent_at || "",
          })) || []
        : [];
      // console.log("activitiesData :",activitiesData);
      // Merge both datasets
      const mergedData = [
        ...activitiesData,
        ...activities2Data,
        ...notificationsData,
      ];

      // console.log('mergedData :',mergedData);
      // Set to state
      setActivities(mergedData.reverse());

      setActivitiesReply(activitiesRes.data.data.replies.reverse());
      setAssignStatus(activitiesRes.data.data?.statuslist.reverse());

      // If you still need the separate data for other purposes:
      // if (activitiesRes.data.success) {
      //   setActivitiesReply1(activitiesRes.data.data?.replies);
      //   setActivitiesLength1(activitiesRes.data.data.totalcount);
      // }
    } catch (error) {
      console.error("Error fetching and merging data:", error);
    }
  }, [createdby]);

  //  one tim running

  //  useEffect(() => {
  //     const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
  //     const alreadyFetched = sessionStorage.getItem("headerDataFetched") === "true";

  //     if (isLoggedIn && !alreadyFetched) {
  //       fetchActivities1();
  //       fetchAndMergeData();
  //       sessionStorage.setItem("headerDataFetched", "true");
  //     }

  //     const interval = setInterval(() => {
  //       if (isLoggedIn && sessionStorage.getItem("headerDataFetched") === "true") {
  //         fetchActivities1();
  //         fetchAndMergeData();
  //       }
  //     }, 60000);

  //     return () => clearInterval(interval);
  //   }, [fetchAndMergeData, createdby]);

  useEffect(() => {
    // fetchActivities();
    fetchActivities1();
    fetchAndMergeData();
    
  }, [createdby]);

  // Fetch data on component mount
  useEffect(() => {
    // fetchActivities();
    fetchActivities1();
    fetchAndMergeData();
    setActivitiesLength(0);

    // const test = axios.get(`${API_URL}/api/projects/notification-view`, {
    //   params: { position_id: 14 }
    // })

    // console.log('test :',test);
  }, [fetchAndMergeData]);

  //
  const removeEmptyTags = (html) => {
    const div = document.createElement("div");
    div.innerHTML = html;

    // Loop through all child elements and remove empty tags
    const elements = div.querySelectorAll("*");
    elements.forEach((element) => {
      if (!element.innerHTML.trim()) {
        element.remove(); // Remove empty elements
      }
    });

    return div.innerHTML;
  };

  const handleActivityView = async (projectid, id, project_number, type) => {
    try {
      console.log(
        "projectid, id, project_number, type, createdby :",
        projectid,
        id,
        project_number,
        type,
        createdby
      );
      // Send the request to mark the activity as read
      let response;

      console.log("activity");
      response = await axios.post(
        `${API_URL}/api/projects/mark-reply-as-read`,
        {
          project_number: project_number,
          action: type,
        }
      );
      // console.log("response1 :", response);

      if (response.data.success) {
        fetchAndMergeData();
        console.log("Activity marked as read");
        console.log("Notification view :", response.data);
      } else {
        console.error("Error marking activity as read");
      }
      console.log("response :", response);
      // Now navigate to the project view
      // history.push(`/project-view/${projectid}`);
      navigate(`/project-view/${projectid}`);
    } catch (error) {
      console.error("Error occurred while marking activity as read", error);
    }
  };
  //reply view

  const [isMenuOpen1, setIsMenuOpen1] = useState(false);
  const submenuRef1 = useRef(null);

  const handleMenuToggle1 = () => {
    setIsMenuOpen1((prev) => !prev);
  };

  // Fetch Activity Data
  const fetchActivities1 = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/projects/project-activity-reply`,
        {
          params: { createdby: createdby },
        }
      );

      if (response.data.success) {
        const notificationLength = response.data.data.totalcount;
        setActivitiesLength1(notificationLength);
      }
    } catch (error) {
      console.error("Error fetching activity data:", error);
    }
  };

  const menuRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (submenuRef1.current && !submenuRef1.current.contains(event.target)) {
        setShowMenu(false); // Close menu if click is outside
      }
    };

    document.addEventListener("mousedown", handleClickOutside); // Detect mouse down event
    return () => {
      document.removeEventListener("mousedown", handleClickOutside); // Cleanup
    };
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        await axios.get(`${API_URL}/api/projects/getNotification-task`);
      } catch (error) {
        console.error("Error fetching notifications:", error);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowMenu(false); // Close menu if click is outside
      }
    };

    document.addEventListener("mousedown", handleClickOutside); // Detect mouse down event
    return () => {
      document.removeEventListener("mousedown", handleClickOutside); // Cleanup
    };
  }, []);

  // reports
  const [showSubMenu, setShowSubMenu] = useState(false);
  const reportmenuRef = useRef(null);

  // Toggle submenu visibility
  const toggleSubMenu = () => {
    setShowSubMenu(!showSubMenu);
  };

  // allentites

  const [showSubMenuall, setShowSubMenuall] = useState(false);
  const reportmenuRefall = useRef(null);

  // Toggle submenu visibility
  const toggleSubMenuall = () => {
    setShowSubMenuall(!showSubMenuall);
  };

  useEffect(() => {
    const handleClickOutsideall = (event) => {
      if (
        reportmenuRefall.current &&
        !reportmenuRefall.current.contains(event.target)
      ) {
        setShowSubMenuall(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutsideall);
    return () => {
      document.removeEventListener("mousedown", handleClickOutsideall);
    };
  }, []);

  const location = useLocation();

  // Check if the current path matches any of the submenu links
  const isActiveall = [
    "/accounts-dashboard",
    "/project-activity",
    "/modula-institution",
  ].includes(location.pathname);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        reportmenuRef.current &&
        !reportmenuRef.current.contains(event.target)
      ) {
        setShowSubMenu(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // const location = useLocation();

  // Check if the current path matches any of the submenu links
  const isActive = [
    "/process-report",
    "/operational-report",
    "/employee-performance",
    "/payment-reports",
    "/client-analysis",
    "/client-record",
    "/projectlist",
  ].includes(location.pathname);

  if (loading) {
    return <Loader />;
  }
  return (
    <section className="header">
      <div className=" w-100 header-hide  d-none d-xl-flex  ">
        <div className="col-1 d-flex pt-3 px-0 ">
          <img
            className="img-fluid header-logo"
            src={logoImage}
            alt="img"
            onClick={handleLogoClick}
          />
        </div>
        <div className=" col-8 mt-3 pt-2 py-2  mx-2 d-flex gap-1 align-items-center  ">
          <div onClick={handleDashboardNavigation} className="btn1">
            Dashboard
          </div>
          {(rolename === "Admin" || rolename === "13") && (
            <NavLink to="/entry-process" className="btn1">
              Project List
            </NavLink>
          )}

          {rolename === "27" && (
            <NavLink to="/publication-list" className="btn1">
              Project List
            </NavLink>
          )}

          {rolename === "14" && (
            <NavLink to="/team-coordinator-list" className="btn1">
              Project List
            </NavLink>
          )}
          {/* {(allrole_type === "Writer" ||
            allrole_type === "Reviewer" ||
            allrole_type === "Statistican") && (
            <NavLink to="/freelancer-project-list" className="btn1">
              Project List
            </NavLink>
          )} */}
          {["Writer", "Reviewer", "Statistican"].some((role) =>
            allrole_type?.includes(role)
          ) && (
            <NavLink to="/freelancer-project-list" className="btn1">
              Project List
            </NavLink>
          )}

          {/* {rolename === "Admin" && (
            <NavLink to="/accounts-dashboard" className="btn1">
              Accounts
            </NavLink>
          )}` */}
          {rolename === "23" && (
            <NavLink to="/invoice-list" className="btn1">
              Invoice List
            </NavLink>
          )}
          {/* {rolename === "Admin" && (
            <NavLink to="/project-activity" className="btn1">
              Project Activity
            </NavLink>
          )} */}
          {/* {rolename === 'Admin' && (
            <NavLink to="/paymentstatus" className="btn1">
              payment
            </NavLink>
          )} */}
          {/* {rolename === "Admin" && (
            <NavLink to="/modula-institution" className="btn1">
              Entities
            </NavLink>
          )} */}
          {rolename === "Admin" && (
            <div
              ref={reportmenuRefall}
              onClick={toggleSubMenuall}
              className={`position-relative btn1 ${
                isActiveall ? "active" : ""
              }`}
            >
              All Activities
              <FaChevronDown
                className={`ms-2 ${showSubMenuall ? "rotate-180" : ""}`}
              />
              {showSubMenuall && (
                <div className="dropdown-menu show position-absolute">
                  <NavLink to="/accounts-dashboard" className="dropdown-item">
                    Accounts
                  </NavLink>
                  <NavLink to="/project-activity" className="dropdown-item">
                    Project Activity
                  </NavLink>
                  <NavLink to="/modula-institution" className="dropdown-item">
                    Entities
                  </NavLink>
                </div>
              )}
            </div>
          )}
          {/* reports ................>>>>>>>.........<<<<<<<<<<<<< */}
          {(rolename === "Admin" || rolename === "13") && (
            <div
              ref={reportmenuRef}
              onClick={toggleSubMenu}
              className={`position-relative btn1 ${isActive ? "active" : ""}`}
            >
              Reports
              <FaChevronDown
                className={`ms-2 ${showSubMenu ? "rotate-180" : ""}`}
              />
              {showSubMenu && (
                <div className="dropdown-menu show position-absolute">
                  <NavLink to="/process-report" className="dropdown-item">
                    Process Reports
                  </NavLink>
                  <NavLink to="/operational-report" className="dropdown-item">
                    Operational Reports
                  </NavLink>
                  <NavLink to="/employee-performance" className="dropdown-item">
                    Employee Performence
                  </NavLink>
                  <NavLink to="/payment-reports" className="dropdown-item">
                    Payment Reports
                  </NavLink>
                  <NavLink to="/client-analysis" className="dropdown-item">
                    Client Analysis
                  </NavLink>
                  <NavLink to="/client-record" className="dropdown-item">
                    Client Record
                  </NavLink>
                  <NavLink to="/projectlist" className="dropdown-item">
                    Project List
                  </NavLink>
                </div>
              )}
            </div>
          )}
          {/* sme list..................... */}
          {rolename === "28" && (
            <NavLink to="/sme-list" className="btn1">
              Project List
            </NavLink>
          )}
          {rolename === "23" && (
            <NavLink to="/accounts-projects" className="btn1">
              Project List
            </NavLink>
          )}
          {/* {rolename === "14" && (
            <NavLink to="/people-details" className="btn1">
              Peoples
            </NavLink>
          )} */}
        </div>

        {/* <div className="col-5  d-flex justify-content-end"> */}
        <div
          className={`d-flex justify-content-between header-admin mt-1 ${
            rolename === "7" || rolename === "8" || rolename === "14"
              ? "col-3"
              : "col-3"
          }`}
        >
          <div className="d-flex pt-2  ">
            {/* <div className="group-icon text-center mx-2 pt-2  ">
                <IoSearch className="head-icon" />
              </div>
              <div className="group-icon text-center mx-2 pt-2">
                <TiMessage className="head-icon" />
              </div> */}
            {(rolename === "Admin" ||
              rolename === "13" ||
              rolename === "14") && (
              <Tooltip title="Notifications">
                <div
                  className="notification-container text-center mx-2 mt-1"
                  onClick={handleMenuToggle}
                >
                  <FaRegBell
                    className={`ico-header-icon ${
                      activitiesLength >= 1 ? "red-notification" : ""
                    }`}
                  />
                  {activitiesLength >= 1 && (
                    <p className="notification-count">{activitiesLength}</p>
                  )}
                </div>
              </Tooltip>
            )}

            {rolename !== "Admin" && rolename !== "13" && rolename !== "14" && (
              <Tooltip title="Notifications">
                {/* <div className=" text-center mx-2 " onClick={handleMenuToggle1}> */}
                <div
                  className="notification-container text-center mx-2 mt-1"
                  onClick={handleMenuToggle1}
                >
                  {/* <FaRegBell className="ico-header-icon" /> */}

                  <FaRegBell
                    className={`ico-header-icon ${
                      activitiesLength1 > 0 ? "red-notification" : ""
                    }`}
                  />
                  {activitiesLength1 > 0 && (
                    <p className="notification-count">{activitiesLength1}</p>
                  )}
                </div>
              </Tooltip>
            )}

            {isMenuOpen && activitiesLength >= 1 && (
              <div className="submenu-notification" ref={submenuRef}>
                {/* Activities List */}
                {activities.length > 0 &&
                  activities.map((activity, index) => (
                    <div key={index} className="border-notic">
                      <div className="view-names1">
                        {[
                          CapitalizeCaseU(activity.name),
                          CapitalizeCaseU(activity.project),
                        ]
                          .filter(Boolean)
                          .join(" / ")}
                      </div>
                      <div className="row">
                        <div className="col-10 created-min mt-1">
                          <span
                            dangerouslySetInnerHTML={{
                              __html: removeEmptyTags(
                                CapitalizeCaseU(activity?.message || "")
                              ),
                            }}
                          />
                        </div>
                        <div className="col-1">
                          <Tooltip title="View">
                            <div
                              onClick={() =>
                                handleActivityView(
                                  activity?.project_id,
                                  activity?.id,
                                  activity?.project_number,
                                  activity.type
                                  // "activity"
                                )
                              }
                            >
                              <VscEye className="open-icon-head" />
                            </div>
                          </Tooltip>
                        </div>
                      </div>
                    </div>
                  ))}

                {/* Activity Replies List - Only Show if More than One Reply Exists */}
                {/* {actityreply.length > 0 &&
                  actityreply.map((activity, index) => (
                    <div key={index} className="border-notic">
                      <div className="view-names1">
                        {CapitalizeCaseU(activity.createdby_name)} /{" "}
                        {CapitalizeCaseU(
                          activity.activity?.activity_data?.project_id
                        )}
                      </div>
                      <div className="row">
                        <div className="col-10 created-min mt-1">
                          <span
                            dangerouslySetInnerHTML={{
                              __html: removeEmptyTags(
                                CapitalizeCaseU(activity?.reply_content || "")
                              ),
                            }}
                          />
                        </div>
                        <div className="col-1">
                          <Tooltip title="View">
                            <div
                              onClick={() =>
                                handleActivityView(
                                  activity.activity?.activity_data?.project_id,
                                  activity.activity?.activity_data?.id,
                                  activity.id,
                                  "reply"
                                )
                              }
                            >
                              <VscEye className="open-icon-head" />
                            </div>
                          </Tooltip>
                        </div>
                      </div>
                    </div>
                  ))} */}
                {/* 
                {assigneeStatus.length > 0 &&
                  assigneeStatus.map((activity, index) => (
                    <div key={index} className="border-notic">
                      <div className="view-names1">
                        {CapitalizeCaseU(activity.createdby_name)} /{" "}
                        {CapitalizeCaseU(activity.status_data?.project_id)}
                      </div>
                      <div className="row">
                        <div className="col-10 created-min mt-1">
                          <span> {CapitalizeCaseU(activity.activity)}</span>
                        </div>
                        <div className="col-1">
                          <Tooltip title="View">
                            <div
                              onClick={() =>
                                handleActivityView(
                                  activity.status_data?.project_id,
                                  activity.status_data?.id,
                                  activity.id,
                                  "statusassign"
                                  
                                )
                              }
                            >
                              <VscEye className="open-icon-head" />
                            </div>
                          </Tooltip>
                        </div>
                      </div>
                    </div>
                  ))} */}

                <div className="d-flex justify-content-end">
                  <button
                    className="all-clear-head"
                    onClick={() =>
                      handleActivityView("", "", "", "clear_all", "")
                    }
                  >
                    Clear All
                  </button>
                </div>
              </div>
            )}
          </div>
          <div className=" d-flex   justify-content-between my-1 mx-1 pro-fi">
            <div className="pro-main mx-2 text-center  ">
              <div className="pro-name ">{Capitalize(logingname)}</div>
              <div className="pro-admin">
                <Link to="/admin-profile" className="admin-create">
                  {Capitalize(rolename_n)}
                </Link>
              </div>
            </div>

            <img
              className=" pro-img"
              src={profileimage}
              alt="img"
              onClick={toggleMenu}
            />
            {/* {showMenu && (
              <div className="submenu">
                <ul>
                  <li>
                    <Link to="/settings">
                      <div className="">
                        <IoSettingsOutline className="" />
                        <span className="">Settings</span>
                      </div>
                    </Link>
                  </li>
                  <li>
                    <NavLink
                      to="/"
                      className="logout-link"
                      onClick={handleLogout}
                    >
                      <IoExitOutline className="logout-icon" />
                      <span className="">Logout</span>
                    </NavLink>
                  </li>
                </ul>
              </div>
            )} */}
            {showMenu && (
              <div className="submenu" ref={menuRef}>
                <div>
                  {rolename === "Admin" && (
                    <div className="border-notic">
                      <Link to="/settings" className="text-decoration-none">
                        <div className="view-project-head">
                          <IoSettingsOutline className="" />
                          <span className="mx-2">Settings</span>
                        </div>
                      </Link>
                    </div>
                  )}
                  <div onClick={handleLogout} className="border-notic">
                    {/* <Link
                      to="/"
                      className="logout-link text-decoration-none"
                      onClick={handleLogout}
                    >
                      
                    </Link> */}
                    <div className="view-project-head">
                      <IoExitOutline className="logout-icon" />
                      <span className="mx-2">Logout</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      {/* <div className="row w-100 header-hide   d-xl-none  d-none d-lg-flex  ">
        <div className="col-1 d-flex justify-content-center  px-0 ">
          <img
            className="img-fluid header-logo w-75"
            src={logoImage}
            alt="img"
          />
        </div>

        <div className="col-5  d-flex justify-content-between header-admin mt-1 ">
          <div className="d-flex pt-2  ">
            <div className="group-icon text-center mx-2 pt-2">
              <FaRegBell className="head-icon" />
            </div>
          </div>
          <div className=" d-flex   justify-content-between my-1 mx-1 pro-fi">
            <div className="pro-main mx-2 text-center  ">
              <div className="pro-name ">
                <p>Rabina </p>
              </div>
              <div className="pro-admin">
                <Link to="/admin-profile" className="admin-create">
                  Admin
                </Link>
              </div>
            </div>

            <img
              className=" pro-img"
              src={Profile}
              alt="img"
              onClick={toggleMenu}
            />
            {showMenu && (
              <div className="submenu">
                <ul>
                  <li onClick={handleLogout}>Logout</li>
                </ul>
              </div>
            )}
          </div>
        </div>
      </div> */}

      <div className="col-12 w-100  mt-0 d-lg-none ">
        <div className="w-100 d-flex justify-content-between side-head1">
          <div className="d-flex mt-2 mx-4 ">
            <div className=" text-center px-2  ">
              <IoSearch className="head-icon1" />
            </div>
            <div className=" text-center px-2">
              <TiMessage className="head-icon1" />
            </div>
            <div className=" text-center px-2">
              <FaRegBell className="head-icon1" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Header;
