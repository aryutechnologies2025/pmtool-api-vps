import React, { useState, useEffect } from 'react';
import { Editor } from 'primereact/editor';

const RichEditor_view = ({ formData, setFormData }) => {
  const [text, setText] = useState(formData.commandbox || '');

  useEffect(() => {
    // Ensure the formData and local state are synced when formData changes
    if (formData?.commandbox !== undefined) {
      setText(formData.commandbox);
    }
  }, [formData?.commandbox]);

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      e.preventDefault(); 
      const updatedData = {
        activity: text, 
      };
      console.log("Updated data to store:", updatedData);
      function storeData(data) {
        console.log("Storing the following data:", data);
      }
      
      storeData(updatedData);
    
      setText(""); 
      setFormData({ commandbox: "" }); 
    }
  };

  const handleTextChange = (e) => {
    const newText = e.htmlValue;
    setText(newText); // Update local text state
    setFormData({ commandbox: newText }); // Sync with formData state
  };

  return (
    <div className="card">
      <Editor
        placeholder="Type your comment..."
        value={text}
        onTextChange={handleTextChange} // Update formData when text changes
        onKeyDown={handleKeyDown} // Handle Enter key
        style={{ height: '100px' }}
      />
    </div>
  );
};

RichEditor_view.defaultProps = {
  formData: { commandbox: '' },
};

export default RichEditor_view;