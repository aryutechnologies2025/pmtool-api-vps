import React from "react";
import "../assests/css/entryprocess.css";
import { API_URL } from "../config.js";
// import { IoFilter } from "react-icons/io5";
import { VscEye } from "react-icons/vsc";
import { useState, useEffect } from "react";
// import { MdKeyboardArrowDown } from "react-icons/md";
import axios from "axios";
// import axios from '../api/axiosConfig.js';
import Breadcrumbs from "../routes/Breadcrumbs";
import { getDateFormate } from "../dateFormate.js";


import "react-datepicker/dist/react-datepicker.css";
import Header from "./Header";
import ReactDOM from "react-dom";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { Capitalize } from "../campsCase.js";
import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";
import { useLocation } from "react-router-dom";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";

DataTable.use(DT);
function EntryAccountView() {
  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const location = useLocation();
  const { type } = location.state || {};

  // console.log("check data", type);
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);

  // console.log("response.data :", filteredData);

  const fetchData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/accountant/accountant_list`,
        {
          params: {
            type: type || "",
          },
        }
      );
      // console.log("response.data :", response.data);
      // console.log("responseALL:", response.data?.data);
      const details = response.data?.data;

      setData(details);
      setFilteredData(details);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);
  const navigate = useNavigate();

  const handleViewClick = (id) => {
    navigate("/accounts-view/accounts-view-details", {
      state: { rowId: id },
    });
  };

  const truncateText = (text, limit) => {
    if (text && text.length > limit) {
      return text.slice(0, limit) + "..."; // Truncate and add ellipsis if text is longer
    }
    return text;
  };

  const columns = [
    {
      title: "PROJECT ID",
      data: "project_id",
      render: (data) => Capitalize(data),
    },
    {
      title: "DATE",
      data: "entry_date",
      render: (data) => getDateFormate(data),
    },
    // {
    //   title: "DEPARTMENT",
    //   data: null,
    //   render: (data) =>
    //     data?.department?.name ? Capitalize(data.department.name) : "-",
    // },
    // {
    //   title: "INSTITUTE",
    //   data: null,
    //   render: (data) =>
    //     data?.institute?.name ? Capitalize(data.institute.name) : "-",
    // },
    {
      title: "CLIENT NAME",
      data: "client_name",
      render: (data) => `Dr.${Capitalize(data)}`,
    },
    // {
    //   title: "PROFESSION",
    //   data: null,
    //   render: (data) =>
    //     data?.profession?.name ? Capitalize(data.profession.name) : "-",
    // },
    {
      title: "TITLE",
      data: null,
      render: (data, type, row) => {
        const id = `title-${row.sno || Math.random()}`;

        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div
                className="d-flex justify-content-center"
                // onClick={togglePopuptitle}
                onMouseEnter={() => row.title} // Pass title dynamically
                // onMouseLeave={handleMouseLeave}
                id={`title-${row.sno || Math.random()}`}
              >
                {truncateText(row.title, 10)}
              </div>,

              container
            );
          }
        }, 0);

        return `<div id="${id}"></div>`;
      },
    },
    {
      title: "PROJECT STATUS",
      data: "process_status",
      render: (data) => (data ? CapitalizeCaseU(data) : "-"),
    },
    {
      
        title: "Duration".toUpperCase(),
        data: null,
        render: (data) => CapitalizeCaseU(data.projectduration),
      
    },
    // {
    //   title: "PAYMENT STATUS",
    //   data: "payment_process.payment_status",
    //   render: (data, type, row) => {
    //     // Check if paymentProcess exists and has payment_status
    //     if (row.payment_process && row.payment_process.payment_status) {
    //       return CapitalizeCaseU(row.payment_process.payment_status);
    //     } else {
    //       return "-";
    //     }
    //   },
    // },

    {
      title: "Payment Status",
      data: null, // Use null when handling logic in render
      render: function (data, type, row) {
        return row?.payment_process?.payment_status || row?.payment_status || "-";
      }
    },
    {
      title: "ACTIONS",
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                <div className="" title="View">
                  <span>
                    <VscEye
                      onClick={() => handleViewClick(row.id)}
                      className="open-icon"
                    />
                  </span>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  return (
    <section className="container d-flex flex-column min-vh-100 justify-content-between">
      <div className=" row mt-4">
        {/* <div className=" col-1   d-flex justify-content-center">
          <Sider></Sider>
        </div> */}

        <div className="col-12  ">
          <div className="col-12">
            <Header></Header>
          </div>

          <div className="col-12 mt-3 pt-1 wapper w-100 py-5">
            <div className=" row mt-3 d-flex   w-100 ">
              <div className="col-12 col-md-9  px-4 ">
                <p className="heading-entr">Project List</p>
              </div>
              <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>

            <div className="px-1">
              <DataTable
                id="example"
                data={filteredData}
                columns={columns}
                className="display"
                options={{
                  scrollX: true,
                  select: true,
                  pageLength: 20, // Default number of rows per page
                  lengthMenu: [
                    [20, 30, 50],
                    [20, 30, 50],
                  ],
                  order: [],

                }}
              />
            </div>
          </div>
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </section>
  );
}

export default EntryAccountView;
