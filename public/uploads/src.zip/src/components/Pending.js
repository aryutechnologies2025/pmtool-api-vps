import React from "react";
import { API_URL } from "../config";
import Header from "./Header";
import Sider from "./Sider";
import { IoMdAdd } from "react-icons/io";
import { VscGitStashPop, VscEye } from "react-icons/vsc";
import { useNavigate } from "react-router-dom";
import Vector from "../assests/images/Vector.svg";
import { IoIosSearch } from "react-icons/io";
import { useState, useEffect } from "react";

import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

import axios from "axios";
import { Link } from "react-router-dom";
import ReactDOM from "react-dom";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import Breadcrumbs from "../routes/Breadcrumbs";

DataTable.use(DT);

function Pending() {
  const [date, setDate] = useState(null);
  const [date1, setDate1] = useState(null);

  const [showDatas, setShowData] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [formData, setFormData] = useState({});
  const [data, setData] = useState([]);
  const [isReadOnly, setIsReadOnly] = useState(true);
  const [isOpen, setIsOpen] = useState(false);

  const handleDateChange = (date) => {
    setDate(date);
  };

  const handleDateChange1 = (date1) => {
    setDate1(date1);
  };

  const fetchData = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/pending_processes/list`);
      console.log('entry-process', response.data);

      const formattedData = response.data.map((item, index) => ({
        ...item,
        "s.no": (index + 1).toString().padStart(3, '0')
      }));

      setData(formattedData);
      console.log(formattedData);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const fetchShowData = async (id) => {
    try {
      const responseShow = await axios.get(`${API_URL}/api/pending_processes/view/${id}`);
      console.log('Show', responseShow.data.id);
      setFormData(responseShow.data);
      setShowData(responseShow.data);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const handleEditClick = () => {
    setIsReadOnly(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmitpending = async () => {
    try {
      await axios.put(`${API_URL}/api/pending_processes/update/${selectedId}`, formData);
      fetchData();
      setIsOpen(false);
      setIsReadOnly(true);
    } catch (error) {
      console.error("Error updating data", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const openPopup = (id) => {
    setSelectedId(id);
    fetchShowData(id);
    setIsOpen(true);
  };

  const closePopup = () => setIsOpen(false);
  const getCurrentDate = () => {
    const date = new Date();
    return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
  };
  const columns = [
    { 
      title: "DATE", 
      data: null, 
      render: () => getCurrentDate() 
    },
    { title: "PROJECT ID  ", data: "project_id" },
    { title: "Writer pending days ", data: "writer_pending_days" },
    { title: "Reviewer pending days ", data: "reviewer_pending_days" },
    { title: "Project pending days ", data: "project_pending_days" },
    {
      title: "",
      data: null,
      render: (data, type, row) => {
        const id = `actions-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                <VscEye onClick={() => openPopup(row.id)} className="open-icon" />
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  return (
    <>
      <section className="main  w-100">
        <div className="row mt-4 w-100">
          {/* <div className="col-1   d-flex justify-content-center">
            <Sider></Sider>
          </div> */}
          <div className="col-11  ">
            <div className="col-12">
              <Header></Header>
            </div>

            <div className="col-11  pt-1 wapper w-100 mt-3 py-5">
            <div className="pt-2 px-2 d-none d-md-block">
                <Breadcrumbs></Breadcrumbs>
              </div>
              <div className=" row mt-3 d-flex w-100  ">
                <div className="col-5 d-flex mt-2 px-4 ">
                  <p className="heading-entr"> Pending</p>
                </div>
                <div className="col-2 text-center mt-2 ">
                  <div className="d-flex justify-content-center  ">
                    <div className="add-icon">
                      <Link to="/pending/pending-form">
                        <IoMdAdd
                          onClick={() => {
                            setFormData({});
                            openPopup();
                          }}
                          className="add1-icon"
                        />
                      </Link>
                    </div>
                    <div className="add-icon">
                      <VscGitStashPop className="exit-icon" />
                    </div>
                  </div>
                </div>
                <div className="d-flex  col-5   col-md-5   col-lg-5   justify-content-between align-items-center  gap-2 date-sel">
                  <input
                    type="text"
                    className=" input-butn1  "
                    placeholder="ID"
                  />

                  <DatePicker
                    className="input-butn2 mx-2"
                    selected={date}
                    onChange={handleDateChange}
                    dateFormat="dd/MM/yyyy"
                    showMonthDropdown
                    showYearDropdown
                    dropdownMode="select"
                    placeholderText="Date From"
                    popperPlacement="bottom"
                  />
                  <DatePicker
                    className="input-butn4 mx-2"
                    selected={date1}
                    onChange={handleDateChange1}
                    dateFormat="dd/MM/yyyy"
                    showMonthDropdown
                    showYearDropdown
                    dropdownMode="select"
                    placeholderText="Date To"
                    popperPlacement="bottom"
                  />

                  <select className=" input-butn3 ">
                    <option value="">Department</option>
                    <option>one</option>
                    <option>2</option>
                    <option>one</option>
                  </select>
                </div>
              </div>

              <div className="px-1">
                <DataTable
                  id="example"
                  data={data}
                  columns={columns}
                  className="display"
                  options={{ scrollX: true, select: true }}
                />
              </div>
              {isOpen && (
                <div className="popup-container">
                  <div className="popup">
                    <div className="popup-content">
                      <span className="close" onClick={closePopup}>
                        &times;
                      </span>

                      <div className="popup-content1 px-5  ">
                        <div className="row mt-1 mx-2 py-4 ">
                          <div className="col-md-4 float-start pt-2">
                            <h5 className="statis-name   ">ID</h5>
                            <input
                              type="text"
                              name="id"
                              className="client-info1"
                              readOnly={isReadOnly}
                              value={formData.id || ''}
                              onChange={handleInputChange}
                            />
                          </div>

                          <div className="col-md-4 float-start pt-2">
                            <h5 className="statis-name ">
                              Writer Pending Days
                            </h5>
                            <input
                              type="text"
                              name="writer_pending_days"
                              className="client-info1"
                              readOnly={isReadOnly}
                              value={formData.writer_pending_days || ''}
                              onChange={handleInputChange}
                            />
                          </div>

                          <div className="col-md-4 float-start pt-2">
                            <h5 className="statis-name ">
                              Reviewer Pending Days
                            </h5>
                            <input
                              type="text"
                              name="reviewer_pending_days"
                              className="client-info1"
                              readOnly={isReadOnly}
                              value={formData.reviewer_pending_days || ''}
                              onChange={handleInputChange}
                            />
                          </div>

                          <div className="col-md-4 float-start pt-5">
                            <h5 className="statis-name  ">
                              Project Pending Days
                            </h5>
                            <input
                              type="text"
                              name="project_pending_days"
                              className="client-info1"
                              readOnly={isReadOnly}
                              value={formData.project_pending_days || ''}
                              onChange={handleInputChange}
                            />
                          </div>
                          <div className="col-md-4 float-start pt-5">
                            <h5 className="statis-name">
                              Writer Payment Due Date
                            </h5>
                            <input
                              type="text"
                              name="writer_payment_due_date"
                              className="client-info1"
                              readOnly={isReadOnly}
                              value={formData.writer_payment_due_date || ''}
                              onChange={handleInputChange}
                            />
                          </div>

                          <div className="col-md-4 float-start pt-5">
                            <h5 className="statis-name  ">
                              Reviewer Payment Due Date
                            </h5>
                            <input
                              type="text"
                              name="reviewer_payment_due_date"
                              className="client-info1"
                              readOnly={isReadOnly}
                              value={formData.reviewer_payment_due_date || ''}
                              onChange={handleInputChange}
                            />
                          </div>

                          <div className="col-md-10 mt-5 ">
                            {!isReadOnly ? (
                              <button className="save-btn1" onClick={handleSubmitpending}>
                                Save
                              </button>
                            ) : (
                              <button className="save-btn1" onClick={handleEditClick}>
                                Edit
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Pending;
