import React from "react";
import "../assests/css/entryprocess.css";
import { API_URL } from "../config.js";
import { IoIosSearch } from "react-icons/io";
import { IoMdAdd } from "react-icons/io";
import { VscGitStashPop } from "react-icons/vsc";
import { VscEye } from "react-icons/vsc";
import { NavLink } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
import axios from "axios";
import Sider from "./Sider";
import { FaBookReader } from "react-icons/fa";
import Swal from "sweetalert2";
import DatePicker from "react-datepicker";
import Breadcrumbs from "../routes/Breadcrumbs";
import "react-datepicker/dist/react-datepicker.css";
import Header from "./Header";
import ReactDOM from "react-dom";
import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { TfiPencilAlt } from "react-icons/tfi";
import { RiDeleteBin6Line } from "react-icons/ri";
import { TbClockExclamation } from "react-icons/tb";
import { Capitalize } from "../campsCase.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { IoIosMailOpen } from "react-icons/io";
import Tooltip from "@mui/material/Tooltip";
import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";
import { getDateFormate } from "../dateFormate.js";
import { saveAs } from "file-saver";
import Papa from "papaparse";
import { Link } from "react-router-dom";
import { FaIndianRupeeSign } from "react-icons/fa6";
import { LuBadgeDollarSign } from "react-icons/lu";
import { format, parseISO } from "date-fns";
import Loader from "../components/Loader.js";
import Select from "react-select";

DataTable.use(DT);

function Entryprocess() {
  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0");
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const [data, setData] = useState([]);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [showData, setShowData] = useState({});
  const [selectedId, setSelectedId] = useState(null);
  const [filteredData, setFilteredData] = useState([]);
  const [typeofwork, setTypeOfWork] = useState([]); // This is your projectTitle array
  const [institutions, setInstitutions] = useState([]);
  const [filterIntitution, setFilterIntitution] = useState("all");
  const [createdby, setCreatedby] = useState("");
  const [filterTypeOfWork, setFilterTypeOfWork] = useState("all"); // Fixed naming
  const [allData, setAllData] = useState([]); // Store original data
  const [authorname, setAuthorName] = useState([]);
  const [filterAuthorName, setFilterAuthorName] = useState("all"); // Fixed naming
  const [formData, setFormData] = useState({});
  const navigate = useNavigate();

  // Handle view click
  const handleViewClick = (id) => {
    navigate("/entry-process/process-view-details", {
      state: { rowId: id },
    });
  };

  // Fetch data from API
  const fetchData = async (params = {}) => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/activity-list`,
        {
          params: {
            type_of_work: params.type_of_work ?? filterTypeOfWork,
          },
        }
      );

      console.log("response data:", response.data);

      // Set the main data
      setData(response.data.details);
      setAllData(response.data.details); // Store original data

      // Initially show all data
      setFilteredData(response.data.details);

      // Set project titles for dropdown
      setTypeOfWork(response.data.projectTitle || []);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  useEffect(() => {
    fetchData();
  }, []);

  // CORRECTED: Handle Type of Work Change
  const handleTypeOfWorkChange = (selectedOption) => {
    const value = selectedOption ? selectedOption.value : "all";
    setFilterTypeOfWork(value);

    // Apply filter immediately
    if (value === "all") {
      setFilteredData(allData); // Show all data
    } else {
      // Filter based on project_id in the data
      const filtered = allData.filter(
        (item) => item.entry_process_model?.project_id === value
      );
      setFilteredData(filtered);
    }
  };

  // CORRECTED: Handle Filter button click
  const handleFilterClick = () => {
    // Re-fetch data with current filter
    fetchData({
      type_of_work: filterTypeOfWork === "all" ? "" : filterTypeOfWork,
    });
  };

  // CORRECTED: Handle Clear button click
  const handleClearClick = () => {
    setFilterTypeOfWork("all");
    setFilteredData(allData); // Reset to show all data
  };

  // Other handlers
  const handleInstitutionChange = (event) => {
    setFilterIntitution(event.target.value);
  };

  const handleAuthorNameChange = (event) => {
    setFilterAuthorName(event.target.value);
  };

  const [isReadOnly, setIsReadOnly] = React.useState(true);
  const [isOpen, setIsOpen] = useState(false);

  const openPopup = (id) => {
    setIsOpen(true);
    setSelectedId(id);
  };

  const truncateText = (text, limit) => {
    if (text && text.length > limit) {
      return text.slice(0, limit) + "...";
    }
    return text;
  };

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const submenuRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (submenuRef.current && !submenuRef.current.contains(event.target)) {
        setIsMenuOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleMenuToggle = () => {
    setIsMenuOpen((prev) => !prev);
  };

  // Prepare dropdown options
  const typeOfWorkOptions = [
    { value: "all", label: "All Projects" },
    ...(typeofwork.map((work) => ({
      value: work.project_id, // Use project_id as value
      label: Capitalize(work.project_id),
    })) || []),
  ];

  // Columns for DataTable
  const columns = [
    {
      title: "PROJECT ID",
      data: "entry_process_model",
      render: (data) => Capitalize(data?.project_id || "N/A"),
    },
    {
      title: "ACTIVITY PREFORMED",
      data: "activity",
      render: (data) => data,
    },
    {
      title: "USER NAME",
      data: "created_by_user",
      render: (data) => Capitalize(data?.employee_name || "N/A"),
    },
    {
      title: "ROLE",
      data: "role",
      render: (data) => (data ? data.toUpperCase() : ""),
    },

    {
      title: "CREATED DATE",
      data: "created_date",
      render: (data) => getDateFormate(data),
    },
    {
      title: "ACTIONS",
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                <div className="" title="View">
                  <span>
                    <VscEye
                      onClick={() => handleViewClick(row.project_id)}
                      className="open-icon"
                    />
                  </span>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  const handleStartDateChange = (date) => {
    setStartDate(date ? format(date, "yyyy-MM-dd") : null);
  };

  const handleEndDateChange = (date) => {
    setEndDate(date ? format(date, "yyyy-MM-dd") : null);
  };

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }

  return (
    <section className="container d-flex flex-column justify-content-between min-vh-100">
      <div className=" row mt-4">
        <div className="col-12  ">
          <div className="col-12">
            <Header></Header>
          </div>

          <div className="col-12 mt-3 pt-1 wapper w-100 py-5">
            <div className=" row mt-3 d-flex   w-100 ">
              <div className="col-12 col-md-6  px-4 ">
                <p className="heading-entr">Activity Logs</p>
              </div>
              <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>

            <div className="row px-5 d-flex justify-content-end">
              <div className=" d-flex justify-content-end "></div>
            </div>

            <div className="row p-2">
              <div className="col-12 d-flex flex-wrap justify-content-between gap-3">
                <div className="d-flex flex-wrap justify-content-left gap-3">
                  <div className="mt-4 width-default-dropdown">
                    {/* Dropdown for filtering */}
                    <Select
                      options={typeOfWorkOptions}
                      value={typeOfWorkOptions.find(
                        (option) => option.value === filterTypeOfWork
                      )}
                      onChange={handleTypeOfWorkChange}
                      isSearchable={true}
                      placeholder="Select Project ID..."
                    />
                  </div>

                  {/* <div className="mt-4">
                    <button
                      className="button-primary"
                      onClick={handleFilterClick}
                    >
                      Filter
                    </button>
                  </div> */}

                  <div className="mt-4 ">
                    <button
                      className="button-primary-all"
                      onClick={handleClearClick}
                    >
                      All Clear
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-2">
              <DataTable
                id="example"
                data={filteredData}
                columns={columns}
                className="display"
                options={{
                  scrollX: true,
                  select: true,
                  pageLength: 20,
                  lengthMenu: [
                    [20, 30, 50],
                    [20, 30, 50],
                  ],
                  order: [],
                }}
              />
              {isMenuOpen && (
                <div className="submenu-mail" ref={submenuRef}>
                  <div>Mail1</div>
                  <div>Mail2</div>
                  <div>Mail3</div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </section>
  );
}

export default Entryprocess;
