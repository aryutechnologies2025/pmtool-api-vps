import React, { createContext, useState, useEffect } from "react";
import axios from "axios";
import Swal from "sweetalert2";
import { API_URL } from "../config";

export const SettingsContext = createContext();

export const SettingsProvider = ({ children }) => {
  const [logoImage, setLogoImage] = useState(null);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await axios.get(`${API_URL}/api/setting-list`);
        const savedData = response.data.data;

        setLogoImage(savedData.logo_image ? `${API_URL}/uploads/settings/${savedData.logo_image}` : null);
      } catch (error) {
        console.log('check error', error);
      }
    };

    fetchSettings();
  }, []);

  return (
    <SettingsContext.Provider value={{ logoImage }}>
      {children}
    </SettingsContext.Provider>
  );
};
