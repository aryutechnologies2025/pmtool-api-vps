import React from "react";
import "../assests/css/entryprocess.css";
import { API_URL } from "../config.js";
// import { IoFilter } from "react-icons/io5";
import { VscEye } from "react-icons/vsc";
import { useState, useEffect } from "react";
// import { MdKeyboardArrowDown } from "react-icons/md";
import axios from "axios";
// import axios from '../api/axiosConfig.js';
import Breadcrumbs from "../routes/Breadcrumbs";
import { getDateFormate } from "../dateFormate.js";
import "react-datepicker/dist/react-datepicker.css";
import Header from "./Header";
import ReactDOM from "react-dom";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { Capitalize } from "../campsCase.js";
import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";
import { useLocation } from "react-router-dom";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import Loader from "../components/Loader.js";

DataTable.use(DT);
function EntryProjectView() {
  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const location = useLocation();
  const {
    type,
    month,
    process_status,
    journal_status,
    completed_count,
    payment_status,
    count_type,
    client_review,
    listview,
  } = location.state || {};

  console.log("check data", location.state);
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);

  console.log("filtereddata:", filteredData);
  const fetchData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/project-list-view`,
        {
          params: {
            type: type || "",
            month: month || "",
            process_status: process_status || "",
            journal_status: journal_status || "",
            completed_count: completed_count || "",
            payment_status: payment_status || "",
            count_type: count_type || "",
            client_review: client_review || "",
            listview: listview || "",
          },
        }
      );

      const details = response.data?.details || [];
      console.log("details :", details);
      console.log("count_type :", count_type);

      if (count_type === "freelancer_count") {
        const freelancerDetails = response.data?.freelancer_details || [];
        console.log("freelancerDetails :", freelancerDetails);
        const data = freelancerDetails.map((item) => {
          return {
            id: item.id,
            project_id: item.project_id,
            entry_date: item.entry_date,
            department: item.department.name,
            institute: item.institute.name,
            process_status: item.process_status,

            client_name: item.client_name,
            profession: item.profession.name,
            title: item.title,
            project_duration: item.project_duration,
            payment_status: item.payment_status,
          };
        });
        setData(freelancerDetails);
        setFilteredData(data);
      } else if (count_type === "project_delay") {
        const freelancerDetails = response.data?.delayed_projects || [];
        console.log("freelancerDetails :", freelancerDetails);
        const data = freelancerDetails.map((item) => {
          return {
            id: item.id,
            project_id: item.project_id,
            entry_date: item.entry_date,
            department: item.department,
            process_status: item.process_status,

            institute: item.institute,
            client_name: item.client_name,
            profession: item.profession,
            title: item.title,
            project_duration: item.projectDuration,
            payment_status: item.payment_status,
          };
        });
        setData(freelancerDetails);
        setFilteredData(data);
      } else {
        const data = details.map((item) => {
          return {
            id: item.id,
            project_id: item.project_id,
            entry_date: item.entry_date,
            process_status: item.process_status,

            department: item.department_info.name,
            institute: item.institute_info.name,
            client_name: item.client_name,
            profession: item.profession_info.name,
            title: item.title,
            project_duration: item.projectduration,
            payment_status: item.payment_process?.payment_status,
          };
        });
        setData(details);
        setFilteredData(data);
      }
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);
  const navigate = useNavigate();

  const handleViewClick = (id) => {
    navigate("/entry-process/process-view-details", {
      state: { rowId: id },
    });
  };
  //  console.log("idrow :",handleViewClick)

  const truncateText = (text, limit) => {
    if (text && text.length > limit) {
      return text.slice(0, limit) + "..."; // Truncate and add ellipsis if text is longer
    }
    return text;
  };

  const columns = [
    {
      title: " Project ID".toUpperCase(),
      data: "project_id",
      render: (data) => Capitalize(data),
    },
    {
      title: "DATE",
      data: "entry_date",
      render: (data) => getDateFormate(data),
    },
    {
      title: "Department".toUpperCase(),
      data: "department",
      render: (data) => Capitalize(data),
    },
    {
      title: "Institution".toUpperCase(),
      data: "institute",
      render: (data) => Capitalize(data),
    },
    {
      title: "Client Name".toUpperCase(),
      data: "client_name",
      render: (data) => `Dr.${Capitalize(data)}`,
    },
    {
      title: "Profession".toUpperCase(),
      data: "profession",
      render: (data) => Capitalize(data),
    },
    {
      title: "TITLE",
      data: null,
      render: (data, type, row) => {
        const id = `title-${row.sno || Math.random()}`;

        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div
                className="d-flex justify-content-center"
                // onClick={togglePopuptitle}
                onMouseEnter={() => row.title} // Pass title dynamically
                // onMouseLeave={handleMouseLeave}
                id={`title-${row.sno || Math.random()}`}
              >
                {truncateText(row.title, 10)}
              </div>,

              container
            );
          }
        }, 0);

        return `<div id="${id}"></div>`;
      },
    },
    // {
    //   title: "Process Status".toUpperCase(),
    //   data: null,
    //   render: (data) => CapitalizeCaseU(data.process_status),
    // },

    {
      title: "Duration".toUpperCase(),
      data: null,
      render: (data) => CapitalizeCaseU(data.project_duration),
    },
    {
      title: "Process Status".toUpperCase(),
      data: null,
      render: (data) => {
        const status = data.process_status?.toLowerCase() || "";
        const classMap = {
          in_progress: "status-in-progress",
          completed: "status-completed",
          not_assigned: "status-not-assigned",
          pending_author: "status-pending-author",
          withdrawal: "status-withdrawn-author",
          client_review: "status-client-review",
        };

        const className = `status-badge ${classMap[status] || ""}`;

        // Utility to convert snake_case or lowercase to Capitalized Words
        const formatStatus = (str) =>
          str.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());

        return `<div class="${className}">${formatStatus(status)}</div>`;
      },
    },

    // {
    //   title: "PAYMENT STATUS",
    //   data: null,
    //   render: (data) => CapitalizeCaseU(data.payment_process.payment_status || "-"),
    // },
    {
      title: "PAYMENT STATUS",
      data: null,
      render: (data) => {
        return CapitalizeCaseU(data.payment_status);
      },
    },

    {
      title: "ACTIONS",
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                <div className="" title="View">
                  <span>
                    <VscEye
                      onClick={() => handleViewClick(row.id)}
                      className="open-icon"
                    />
                  </span>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }

  return (
    <section className="container d-flex flex-column min-vh-100 justify-content-between">
      <div className=" row mt-4">
        {/* <div className=" col-1   d-flex justify-content-center">
          <Sider></Sider>
        </div> */}

        <div className="col-12  ">
          <div className="col-12">
            <Header></Header>
          </div>

          <div className="col-12 mt-3 pt-1 wapper w-100 py-5">
            <div className=" row mt-3 d-flex   w-100 ">
              <div className="col-12 col-md-9  px-4 ">
                <p className="heading-entr">Project View</p>
              </div>
              <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>

            <div className="px-1">
              <DataTable
                id="example"
                // data={filteredData}
                data={[...filteredData].reverse()}
                columns={columns}
                className="display"
                options={{
                  scrollX: true,
                  select: true,
                  pageLength: 20, // Default number of rows per page
                  lengthMenu: [
                    [20, 30, 50],
                    [20, 30, 50],
                  ],
                }}
              />
            </div>
          </div>
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </section>
  );
}

export default EntryProjectView;
