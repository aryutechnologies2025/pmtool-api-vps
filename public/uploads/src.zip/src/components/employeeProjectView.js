import React from "react";
import "../assests/css/entryprocess.css";
import { API_URL } from "../config.js";

import { useState, useEffect } from "react";
// import { MdKeyboardArrowDown } from "react-icons/md";
import axios from "axios";
import { getDateFormate } from "../dateFormate.js";
import Breadcrumbs from "../routes/Breadcrumbs";

import "react-datepicker/dist/react-datepicker.css";
import Header from "./Header";
import ReactDOM from "react-dom";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { Capitalize } from "../campsCase.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";
import { saveAs } from "file-saver";
import Papa from "papaparse";
import { useLocation } from "react-router-dom";
import Loader from "../components/Loader.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import { VscEye } from "react-icons/vsc";

DataTable.use(DT);
function EntryProjectView() {
  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const location = useLocation();
  const { type, createdby, employee_type, month } = location.state || {};
  const [data, setData] = useState([]);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [showData, setShowData] = useState({});
  const [selectedId, setSelectedId] = useState(null);
  const [filteredData, setFilteredData] = useState([]);
  // console.log("filterdata:",filteredData)

  const [typeofwork, setTypeOfWork] = useState([]);
  const [filtertypeofwork, getTypeOfwork] = useState("thesis");

  const [formData, setFormData] = useState({});
  const navigate = useNavigate();

  const handleViewClick = (id) => {
    navigate("/entry-process/process-view-details", {
      state: { rowId: id },
    });
  };

  // console.log('filtertypeofwork : ' + filtertypeofwork)
  // console.log('type : ' + type)
  // console.log('createdby : ' + createdby)
  // console.log('startDate : ' + startDate)
  // console.log('endDate : ' + endDate)

  const fetchData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/employee-project-list`,
        {
          params: {
            start_date: startDate,
            end_date: endDate,
            type: type,
            createdby: createdby,
            type_of_work: filtertypeofwork,
            month: month,
          },
        }
      );
      console.log("response :", response);
      setData(response.data.details);
      setFilteredData(response.data.details);
      setTypeOfWork(response.data.typeofwork);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleChange = (event) => {
    const selectedValue = event.target.value;
    getTypeOfwork(selectedValue);
  };

  //exprt
  const exportToCSV = () => {
    // Define custom headers and map them to data fields
    const headers = [
      {
        label: "Project Title",
        value: "title",
        render: (data) => (data ? Capitalize(data) : "-"),
      },
      {
        label: "Project Id",
        value: "project_id",
        render: (data) => (data ? Capitalize(data) : "-"),
      },
      {
        label: "Type of Work",
        value: "type_of_work",
        render: (data) => (data ? Capitalize(data) : "-"),
      },
      {
        label: "Entry Date",
        value: "writer_assigned_date",
        render: (data) => data,
      }, // No transformation needed
      {
        label: "Process Status",
        value: "process_status",
        render: (data) => (data ? Capitalize(data) : "-"),
      },
    ];

    // Prepare data with headers
    const csv = Papa.unparse({
      fields: headers.map((header) => header.label), // Use labels as headers
      data: filteredData.map((row) =>
        headers.map((header) =>
          header.render ? header.render(row[header.value]) : row[header.value]
        )
      ),
    });

    // Create a Blob from the CSV string
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });

    // Format the filename with the start and end dates
    const formattedStartDate = startDate
      ? startDate.replace(/-/g, "")
      : new Date().toISOString().split("T")[0].replace(/-/g, ""); // If endDate is empty, use current date
    const formattedEndDate = endDate
      ? endDate.replace(/-/g, "")
      : new Date().toISOString().split("T")[0].replace(/-/g, ""); // If endDate is empty, use current date
    const fileName = `entryprocess_${formattedStartDate}_to_${formattedEndDate}.csv`;

    // Use FileSaver to save the file
    saveAs(blob, fileName);
  };

  const truncateText = (text, limit) => {
    if (text && text.length > limit) {
      return text.slice(0, limit) + "..."; // Truncate and add ellipsis if text is longer
    }
    return text;
  };

  let columns;
  if (employee_type === "freelancers") {
    columns = [
      {
        title: "PROJECT ID",
        data: "project_id",
        render: (data) => Capitalize(data),
      },
      // { title: "DATE", data: "entry_date", render: (data) => getDateFormate(data) },
      {
        title: "DATE",
        data: "entry_date",
        render: function (data, type, row) {
          return data ? getDateFormate(data) : "-"; // Call function properly
        },
      },
      {
        title: "TITLE",
        data: null,
        render: (data, type, row) => {
          const id = `title-${row.sno || Math.random()}`;

          setTimeout(() => {
            const container = document.getElementById(id);
            if (container && !container.hasChildNodes()) {
              ReactDOM.render(
                <div
                  className="d-flex justify-content-center"
                  // onClick={togglePopuptitle}
                  onMouseEnter={() => row.title} // Pass title dynamically
                  // onMouseLeave={handleMouseLeave}
                  id={`title-${row.sno || Math.random()}`}
                >
                  {truncateText(row.title, 10)}
                </div>,

                container
              );
            }
          }, 0);

          return `<div id="${id}"></div>`;
        },
      },
      {
        title: "PROCESS STATUS",
        data: "process_status",
        render: (data) => (data ? Capitalize(data) : "-"),
      },
      {
        title: "Duration".toUpperCase(),
        data: null,
        render: (data) => CapitalizeCaseU(data.projectduration),
      },
      {
        title: "freelancer fee".toUpperCase(),
        data: "freelancer_fee",
        render: (data) => (data ? Capitalize(data) : "-"),
      },
      {
        title: "payment status date".toUpperCase(),
        data: null,
        render: (data) =>
          data?.payment_process?.payment_date
            ? Capitalize(data.payment_process.payment_date)
            : "-",
      },
    ];
  } else {
    columns = [
      {
        title: "Project ID".toUpperCase(),
        data: "project_id",
        render: (data) => (data ? Capitalize(data) : "-"),
      },
      // { title: "DATE", data: "entry_date", render: (data) => getDateFormate(data) },
      {
        title: "DATE",
        data: "entry_date",
        render: (data) => getDateFormate(data),
      },
      {
        title: "Department".toUpperCase(),
        data: null,
        render: (data) =>
          data?.department_info?.name
            ? Capitalize(data.department_info.name)
            : "-",
      },
      {
        title: "Institution".toUpperCase(),
        data: null,
        render: (data) =>
          data?.institute_info?.name
            ? Capitalize(data.institute_info.name)
            : "-",
      },

      {
        title: "Client Name".toUpperCase(),
        data: "client_name",
        render: (data) => (data ? Capitalize(data) : "-"),
      },
      {
        title: "Profession".toUpperCase(),
        data: null,
        render: (data) =>
          data?.profession_info?.name
            ? Capitalize(data.profession_info.name)
            : "-",
      },
      {
        title: "TITLE",
        data: null,
        render: (data, type, row) => {
          const id = `title-${row.sno || Math.random()}`;

          setTimeout(() => {
            const container = document.getElementById(id);
            if (container && !container.hasChildNodes()) {
              ReactDOM.render(
                <div
                  className="d-flex justify-content-center"
                  // onClick={togglePopuptitle}
                  onMouseEnter={() => row.title} // Pass title dynamically
                  // onMouseLeave={handleMouseLeave}
                  id={`title-${row.sno || Math.random()}`}
                >
                  {truncateText(row.title, 10)}
                </div>,

                container
              );
            }
          }, 0);

          return `<div id="${id}"></div>`;
        },
      },
      {
        title: "Process Status".toUpperCase(),
        data: null,
        render: (data) => CapitalizeCaseU(data.process_status),
      },
      {
        title: "Duration".toUpperCase(),
        data: null,
        render: function (data, type, row) {
          let assigneddate = "-";

          if (row.writer_data) {
            assigneddate = row.writer_data[0].project_duration;
          } else if (row.reviewer_data) {
            assigneddate = row.reviewer_data[0].project_duration;
          } else if (row.statistican_data) {
            assigneddate = row.statistican_data[0].project_duration;
          }
          return assigneddate !== "-" ? getDateFormate(assigneddate) : "-";
        },
      },
      {
        title: "Payment Status".toUpperCase(),
        data: null,
        render: (data) =>
          data?.payment_process?.payment_status
            ? Capitalize(data.payment_process.payment_status)
            : "-",
      },
      {
        title: "ACTIONS",
        data: null,
        render: (data, type, row) => {
          const id = `process-${row.sno || Math.random()}`;
          setTimeout(() => {
            const container = document.getElementById(id);
            if (container && !container.hasChildNodes()) {
              ReactDOM.render(
                <div className="d-flex justify-content-center">
                  <div className="" title="View">
                    <span>
                      <VscEye
                        onClick={() => handleViewClick(row.id)}
                        className="open-icon"
                      />
                    </span>
                  </div>
                </div>,
                container
              );
            }
          }, 0);
          return `<div id="${id}"></div>`;
        },
      },
    ];
  }

  const handleStartDateChange = (date) => {
    setStartDate(date ? date.toISOString().split("T")[0] : null);
  };

  const handleEndDateChange = (date) => {
    setEndDate(date ? date.toISOString().split("T")[0] : null);
  };

  const handleTypeOfWorkChange = (event) => {
    getTypeOfwork(event.target.value);
  };

  const handleClearClick = () => {
    setStartDate(null);
    setEndDate(null);
    getTypeOfwork("all");
  };
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }
  return (
    <section className="container d-flex flex-column min-vh-100 justify-content-between">
      <div className=" row mt-4">
        {/* <div className=" col-1   d-flex justify-content-center">
          <Sider></Sider>
        </div> */}

        <div className="col-12  ">
          <div className="col-12">
            <Header></Header>
          </div>

          <div className="col-12 mt-3 pt-1 wapper w-100 ">
            <div className=" row mt-3 d-flex   w-100 ">
              <div className="col-12 col-md-9  px-4 ">
                <p className="heading-entr">Project View </p>
              </div>
              <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>

            {/* <div className="row p-2">
              <div className="col-12 d-flex justify-content-between gap-3">
                <div className="  d-flex justify-content-left gap-3">
                  <div className="width-default">
                    <label htmlFor="start-date" className="">
                      Start-Date
                    </label>
                    <input
                      type="date"
                      id="start-date"
                      className="form-control-date ms-3 ms-md-0"
                      value={startDate || ""} // Ensure empty value works
                      onChange={(e) => setStartDate(e.target.value)}
                      isClearable
                    />
                  </div>

                  <div className="width-default ">
                    <label htmlFor="end-date" className="">
                      End-Date
                    </label>
                    <input
                      type="date"
                      id="end-date"
                      className="form-control-date"
                      value={endDate || ""} // Ensure empty value works
                      onChange={(e) => setEndDate(e.target.value)}
                      isClearable
                    />
                  </div>
                  <div className="mt-4 width-default ">
                    <select
                      className=" form-select-date"
                      value={filtertypeofwork}
                      onChange={handleTypeOfWorkChange}
                    >
                      <option value="all">Type Of Work</option>
                      {typeofwork.map((work) => (
                        <option
                          key={work.type_of_work}
                          value={work.type_of_work}
                        >
                          {Capitalize(work.type_of_work)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="mt-4">
                    <button className="button-primary " onClick={fetchData}>
                      Filter
                    </button>
                  </div>

                  <div className="mt-4 width-default">
                    <button
                      className="button-primary-all"
                      onClick={handleClearClick}
                    >
                      All Clear
                    </button>
                  </div>
                </div>

                <div className="d-flex justify-content-end">
                  <div className=" text-center mt-3 ">
                    <div className=" d-flex justify-content-center    ">
                      <Tooltip title="Export">
                        <div className="add-icon">
                          <VscGitStashPop
                            className="add1-icon"
                            onClick={exportToCSV}
                          />
                        </div>
                      </Tooltip>
                    </div>
                  </div>
                </div>
              </div>
            </div> */}

            <div className="px-1">
              <DataTable
                id="example"
                data={filteredData}
                columns={columns}
                className="display"
                options={{
                  scrollX: true,
                  select: true,
                  pageLength: 20, // Default number of rows per page
                  lengthMenu: [
                    [20, 30, 50],
                    [20, 30, 50],
                  ],
                }}
              />
            </div>
          </div>
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </section>
  );
}

export default EntryProjectView;
