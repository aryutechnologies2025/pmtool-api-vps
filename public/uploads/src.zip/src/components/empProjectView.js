import React from "react";
import "../assests/css/entryprocess.css";
import { API_URL } from "../config.js";
import { IoIosSearch } from "react-icons/io";
// import { IoFilter } from "react-icons/io5";
import { IoMdAdd } from "react-icons/io";
import { VscGitStashPop } from "react-icons/vsc";
import { VscEye } from "react-icons/vsc";
import { NavLink } from "react-router-dom";
import { useState, useEffect } from "react";
// import { MdKeyboardArrowDown } from "react-icons/md";
import axios from "axios";
// import axios from '../api/axiosConfig.js';

import Sider from "./Sider";
import { FaBookReader } from "react-icons/fa";
import Swal from "sweetalert2";

import DatePicker from "react-datepicker";
import Breadcrumbs from "../routes/Breadcrumbs";

import "react-datepicker/dist/react-datepicker.css";
import Header from "./Header";
import ReactDOM from "react-dom";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { TfiPencilAlt } from "react-icons/tfi";
import { RiDeleteBin6Line } from "react-icons/ri";
import { TbClockExclamation } from "react-icons/tb";
import { Capitalize } from "../campsCase.js";
import { CapitalizeCase } from "../capsUnderCase.js";

import Tooltip from "@mui/material/Tooltip";
import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";
import { getDateFormate } from "../dateFormate.js";
import { saveAs } from "file-saver";
import Papa from "papaparse";
import { LuBadgeDollarSign } from "react-icons/lu";
import { useLocation } from "react-router-dom";
import Loader from "../components/Loader.js";

import { TbHourglassLow } from "react-icons/tb";
import { SiFreelancer } from "react-icons/si";
import { MdDoNotDisturb } from "react-icons/md";
import { AiOutlineAlert } from "react-icons/ai";
import { GoProjectRoadmap } from "react-icons/go";

import { CapitalizeCaseU } from "../capsUnderCaseU.js";

DataTable.use(DT);
function EntryProjectView() {
  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const location = useLocation();
  const { type, createdby } = location.state || {};

  console.log("location.state", location.state);

  const [data, setData] = useState([]);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [showData, setShowData] = useState({});
  const [selectedId, setSelectedId] = useState(null);
  const [filteredData, setFilteredData] = useState([]);
  const [typeofwork, setTypeOfWork] = useState([]);
  const [filtertypeofwork, getTypeOfwork] = useState("all");
  const [projectcount, setDataCount] = useState(0);

  const [formData, setFormData] = useState({});
  console.log("alldata:", data);


  const fetchData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/emp-project-list`,
        {
          params: {
            start_date: startDate,
            end_date: endDate,
            type: type,
            createdby: createdby,
            type_of_work: filtertypeofwork,
          },
        }
      );

      setDataCount(response.data);
      setData(response.data.details);
      setFilteredData(response.data.details);
      setTypeOfWork(response.data.typeofwork);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleChange = (event) => {
    const selectedValue = event.target.value;
    getTypeOfwork(selectedValue);
  };

  //exprt
  const exportToCSV = () => {
    // Define custom headers and map them to data fields
    const headers = [
      {
        label: "Project ID",
        value: "project_id",
        transform: (data) => Capitalize(data || "-"),
      },
      {
        label: "Entry Date",
        value: "entry_date",
        transform: (data) => getDateFormate(data || "-"),
      },
      {
        label: "Department",
        value: "department",
        transform: (data) => (data?.name ? Capitalize(data.name) : "-"),
      },
      {
        label: "Institution",
        value: "institute",
        transform: (data) => (data?.name ? Capitalize(data.name) : "-"),
      },
      {
        label: "Client Name",
        value: "client_name",
        transform: (data) => Capitalize(data || "-"),
      },
      {
        label: "Title",
        value: "title",
        transform: (data) => Capitalize(data || "-"),
      },
      {
        label: "Process Status",
        value: "process_status",
        transform: (data) => CapitalizeCaseU(data || "-"),
      },
      {
        label: "Type of Work",
        value: "type_of_work",
        transform: (data) => Capitalize(data || "-"),
      },
      {
        label: "Assigned Date",
        value: "assigned_date",
        transform: (_, row) => {
          // Extracting assigned date from the available sources
          let assignedDate =
            row.writer_data?.[0]?.assign_date ||
            row.reviewer_data?.[0]?.assign_date ||
            row.statistican_data?.[0]?.assign_date ||
            "-";

          return assignedDate !== "-" ? getDateFormate(assignedDate) : "-";
        },
      },
      {
        title: "Duration".toUpperCase(),
        data: null,
        render: (data) => CapitalizeCaseU(data.projectduration),
      },
      {
        label: "Pending Days",
        value: "pending_days",
        transform: (_, row) => {
          let pendingDays =
            row.writer_pending_days ||
            row.reviewer_pending_days ||
            row.statistican_pending_days ||
            "-";
          return pendingDays;
        },
      },
    ];

    // Prepare data for CSV export
    const csvData = filteredData.map((row) =>
      headers.map((header) =>
        header.transform
          ? header.transform(row[header.value], row)
          : row[header.value] || "-"
      )
    );

    // Convert data to CSV format using PapaParse
    const csv = Papa.unparse({
      fields: headers.map((header) => header.label), // Column names
      data: csvData,
    });

    // Create a Blob from the CSV string
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });

    // Format the filename with the start and end dates
    const formattedStartDate = startDate
      ? startDate.replace(/-/g, "")
      : new Date().toISOString().split("T")[0].replace(/-/g, "");
    const formattedEndDate = endDate
      ? endDate.replace(/-/g, "")
      : new Date().toISOString().split("T")[0].replace(/-/g, "");
    const fileName = `entryprocess_${formattedStartDate}_to_${formattedEndDate}.csv`;

    // Use FileSaver to save the file
    saveAs(blob, fileName);
  };

  const navigate = useNavigate();

  const handleViewClick = (id) => {
    navigate("/entry-process/process-view-details", {
      state: { rowId: id },
    });
  };

  const truncateText = (text, limit) => {
    if (text && text.length > limit) {
      return text.slice(0, limit) + "..."; // Truncate and add ellipsis if text is longer
    }
    return text;
  };

  const columns = [
    {
      title: "Project ID",
      data: "project_id",
      render: (data) => Capitalize(data),
    },
    // { title: "DATE", data: "entry_date", render: (data) => getDateFormate(data) },
    {
      title: "DATE",
      data: "entry_date",
      render: (data) => getDateFormate(data),
    },
    // {
    //   title: "Department".toUpperCase(),
    //   data: null,
    //   render: (data) =>
    //     data?.department?.name ? Capitalize(data.department.name) : "-",
    // },
    // {
    //   title: "Institution".toUpperCase(),
    //   data: null,
    //   render: (data) =>
    //     data?.institute?.name ? Capitalize(data.institute.name) : "-",
    // },
    // {
    //   title: "Client Name".toUpperCase(),
    //   data: "client_name",
    //   render: (data) => Capitalize(data),
    // },
    {
      title: "TITLE",
      data: null,
      render: (data, type, row) => {
        const id = `title-${row.sno || Math.random()}`;

        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div
                className="d-flex justify-content-center"
                // onClick={togglePopuptitle}
                onMouseEnter={() => row.title} // Pass title dynamically
                // onMouseLeave={handleMouseLeave}
                id={`title-${row.sno || Math.random()}`}
              >
                {truncateText(row.title, 10)}
              </div>,

              container
            );
          }
        }, 0);

        return `<div id="${id}"></div>`;
      },
    },
    {
      title: "Process Status".toUpperCase(),
      data: null,
      render: (data) => {
        const status = data.process_status?.toLowerCase() || "";
        const classMap = {
          in_progress: "status-in-progress",
          completed: "status-completed",
          not_assigned: "status-not-assigned",
          pending_author: "status-pending-author",
          withdrawal: "status-withdrawn-author",
          client_review: "status-client-review",
        };

        const className = `status-badge ${classMap[status] || ""}`;

        // Utility to convert snake_case or lowercase to Capitalized Words
        const formatStatus = (str) =>
          str.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());

        return `<div class="${className}">${formatStatus(status)}</div>`;
      },
    },
    // {
    //   title: "TYPE OF WORK",
    //   data: "type_of_work",
    //   render: (data) => Capitalize(data),
    // },
    // {
    //   title: "ASSIGNED DATE",
    //   data: null,
    //   render: function (data, type, row) {
    //     let assigneddate = "-";

    //     if (row.writer_data) {
    //       assigneddate = row.writer_data[0].assign_date;
    //     } else if (row.reviewer_data) {
    //       assigneddate = row.reviewer_data[0].assign_date;
    //     } else if (row.statistican_data) {
    //       assigneddate = row.statistican_data[0].assign_date;
    //     }

    //     // If assigneddate is found, format it (optional)
    //     return assigneddate !== "-" ? getDateFormate(assigneddate) : "-";
    //   },
    // },
    {
      title: "Duration".toUpperCase(),
      data: null,
      render: (data) => CapitalizeCaseU(data.projectduration),
    },
    {
      title: "Freelancer Fee".toUpperCase(),
      data: null,
      render: (data) =>
        data?.employee_payment_details?.length
          ? data.employee_payment_details
              .map((detail) => Capitalize(detail.payment))
              .join(", ")
          : "-",
    },
    {
      title: "Payment Status Date".toUpperCase(),
      data: null,
      render: (data) =>
        data?.employee_payment_details?.length
          ? data.employee_payment_details
              .map((detail) => getDateFormate(detail.payment_date))
              .join(", ")
          : "-",
    },
    {
      title: "Payment Status".toUpperCase(),
      data: null,
      render: (data) => CapitalizeCaseU(data.employee_payment_details[0]?.status || "-"),
    },
    // {
    //   title: "PENDING DAYS",
    //   data: null,
    //   render: function (data, type, row) {
    //     let pendingDays =
    //       row.writer_pending_days ||
    //       row.reviewer_pending_days ||
    //       row.statistican_pending_days ||
    //       "-";

    //     return pendingDays !== "-" ? pendingDays : "-";
    //   },
    // },
    // {
    //   title: "ACTIONS",
    //   data: null,
    //   render: (data, type, row) => {
    //     const id = `process-${row.sno || Math.random()}`;
    //     setTimeout(() => {
    //       const container = document.getElementById(id);
    //       if (container && !container.hasChildNodes()) {
    //         ReactDOM.render(
    //           <div className="d-flex justify-content-center">
    //             <div className="" title="View">
    //               <span>
    //                 <VscEye
    //                   onClick={() => handleViewClick(row.id)}
    //                   className="open-icon"
    //                 />
    //               </span>
    //             </div>
    //           </div>,
    //           container
    //         );
    //       }
    //     }, 0);
    //     return `<div id="${id}"></div>`;
    //   },
    // },
  ];
  const handleFilterClick = () => {
    fetchData();
  };
  const handleClearClick = () => {
    setStartDate("");
    setEndDate("");
    getTypeOfwork("all");

    fetchData({
      start_date: "",
      end_date: "",
      type_of_work: "all",
    });
  };

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }
  return (
    <section className="container  d-flex flex-column min-vh-100 justify-content-between">
      <div className=" row mt-4">
        {/* <div className=" col-1   d-flex justify-content-center">
          <Sider></Sider>
        </div> */}

        <div className="col-12  ">
          <div className="col-12">
            <Header></Header>
          </div>

          <div className="col-12 mt-3 pt-1 wapper w-100 ">
            <div className=" row mt-3 d-flex   w-100 ">
              <div className="col-12 col-md-9  px-4 ">
                <p className="heading-entr">Freelancer Project View</p>
              </div>
              <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>
            <div className="row px-3  gap-5 d-flex  flex-wrap">
              <div className="col-3 project-task-project-blue px-1 align-items-center d-flex justify-content-around">
                {/* <div className="task-box1-dash align-items-center pt-2"> */}
                <GoProjectRoadmap className="project-icon" />
                {/* </div> */}
                <div className="project-writer-dashboard mt-1 ">
                  Total Project count
                </div>
                <div className="project-writer-dashboard-font mt-1">
                  {projectcount.projectsCount}
                </div>
              </div>
              <div className="col-3 project-task-project-orange px-1 align-items-center d-flex justify-content-around">
                {/* <div className="task-box2-dash-orange align-items-center pt-1"> */}
                <TbHourglassLow className="project-icon3" />
                {/* </div> */}

                <div className="project-writer-dashboard-black mt-1">
                  Pending project count
                </div>
                <div className="project-writer-dashboard-font-black mt-1">
                  {projectcount.projectpendingcount}
                </div>
              </div>
              <div className="col-3 project-task-project1 px-1 align-items-center d-flex justify-content-around">
                {/* <div className="task-box3-dash align-items-center pt-3"> */}
                <AiOutlineAlert className="project-icon" />
                {/* </div> */}
                <div className="project-writer-dashboard mt-1">
                  Emergency project count
                </div>
                <div className="project-writer-dashboard-font mt-1">
                  {projectcount.projectemergencycount}
                </div>
              </div>
            </div>

            {/* <div className="row px-5 d-flex justify-content-end">
              <div className=" d-flex justify-content-end ">
                <div className=" text-center ">
                  <div className=" d-flex justify-content-center    ">
                    <Tooltip title="Export">
                      <div className="add-icon">
                        <VscGitStashPop
                          className="add1-icon"
                          onClick={exportToCSV}
                        />
                      </div>
                    </Tooltip>
                  </div>
                </div>
              </div>
            </div> */}
          </div>
          <section className=" mt-3 pt-1 wapper">
            <div className="row p-2">
              <div className=" col-12  d-flex justify-content-between gap-3">
                <div className="d-flex flex-wrap justify-content-left gap-3">
                  <div className="width-default">
                    <label htmlFor="start-date" className="">
                      Start-Date
                    </label>
                    <input
                      type="date"
                      id="start-date"
                      className="form-control-date ms-3 ms-md-0"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      dateFormat="yyyy-MM-dd"
                    />
                  </div>

                  <div className="width-default ">
                    <label htmlFor="end-date" className="">
                      End-Date
                    </label>
                    <input
                      type="date"
                      id="end-date"
                      className="form-control-date "
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      dateFormat="yyyy-MM-dd"
                    />
                  </div>
                  {/* <div className=" width-default ">
                    <label htmlFor="type-of" className="">
                      Type of work
                    </label>
                    <select
                      id="type-of"
                      className=" form-select-date"
                      value={filtertypeofwork}
                      onChange={handleChange}
                    >
                      <option value="all">Type Of Work</option>
                      {typeofwork.map((work) => (
                        <option
                          key={work.type_of_work}
                          value={work.type_of_work}
                        >
                          {Capitalize(work.type_of_work)}
                        </option>
                      ))}
                    </select>
                  </div> */}

                  <div className="mt-4">
                    <button
                      className="button-primary "
                      onClick={handleFilterClick}
                    >
                      Filter
                    </button>
                  </div>
                  <div className="mt-4 ">
                    <button
                      className="button-primary-all"
                      onClick={handleClearClick}
                    >
                      All Clear
                    </button>
                  </div>
                </div>
                <div className=" d-flex justify-content-end ">
                  <div className=" text-center mt-2 ">
                    <div className=" d-flex justify-content-center ">
                      <Tooltip title="Export">
                        <div className="add-icon">
                          <VscGitStashPop
                            className="add1-icon"
                            onClick={exportToCSV}
                          />
                        </div>
                      </Tooltip>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="px-1">
              <DataTable
                id="example"
                data={filteredData}
                columns={columns}
                className="display"
                options={{
                  scrollX: true,
                  select: true,
                  pageLength: 20, // Default number of rows per page
                  lengthMenu: [
                    [20, 30, 50],
                    [20, 30, 50],
                  ],
                }}
              />
            </div>
          </section>
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </section>
  );
}

export default EntryProjectView;
