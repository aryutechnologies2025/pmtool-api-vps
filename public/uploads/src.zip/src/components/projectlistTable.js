import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";
import Papa from "papaparse";
import { saveAs } from "file-saver";
import { Tooltip } from "@mui/material";
import { VscGitStashPop } from "react-icons/vsc";
import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import "../assests/css/enterprocesshead.css";
import { API_URL } from "../config.js";
import { getDateFormate } from "../dateFormate.js";
import { Capitalize } from "../campsCase.js";
import Header from "./Header";
import Footer from "./Footer";
import Breadcrumbs from "../routes/Breadcrumbs";
import { formatIndianCurrency } from "../AmountFormet.js";
import Loader from "../components/Loader.js";

DataTable.use(DT);

function ProjectListTable() {
  const location = useLocation();
  // const location = useLocation();
  // const { projectType } = location.state || {};
  const procesStatus = localStorage.getItem("procesStatus");
  const departmentStatus = localStorage.getItem("departmentstatus");
  const projectType = localStorage.getItem("projectType");
  const paymentStatus = localStorage.getItem("paymentStatus");
  const instutionStatus = localStorage.getItem("instutionstatus");
  const professionStatus = localStorage.getItem("professionstatus");
  //
  const freeid = localStorage.getItem("empname");
  const projectallid = JSON.parse(localStorage.getItem("projectallid"));

  console.log("allcheck123", projectallid);

  setTimeout(() => {
    localStorage.removeItem("projectType");
    localStorage.removeItem("paymentStatus");
    localStorage.removeItem("procesStatus");
    localStorage.removeItem("departmentstatus");
    localStorage.removeItem("instutionstatus");
    localStorage.removeItem("professionstatus");
    localStorage.removeItem("projectallid");
  }, 20000);

  const roleName = localStorage.getItem("medicsroleName");
  console.log("role:", roleName);
  const { type, createdby, count_type, position } = location.state || {};

  const [data, setData] = useState([]);
  // const [startDate, setStartDate] = useState("");
  // const [endDate, setEndDate] = useState("");
  const [filteredData, setFilteredData] = useState([]);

  console.log("allid:", filteredData);
  // const [typeofwork, setTypeOfWork] = useState([]);
  // const [filtertypeofwork, setTypeOfworkFilter] = useState("all");

  const [tempFromDate, setTempFromDate] = useState(null);
  const [tempToDate, setTempToDate] = useState(null);
  const [tempDepartmentsData, setTempDepartmentsData] = useState(null);
  const [tempIntitutesData, setTempIntitutesData] = useState(null);
  const [tempProfessionData, setTempProfessionData] = useState(null);
  const [tempTypeOfWorkData, setTempTypeOfWorkData] = useState(null);
  const [tempProcessStatusData, setTempProcessStatusData] = useState(null);
  const [tempPaymentStatusData, setTempPaymentStatusData] = useState(null);

  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [departmentsData, setDepartmentsData] = useState(
    departmentStatus || null
  );
  const [intitutesData, setIntitutesData] = useState(instutionStatus || null);
  const [professionData, setProfessionData] = useState(
    professionStatus || null
  );
  const [processStatusData, setProcessStatusData] = useState(
    procesStatus || null
  );
  const [typeOfWorkData, setTypeOfWorkData] = useState(projectType || null); // Convert null to empty string
  const [paymentStatusData, setPaymentStatusData] = useState(
    paymentStatus || null
  );
  // console.log('paymentStatusData :',paymentStatusData);
  const [availableOptions, setDepartments] = useState([]);
  const [dropdownItems, setProfessions] = useState([]);
  const [optionsinstitute, setIntitutes] = useState([]);

  // console.log("proect_type:", projectType);
  // console.log("paymentStatus:", paymentStatus);
  // console.log("dropdownItems :", dropdownItems);
  // console.log("availableOptions :", availableOptions);
  // console.log("optionsinstitute :", optionsinstitute);

  const fetchRoles = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/institutions`
      );

      setIntitutes(response.data);
    } catch (err) {
      console.log("Failed to fetch roles.");
    }
  };

  const fetchDepartments = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/departments`
      );
      setDepartments(response.data);
    } catch (err) {
      console.log("Failed to fetch roles.");
    }
  };

  const fetchProfession = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/professions`
      );

      setProfessions(response.data);
    } catch (err) {
      console.log("Failed to fetch roles.");
    }
  };

  useEffect(() => {
    fetchRoles();
    fetchDepartments();
    fetchProfession();
  }, []);

  const fetchData = async () => {
    // console.log("aaa");
    try {
      const response = await axios.get(
        `${API_URL}/api/reports/get-projectList-report`,
        {
          params: {
            id: projectallid ? projectallid.toString() : "",
            start_date: fromDate,
            end_date: toDate,
            department: departmentsData,
            institute: intitutesData,
            profession: professionData,
            type_of_work: typeOfWorkData,
            process_status: processStatusData,
            payment_status: paymentStatusData,
          },
        }
      );

      // console.log("summa:", response);

      // const projectIdsFromStorage = JSON.parse(localStorage.getItem("projectallid")) || [];

      // // Filter only matching project IDs
      // const filteredProjects = response.data.filter(project =>
      //   projectIdsFromStorage.includes(project.id)
      // );
      // console.log("Filtered response:", filteredProjects);

      // console.log("response:", response.data);

      const transformedData = response.data.map((item) => {
        const getNames = (dataArray) => {
          if (!dataArray || !Array.isArray(dataArray)) return "";
          return dataArray.map((obj) => obj.name).join(", ");
        };

        const getStatuses = (dataArray) => {
          if (!dataArray || !Array.isArray(dataArray)) return "";
          return dataArray.map((obj) => obj.status).join(", ");
        };

        const getPayments = (paymentDetails) => {
          if (!paymentDetails || !paymentDetails.payment_data) return [];
          return paymentDetails.payment_data.map((payment) => payment.payment);
        };

        const payments = item.payment_details
          ? getPayments(item.payment_details)
          : [];

        return {
          id: item.id || "-",
          project_id: item.project_id || "-",
          department: item.department.name || "-",
          institution: item.institute.name || "-",
          client: item.client_name || "-",
          profession: item.profession.name || "-",
          title: item.title || "-",
          type_of_work: item.type_of_work || "-",
          process_status: item.process_status || "-",
          process_status_date: item.process_date || "-",
          statistican: getNames(item.statistican_data) || "-",
          statistican_status: getStatuses(item.statistican_data) || "-",
          writer: getNames(item.writer_data) || "-",
          writer_status: getStatuses(item.writer_data) || "-",
          reviewer: getNames(item.reviewer_data) || "-",
          reviewer_status: getStatuses(item.reviewer_data) || "-",
          pub_man: getNames(item.journal_data) || "-",
          pub_man_status: getStatuses(item.journal_data) || "-",
          budget: item.budget || "-",
          payment_status: item.payment_details?.payment_status || "-",
          payment_1: payments[0] || "-",
          payment_2: payments[1] || "-",
          payment_3: payments[2] || "-",
          payment_4: payments[3] || "-",
          discount: item.payment_details?.discounts || "-",
          writer_fee: item.writer_fee || "-",
          journal_fee: item.publication_manager_fee || "-",

          reviewer_feetle: item.reviewer_feetle || "-", // Note: typo in your column definition (feetle vs fee)
          office_expence: item.office_expence || "-",
          income: item.income || "-",
        };
      });

      setData(transformedData);
      // console.log("writerfee:",transformedData);
      setFilteredData(transformedData);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, [
    fromDate,
    toDate,
    departmentsData,
    intitutesData,
    professionData,
    typeOfWorkData,
    processStatusData,
    paymentStatusData,
  ]);

  // useEffect(() => {
  //   const projectType = localStorage.getItem('projectType');

  //   const validTypeOfWorkOptions = ['statistics', 'manuscript', 'thesis', 'others'];
  //   const validPaymentStatusOptions = ['advance_pending', 'partial_payment_pending', 'final_payment_pending', 'completed'];

  //   if (projectType) {
  //     if (validTypeOfWorkOptions.includes(projectType)) {
  //       setTempTypeOfWorkData(projectType);
  //     } else if (validPaymentStatusOptions.includes(projectType)) {
  //       setPaymentStatusData(projectType);
  //     }
  //   }
  // }, [projectType]);

  const handleApplyFilters = () => {
    setFromDate(tempFromDate);
    setToDate(tempToDate);
    setDepartmentsData(tempDepartmentsData);
    setProfessionData(tempProfessionData);
    setIntitutesData(tempIntitutesData);
    setTypeOfWorkData(tempTypeOfWorkData);
    setProcessStatusData(tempProcessStatusData);
    setPaymentStatusData(tempPaymentStatusData);
  };

  // const handleTypeOfWorkChange = (event) => {
  //   setTypeOfworkFilter(event.target.value);
  // };

  const exportToCSV = () => {
    const headers = [
      { label: "Project ID", value: "project_id", render: Capitalize },
      { label: "Department", value: "department", render: Capitalize },
      { label: "Institution", value: "institution", render: Capitalize },
      { label: "Client", value: "client", render: Capitalize },
      { label: "Profession", value: "profession", render: Capitalize },
      { label: "Title", value: "title", render: Capitalize },
      { label: "Type of work", value: "type_of_work", render: Capitalize },
      { label: "Process status", value: "process_status", render: Capitalize },
      {
        label: "Process status date",
        value: "process_status_date",
        render: getDateFormate,
      },
      { label: "Statistician", value: "statistican", render: Capitalize },
      {
        label: "Statistician status",
        value: "statistican_status",
        render: Capitalize,
      },
      { label: "Writer", value: "writer", render: Capitalize },
      { label: "Writer status", value: "writer_status", render: Capitalize },
      { label: "Reviewer", value: "reviewer", render: Capitalize },
      {
        label: "Reviewer Status",
        value: "reviewer_status",
        render: Capitalize,
      },
      { label: "Pub.man", value: "pub_man", render: Capitalize },
      { label: "Pub. man status", value: "pub_man_status", render: Capitalize },
      {
        label: "Budget",
        value: "budget",
        render: (value) => formatIndianCurrency(Number(value) || 0),
      },
      { label: "Payment status", value: "payment_status", render: Capitalize },
      {
        label: "Payment 1",
        value: "payment_1",
        render: (value) => formatIndianCurrency(Number(value) || 0),
      },
      {
        label: "Payment 2",
        value: "payment_2",
        render: (value) => formatIndianCurrency(Number(value) || 0),
      },
      {
        label: "Payment 3",
        value: "payment_3",
        render: (value) => formatIndianCurrency(Number(value) || 0),
      },
      {
        label: "Payment 4",
        value: "payment_4",
        render: (value) => formatIndianCurrency(Number(value) || 0),
      },
      { label: "Discount", value: "discount", render: Capitalize },
      { label: "Writer fee", value: "writer_fee", render: Capitalize },
      { label: "Reviewer fee", value: "reviewer_feetle", render: Capitalize },
      { label: "Office expence", value: "office_expence", render: Capitalize },
      { label: "Income", value: "income", render: Capitalize },
    ];

    const csv = Papa.unparse({
      fields: headers.map((header) => header.label),
      data: filteredData.map((row) =>
        headers.map((header) =>
          header.render ? header.render(row[header.value]) : row[header.value]
        )
      ),
    });

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const formattedStartDate = fromDate
      ? fromDate.replace(/-/g, "")
      : new Date().toISOString().split("T")[0].replace(/-/g, "");
    const formattedEndDate = toDate
      ? toDate.replace(/-/g, "")
      : new Date().toISOString().split("T")[0].replace(/-/g, "");
    const fileName = `entryprocess_${formattedStartDate}_to_${formattedEndDate}.csv`;

    saveAs(blob, fileName);
  };

  const columns = [
    // { title: " ID", data: "id" },

    { title: "Project ID", data: "project_id", render: Capitalize },
    { title: "Department", data: "department", render: Capitalize },
    { title: "Institution", data: "institution", render: Capitalize },
    { title: "Client", data: "client", render: Capitalize },
    { title: "Profession", data: "profession", render: Capitalize },
    { title: "Title", data: "title", render: Capitalize },
    { title: "Type of work", data: "type_of_work", render: Capitalize },
    // { title: "Process status", data: "process_status", render: Capitalize },
    {
      title: "Process Status".toUpperCase(),
      data: null,
      render: (data) => {
        const status = data.process_status?.toLowerCase() || "";
        const classMap = {
          in_progress: "status-in-progress",
          completed: "status-completed",
          not_assigned: "status-not-assigned",
          pending_author: "status-pending-author",
          withdrawal: "status-withdrawn-author",
          client_review: "status-client-review",
        };

        const className = `status-badge ${classMap[status] || ""}`;

        // Utility to convert snake_case or lowercase to Capitalized Words
        const formatStatus = (str) =>
          str.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());

        return `<span class="${className}">${formatStatus(status)}</span>`;
      },
    },
    {
      title: "Process status date",
      data: "process_status_date",
      render: getDateFormate,
    },
    { title: "Statistician", data: "statistican", render: Capitalize },
    {
      title: "Statistician status",
      data: "statistican_status",
      render: Capitalize,
    },
    { title: "Writer", data: "writer", render: Capitalize },
    { title: "Writer status", data: "writer_status", render: Capitalize },
    { title: "Reviewer", data: "reviewer", render: Capitalize },
    { title: "Reviewer Status", data: "reviewer_status", render: Capitalize },
    { title: "Pub.man", data: "pub_man", render: Capitalize },
    { title: "Pub. man status", data: "pub_man_status", render: Capitalize },
    {
      title: "Budget",
      data: "budget",
      render: (value) => formatIndianCurrency(Number(value) || 0),
    },
    { title: "Payment status", data: "payment_status", render: Capitalize },
    {
      title: "Payment 1",
      data: "payment_1",
      render: (value) => formatIndianCurrency(Number(value) || 0),
    },
    {
      title: "Payment 2",
      data: "payment_2",
      render: (value) => formatIndianCurrency(Number(value) || 0),
    },
    {
      title: "Payment 3",
      data: "payment_3",
      render: (value) => formatIndianCurrency(Number(value) || 0),
    },
    {
      title: "Payment 4",
      data: "payment_4",
      render: (value) => formatIndianCurrency(Number(value) || 0),
    },
    { title: "Discount", data: "discount", render: Capitalize },
    {
      title: "Journal fee",
      data: "journal_fee",
      render: (value) => formatIndianCurrency(Number(value) || 0),
    },
    {
      title: "Writer fee",
      data: "writer_fee",
      render: (value) => formatIndianCurrency(Number(value) || 0),
    },
    {
      title: "Reviewer fee",
      data: "reviewer_feetle",
      render: (value) => formatIndianCurrency(Number(value) || 0),
    },
    {
      title: "Office expence",
      data: "office_expence",
      render: (value) => formatIndianCurrency(Number(value) || 0),
    },
    {
      title: "Income",
      data: "income",
      render: (value) => formatIndianCurrency(Number(value) || 0),
    },
  ];

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }
  return (
    <section className="container d-flex flex-column min-vh-100 justify-content-between">
      <div className="row mt-4">
        <div className="col-12">
          <Header />
          <div className="col-12 mt-3 pt-1 wapper w-100 py-5">
            <div className="row mt-3 d-flex w-100">
              <div className="col-12 col-md-9 px-4">
                <p className="heading-entr">Project List</p>
              </div>
              <div className="col-3 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs />
              </div>
            </div>
            {roleName !== "SME" && roleName !== "Publication Manager" && (
              <>
                <div className="row px-5 d-flex justify-content-end">
                  <div className="d-flex justify-content-end">
                    <Tooltip title="Export">
                      <div className="add-icon" onClick={exportToCSV}>
                        <VscGitStashPop className="export-icon" />
                      </div>
                    </Tooltip>
                  </div>
                </div>
                <div className="row p-2">
                  <div className="col-12 d-flex justify-content-left gap-3 flex-wrap">
                    <div className="width-default">
                      <label htmlFor="start-date">Start-Date</label>
                      <input
                        type="date"
                        id="start-date"
                        className="form-control-date ms-3 ms-md-0"
                        value={tempFromDate}
                        onChange={(e) => setTempFromDate(e.target.value)}
                      />
                    </div>

                    <div className="width-default">
                      <label htmlFor="end-date">End-Date</label>
                      <input
                        type="date"
                        id="end-date"
                        className="form-control-date"
                        value={tempToDate}
                        onChange={(e) => setTempToDate(e.target.value)}
                      />
                    </div>

                    <div className="width-default mt-4">
                      <select
                        className="form-select-date"
                        value={tempDepartmentsData}
                        onChange={(e) => setTempDepartmentsData(e.target.value)}
                      >
                        <option value="all">Department</option>
                        {availableOptions.map((work) => (
                          <option key={work.name} value={work.name}>
                            {Capitalize(work.name)}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="width-default mt-4">
                      <select
                        className="form-select-date"
                        value={tempIntitutesData}
                        onChange={(e) => setTempIntitutesData(e.target.value)}
                      >
                        <option value="all">Institution</option>
                        {optionsinstitute.map((work) => (
                          <option key={work.name} value={work.name}>
                            {Capitalize(work.name)}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="width-default mt-4">
                      <select
                        className="form-select-date"
                        value={tempProfessionData}
                        onChange={(e) => setTempProfessionData(e.target.value)}
                      >
                        <option value="all">Profession</option>
                        {dropdownItems.map((work) => (
                          <option key={work.name} value={work.name}>
                            {Capitalize(work.name)}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="width-default mt-4">
                      <select
                        className="form-select-date"
                        value={tempTypeOfWorkData}
                        onChange={(e) => setTempTypeOfWorkData(e.target.value)}
                      >
                        <option value="">Type of work</option>
                        <option value="statistics">Statistics</option>
                        <option value="manuscript">Manuscript</option>
                        <option value="thesis">Thesis</option>
                        {/* /*---<option value="presentation">Presentation</option> */}
                        <option value="others">Others</option>
                      </select>
                    </div>

                    <div className="width-default mt-4">
                      <select
                        className="form-select-date"
                        value={tempProcessStatusData}
                        onChange={(e) =>
                          setTempProcessStatusData(e.target.value)
                        }
                      >
                        <option value="">Process status</option>
                        <option value="not_assigned">Not Assigned</option>
                        <option value="pending_author">Pending - Author</option>
                        <option value="completed">Completed</option>
                        <option value="withdrawal">Withdrawn</option>
                        <option value="in_progress">In Progress</option>
                        <option value="client_review">Client Review</option>
                      </select>
                    </div>

                    <div className="width-default mt-4">
                      <select
                        className="form-select-date"
                        value={tempPaymentStatusData}
                        onChange={(e) =>
                          setTempPaymentStatusData(e.target.value)
                        }
                      >
                        <option value="">Payment Status</option>
                        <option value="advance_pending">Advance Pending</option>
                        <option value="partial_payment_pending">
                          Partial payment pending
                        </option>
                        <option value="final_payment_pending">
                          Final payment pending
                        </option>
                        <option value="completed">Completed</option>
                      </select>
                    </div>

                    <div className="mt-4">
                      <button
                        className="button-primary"
                        onClick={handleApplyFilters}
                      >
                        Filter
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}
            <div className="p-2">
              <DataTable
                // data={filteredData}
                data={[...filteredData].reverse()}
                columns={columns}
                className="display"
                options={{
                  scrollX: true,
                  select: true,
                  pageLength: 20,
                  lengthMenu: [
                    [20, 30, 50],
                    [20, 30, 50],
                  ],
                  order: [],
                  autoWidth: false,
                  fixedColumns: true,
                  scrollCollapse: true,
                  fixedHeader: true,
                  columnDefs: [
                    { width: "100px", targets: 0 }, // First column = 100px
                    { width: "20%", targets: [1, 2] }, // Multiple columns at 20%
                  ],
                }}
              />
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </section>
  );
}

export default ProjectListTable;
