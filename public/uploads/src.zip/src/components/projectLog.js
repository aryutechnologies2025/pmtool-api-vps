import "../assests/css/entryprocess.css";
import { API_URL } from "../config.js";
import { useState, useEffect, useRef } from "react";
import axios from "axios";
import Breadcrumbs from "../routes/Breadcrumbs";
import "react-datepicker/dist/react-datepicker.css";
import Header from "./Header";
import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { Capitalize } from "../campsCase.js";
import Footer from "../components/Footer";
import Loader from "../components/Loader.js";
import Select from "react-select";

DataTable.use(DT);

function ProjectLog() {
  const [filteredData, setFilteredData] = useState([]);
  const [originalData, setOriginalData] = useState([]);
  const [projectOptions, setProjectOptions] = useState([]);
  const [userOptions, setUserOptions] = useState([]);
  const [selectedProject, setSelectedProject] = useState("all");
  const [selectedUser, setSelectedUser] = useState("all");
  const [loading, setLoading] = useState(true);
  const [tableKey, setTableKey] = useState(0);

  const fetchData = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `${API_URL}/api/entry_process/projectLog`
      );

      const formattedData = response.data.log.map((item) => {
        return {
          project_id: item.entry_process?.project_id || "N/A",
          employee_name: item.user_data?.employee_name || "N/A",
          role: item.status_type || "Reviewer",
          status: item.status || "N/A",
          created_date: item.created_date || "N/A",
        };
      });
      
      setOriginalData(formattedData);
      setFilteredData(formattedData);
      
      // Create unique project IDs for filter dropdown
      const uniqueProjectIds = [...new Set(formattedData.map(item => item.project_id))];
      const projectFilterOptions = uniqueProjectIds.map(projectId => ({
        value: projectId,
        label: Capitalize(projectId)
      }));
      setProjectOptions(projectFilterOptions);
      
      // Create unique user names for filter dropdown
      const uniqueUserNames = [...new Set(formattedData.map(item => item.employee_name))];
      const userFilterOptions = uniqueUserNames.map(userName => ({
        value: userName,
        label: Capitalize(userName)
      }));
      setUserOptions(userFilterOptions);
      
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFilterClick = () => {
    let resultData = [...originalData];
    
    // Apply project filter
    if (selectedProject !== "all") {
      resultData = resultData.filter(
        (item) => item.project_id === selectedProject
      );
    }
    
    // Apply user filter
    if (selectedUser !== "all") {
      resultData = resultData.filter(
        (item) => item.employee_name === selectedUser
      );
    }
    
    // Sort in descending order by created_date
    const sortedData = resultData.sort((a, b) => {
      const dateA = new Date(a.created_date);
      const dateB = new Date(b.created_date);
      return dateB - dateA; // Descending order
    });
    
    setFilteredData(sortedData);
    // Force table re-render
    setTableKey(prev => prev + 1);
  };

  const handleClearClick = () => {
    setSelectedProject("all");
    setSelectedUser("all");
    setFilteredData(originalData);
    setTableKey(prev => prev + 1);
  };

  const handleProjectChange = (selectedOption) => {
    setSelectedProject(selectedOption ? selectedOption.value : "all");
  };

  const handleUserChange = (selectedOption) => {
    setSelectedUser(selectedOption ? selectedOption.value : "all");
  };

  // DataTable configuration
  const columns = [
    {
      title: "PROJECT ID",
      data: "project_id",
      render: (data, type, row) => Capitalize(row.project_id || "")
    },
    {
      title: "ASSIGN USER",
      data: "employee_name",
      render: (data, type, row) => Capitalize(row.employee_name || "")
    },
    {
      title: "ROLE",
      data: "role",
      render: (data, type, row) => Capitalize(row.role || "")
    },
    {
      title: "STATUS",
      data: "status",
      render: (data, type, row) => Capitalize(row.status || "")
    },
    {
      title: "CREATED DATE",
      data: "created_date",
      render: (data, type, row) => (row.created_date || "")
    }
  ];

  const projectFilterOptions = [
    { value: "all", label: "All Projects" },
    ...projectOptions
  ];

  const userFilterOptions = [
    { value: "all", label: "All Users" },
    ...userOptions
  ];

  if (loading) {
    return <Loader />;
  }

  return (
    <section className="container d-flex flex-column justify-content-between min-vh-100">
      <div className="row mt-4">
        <div className="col-12">
          <div className="col-12">
            <Header />
          </div>

          <div className="col-12 mt-3 pt-1 wapper w-100 py-5">
            <div className="row mt-3 d-flex w-100">
              <div className="col-12 col-md-6 px-4">
                <p className="heading-entr">Logs</p>
              </div>
              <div className="col-6 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs />
              </div>
            </div>

            <div className="row p-2">
              <div className="col-12 d-flex flex-wrap justify-content-between gap-3">
                <div className="d-flex flex-wrap justify-content-left gap-3">
                  {/* Project Filter */}
                  <div className="mt-4 width-default-dropdown">
                    <Select
                      options={projectFilterOptions}
                      value={projectFilterOptions.find(
                        (option) => option.value === selectedProject
                      )}
                      onChange={handleProjectChange}
                      isSearchable={true}
                      placeholder="Select Project ID"
                      isClearable={true}
                    />
                  </div>
                  
                  {/* User Filter */}
                  <div className="mt-4 width-default-dropdown">
                    <Select
                      options={userFilterOptions}
                      value={userFilterOptions.find(
                        (option) => option.value === selectedUser
                      )}
                      onChange={handleUserChange}
                      isSearchable={true}
                      placeholder="Select User"
                      isClearable={true}
                    />
                  </div>
                  
                  <div className="mt-4">
                    <button
                      className="button-primary"
                      onClick={handleFilterClick}
                    >
                      Filter
                    </button>
                  </div>

                  <div className="mt-4">
                    <button
                      className="button-primary-all"
                      onClick={handleClearClick}
                    >
                      Clear All
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-2">
              {filteredData.length > 0 ? (
                <DataTable
                  key={tableKey}
                  id="example"
                  data={filteredData}
                  columns={columns}
                  className="display"
                  options={{
                    responsive: true,
                    scrollX: true,
                    select: true,
                    pageLength: 10,
                    lengthMenu: [
                      [10, 20, 30, 50],
                      [10, 20, 30, 50]
                    ],
                    order: [[3, "desc"]],
                    language: {
                      emptyTable: "No data available in table"
                    }
                  }}
                />
              ) : (
                <div className="alert alert-info text-center">
                  No data found
                  {(selectedProject !== "all" || selectedUser !== "all") && 
                    ` for ${selectedProject !== "all" ? `Project ID: ${selectedProject}` : ""}
                     ${selectedProject !== "all" && selectedUser !== "all" ? " and " : ""}
                     ${selectedUser !== "all" ? `User: ${selectedUser}` : ""}`
                  }
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </section>
  );
}

export default ProjectLog;