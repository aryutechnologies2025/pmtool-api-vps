import React, { useState, useEffect, useCallback, useMemo } from "react";
import DataTable from "datatables.net-react";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import axios from "axios";
import Swal from "sweetalert2";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import { useParams } from "react-router-dom";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import { getDateFormate } from "../dateFormate.js";

function Rejection_form() {
  const { id } = useParams();
  
  // States
  const [allid, setId] = useState(null);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [projectid, setProjectid] = useState(null);
  
  // Initialize form with memoized default date
  const getTodayDate = useCallback(() => {
    const today = new Date();
    return today.toISOString().split('T')[0]; // More efficient date formatting
  }, []);

  const [formData, setFormData] = useState({
    journalName: "",
    articleId: "",
    rejectedDate: getTodayDate(),
    comments: "",
  });

  // Get user details once
  const [createdby, setCreatedby] = useState(null);
  useEffect(() => {
    const storedDetails = localStorage.getItem("medicsuser");
    if (storedDetails) {
      try {
        const parsedDetails = JSON.parse(storedDetails);
        setCreatedby(parsedDetails?.id || null);
      } catch (error) {
        console.error("Error parsing user details:", error);
      }
    }
  }, []);

  // Memoized data fetching functions
  const fetchProjectData = useCallback(async (id) => {
    try {
      const response = await axios.get(`${API_URL}/api/author/author-view/${id}`);
      return response.data.author;
    } catch (error) {
      console.error("Error fetching project data:", error);
      throw error;
    }
  }, []);

  const fetchRejectionData = useCallback(async (projectId) => {
    try {
      const response = await axios.get(`${API_URL}/api/author/rejected-list`, {
        params: { project_id: projectId },
      });
      return response.data?.[0] || {};
    } catch (error) {
      console.error("Error fetching rejection data:", error);
      return {}; // Return empty object instead of throwing
    }
  }, []);

  const fetchRejectionList = useCallback(async (projectId) => {
    try {
      const response = await axios.get(`${API_URL}/api/author/rejected-list`, {
        params: { project_id: projectId },
      });
      return response.data || [];
    } catch (error) {
      console.error("Error fetching rejection list:", error);
      return [];
    }
  }, []);

  // Main data fetching with error handling
  const fetchAllData = useCallback(async (id) => {
    if (!id) return;
    
    setLoading(true);
    try {
      // Fetch in parallel for better performance
      const projectData = await fetchProjectData(id);
      const projectId = projectData.journal_data?.[0]?.project_id;
      
      // Fetch rejection data and list in parallel
      const [rejectionData, rejectionList] = await Promise.allSettled([
        fetchRejectionData(projectId),
        fetchRejectionList(projectId)
      ]);

      // Update states
      setId(projectData.id);
      setProjectid(projectId);
      setData(rejectionList.value || []);

      // Update form data
      setFormData({
        journalName: CapitalizeCaseU(projectData.journal_data?.[0]?.assign_user || ""),
        articleId: projectData.submission?.[0]?.article_id || "",
        rejectedDate: rejectionData.value?.date_of_rejected || getTodayDate(),
        comments: rejectionData.value?.comments || "",
      });

    } catch (error) {
      console.error("Error in fetchAllData:", error);
      Swal.fire({
        icon: "error",
        title: "Data Load Failed",
        text: "There was an error loading the form data.",
        timer: 3000,
      });
    } finally {
      setLoading(false);
    }
  }, [fetchProjectData, fetchRejectionData, fetchRejectionList, getTodayDate]);

  // Initial load
  useEffect(() => {
    if (id) {
      fetchAllData(id);
    }
  }, [id, fetchAllData]);

  // Handle form changes
  const handleChange = useCallback((e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  }, []);

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!allid || !createdby) {
      Swal.fire({
        icon: "warning",
        title: "Missing Information",
        text: "Project or user information is missing.",
      });
      return;
    }

    // Show loading
    const loader = document.getElementById("global-loader");
    if (loader) loader.style.display = "flex";

    try {
      const response = await axios.post(`${API_URL}/api/author/rejected-form`, {
        project_id: allid,
        journal_name: formData.journalName,
        article_id: formData.articleId,
        date_of_rejected: formData.rejectedDate,
        comments: formData.comments,
        created_by: createdby,
      });
      console.log("Submission response:", response.data);
      if (response.data) {
        Swal.fire({
          icon: "success",
          title: "Rejection Added!",
          text: "The rejection has been successfully saved.",
          confirmButtonText: "OK",
          timer: 2000,
        });

        // Refresh data after submission
        await fetchAllData(id);
        fetchRejectionData();
        // Clear form comments for new entry
        setFormData(prev => ({
          ...prev,
          comments: ""
        }));
      }
    } catch (error) {
      console.error("Submission error:", error);
      Swal.fire({
        icon: "error",
        title: "Submission Failed",
        text: error.response?.data?.message || "There was an error submitting the rejection.",
        confirmButtonText: "Retry",
      });
    } finally {
      if (loader) loader.style.display = "none";
    }
  };

  // Table columns configuration
  const columns = useMemo(() => [
    {
      title: "Journal Name",
      data: "journal_name",
      render: (data) => data?.trim() ? Capitalize(data) : "-",
    },
    {
      title: "Article ID",
      data: "article_id",
      render: (data) => data?.trim() ? Capitalize(data) : "-",
    },
    {
      title: "Date of Rejected",
      data: "date_of_rejected",
      render: (data) => data?.trim() ? getDateFormate(data) : "-",
    },
    {
      title: "Comments",
      data: "comments",
      render: (data) => data?.trim() ? Capitalize(data) : "-",
    },
  ], []);

  // Table options
  const tableOptions = useMemo(() => ({
    scrollX: true,
    select: true,
    pageLength: 20,
    lengthMenu: [[20, 30, 50], [20, 30, 50]],
    search: {
      return: true,
    },
    responsive: true,
    processing: true,
    serverSide: false,
    ordering: true,
    order: [[2, 'desc']], // Sort by rejected date descending
  }), []);

  if (loading) {
    return (
      <div className="container text-center py-5">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="form-all-form">Rejected Form</div>

      <form onSubmit={handleSubmit}>
        <div className="row justify-content-around">
          <div className="col-md-5 mb-3">
            <label className="label-public-name">Journal Name</label>
            <input
              type="text"
              className="form-control1"
              name="journalName"
              value={formData.journalName}
              readOnly
              disabled={loading}
            />
          </div>
          <div className="col-md-5 mb-3">
            <label className="label-public-name">Article Id</label>
            <input
              type="text"
              className="form-control1"
              name="articleId"
              value={formData.articleId}
              readOnly
              disabled={loading}
            />
          </div>
        </div>
        
        <div className="row justify-content-around mt-2">
          <div className="col-md-5 mb-3">
            <label className="label-public-name">Date Of Rejected</label>
            <input
              type="date"
              className="form-control1"
              name="rejectedDate"
              value={formData.rejectedDate}
              onChange={handleChange}
              autoComplete="off"
              disabled={loading}
              required
            />
          </div>
          <div className="col-md-5 mb-3">
            <label className="label-public-name">Comments</label>
            <textarea
              className="form-control1"
              name="comments"
              value={formData.comments}
              onChange={handleChange}
              autoComplete="off"
              rows="3"
              disabled={loading}
              required
            />
          </div>
        </div>
        
        <div className="row justify-content-end px-5 pt-2">
          <div className="col-auto">
            <button 
              type="submit" 
              className="save-form-task mb-2 pt-1"
              disabled={loading || !formData.comments.trim()}
            >
              {loading ? "Submitting..." : "Submit"}
            </button>
          </div>
        </div>
      </form>

      <section className="pb-2">
        <div className="mt-4">
          {data.length === 0 ? (
            <div className="text-center py-4">
              <p>No rejection records found.</p>
            </div>
          ) : (
            <DataTable
              id="rejection-table"
              data={data}
              columns={columns}
              className="display"
              options={tableOptions}
            />
          )}
        </div>
      </section>
    </div>
  );
}

export default React.memo(Rejection_form);