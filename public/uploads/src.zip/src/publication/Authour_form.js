import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import { API_URL } from "../config.js";
import Swal from "sweetalert2";
import "sweetalert2/dist/sweetalert2.min.css";
import { Capitalize } from "../campsCase.js";
import { useParams } from "react-router-dom";
import { jsPDF } from "jspdf";
import { saveAs } from "file-saver";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import { TfiPencilAlt } from "react-icons/tfi";
import { RiDeleteBin6Line } from "react-icons/ri";

function AuthorForm({ project_id }) {

  // console.log("author id",project_id)
  const { id } = useParams();
  // console.log("paramid:", id);
  const [allid, setId] = useState([]);
  // console.log("allid",allid)
  const [loading, setLoading] = useState(true);
  //  console.log("useid:",id)
  const [showModal, setShowModal] = useState(false);
  const [showModaledit, setShowModaledit] = useState(false);
  const [authors, setAuthors] = useState([]);
  const [formData, setFormData] = useState({
    sequence: "",
    initial: "",
    firstName: "",
    lastName: "",
    designation: "",
    department: "",
    institution: "",
    state: "",
    country: "",
    email: "",
    phone: "",
    corresponding: false,
  });
  // console.log("submit data:", formData);

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    const newValue = type === "checkbox" ? checked : value;

    console.log(`Field: ${name}, Value: ${newValue}`); // Log the field name and value

    setFormData({
      ...formData,
      [name]: newValue,
    });
  };

  useEffect(() => {

  if (project_id) {
    fetchProjectManagerData();
  }
}, [project_id]);

  useEffect(() => {
    if (project_id) {
      fetchData(project_id);
    }
  }, [project_id]);

  const fetchProjectManagerData = async (project_id) => {

   console.log("fetching data for project_id:", project_id);
      try {
        setLoading(true);
        const responseShow = await axios.get(
          `${API_URL}/api/author/author-view/${project_id}`
        );

        console.log("responseShow:", responseShow);
  
        if (responseShow.data?.author) {
          setProgess(responseShow.data?.author || {});
          setJounaldata(responseShow.data?.author?.journal_data?.[0] || {});
          setId(responseShow.data?.author.id);
          // console.log("Set allid to:", responseShow.data.author.id);
        }
      } catch (error) {
        console.error("Error fetching project data", error);
        // Swal.fire({
        //   icon: "error",
        //   title: "Failed to load project data",
        //   text: "Please refresh the page",
        // });
      } finally {
        setLoading(false);
      }
    };


   const fetchData = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/author/author-list`, {
        params: {
          project_id: project_id,
          // project_id: id,
        },
      });

      setData(response.data || []);
      // setTabid(response.data.map((author) => author.id));
      setTablename(response.data || []);

      // console.log("Filtered Data:", response.data);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  // addd
  const handleAddAuthor = async () => {
    document.getElementById("global-loader").style.display = "flex";

    setTimeout(async () => {
      try {
        let response = await axios.post(`${API_URL}/api/author/add-author`, {
          project_id: project_id,
          initial: formData.initial,
          first_name: formData.firstName,
          last_name: formData.lastName,
          profession_id: formData.designation,
          department_id: formData.department,
          institute_id: formData.institution,
          state: formData.state,
          country: formData.country,
          email: formData.email,
          phone: formData.phone,
          created_by: createdby,
        });

        console.log("author form:", response);

        Swal.fire({
          icon: "success",
          title: "Author Added!",
          text: "The author details have been successfully saved.",
          confirmButtonText: "OK",
        });
        setFormData({
          sequence: "",
          initial: "",
          firstName: "",
          lastName: "",
          designation: "",
          department: "",
          institution: "",
          state: "",
          country: "",
          email: "",
          phone: "",
          corresponding: false,
        });
        setShowModal(false);
        fetchData();
      
      } catch (error) {
        console.error(error);

        Swal.fire({
          icon: "error",
          title: "Submission Failed",
          text: "There was an error submitting the author details. Please try again.",
          confirmButtonText: "Retry",
        });
      } finally {
        document.getElementById("global-loader").style.display = "none";
      }
    }, 500);
  };

  // edit

  const handleEditSumbit = async () => {
    document.getElementById("global-loader").style.display = "flex";
    setTimeout(async () => {
      try {
        let response = await axios.post(`${API_URL}/api/author/edit-author`, {
          id: formData.id,
          project_id: project_id,
          initial: formData.initial,
          first_name: formData.firstName,
          last_name: formData.lastName,
          profession_id: formData.designation,
          department_id: formData.department,
          institute_id: formData.institution,
          state: formData.state,
          country: formData.country,
          email: formData.email,
          phone: formData.phone,
          created_by: createdby,
        });
        console.log("author form:", response);
        Swal.fire({
          icon: "success",
          title: "Author Updated!",
          text: "The author details have been successfully Updated.",
          confirmButtonText: "OK",
        });
        setFormData({
          id: "",
          sequence: "",
          initial: "",
          firstName: "",
          lastName: "",
          designation: "",
          department: "",
          institution: "",
          state: "",
          country: "",
          email: "",
          phone: "",
          corresponding: false,
        });
        setShowModaledit(false);
        fetchData();
      } catch (error) {
        console.error(error);
        Swal.fire({
          icon: "error",
          title: "Submission Failed",
          text: "There was an error submitting the author details. Please try again.",
          confirmButtonText: "Retry",
        });
      } finally {
        document.getElementById("global-loader").style.display = "none";
      }
    }, 500);
  };

  const [data, setData] = useState([]);
  const [tabid, setTabid] = useState([]);
  const [tablename, setTablename] = useState([]);
  // console.log("tablename:", tablename);

  // console.log("tabledatais:", tabid);
  // console.log("tabledetails:", data);

  // const [tabelall,setTableall]=useState=([]);
  //  const fetchProjectManagerData = async () => {
  //   try {
  //     setLoading(true);
  //     const responseShow = await axios.get(
  //       `${API_URL}/api/author/author-view/${id}`
  //     );

  //     setProgess(responseShow.data.author);
  //     setJounaldata(responseShow.data.author.journal_data[0]);

  //     setId(responseShow.data.author.id);

  //     // console.log("journalname:",responseShow.data.journal_data[0].assign_user);
  //   } catch (error) {
  //     console.error("error fetching data", error);
  //   }finally {
  //     setLoading(false);
  //   }
  // };


 

  
  const [availableOptions, setDepartments] = useState([]);

  const [dropdownItems, setProfessions] = useState([]);

  const [optionsinstitute, setIntitutes] = useState([]);

  //Institiue list

  const fetchRoles = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/institutions`
      );

      setIntitutes(response.data);
      // console.log("instution:", response.data);
    } catch (err) {
      console.log("Failed to fetch roles.");
    }
  };

  const fetchDepartments = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/departments`
      );
      setDepartments(response.data);
    } catch (err) {
      console.log("Failed to fetch roles.");
    }
  };

  const fetchProfession = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/professions`
      );

      setProfessions(response.data);
    } catch (err) {
      console.log("Failed to fetch roles.");
    }
  };

   
    useEffect(() => {
    fetchRoles();
    fetchDepartments();
    fetchProfession();
    fetchData();
  }, []);
 





  const [progess, setProgess] = useState([]);
  const [journaldata, setJounaldata] = useState([]);

  // console.log("allid:", allid);

  // console.log("progresscount:", progess);
  // console.log("journal:", journaldata);



  // const [selectedAuthor, setSelectedAuthor] = useState(null);

  const [selectedAuthorId, setSelectedAuthorId] = useState(null);
  // console.log("select:", selectedAuthorId);

  const handleCheckboxChange = (e, authorId) => {
    if (e.target.checked) {
      setSelectedAuthorId(authorId);
      console.log("Selected Author ID:", authorId);
    } else {
      setSelectedAuthorId(null);
    }
  };

  const generateCoverLetter = () => {
    const formattedDate = new Date().toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });

    if (!selectedAuthorId) return "No corresponding author selected.";

    const tablename = data.find((author) => author.id === selectedAuthorId);
    if (!tablename) return "No corresponding author selected.";

    // Two-column formatting logic
    const columnWidth = 45; // increased width for more buffer space

    const leftColumn = [
      `Initial        : ${CapitalizeCaseU(tablename.initial || "-")}`,
      `First Name     : ${CapitalizeCaseU(tablename.first_name || "-")}`,
      `Last Name      : ${CapitalizeCaseU(tablename.last_name || "-")}`,
      `Phone          : ${CapitalizeCaseU(tablename.phone || "-")}`,
      `Profession     : ${CapitalizeCaseU(tablename.profession?.name || "-")}`,
      `Department     : ${CapitalizeCaseU(tablename.department?.name || "-")}`,
      `Institution    : ${CapitalizeCaseU(tablename.institute?.name || "-")}`,
      `Email          : ${CapitalizeCaseU(tablename.email || "-")}`,
      `State          : ${CapitalizeCaseU(tablename.state || "-")}`,
      `Country        : ${CapitalizeCaseU(tablename.country || "-")}`,
    ];

    // const rightColumn = [
    //   `Profession:     ${CapitalizeCaseU(tablename.profession?.name || "-")}`,
    //   `Department:     ${CapitalizeCaseU(tablename.department?.name || "-")}`,
    //   `Institution:    ${CapitalizeCaseU(tablename.institute?.name || "-")}`,
    //   `Email:          ${CapitalizeCaseU(tablename.email || "-")}`,
    //   `State:          ${CapitalizeCaseU(tablename.state || "-")}`,
    //   `Country:        ${CapitalizeCaseU(tablename.country || "-")}`,
    // ];

    const rows = [];
    const maxRows = Math.max(leftColumn.length);
    for (let i = 0; i < maxRows; i++) {
      const left = leftColumn[i] || "";
      // const right = rightColumn[i] || "";
      rows.push(`${left.padEnd(columnWidth, " ")}`);
    }

    const authorDetails = rows.join("\n");

    const leftColumn1 = [
      `Project ID           : ${CapitalizeCaseU(progess.project_id || "-")}`,
      `Date                    : ${CapitalizeCaseU(progess.entry_date || "-")}`,
      `Department        : ${CapitalizeCaseU(progess.department?.name || "-")}`,
      `Institution           : ${CapitalizeCaseU(
        progess.institute?.name || "-"
      )}`,
      `Client Name       : ${CapitalizeCaseU(progess.client_name || "-")}`,
      `Profession          : ${CapitalizeCaseU(
        progess.profession?.name || "-"
      )}`,
      `Title                   : ${CapitalizeCaseU(progess.title || "-")}`,
      `Process Status    : ${CapitalizeCaseU(progess.process_status || "-")}`,
      `Duration             : ${CapitalizeCaseU(
        progess.projectduration || "-"
      )}`,
    ];

    const formattedProjectDetails = leftColumn1
      .map((line) => {
        const colonIndex = line.indexOf(":");
        const label = line.slice(0, colonIndex).trim();
        const value = line.slice(colonIndex + 1).trim();
        return `${label.padEnd(15, " ")} : ${value}`; // 15 = length of "Process Status"
      })
      .join("\n");
    return `
From:\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t Date: ${formattedDate}
 Dr.${CapitalizeCaseU(tablename.initial)} ${CapitalizeCaseU(
      tablename.first_name
    )}${tablename.last_name}
 ${CapitalizeCaseU(progess.institute?.name || "-")}   

To,
  The Editor,
  ${CapitalizeCaseU(journaldata.assign_user)}

Sub: Submission of manuscript for publication as a research article.

Dear Editor,
    I ${CapitalizeCaseU(tablename.initial)} ${CapitalizeCaseU(
      tablename.first_name
    )}${
      tablename.last_name
    } on behalf of my co-authors submit the following manuscript for publication consideration. I understand the objectives of the journal and have formatted the manuscript to fit the style and needs of the journal. I confirm that the manuscript has been prepared for and sent only to ${CapitalizeCaseU(
      journaldata.assign_user
    )} for publication consideration and not submitted to any other journal or any other type of publication either by me or any of my co-authors.

Title of the Article: ${CapitalizeCaseU(progess.title)}

Type of Article: ${CapitalizeCaseU(journaldata.type_of_article)}

Conflict of Interest: Nil

Source of Funding: Nil


Author Name and Affiliation (In sequence):

${formattedProjectDetails}

Corresponding Author:

${authorDetails}


Yours’ sincerely,
${CapitalizeCaseU(tablename.initial)} ${CapitalizeCaseU(tablename.first_name)}${
      tablename.last_name
    } 

  `;
  };

  const downloadPDF = () => {
    const doc = new jsPDF();
    doc.setFont("times", "normal");
    doc.setFontSize(12);

    const coverLetterText = generateCoverLetter(
      selectedAuthorId,
      "Journal Name",
      "Article Title",
      "Research Article",
      data
    );

    const splitText = doc.splitTextToSize(coverLetterText, 180); // Ensure text fits within margins
    doc.text(splitText, 10, 10);

    doc.save("Orginal cover letter for cross check.pdf");
  };

  const downloadWord = () => {
    const coverLetterText = generateCoverLetter(
      selectedAuthorId,
      "Journal Name",
      "Article Title",
      "Research Article",
      data
    );

    const blob = new Blob([coverLetterText], { type: "application/msword" });
    saveAs(blob, "Orginal cover letter for cross check");
  };
  const handleCloseModal = () => {
    setShowModaledit(false);
    setFormData({
      sequence: "",
      initial: "",
      firstName: "",
      lastName: "",
      designation: "",
      department: "",
      institution: "",
      state: "",
      country: "",
      email: "",
      phone: "",
      corresponding: false,
    });
  };

  const handleEditAuthor = (author) => {
    setFormData({
      id: author.id,
      sequence: author.sequence || "",
      initial: author.initial || "",
      firstName: author.first_name || "",
      lastName: author.last_name || "",
      designation: author.profession?.id || "",
      department: author.department?.id || "",
      institution: author.institute?.id || "",
      state: author.state || "",
      country: author.country || "",
      email: author.email || "",
      phone: author.phone || "",
      corresponding: author.corresponding || false,
    });

    setShowModaledit(true);
  };

  const handleDeleteClick = async (id) => {
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to delete this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "No, keep it",
    });

    if (result.isConfirmed) {
      console.log("authorid", id);
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/author/delete-author`,{
              id:id,
              project_id: allid,
            }
          );
          console.log(response);

          Swal.fire({
            title: "Deleted!",
            text: "Your document has been deleted.",
            icon: "success",
            confirmButtonText: "Okay",
          }).then(() => {
          // Reload the page after user clicks OK
          window.location.reload();
        });

          fetchData();
        } catch (error) {
          console.log(error);
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

   if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{height: "400px"}}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <section>
      <div className="row mt-1 px-3">
        <div className="col-12">
          <div className="d-flex justify-content-end">
            <button
              className="save-form-task mb-2 pt-1"
              onClick={downloadPDF}
              // onClick={() => setShowModal(true)}
            >
              Download PDF
            </button>
            <button
              className="save-form-task mb-2 pt-1"
              onClick={downloadWord}
              // onClick={() => setShowModal(true)}
            >
              Download WORD
            </button>
            <button
              className="save-form-task mb-2 pt-1"
              onClick={() => setShowModal(true)}
            >
              Add Author
            </button>
          </div>

          {/* Modal */}
          <div
            className={`modal fade ${showModal ? "show d-block" : ""}`}
            tabIndex="-1"
            role="dialog"
          >
            <div className="modal-container-view" role="document">
              <div className="modal-box-public">
                <div className="modal-header">
                  <h5 className="modal-title">Add Author</h5>
                  <button
                    type="button"
                    className="btn-close"
                    onClick={() => setShowModal(false)}
                  ></button>
                </div>

                <div className="modal-body">
                  <div className="row">
                    {/* Hidden Fields for Autocomplete Fix */}
                    <input
                      type="text"
                      name="fakeusernameremembered"
                      style={{ display: "none" }}
                      autoComplete="username"
                    />
                    <input
                      type="password"
                      name="fakepasswordremembered"
                      style={{ display: "none" }}
                      autoComplete="new-password"
                    />

                    {/* Individual Text Fields */}
                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Initial</label>
                      <input
                        type="text"
                        className="form-control1"
                        name="initial"
                        value={formData.initial}
                        onChange={handleInputChange}
                        autoComplete="off"
                      />
                    </div>

                    <div className="col-md-6 mb-2">
                      <label className="statis-name">First Name</label>
                      <input
                        type="text"
                        className="form-control1"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        autoComplete="off"
                      />
                    </div>
                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Last Name</label>
                      <input
                        type="text"
                        className="form-control1"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        autoComplete="off"
                      />
                    </div>

                    {/* Dropdown Fields */}
                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Profession</label>
                      <select
                        className="form-select1 "
                        name="designation"
                        value={formData.designation}
                        onChange={handleInputChange}
                      >
                        <option value="">Select Profession</option>
                        {dropdownItems.map((profession, index) => (
                          <option key={index} value={profession.id}>
                            {profession.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Department</label>
                      <select
                        className="form-select1"
                        name="department"
                        value={formData.department}
                        onChange={handleInputChange}
                      >
                        <option value="">Select Department</option>
                        {availableOptions.map((department, index) => (
                          <option key={index} value={department.id}>
                            {department.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Institution</label>
                      <select
                        className="form-select1"
                        name="institution"
                        value={formData.institution}
                        onChange={handleInputChange}
                      >
                        <option value="">Select Institution</option>
                        {optionsinstitute.map((institute, index) => (
                          <option key={index} value={institute.id}>
                            {institute.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="col-md-6 mb-2">
                      <label className="statis-name">State</label>
                      <input
                        type="text"
                        className="form-control1"
                        name="state"
                        value={formData.state}
                        onChange={handleInputChange}
                        autoComplete="off"
                      />
                    </div>

                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Country</label>
                      <input
                        type="text"
                        className="form-control1"
                        name="country"
                        value={formData.country}
                        onChange={handleInputChange}
                        autoComplete="off"
                      />
                    </div>
                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Email</label>
                      <input
                        type="email"
                        className="form-control1"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        autoComplete="off"
                      />
                    </div>

                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Phone</label>
                      <input
                        type="number"
                        className="form-control1"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        autoComplete="off"
                      />
                    </div>
                  </div>
                </div>

                <div className="modal-footer">
                  <button
                    className="view-rej"
                    onClick={() => setShowModal(false)}
                  >
                    Close
                  </button>
                  <button className="view-accept" onClick={handleAddAuthor}>
                    Submit
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* edit */}

          <div
            className={`modal fade ${showModaledit ? "show d-block" : ""}`}
            tabIndex="-1"
            role="dialog"
          >
            <div className="modal-container-view" role="document">
              <div className="modal-box-public">
                <div className="modal-header">
                  <h5 className="modal-title">Edit Author</h5>
                  <button
                    type="button"
                    className="btn-close"
                    onClick={handleCloseModal}
                  ></button>
                </div>

                <div className="modal-body">
                  <div className="row">
                    {/* Hidden Fields for Autocomplete Fix */}
                    <input
                      type="text"
                      name="fakeusernameremembered"
                      style={{ display: "none" }}
                      autoComplete="username"
                    />
                    <input
                      type="password"
                      name="fakepasswordremembered"
                      style={{ display: "none" }}
                      autoComplete="new-password"
                    />

                    {/* Individual Text Fields */}
                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Initial</label>
                      <input
                        type="text"
                        className="form-control1"
                        name="initial"
                        value={formData.initial}
                        onChange={handleInputChange}
                        autoComplete="off"
                      />
                    </div>

                    <div className="col-md-6 mb-2">
                      <label className="statis-name">First Name</label>
                      <input
                        type="text"
                        className="form-control1"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        autoComplete="off"
                      />
                    </div>
                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Last Name</label>
                      <input
                        type="text"
                        className="form-control1"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        autoComplete="off"
                      />
                    </div>

                    {/* Dropdown Fields */}
                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Profession</label>
                      <select
                        className="form-select1 "
                        name="designation"
                        value={formData.designation}
                        onChange={handleInputChange}
                      >
                        <option value="">Select Profession</option>
                        {dropdownItems.map((profession, index) => (
                          <option key={index} value={profession.id}>
                            {profession.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Department</label>
                      <select
                        className="form-select1"
                        name="department"
                        value={formData.department}
                        onChange={handleInputChange}
                      >
                        <option value="">Select Department</option>
                        {availableOptions.map((department, index) => (
                          <option key={index} value={department.id}>
                            {department.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Institutionfdfd</label>
                      <select
                        className="form-select1"
                        name="institution"
                        value={formData.institution}
                        onChange={handleInputChange}
                      >
                        <option value="">Select Institution</option>
                        {optionsinstitute.map((institute, index) => (
                          <option key={index} value={institute.id}>
                            {institute.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="col-md-6 mb-2">
                      <label className="statis-name">State</label>
                      <input
                        type="text"
                        className="form-control1"
                        name="state"
                        value={formData.state}
                        onChange={handleInputChange}
                        autoComplete="off"
                      />
                    </div>

                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Country</label>
                      <input
                        type="text"
                        className="form-control1"
                        name="country"
                        value={formData.country}
                        onChange={handleInputChange}
                        autoComplete="off"
                      />
                    </div>
                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Email</label>
                      <input
                        type="email"
                        className="form-control1"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        autoComplete="off"
                      />
                    </div>

                    <div className="col-md-6 mb-2">
                      <label className="statis-name">Phone</label>
                      <input
                        type="number"
                        className="form-control1"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        autoComplete="off"
                      />
                    </div>
                  </div>
                </div>

                <div className="modal-footer">
                  <button className="view-rej" onClick={handleCloseModal}>
                    Close
                  </button>
                  <button className="view-accept" onClick={handleEditSumbit}>
                    Submit
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="col-12 scrollable-container">
            <div className="scrollable-content">
              <table className="author-details-table table-bordered">
                <thead>
                  <tr>
                    <th>Author Sequence</th>
                    <th>Initial</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Profession</th>
                    <th>Department</th>
                    <th>Institution</th>
                    <th>State</th>
                    <th>Country</th>
                    <th>Email ID</th>
                    <th>Phone Number</th>
                    <th>Corresponding Author</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {data.length > 0 ? (
                    data.map((author, index) => (
                      <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{author.initial || "-"}</td>
                        <td>{author.first_name || "-"}</td>
                        <td>{author.last_name || "-"}</td>
                        <td>{author.profession?.name || "-"}</td>
                        <td>{author.department?.name || "-"}</td>
                        <td>{author.institute?.name || "-"}</td>
                        <td>{author.state || "-"}</td>
                        <td>{author.country || "-"}</td>
                        <td>{author.email || "-"}</td>
                        <td>{author.phone || "-"}</td>
                        <td>
                          <input
                            type="radio"
                            checked={selectedAuthorId === author.id}
                            onChange={(e) =>
                              handleCheckboxChange(e, author.id, author.tableId)
                            }
                          />
                        </td>
                        <td>
                          <div className="d-flex justify-content-center">
                            <div className="d-flex justify-content-around modula-main mt-1">
                              <div
                                className="modula-icon-edit"
                                onClick={() => handleEditAuthor(author)}
                                role="button"
                                tabIndex={0}
                              >
                                <TfiPencilAlt />
                              </div>

                              <div className="border border-1 mx-2"></div>

                              <div
                                className="modula-icon-del"
                                onClick={() => handleDeleteClick(author.id)}
                                role="button"
                                tabIndex={0}
                              >
                                <RiDeleteBin6Line />
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="13" className="text-center">
                        No data found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default AuthorForm;
