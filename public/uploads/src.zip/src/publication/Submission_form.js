import React, { useState, useEffect } from "react";
import DataTable from "datatables.net-react";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import axios from "axios";
import Swal from "sweetalert2";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import { useParams } from "react-router-dom";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import { getDateFormate } from "../dateFormate.js";

function Submission_form() {
  const [allid, setId] = useState(null);
  const { id } = useParams();

  // Get user details once
  const storedDetails = localStorage.getItem("medicsuser");
  const parsedDetails = storedDetails ? JSON.parse(storedDetails) : null;
  const createdby = parsedDetails?.id || null;

  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0");
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  // Initialize formData with all required fields
  const [formData, setFormData] = useState({
    journalName: "",
    articleType: "",
    reviewType: "",
    articleId: "",
    submissionDate: getTodayDate(),
    journalFee: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    document.getElementById("global-loader").style.display = "flex";

    try {
      const response = await axios.post(
        `${API_URL}/api/author/add-submission`,
        {
          project_id: allid,
          journal_name: formData.journalName,
          type_of_article: formData.articleType,
          article_id: formData.articleId,
          review: formData.reviewType,
          date_of_submission: formData.submissionDate,
          journal_fee: formData.journalFee,
          created_by: createdby,
        }
      );

      Swal.fire({
        icon: "success",
        title: "Submission Added!",
        text: "The upload details have been successfully saved.",
        confirmButtonText: "OK",
      });

      // Reset form but keep the date
      setFormData((prev) => ({
        ...prev,
        articleId: "",
        journalFee: "",
      }));

      // Refetch data
      await fetchProjectManagerData();
    } catch (error) {
      console.error(error);
      Swal.fire({
        icon: "error",
        title: "Submission Failed",
        text:
          error.response?.data?.message ||
          "There was an error submitting the details.",
        confirmButtonText: "Retry",
      });
    } finally {
      document.getElementById("global-loader").style.display = "none";
    }
  };

  const [data, setData] = useState([]);

  // console.log("alllistdata:", data);

  const [submissionList, setSubmissionList] = useState([]);

  const fetchData = async (projectId) => {
    if (!projectId || !createdby) return;

    try {
      const response = await axios.get(
        `${API_URL}/api/author/submission-list`,
        {
          params: { createdby, project_id: projectId },
        }
      );

      if (response.data?.length > 0) {
        const latestSubmission = response.data[0];
        setFormData((prev) => ({
          ...prev,
          // journalName: latestSubmission.journal_name || prev.journalName,
          journalName: CapitalizeCaseU(
            latestSubmission.journal_name || prev.journalName
          ),

          articleType: latestSubmission.type_of_article || prev.articleType,
          reviewType: latestSubmission.review || prev.reviewType,
          articleId: latestSubmission.article_id || "",
          submissionDate: latestSubmission.date_of_submission || getTodayDate(),
          journalFee: latestSubmission.journal_fee || "",
        }));
      }
      setData(response.data);
      setSubmissionList(response.data);
    } catch (error) {
      console.error("Error fetching submission list", error);
    }
  };

  const fetchProjectManagerData = async () => {
    if (!id) return;

    try {
      const response = await axios.get(
        `${API_URL}/api/author/author-view/${id}`
      );

      const projectData = response.data.author;
      const journalData = projectData.journal_data?.[0] || {};

      setId(projectData.id);

      // Set initial form data from journal data
      setFormData((prev) => ({
        ...prev,
        journalName: CapitalizeCaseU(journalData.assign_user || ""),
        articleType: CapitalizeCaseU(journalData.type_of_article || ""),
        reviewType: journalData.review || "",
      }));

      // Fetch submission data after we have the project ID
      await fetchData(projectData.id);
    } catch (error) {
      console.error("Error fetching project data", error);
    }
  };

  useEffect(() => {
    fetchProjectManagerData();
  }, [id]);

  const columns = [
    {
      title: "Journal Name",
      data: "journal_name",
      render: function (data) {
        return data?.trim() ? Capitalize(data) : "-";
      },
    },
    {
      title: "Type Of Article",
      data: "type_of_article",
      render: function (data) {
        return data?.trim() ? Capitalize(data) : "-";
      },
    },
    {
      title: "Review",
      data: "review",
      render: function (data) {
        return data?.trim() ? Capitalize(data) : "-";
      },
    },
    {
      title: "Article ID",
      data: "article_id",
      render: function (data) {
        return data?.trim() ? Capitalize(data) : "-";
      },
    },
    {
      title: "Date of submission",
      data: "date_of_submission",
      render: function (data) {
        return data?.trim() ? getDateFormate(data) : "-";
      },
    },
    {
      title: "Journal Fee",
      data: "journal_fee",
      render: function (data) {
        return data?.trim() ? Capitalize(data) : "-";
      },
    },
    // {
    //     title: "ACTIONS",
    //     data: null,
    //     render: (data, type, row) => {
    //       const id = `actions-${row.sno || Math.random()}`;
    //       setTimeout(() => {
    //         const container = document.getElementById(id);
    //         if (container && !container.hasChildNodes()) {
    //           ReactDOM.render(
    //             <div className="d-flex justify-content-center">
    //               <div className="d-flex justify-content-around modula-main mt-1  ">
    //                 <div
    //                   className="download-button-file"
    //                   onClick={() => handleFileDownload(data)}
    //                 >
    //                   <MdDownload />
    //                 </div>
    //               </div>
    //             </div>,
    //             container
    //           );
    //         }
    //       }, 0);
    //       return `<div id="${id}"></div>`;
    //     },
    //   },
  ];

  return (
    <>
      <div className="container ">
        <div className="form-all-form">Submission Form</div>

        <form>
          <div className="d-flex justify-content-around">
            <div className="col-md-5">
              <label className="label-public-name">Journal Name</label>
              <input
                type="text"
                className="form-control1"
                name="journalName"
                value={formData.journalName}
                onChange={handleChange}
                autoComplete="off"
              />
            </div>
            <div className="col-md-5">
              <label className="label-public-name">Type of Article</label>
              <select
                type="text"
                className="form-select1"
                name="articleType"
                value={formData.articleType}
                onChange={handleChange}
              >
                <option value="" disabled selected>
                  Type of Article{" "}
                </option>
                <option value="original_research_article">
                  Original Research Article
                </option>
                <option value="case_report">Case Report</option>
                <option value="case_series">Case Series</option>
                <option value="systematic_review">Systematic Review</option>
                <option value="comprehensive_review">
                  Comprehensive Review
                </option>
              </select>{" "}
            </div>
          </div>
          <div className="d-flex justify-content-around mt-2">
            <div className="col-md-5 ">
              <label className="label-public-name">
                Quick Review / Normal Review
              </label>

              <div className="d-flex">
                <div className="form-check mx-2">
                  <input
                    type="radio"
                    className="form-check-input"
                    id="quickReview"
                    name="reviewType" // Shared name for radio buttons
                    value="quickReview"
                    checked={formData.reviewType === "quickReview"}
                    onChange={handleChange}
                  />
                  <label className="label-public-name" htmlFor="quickReview">
                    Quick Review
                  </label>
                </div>

                <div className="form-check mx-2">
                  <input
                    type="radio"
                    className="form-check-input"
                    id="normalReview"
                    name="reviewType" // Shared name for radio buttons
                    value="normalReview"
                    checked={formData.reviewType === "normalReview"}
                    onChange={handleChange}
                    // readOnly
                    // disabled
                  />
                  <label className="label-public-name" htmlFor="normalReview">
                    Normal Review
                  </label>
                </div>
              </div>
            </div>
            <div className="col-md-5">
              <label className="label-public-name">Article Id</label>
              <input
                type="text"
                className="form-control1"
                name="articleId"
                value={formData.articleId}
                onChange={handleChange}
                autoComplete="off"
              />
            </div>
          </div>
          <div className="d-flex justify-content-around mt-2">
            <div className="col-md-5">
              <label className="label-public-name">Date of Submission</label>
              <input
                type="date"
                className="form-control1"
                name="submissionDate"
                value={formData.submissionDate}
                onChange={handleChange}
                autoComplete="off"
              />
            </div>
            <div className="col-md-5">
              <label className="label-public-name">Jounal Fee</label>
              <input
                type="text"
                className="form-control1"
                name="journalFee"
                value={formData.journalFee}
                onChange={handleChange}
                autoComplete="off"
              />
            </div>
          </div>

          <div className="d-flex justify-content-end px-5 pt-2">
            <button className="save-form-task mb-2 pt-1" onClick={handleSubmit}>
              Submit
            </button>
          </div>
        </form>
        <section className="pb-2">
          <div>
            <DataTable
              id="example"
              data={data}
              columns={columns}
              className="display"
              options={{
                scrollX: true,
                select: true,
                pageLength: 20, // Default number of rows per page
                lengthMenu: [
                  [20, 30, 50],
                  [20, 30, 50],
                ],
                search: {
                  return: true, // Ensures search starts fresh
                },
              }}
            />
          </div>
        </section>
      </div>
    </>
  );
}

export default Submission_form;
