// import React from 'react'

// function Public_form_side() {
//   return (
//     <>
//     <section>
//         <div className='form-heading mt-1'>
//             FORMS:
//         </div>
//         <div className='form-list-name mt-1'>
//             Authour Form
//         </div>
//         <div className='form-list-name mt-1'>
//             Upload Files
//         </div>
//         <div className='form-list-name mt-1'>
//             Submission Form
//         </div>
//         <div className='form-list-name mt-1'>
//             Reviewer Form
//         </div>
//         <div className='form-list-name mt-1'>
//             Rejection Form
//         </div>
//         <div className='form-list-name mt-1'>
//             Resubmission
//         </div>
       
//     </section>
//     </>
//   )
// }

// export default Public_form_side


import React from 'react';

const forms = [
    'Author Form',
    'Documents Form',
    'Submission Form',
    'Reviewers Comments Form',
    'Rejection Form',
    'Resubmission'
];

function Public_form_side({ onSelectForm, activeForm,allid }) {
    // console.log("allisdata:",allid);
    
    return (
        <section>
            <div className='form-heading mt-1'>FORMS:</div>
            {forms.map((form, index) => (
                <div
                    key={index}
                    className={`form-list-name  ${activeForm === form ? 'active' : ''}`}
                    onClick={() => onSelectForm(form)}
                >
                    {form}
                </div>
            ))}
        </section>
    );
}

export default Public_form_side;
