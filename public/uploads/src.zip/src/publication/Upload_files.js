import React, { useState, useEffect ,useRef } from "react";
import { RiDeleteBin6Line } from "react-icons/ri";
import { AiOutlineClose } from "react-icons/ai"; // Cancel icon
import DataTable from "datatables.net-react";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import axios from "axios";
import { MdDownload } from "react-icons/md";
import ReactDOM from "react-dom";
import { API_URL } from "../config.js";
import Swal from "sweetalert2";
import { saveAs } from "file-saver";
import { Capitalize } from "../campsCase.js";
import { useParams } from "react-router-dom";

// import JSZip from 'jszip';

function UploadFiles({ project_id }) {


  const [allid, setId] = useState([]);
  const { id } = useParams();

  const [files, setFiles] = useState([]);
  const [formData, setFormData] = useState({
    title: "",
    others: "",
    file: [],
  });

  const handleFileChange = (event) => {
    const newFiles = Array.from(event.target.files);

    setFormData((prevFormData) => ({
      ...prevFormData,
      file: [...(prevFormData.file || []), ...newFiles], // Ensures it's an array
    }));
  };

  // Improved File Deletion Logic
  const handleSingleFileDelete = (index) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      file: prevFormData.file.filter((_, i) => i !== index),
    }));
  };


const fileInputRef = useRef(null);


  // Clear all files
 const handleClearAll = () => {
  setFormData((prevFormData) => ({
    ...prevFormData,
    file: [],
  }));

  // Clear the file input field using the ref
  if (fileInputRef.current) {
    fileInputRef.current.value = "";
  }
};

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;

    // get
  const [data, setData] = useState([]);

    useEffect(() => {
      if (project_id) {
        fetchData(project_id);
      }
    }, [project_id]);
    
  const fetchData = async () => {
    try {
      // console.log("Fetching data for project_id:", allid);
      const response = await axios.get(`${API_URL}/api/author/document-list`, {
        params: { project_id: project_id },
      });

      console.log("Request URL:", response.request.responseURL);
      setData(response.data);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  // useEffect(() => {
  //   // if (allid) {
  //     fetchData(allid);
  //   // }
  // }, [allid]);

  // post
  const handleSubmit = async (e) => {
    e.preventDefault();

    const submissionData = new FormData();
    submissionData.append("project_id", projectid);
    submissionData.append("title", formData.title);
    submissionData.append("other_title", formData.others);
    submissionData.append("created_by", createdby);

    // Correct format for files: file[0], file[1], etc.
    formData.file.forEach((file, index) => {
      submissionData.append(`file[${index}]`, file);
    });

    document.getElementById("global-loader").style.display = "flex";

    setTimeout(async () => {
      try {
        let response = await axios.post(
          `${API_URL}/api/author/document-store`,
          submissionData
        );

        console.log("submission form:", response);

        Swal.fire({
          icon: "success",
          title: "Submission Added!",
          text: "The upload details have been successfully saved.",
          confirmButtonText: "OK",
        });

        setFormData({
          title: "",
          others: "",
          file: [],
        });

        fetchData();
      } catch (error) {
        console.error(error);

        Swal.fire({
          icon: "error",
          title: "Submission Failed",
          text: "There was an error submitting the author details. Please try again.",
          confirmButtonText: "Retry",
        });
      } finally {
        document.getElementById("global-loader").style.display = "none";
      }
    }, 500);
  };

  // delete

  const handleDeleteClick = async (id) => {
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to delete this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "No, keep it",
    });

    if (result.isConfirmed) {
      console.log("id", id);
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/author/document-delete/${id}`
          );
          console.log(response);

          Swal.fire({
            title: "Deleted!",
            text: "Your document has been deleted.",
            icon: "success",
            confirmButtonText: "Okay",
          });

          await fetchData();
          //  window.location.reload();
        } catch (error) {
          console.log(error);
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  // download

  // const downloadAllFiles = async (filesPath) => {
  //   console.log("files", filesPath);

  //   // const link = document.createElement("a");
  //   // link.href = resume;
  //   // link.download = "resume.pdf";
  //   // document.body.appendChild(link);
  //   // link.click();
  //   // document.body.removeChild(link);

  //   const link = document.createElement("a");
  //   link.href = filesPath;
  //   link.download = `https://backend.medicsresearch.com/author_document_files/1742795281_pexels-jochen-meyer-2148428490-30091614.jpg`;
  //   document.body.appendChild(link);
  //   link.click();
  //   document.body.removeChild(link);

  //   // for (const file of files) {
  //   //   const downloadUrl = `${API_URL}/api/author/document-list?file_path=${encodeURIComponent(
  //   //     filesPath
  //   //   )}`;

  //   //   try {
  //   //     const response = await fetch(downloadUrl);

  //   //     if (!response.ok) {
  //   //       console.error(
  //   //         `Failed to download: ${file.file_path} (Status: ${response.status})`
  //   //       );
  //   //       continue;
  //   //     }

  //   //     const contentDisposition = response.headers.get("Content-Disposition");
  //   //     const suggestedFileName = contentDisposition
  //   //       ? decodeURIComponent(
  //   //           contentDisposition.split("filename*=UTF-8")[1] ||
  //   //             contentDisposition.split("filename=")[1].replace(/['"]/g, "")
  //   //         )
  //   //       : file.file_path.split("/").pop();

  //   //     const blob = await response.blob();

  //   //     if (!blob || blob.size === 0) {
  //   //       console.error(`Empty file detected: ${file.file_path}`);
  //   //       continue;
  //   //     }

  //   //     saveAs(blob, suggestedFileName);
  //   //   } catch (error) {
  //   //     console.error(`Error fetching file: ${file.file_path}`, error);
  //   //   }
  //   // }
  //   // const link = document.createElement("a");
  //   // link.href = filesPath;
  //   // link.download = filesPath.split('/').pop();
  //   // document.body.appendChild(link);
  //   // link.click();
  //   // document.body.removeChild(link);
  // };

  const downloadAllFiles = (filesPath) => {
    const link = document.createElement("a");
    link.href = `${API_URL}/${filesPath}`; // Full path for download
    link.target = "_blank"; // Ensures compatibility with certain browsers
    link.setAttribute("download", filesPath.split("/").pop()); // Correct filename for download

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const columns = [
    { title: " File", data: "title", render: (data) => Capitalize(data) },
    {
      title: "File Status ",
      data: "created_at",
      render: function (data) {
        return data ? new Date(data).toLocaleDateString("en-GB") : "-";
      },
    },
    {
      title: "ACTIONS",
      data: null,
      render: (data, type, row) => {
        const id = `actions-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                <div className="d-flex justify-content-around modula-main mt-1  ">
                  <div
                    className="download-button-file"
                    onClick={() => downloadAllFiles(row.files[0].file_path)}
                  >
                    <MdDownload />
                  </div>

                  <div className="border border-1"></div>

                  <div
                    className="modula-icon-del"
                    onClick={() => handleDeleteClick(data.id)}
                  >
                    <RiDeleteBin6Line />
                  </div>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  useEffect(() => {
    setTimeout(() => {
      const searchInput = document.querySelector("#example_filter input");
      if (searchInput) {
        searchInput.setAttribute("autocomplete", "off");
      }
    }, 0);
  }, []);

  const [showInput, setShowInput] = useState(false);

  // const handleSelectChange = (e) => {
  //   setShowInput(e.target.value === "Others");

  //   setFormData({ ...formData, title: e.target.value });
  // };

  const handleSelectChange = (e) => {
    const selectedTitle = e.target.value;
    setShowInput(selectedTitle === "Others");

    setFormData((prevFormData) => ({
      ...prevFormData,
      title: selectedTitle,
      others: selectedTitle === "Others" ? "" : prevFormData.others,
    }));
  };

  const handleOthersChange = (e) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      others: e.target.value,
    }));
  };

  const [progess, setProgess] = useState([]);
  const [journaldata, setJounaldata] = useState([]);

  console.log("allid:", allid);

  console.log("progresscount:", progess);
  console.log("journal:", journaldata);

  const [projectid, setProjectid] = useState([]);

  console.log("projectid:", projectid);

  const fetchProjectManagerData = async () => {
    try {
      const responseShow = await axios.get(
        `${API_URL}/api/author/author-view/${id}`
      );

      setProgess(responseShow.data);
      setJounaldata(responseShow.data.author.journal_data[0]);

      setId(responseShow.data.author.id);
      setProjectid(responseShow.data.author.journal_data[0].project_id);

      // console.log("journalname:",responseShow.data.journal_data[0].assign_user);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    if (id) {
      fetchProjectManagerData(id);
    }
  }, [id]);

  return (
    <div className="container ">
      <div className="form-all-form">Upload files</div>

      <form>
        <div className="d-flex justify-content-around">
          {/* Manuscript File Section */}
          <div className="col-md-5">
            <label className="label-public-name">select the Title</label>

            <select
              className="form-select1 p-3 pb-2"
              onChange={handleSelectChange}
              value={formData.title}
            >
              <option value="" disabled selected>
                select a file
              </option>
              <option value="Manuscript File">Manuscript File</option>
              <option value="Cover Letter">Cover Letter</option>
              <option value="Copyright Form">Copyright Form</option>
              <option value="IJCME Form">IJCME Form</option>
              <option value="Informed Consent">Informed Consent</option>
              <option value="Ethics Committee Approval">
                Ethics Committee Approval
              </option>
              <option value="Tables and Graphs">Tables and Graphs</option>
              <option value="Others">Others</option>
            </select>
          </div>

          <div className="col-md-5">
            <label className="label-public-name">files</label>
            <div className="form-control1 d-flex justify-content-end pb-1">
              <input
              ref={fileInputRef}
                type="file"
                accept="file/*"
                multiple
                
                className="file-upload-input"
                onChange={handleFileChange}
              />
              <RiDeleteBin6Line
                className="file-del-icon"
                onClick={handleClearAll}
              />
            </div>
            {Array.isArray(formData.file) && formData.file.length > 0 && (
              <div className="mt-2 w-100 px-1">
                {formData.file.map((file, index) => (
                  <div key={index} className="d-flex align-items-center">
                    <AiOutlineClose
                      className="cancel-list mx-1"
                      onClick={() => handleSingleFileDelete(index)}
                    />
                    <span>{file.name}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="px-5  mt-2">
          <div className="col-md-5">
            {showInput && (
              <input
                type="text"
                className="form-control1 mt-2"
                placeholder="Enter file"
                value={formData.others}
                onChange={handleOthersChange}
              />
            )}
          </div>
        </div>

        <div className="d-flex justify-content-end px-5 pt-2">
          <button className="save-form-task mb-2 pt-1" onClick={handleSubmit}>
            Upload
          </button>
        </div>
      </form>

      <section className="pb-2">
        <div>
          <DataTable
            id="example"
            data={data}
            columns={columns}
            className="display"
            options={{
              scrollX: true,
              select: true,
              pageLength: 20, // Default number of rows per page
              lengthMenu: [
                [20, 30, 50],
                [20, 30, 50],
              ],
              search: {
                return: true, // Ensures search starts fresh
              },
            }}
          />
        </div>
      </section>
    </div>
  );
}

export default UploadFiles;
