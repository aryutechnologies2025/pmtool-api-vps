import React, { useState, useEffect } from "react";
import DataTable from "datatables.net-react";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import axios from "axios";
import Swal from "sweetalert2";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import { useParams } from "react-router-dom";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import { RiDeleteBin6Line } from "react-icons/ri";
import { AiOutlineClose } from "react-icons/ai";
import { render } from "@testing-library/react";
import { getDateFormate } from "../dateFormate.js";
import ReactDOM from "react-dom";
import PDF from "../assests/images/pdf.svg";
import { MdDownload } from "react-icons/md";
import Excel from "../assests/images/excel.svg";
import ppt from "../assests/images/ppt.svg";
import Word from "../assests/images/word.svg";
import Image from "../assests/images/image.svg";

function Reviewer_comments({project_id}) {
        // console.log("author id",project_id)

  const [allid, setId] = useState([]);
  const { id } = useParams();
  const getTodayDate = () => {
    const today = new Date();
    return today.toISOString().split("T")[0];
  };

  const [formData, setFormData] = useState({
    journalName: "",
    commentDate: getTodayDate(),
    file: [],
  });

  // console.log("formdatall:",formData)

  const [comments, setComments] = useState([{ text: "" }]);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleAddField = () => {
    if (!comments[0].text.trim()) {
      setError(true);
      return;
    }
    setComments([...comments, { text: "" }]);
  };

  const handleRemoveField = (index) => {
    const updatedComments = comments.filter((_, i) => i !== index);
    setComments(updatedComments);
  };

  const handleChange = (e, index = null) => {
    const { name, value } = e.target;

    if (index !== null) {
      setComments((prevComments) => {
        const updatedComments = [...prevComments];
        updatedComments[index].text = value;
        return updatedComments;
      });

      if (index === 0 && value.trim()) setError(false);
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }
  };

  const storedDetails = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetails);
  const createdby = parsedDetails ? parsedDetails.id : null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    document.getElementById("global-loader").style.display = "flex";
    // console.log("project_id", allid);
    // console.log("journal_name", formData.journalName);
    // console.log("record_date", formData.commentDate);
    // console.log("created_by", createdby);

    const formDataToSend = new FormData();
    formDataToSend.append("project_id", allid);
    formDataToSend.append("journal_name", formData.journalName);
    formDataToSend.append("record_date", formData.commentDate);
    formDataToSend.append("created_by", createdby);

    // Append each file individually
    formData.file.forEach((file) => {
      formDataToSend.append("file", file);
    });

    // console.log("payload:",formDataToSend)
    // Add comments separately as a JSON string
    formDataToSend.append(
      "comments",
      JSON.stringify(comments.map((comment) => comment.text.trim()))
    );

    try {
      await axios.post(
        `${API_URL}/api/author/reviewer-comment`,
        formDataToSend,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );

      Swal.fire({
        icon: "success",
        title: "Reviewer Added!",
        text: "The Reviewer details have been successfully saved.",
        confirmButtonText: "OK",
      });

      setFormData({
        journalName: "",
        commentDate: getTodayDate(),
        file: [],
      });
      setComments([{ text: "" }]);
      fetchData(allid);
    } catch (error) {
      console.error(error);
      Swal.fire({
        icon: "error",
        title: "Submission Failed",
        text: "There was an error submitting the reviewer details. Please try again.",
        confirmButtonText: "Retry",
      });
    } finally {
      document.getElementById("global-loader").style.display = "none";
    }
  };

  const [data, setData] = useState([]);
  // const [commonFilesall, setCommonFiles] = useState([]);

  // console.log("common files:",commonFilesall)
 useEffect(() => {
    if (project_id) {
      fetchData(project_id);
    }
  }, [project_id]);
  const fetchData = async (id) => {
    setLoading(true);
    try {
      const response = await axios.get(`${API_URL}/api/author/reviewer-list`, {
        params: { project_id: project_id },
      });
      console.log("first", id);
      // setFormData((prevState) => {
      //   const article = response.data?.[0] || {}; // Ensure we safely access the first element or an empty object
      //   return {
      //     ...prevState,
      //     journalName: article.journal_name,
      //   };
      // });

      // console.log("response.data :", response.data);

      const flatenData = response.data.map((item) => {
        return {
          journal_name: item.journal_name,
          created_at: item.created_at,
          comments: item.comments?.map((comment) => comment) || null,
          files: item.file,
        };
      });
      // setCommonFiles(response.data[0].file)
      // const commonFiles = response.data;

      // const flattenedFiles = commonFiles.map((item) => ({
      //   ...item.file,
      // }));

      // setCommonFiles(flattenedFiles);

      console.log("flatenData :", flatenData);
      setData(flatenData);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const getFileIcon = (type) => {
    const imageFormats = [
      "jpg",
      "png",
      "gif",
      "jpeg",
      "svg",
      "txt",
      "PNG",
      "JPG",
      "SVG",
    ];
    const excelFormats = ["xlsx", "xls", "csv"];
    const wordFormats = ["docx", "doc", "word"];
    const pptFormats = ["ppt", "pptx"];

    if (imageFormats.includes(type)) {
      return <img src={Image} className="img-view" alt="Image" />;
    }

    if (excelFormats.includes(type)) {
      return <img src={Excel} className="img-view" alt="Excel" />;
    }

    if (wordFormats.includes(type)) {
      return <img src={Word} className="img-view" alt="Word" />;
    }

    if (pptFormats.includes(type)) {
      return <img src={ppt} className="img-view" alt="ppt" />;
    }

    if (type === "pdf") {
      return <img src={PDF} className="img-view" alt="PDF" />;
    }

    return null;
  };

  const handleFileDownload = async (filePath) => {
    try {
      // console.log("filePath :",filePath);
      console.log("filePath :", filePath.files);
      // Extract filename from path (assuming filePath is the full path)

      const downloadUrl = `${API_URL}/${filePath}`;
      console.log("downloadUrl :", downloadUrl);
      // Create temporary link for download
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.setAttribute("download", filePath);
      link.setAttribute("target", "_blank");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Download failed",
        text: error.message,
        showConfirmButton: true,
      });
    }
  };



  const columns = [
    {
      title: "Journal Name",
      data: "journal_name",
      render: function (data) {
        return data?.trim() ? Capitalize(data) : "-";
      },
    },
    {
      title: "Reviewers Comment Date",
      data: "created_at",
      render: function (data) {
        return data?.trim() ? getDateFormate(data) : "-";
      },
    },
    {
      title: "Comments",
      data: "comments",
      render: function (data) {
        if (!data || !Array.isArray(data)) return "-";
        return data.map((comment) => Capitalize(comment)).join(", ");
      },
    },
    // {
    //     title: "ACTIONS",
    //     data: null,
    //     render: (data, type, row) => {
    //       const id = `actions-${row.sno || Math.random()}`;
    //       setTimeout(() => {
    //         const container = document.getElementById(id);
    //         if (container && !container.hasChildNodes()) {
    //           ReactDOM.render(
    //             <div className="d-flex justify-content-center">
    //               <div className="d-flex justify-content-around modula-main mt-1  ">
    //                 <div
    //                   className="download-button-file"
    //                   onClick={() => handleFileDownload(data)}
    //                 >
    //                   <MdDownload />
    //                 </div>
    //               </div>
    //             </div>,
    //             container
    //           );
    //         }
    //       }, 0);
    //       return `<div id="${id}"></div>`;
    //     },
    //   },

    {
      title: "ACTIONS",
      data: null,
      render: (data, type, row) => {
        const id = `actions-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                <div className="d-flex justify-content-around  mt-1">
    

                  <div
                    title={
                      data.files ? `${data.files} Uploaded` : "No file uploaded"
                    }
                    style={{ position: "relative" }}
                  >
                    <span
                      onClick={() =>
                        data.files && handleFileDownload(data.files)
                      }
                      style={{ cursor: "pointer" }}
                    >
                      {/* Check for file existence and show appropriate icon */}
                      {data.files
                        ? getFileIcon(data.files.split(".").pop())
                        : "-"}
                    </span>
                  </div>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  // Improved File Deletion Logic
  const handleSingleFileDelete = (index) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      file: prevFormData.file.filter((_, i) => i !== index),
    }));
  };

  const handleFileChange = (event) => {
    const newFiles = Array.from(event.target.files);

    setFormData((prevFormData) => ({
      ...prevFormData,
      file: [...(prevFormData.file || []), ...newFiles], // Ensures it's an array
    }));
  };

  // Clear all files
  const handleClearAll = () => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      file: [],
    }));

    // Clear the file input field
    const fileInput = document.querySelector(".file-upload-input");
    if (fileInput) fileInput.value = "";
  };

  const [progess, setProgess] = useState([]);
  const [journaldata, setJounaldata] = useState([]);

  // console.log("allireviwer:", allid);

  // console.log("progresscount:", progess);
  // console.log("journal:", journaldata);
  const fetchProjectManagerData = async () => {
    try {
      const responseShow = await axios.get(
        `${API_URL}/api/author/author-view/${id}`
      );
      // console.log('responseShow :',responseShow);
      setProgess(responseShow.data.author);
      setJounaldata(responseShow.data.author.journal_data[0]);
      // setFormData(responseShow.data.journal_data[0].assign_user);

      setFormData((prevState) => ({
        ...prevState,
        journalName: CapitalizeCaseU(
          responseShow.data.author.journal_data[0].assign_user || ""
        ),
      }));

      setId(responseShow.data.author.id);

      // console.log("journalname:",responseShow.data.journal_data[0].assign_user);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    if (id) {
      fetchProjectManagerData(id);
    }
  }, [id]);

  return (
    <div className="container">
      <div className="form-all-form">Reviewer Comments Form</div>
      <form onSubmit={handleSubmit}>
        <div className="mt-2">
          <div className="d-flex justify-content-around">
            <div className="col-md-5">
              <label className="label-public-name">Journal Name</label>
              <input
                type="text"
                className="form-control1"
                name="journalName"
                value={formData.journalName}
                onChange={handleChange}
                readOnly
              />
            </div>
            <div className="col-md-5 ">
              <label className="label-public-name">
                Reviewers Comment Date
              </label>
              <input
                type="date"
                className="form-control1"
                name="commentDate"
                value={formData.commentDate}
                onChange={handleChange}
                autoComplete="off"
              />
            </div>
          </div>
        </div>

        <div className="d-flex justify-content-around">
          <div className="col-md-5 ">
            {comments.map((field, index) => (
              <div key={index} className="row mt-2 align-items-center">
                <div className="">
                  <label className="label-public-name">{`Comment ${
                    index + 1
                  }`}</label>
                  <textarea
                    className={`form-control1 ${
                      index === 0 && error ? "error" : ""
                    }`}
                    name="commentBox"
                    value={field.text}
                    onChange={(e) => handleChange(e, index)}
                    autoComplete="off"
                  />
                </div>
                {index === 0 && (
                  <div className=" d-flex align-items-center ">
                    <button
                      type="button"
                      className="save-form-add mt-1"
                      onClick={handleAddField}
                    >
                      Add +
                    </button>
                  </div>
                )}
                {index > 0 && (
                  <div className=" d-flex align-items-center ">
                    <button
                      type="button"
                      className="save-form-del mt-1"
                      onClick={() => handleRemoveField(index)}
                    >
                      Delete
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="col-md-5 mt-2">
            <label className="label-public-name">files</label>
            <div className="form-control1 d-flex justify-content-end pb-1">
              <input
                type="file"
                accept="file/*"
                // multiple
                className="file-upload-input"
                onChange={handleFileChange}
              />
              <RiDeleteBin6Line
                className="file-del-icon"
                onClick={handleClearAll}
              />
            </div>
            {formData.file.length > 0 && (
              <div className="uploaded-files-preview">
                {formData.file.map((file, index) => (
                  <div key={index} className="file-item">
                    {file.name}
                    <RiDeleteBin6Line
                      style={{ cursor: "pointer", color: "red", marginLeft: 8 }}
                      onClick={() => handleSingleFileDelete(index)}
                    />
                  </div>
                ))}
                {/* <button
                  onClick={handleClearAll}
                  className="btn btn-danger mt-2"
                >
                  <AiOutlineClose /> Clear All
                </button> */}
              </div>
            )}
          </div>
        </div>

        <div className="d-flex justify-content-end px-5 pt-2">
          <button className="save-form-task mb-2 pt-1">Submit</button>
        </div>
      </form>

      <section className="pb-2">
        <div>
          <DataTable
            id="example"
            data={data}
            columns={columns}
            className="display"
            options={{
              scrollX: true,
              select: true,
              pageLength: 20, // Default number of rows per page
              lengthMenu: [
                [20, 30, 50],
                [20, 30, 50],
              ],
              search: {
                return: true, // Ensures search starts fresh
              },
            }}
          />
        </div>
      </section>
    </div>
  );
}

export default Reviewer_comments;
