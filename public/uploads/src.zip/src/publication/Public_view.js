import React from "react";
import "../assests/css/public.css";

import { BsBarChartLine } from "react-icons/bs";
import Sider from "../components/Sider.js";

import Header from "../components/Header.js";
import { AiOutlineAlert } from "react-icons/ai";
import { MdDoNotDisturb } from "react-icons/md";
import { FaFileInvoiceDollar } from "react-icons/fa6";
import { GiPiggyBank } from "react-icons/gi";
import "../assests/css/project_management.css";
import ReactDOM from "react-dom";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { useState, useEffect, useRef } from "react";
import { VscGitStashPop } from "react-icons/vsc";

import { IoMdAdd } from "react-icons/io";
import Footer from "../components/Footer.js";
import Tooltip from "@mui/material/Tooltip";
import { useNavigate } from "react-router-dom";
import Breadcrumbs from "../routes/Breadcrumbs.js";
import { VscEye } from "react-icons/vsc";

// icon

import axios from "axios";
import { useParams } from "react-router-dom";
// import { combineEventHandlers } from "recharts/types/util/ChartUtils.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import Public_form_side from "./Public_form_side.js";
import Authour_form from "./Authour_form.js";
import Upload_files from "./Upload_files.js";
import Submission_form from "./Submission_form.js";
import Reviewer_comments from "./Reviewer_comments.js";
import Rejection_form from "./Rejection_form.js";
import Resubmission from "./Resubmission.js";
import Loader from "../components/Loader.js";
import Swal from "sweetalert2";
import Sav from "../assests/images/sav-file-format.png";

import PDF from "../assests/images/pdf.svg";
import Excel from "../assests/images/excel.svg";
import ppt from "../assests/images/ppt.svg";
import Word from "../assests/images/word.svg";
import Image from "../assests/images/image.svg";
import Zip from "../assests/images/Zip.png";

import { Editor } from "primereact/editor";
import { getTotalDuration } from "../utils/projectDurations.js";
import { HRMS_API_URL } from "../config.js";
import Profile from "../assests/images/profile.png";
import Medicslogo from "../assests/images/medicslogo.svg";

// import axios from "axios";

function Public_view() {
  const { id } = useParams();
// main projectid
    const [project_id, setProjectId] = useState("");

  // console.log("iddd", id);
  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;
  const employee_name = parsedDetails ? parsedDetails.employee_name : null;
  const positionData = parsedDetails ? parsedDetails.position : null;
  // const {alloverid} =useParams();

  const formComponents = {
    "Author Form": <Authour_form project_id={project_id}/>,
    "Documents Form": <Upload_files project_id={project_id} />,
    "Submission Form": <Submission_form project_id={project_id} />,
    "Reviewers Comments Form": <Reviewer_comments project_id={project_id} />,
    "Rejection Form": <Rejection_form project_id={project_id} />,
    Resubmission: <Resubmission project_id={project_id} />,
  };

  const [formData, setFormData] = useState({
    commandbox: "",
  });

  const handleCommonFileDownload = async (filePath) => {
    try {
      // Extract filename from path (assuming filePath is the full path)
      const fileName = filePath.split("/").pop();

      const downloadUrl = `${API_URL}/activity_files/${filePath}`;

      // Create temporary link for download
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.setAttribute("download", fileName);
      link.setAttribute("target", "_blank");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Optional: Show success message
      // Swal.fire({
      //   icon: "success",
      //   title: "Download started",
      //   text: `File ${fileName} is being downloaded`,
      //   showConfirmButton: true,
      // });
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Download failed",
        text: error.message,
        showConfirmButton: true,
      });
    }
  };
  const getFileIcon = (type) => {
    const imageFormats = [
      "jpg",
      "png",
      "gif",
      "jpeg",
      "svg",
      "txt",
      "PNG",
      "JPG",
      "SVG",
    ];
    const excelFormats = ["xlsx", "xls", "csv"];
    const wordFormats = ["docx", "doc", "word"];
    const pptFormats = ["ppt", "pptx"];
    const SavFormats = ["sav"];
    const ZipFormats = ["zip"];

    if (imageFormats.includes(type)) {
      return <img src={Image} className="img-view" alt="Image" />;
    }

    if (SavFormats.includes(type)) {
      return <img src={Sav} className="img-view" alt="Image" />;
    }
    if (excelFormats.includes(type)) {
      return <img src={Excel} className="img-view" alt="Excel" />;
    }

    if (wordFormats.includes(type)) {
      return <img src={Word} className="img-view" alt="Word" />;
    }

    if (pptFormats.includes(type)) {
      return <img src={ppt} className="img-view" alt="ppt" />;
    }
    if (ZipFormats.includes(type)) {
          return <img src={Zip} className="img-view" alt="zip" />;
        }
    

    if (type === "pdf") {
      return <img src={PDF} className="img-view" alt="PDF" />;
    }

    return null;
  };

  const [selectedForm, setSelectedForm] = useState("Author Form");

  const [progess, setProgess] = useState([]);

  const [journaldata, setJournaldata] = useState([]);
  // console.log("journaldetails:", progess);
  const [allid, setId] = useState([]);
  const [journalName, setJournalname] = useState([]);

  const [projectcomments, setProjectcomments] = useState([]);

  const [journalcomments, setjournalcomments] = useState([]);
  // console.log("journalcomments:", journalcomments);
  const [commonFilesall, setCommonFiles] = useState([]);

  const [alldocumnts, setAlldocumnet] = useState([]);
  const [projectid, setProjectid] = useState([]);

  // console.log("allid:", projectid);

  const [publicdata, setPublic] = useState([]);
  const [publicdataa, setPublicc] = useState([]);

  const fetchProjectManagerData = async () => {
    try {
      const responseShow = await axios.get(
        `${API_URL}/api/author/author-view/${id}`
      );
      // console.log("project:", id);

      // console.log("all:", responseShow.data);
      // console.log(
      //   "all1112313123:",
      //   responseShow.data.lastCompletedActivity.file
      // );
      setProgess(responseShow.data.author);
      // console.log("summa:", responseShow.data);

      setId(responseShow.data.id);

      setJournaldata(responseShow.data.author.journal_data[0]);

      setProjectid(responseShow.data.author.journal_data[0].project_id);

      setJournalname(responseShow.data.author.journal_data[0].assign_user);
      setjournalcomments(responseShow.data.author.journal_data[0].comments);
      setProjectcomments(responseShow.data.author.projectcomment || []);
      // setAlldocumnet(responseShow.data.author.documents[0].select_document);
      setPublic(responseShow.data.projectLogs);
      setPublicc(responseShow.data.author.journal_data[0].status);

      setCommonFiles(responseShow.data.lastCompletedActivity || []);

      // setCommonFiles(responseShow.data.author.documents[0].file[0].file
      // );

      //       const singleGroup = responseShow.data.author.documents?.[0]?.file?.[0]?.file;
      // setCommonFiles(singleGroup ? [singleGroup] : []);

      // const commonFiles = responseShow.data.file;
      // const flattenedFiles = commonFiles.map((item) => ({
      //   ...item.file,
      // }));

      // setCommonFiles(flattssenedFiles);
      setLoading(false);

    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    fetchProjectManagerData();
  }, []);

  const handleNeedChange = (
    event,
    // setStatus,
    personId,
    assign_user,
    assign_date,
    status_date
  ) => {
    const newValue = event.target.value;
    // setStatus(newValue);
    // console.log("assign:", newValue);
    // setoldid(assign_user);

    sendStatusToBackend(
      newValue,
      event.target.name,
      personId,
      assign_user,
      assign_date,
      status_date
    );
    // console.log("assigndata:", sendStatusToBackend);
  };
  const sendStatusToBackend = async (
    statusValue,
    statusType,
    p_emdid,
    assign_user,
    assign_date,
    status_date
  ) => {
    // const id_p = project_id;
    const payload = {
      status: statusValue,
      type: statusType,
      created_by: createdby,
      project_id: projectid,
      p_emdid: p_emdid,
      assign_user: journalName,
      // projectid: projectId,
      assigned_date: assign_date,
      status_date: status_date,
      //  employee_id
    };
    // console.log("payload1234", payload);
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to change the  status?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, change it!",
      cancelButtonText: "Cancel",
    });
    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";
      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/author/publication-support`,
            payload
          );

          // console.log("response1", response);

          if (response.status === 200) {
            Swal.fire("Success", "Status updated successfully", "success").then(
              () => {
                window.location.reload();
              }
            );
            // fetchShowData(id);
          } else {
            Swal.fire("Error", "Failed to update the status", "error");
          }
        } catch (error) {
          console.error("Error updating status:", error); // Log any errors here
          Swal.fire("Error", "Failed to update the status", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  const removeEmptyTags = (html) => {
    const div = document.createElement("div");
    div.innerHTML = html;

    // Loop through all child elements and remove empty tags
    const elements = div.querySelectorAll("*");
    elements.forEach((element) => {
      if (!element.innerHTML.trim()) {
        element.remove(); // Remove empty elements
      }
    });

    return div.innerHTML;
  };

  // all project task view

  const [fetchData, setFetchData] = useState({});

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0"); // Pad single digits
    const day = String(date.getDate()).padStart(2, "0"); // Pad single digits
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  };
  // console.log("postion", positionData);

  const rolename = localStorage.getItem("medocsrolename") || "Admin";
  const emp_type = localStorage.getItem("medicsEmpName") || "Admin";


  // console.log("project_id:", project_id);
  const [rejectreason, setRejectReason] = useState([]);
  const [activityreason, setActivityReason] = useState([]);
  const [assignByPosition, setAssignByPosition] = useState("");
  const [type_of_work, setTypeOfWork] = useState("");

  // console.log("typework:", type_of_work);
  const [projectStatusCheck, setProjectStatus] = useState(null);
  const [projectStatusId, setProjectStatusId] = useState(null);
  const [projectStatusVal, setProjectStatusVal] = useState(null);
  // console.log("projectcomments:", projectcomments);
  const [projectcommetnsR, setProjectcommentRs] = useState([]);
  const [empimages, setEmployeeImage] = useState({});
  const [writercompleted, setWriterCompleted] = useState({});
  const [revierecompleted, setReviewerCompleted] = useState({});
  const [statiscompleted, setStatisCompleted] = useState({});
  const [createdbyFiles, setCreatedByDetails] = useState([]);
  // console.log("tablefiles:",createdbyFiles)
  const [projectId, setProjectName] = useState([]);

  const [rejectUserData, setRejectUserData] = useState([]);

  const [rejectlist, setRejectlist] = useState([]);
  const [rejectlistid, setRejectlistid] = useState([]);

  const [widthdraw, setwidthdraw] = useState([]);

  // console.log("widthdrawn:", widthdraw);

  // console.log("rejectlistdata:", rejectlistid);

  const [documentname, setDocument] = useState([]);

  // console.log("documnet 1234523:", documentname);

  const [rejectedAssignUserIds, setRejectedAssignUserIds] = useState([]);

  const [tcStatus, setTcStatus] = useState("");
  const [tcData, setTCData] = useState("");
  // console.log("tcData1234567890 :", tcData);
  const [commonStatus, setCommonStatus] = useState("");

  // console.log("commonstatus:", commonStatus);
  // console.log("Rejected assign_user IDs:", rejectedAssignUserIds);

  // console.log("datetime:", createdbyFiles);
  const [writesdetails, setWritersdetails] = useState([]);
  const [empData, setEmployeeData] = useState({});
  // console.log("alldocumnet:", alldocumnts);
  const [loading, setLoading] = useState(true);

  const fetchShowData = async (id) => {
    try {
      const responseShow = await axios.get(
        `${API_URL}/api/entry_process/project-view/${id}`,
        {
          params: {
            created_by: createdby,
          },
        }
      );

      const fetchData = responseShow.data;
      console.log("now",fetchData)
      const createdbyFiles =
        fetchData.response?.project_details?.commentslist || [];
      // console.log("createdbyFiles :", createdbyFiles);

      const uploadedFiles = createdbyFiles.map((doc) => {
        // const comment = doc.created_by_users ? doc.comments[0].comment
        //   : undefined;
        // console.log('doccc', doc)
        // Handle both array and single file cases
        const filesArray = Array.isArray(doc.file) ? doc.file : [doc.file];

        return {
          date: doc.created_date?.split(" ")[0] || "",
          added_at: doc.created_date ?? '-',
          createdby: doc.createdby_name ?? '-',
          type: doc.type || undefined,
          employee_name: doc.employee_name || undefined,
          role_name: doc.name || doc.position,
          // doc_id: doc.doc_id,
          files: filesArray.map((file) => ({
            // created_at: file.file_create,
            // file_ids: file.id,
            file_path: file.files ?? '-',
            file_name: file.original_name || "",
            extension: file.original_name?.split(".").pop()?.toLowerCase(),
          })),
          comments: doc.activity ?? '-',
          documentcount: filesArray.length ?? '-',
        };
      });
      setCreatedByDetails(uploadedFiles);
      setAlldocumnet(fetchData.duration_options);

      const rejectAssignIds = responseShow.data.rejected_list.map(
        (item) => item.assign_id
      );
      setRejectlistid(rejectAssignIds);
      // console.log("allcheckdata:", fetchData);
      const flatenTCdata = fetchData.response.project_details.tc_data.map(
        (item) => {
          // This will call setTcStatus for each item
          return {
            status: item.status,
          };
        }
      );
      setTCData(flatenTCdata);
      // console.log("TC Data :", flatenTCdata);
      // console.log("TC Status :", flatenTCdata.status);

      // setTcStatus(flatenTCdata.status)
      const originaltodoData = fetchData.rejected_list;
      // console.log('originaltodoData :',originaltodoData);
      setRejectUserData(originaltodoData);

      const flattenedToData = originaltodoData.map((item) => {
        return {
          status: CapitalizeCaseU(item.status),
          employee_name: item.user_data.employee_name,
          name: CapitalizeCaseU(item.user_data.created_by_user.name),
          updated_at: formatDate(item.updated_at),
        };
      });

      setRejectlist(flattenedToData);

      const rejectedIds = fetchData.response.project_details.writer_data
        .filter((writer) => writer.status === "rejected")
        .map((writer) => writer.assign_user);

      setRejectedAssignUserIds(rejectedIds);

      setWriterCompleted(fetchData.writerCompleted);

      setProjectName(fetchData.response.project_details.project_id);
      setReviewerCompleted(fetchData.reviewerCompleted);
      setStatisCompleted(fetchData.statisticanCompleted);
      setProjectId(fetchData.response.project_details.id);
      setTypeOfWork(fetchData.response.project_details.type_of_work);

      setDocument(fetchData.duration_options);

      setProjectcomments(
        fetchData?.response?.project_details?.projectcomment || []
      );
      setProjectcommentRs(
        fetchData?.response?.project_details?.projectcomment_r || []
      );

      const projectstatus =
        fetchData?.response?.project_details?.projectcomment_r || [];

      // console.log("projectstatus", projectstatus);
      setProjectStatusVal(projectstatus[0]?.type);

      const projectAcceptStatus =
        fetchData?.response?.project_details?.project_accept_statust || [];
      setProjectStatus(projectAcceptStatus[0]?.status);
      setFetchData(fetchData.response.project_details);
      setwidthdraw(fetchData.response.project_details.process_status);

      setWritersdetails(fetchData.response.project_details.writer_data);
      setEmployeeData(fetchData.response.employee_details);
      const employeedetails = fetchData.response.employee_details;
      const profileimage_f = employeedetails?.profile_image || "";
      const profileimage = profileimage_f
        ? `${HRMS_API_URL}/${profileimage_f}`
        : Profile;

      setEmployeeImage(profileimage);
      setCommonStatus(fetchData.response.project_details.process_status);
      // const formattedEmployees = fetchData.employees.map((employee) => ({
      //   name: employee.employee_name,
      //   id: employee.id,
      //   role_id: employee.position || null,
      //   position: employee.role_name?.name,
      //   image: employee.profile_image
      //     ? `${HRMS_API_URL}/${employee.profile_image}`
      //     : Profile,
      // }));

      // setOptionsAssigner(formattedEmployees);

      setChosenOption(fetchData.response.project_details.process_status || "");
      const fetchedFiles =
        fetchData?.response?.project_details?.documents || [];

      const formattedFiles = fetchedFiles.flatMap((doc) => {
        const filesArray = Array.isArray(doc.file) ? doc.file : [doc.file];

        return filesArray.map((file) => {
          const fileType = file.file.split(".").pop(); // Extract file extension
          const relativePath = file.file.replace(/\\/g, "/"); // Handle backslashes

          let documentTitles = [];
          try {
            const parsedData = JSON.parse(doc.select_document || "[]");
            documentTitles = Array.isArray(parsedData) ? parsedData : []; // Ensure it's an array
          } catch (error) {
            console.error(
              "Invalid JSON format for select_document:",
              doc.select_document
            );
          }
          const title = Array.isArray(documentTitles)
            ? documentTitles.join(", ")
            : "";

          return {
            entry_process_model_id: doc.entry_process_model_id,
            name: file.file,
            original_name: file.original_name,
            id: file.id,
            created_by: doc.created_by,
            optionName: title, // Use the formatted string
            type: fileType, // File type/extension
            fileName: file.file.split("/").pop(), // Extract filename
            url: file.file
              ? `${API_URL}/uploads/${relativePath}`
              : "Unknown URL",
            // url: ${BASE_URL}/uploads/${relativePath},
            url_d: `${API_URL}/uploads/${relativePath}`, // Construct file URL

            dateAdded: formatDate(doc.created_at),
            assigne: doc?.created_by_user?.employee_name || "Unknown",
          };
        });
      });

      setSubmittedFiles(formattedFiles);
      //reject reason
      setRejectReason(fetchData.response.project_details?.reject_reason);
      setActivityReason(fetchData.response.project_details.activity_data);
      // console.log("fetchData.response. :", fetchData.response);
      
      const commonFiles = fetchData.response.project_details.common_doc;
      const flattenedFiles = commonFiles.map((item) => ({
        ...item.file,
      }));

      // setCommonFiles(flattenedFiles);

      // console.log('flattenedFiles :',flattenedFiles);
      // console.log("uploadedFiles :", uploadedFiles);



      if (projectstatus?.length > 0) {
        // console.log("projectstatus", projectstatus);

        const formattedEmployee = {
          name: projectstatus[0]?.user_date?.employee_name || "Unknown",
          id: projectstatus[0]?.assign_user || null,
          position: projectstatus[0]?.type || "Unassigned",
          role_id: projectstatus[0]?.user_date?.position || null,
          image: projectstatus[0]?.user_date?.profile_image
            ? `${HRMS_API_URL}/${projectstatus[0]?.user_date?.profile_image}`
            : Profile,
        };
        // Set the selectedOption
        setSelectedOption(formattedEmployee);
        setSelectedStatus(projectstatus[0].status);
      }
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    if (id) {
      fetchShowData(id);
      fetchProjectManagerData(id);
    }
  }, [id]);

  const handleDownload = async (filePath) => {
    try {
      // Extract filename from path (assuming filePath is the full path)
      const fileName = filePath.split("/").pop();

      const downloadUrl = `${API_URL}/activity_files/${filePath}`;

      // Create temporary link for download
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.setAttribute("download", fileName);
      link.setAttribute("target", "_blank");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Optional: Show success message
      // Swal.fire({
      //   icon: "success",
      //   title: "Download started",
      //   text: `File ${fileName} is being downloaded`,
      //   showConfirmButton: true,
      // });
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Download failed",
        text: error.message,
        showConfirmButton: true,
      });
    }
  };

  // const handleCommonFileDownload = async (filePath) => {
  //   try {
  //     // Extract filename from path (assuming filePath is the full path)
  //     const fileName = filePath.split("/").pop();

  //     const downloadUrl = `${API_URL}/uploads/${filePath}`;

  //     // Create temporary link for download
  //     const link = document.createElement("a");
  //     link.href = downloadUrl;
  //     link.setAttribute("download", fileName);
  //     link.setAttribute("target", "_blank");
  //     document.body.appendChild(link);
  //     link.click();
  //     document.body.removeChild(link);

  //     // Optional: Show success message
  //     // Swal.fire({
  //     //   icon: "success",
  //     //   title: "Download started",
  //     //   text: `File ${fileName} is being downloaded`,
  //     //   showConfirmButton: true,
  //     // });
  //   } catch (error) {
  //     Swal.fire({
  //       icon: "error",
  //       title: "Download failed",
  //       text: error.message,
  //       showConfirmButton: true,
  //     });
  //   }
  // };

  // single file download

  // =================== DOWNLOAD FUNCTION ===================
  // const handleDownloadsingle = async (createdby, date, type, projectid) => {
  //   try {
  //     const response = await axios.get(
  //       `${API_URL}/api/entry_process/document-download`,
  //       {
  //         params: {
  //           createdby,
  //           date,
  //           type,
  //           projectid,
  //           pid: project_id, // Ensure this is defined
  //         },
  //         responseType: "blob",
  //       }
  //     );

  //     // Check if the response is an error (sometimes errors come as blobs)
  //     if (response.headers["content-type"]?.includes("application/json")) {
  //       const errorText = await response.data.text();
  //       const errorData = JSON.parse(errorText);
  //       throw new Error(errorData.message || "Download failed");
  //     }

  //     // Extract filename from headers
  //     const contentDisposition = response.headers["content-disposition"];
  //     let filename = "document";

  //     if (contentDisposition) {
  //       const match = contentDisposition.match(
  //         /filename\*?=['"]?(?:UTF-\d['"]*)?([^;\r\n"']*)['"]?;?/i
  //       );
  //       filename = match?.[1] || filename;
  //     }

  //     // Create a download link and trigger it
  //     const blob = new Blob([response.data], {
  //       type: response.headers["content-type"] || "application/octet-stream",
  //     });
  //     const downloadUrl = URL.createObjectURL(blob);
  //     const link = document.createElement("a");
  //     link.href = downloadUrl;
  //     link.download = filename;
  //     document.body.appendChild(link);
  //     link.click();
  //     document.body.removeChild(link);
  //     URL.revokeObjectURL(downloadUrl);
  //   } catch (error) {
  //     console.error("Download error:", error);
  //     Swal.fire("Error", error.message || "Failed to download file", "error");
  //   }
  // };

  const handleTextChange = (e) => {
    const newText = e.htmlValue;
    setFormData((prevData) => ({
      ...prevData,
      commandbox: newText,
    }));
  };

  const [editorKey, setEditorKey] = useState(0);

  const [uploadAfile, setFileAcData] = useState([]);
  const fileInputRef = useRef(null);

  const handleActivityFileChange = (event) => {
    const selectedFiles = Array.from(event.target.files);
    setFileAcData(selectedFiles);
  };

  const handleEditorChange = async (e) => {
    e.preventDefault();

    const updatedData = {
      project_id: projectid,
      activity: formData.commandbox,
      createdby: createdby,
      createdby_name: employee_name,
    };

    const formDataToSend = new FormData();

    for (const key in updatedData) {
      formDataToSend.append(key, updatedData[key]);
    }

    if (uploadAfile && uploadAfile.length > 0) {
      uploadAfile.forEach((file, index) => {
        formDataToSend.append("activity_file[]", file);
      });
    }

    try {
      const response = await axios.post(
        `${API_URL}/api/projects/store`,
        formDataToSend,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      setFormData((prevData) => ({
        ...prevData,
        commandbox: "",
      }));
      setEditorKey((prevKey) => prevKey + 1);
      setFileAcData([]);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      fetchShowData(id);
    } catch (error) {
      Swal.fire("Error", "Failed to update the comments", "error");
    }
  };

  const [errors, setErrors] = useState({});

  const [optionsAssigner, setOptionsAssigner] = useState([
    { name: "", id: "", image: Medicslogo, position: "" },
  ]);

  const [selectedOption, setSelectedOption] = useState(null);
  // console.log("assignuser:", selectedOption);

  const [searchQuery, setSearchQuery] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownAssgineStatus = useRef(null);
  const toggleDropdown = () => setIsDropdownOpen((prev) => !prev);

  const handleOptionSelect = async (option) => {
    Swal.fire({
      title: "Are you sure?",
      text: "Do you want to change the assignee?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, change it!",
      cancelButtonText: "Cancel",
    }).then(async (result) => {
      // Add 'async' here for the 'then' block
      if (result.isConfirmed) {
        const id_p = project_id;
        const updatedData = {
          assign_by: option.id,
          position: option.role_id,
        };

        try {
          // API call to update project status using 'await' since the function is now 'async'
          const response = await axios.post(
            `${API_URL}/api/entry_process/project-status/${id_p}`,
            updatedData
          );

          Swal.fire("Success!", "The assignee has been updated.", "success");
          fetchShowData(id);
        } catch (error) {
          Swal.fire("Error", "Failed to update the assignee", "error");
        }
      } else {
        // If the user clicks "Cancel", no action is taken
        console.log("Assignee change was canceled");
      }
    });
  };

  const filteredOptions = optionsAssigner.filter(
    (option) =>
      option.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      option.position.toLowerCase().includes(searchQuery.toLowerCase())
  );
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownAssgineStatus.current &&
        !dropdownAssgineStatus.current.contains(event.target)
      ) {
        setIsDropdownOpen(false);
      }
    };

    // Add event listener for clicks outside
    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      // Clean up event listener
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleDelete = async (fileName, documentId, createdById) => {
    const storedDetails = localStorage.getItem("medicsuser");
    const parsedDetails = JSON.parse(storedDetails);
    const currentUserId = parsedDetails ? parsedDetails.id : null;
    const currentUserRole = parsedDetails ? parsedDetails.position : null; // Assuming role is stored here, adjust if different

    // Admin check: If user is an admin, allow deletion of any file
    if (currentUserRole === "Admin") {
      const result = await Swal.fire({
        title: "Are you sure?",
        text: "Do you want to delete this document?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "Cancel",
      });

      if (result.isConfirmed) {
        try {
          const response = await fetch(
            `${API_URL}/api/entry_process/document-delete/${documentId}?created_by=${createdby}`,
            {
              method: "DELETE",
              headers: {
                "Content-Type": "application/json",
              },
            }
          );

          if (response.ok) {
            setFiles(files.filter((file) => file.documentId !== documentId));
            fetchShowData(id);
            Swal.fire("Success!", "File deleted successfully!", "success");
          } else {
            // Handle error response
            const errorData = await response.json();
            console.error("Error deleting document:", errorData.message);
          }
        } catch (error) {
          console.error("Error deleting document:", error.message);
        }
      } else {
        Swal.fire("Cancelled", "Your document is safe :)", "info");
      }
    } else {
      if (`'.${currentUserId}.'` === `'.${createdById}.'`) {
        const result = await Swal.fire({
          title: "Are you sure?",
          text: "Do you want to delete this document?",
          icon: "warning",
          showCancelButton: true,
          confirmButtonText: "Yes, delete it!",
          cancelButtonText: "Cancel",
        });

        if (result.isConfirmed) {
          try {
            const response = await fetch(
              `${API_URL}/api/entry_process/document-delete/${documentId}?created_by=${createdby}`,
              {
                method: "DELETE",
                headers: {
                  "Content-Type": "application/json",
                },
              }
            );
            if (response.ok) {
              setFiles(files.filter((file) => file.documentId !== documentId));
              fetchShowData(id);
              Swal.fire("Success!", "File deleted successfully!", "success");
            } else {
              const errorData = await response.json();
              console.error("Error deleting document:", errorData.message);
            }
          } catch (error) {
            console.error("Error deleting document:", error.message);
          }
        } else {
          Swal.fire("Cancelled", "Your document is safe :)", "info");
        }
      } else {
        Swal.fire(
          "Not Allowed",
          "You are not allowed to delete this document.",
          "error"
        );
      }
    }
  };

  const allOptions = [
    { value: "not_assigned", label: "Not Assigned" },
    { value: "pending_author", label: "Pending - Author" },
    { value: "completed", label: "Completed" },
    { value: "withdrawal", label: "Withdrawal" },
    { value: "in_progress", label: "In Progress" },
  ];

  // States to manage the dropdown
  const [isListExpanded, setIsListExpanded] = useState(false);
  const [chosenOption, setChosenOption] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const dropdownRef = useRef(null);

  // Filter options based on search term
  const filtereddepOptions = allOptions.filter((option) =>
    option.label.toLowerCase().includes(searchInput.toLowerCase())
  );

  const toggleList = () => setIsListExpanded(!isListExpanded);

  const handledepOptionSelect = async (option) => {
    Swal.fire({
      title: "Are you sure?",
      text: "Do you want to change the status?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, change it!",
      cancelButtonText: "Cancel",
    }).then(async (result) => {
      if (result.isConfirmed) {
        setChosenOption(option.value);
        setIsListExpanded(false);
        setSearchInput("");

        const id = project_id;
        const updatedData = {
          status: option.value,
          createdby: createdby,
        };
        document.getElementById("global-loader").style.display = "flex";

        setTimeout(async () => {
          try {
            // API call to update project status using 'await' since the function is now 'async'
            const response = await axios.post(
              `${API_URL}/api/entry_process/project-status/${id}`,
              updatedData
            );

            Swal.fire("Success!", "The assignee has been updated.", "success");
          } catch (error) {
            console.error("Error updating project status", error);
            Swal.fire("Error", "Failed to update the assignee", "error");
          } finally {
            document.getElementById("global-loader").style.display = "none";
          }
        }, 500);
      } else {
        console.log("Assignee change was canceled");
      }
    });
  };
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsListExpanded(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  //accept view show

  const [isAccepted, setIsAccepted] = useState(false);
  const [isRejected, setIsRejected] = useState(false);

  const handleAcceptClick = async () => {
    Swal.fire({
      title: "Are you sure?",
      text: "Do you want to accept this project?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, accept it!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        setIsAccepted(true);
        setIsRejected(false);
        const id_p = project_id;

        const updatedData = {
          project_id: project_id,
          type: "accepted",
          project_status: projectStatusVal,
          created_by: createdby,
          position: positionData,
        };
        // console.log("updatedData :", updatedData);

        document.getElementById("global-loader").style.display = "flex";
        setTimeout(async () => {
          try {
            const response = await axios.post(
              `${API_URL}/api/entry_process/project-status/${id_p}`,
              updatedData
            );

            Swal.fire({
              icon: "success",
              title: "Success",
              text: "Project accepted successfully!",
            });
            fetchShowData(id);
          } catch (error) {
            console.error("Error updating project status:", error);
          } finally {
            document.getElementById("global-loader").style.display = "none";
          }
        }, 500);
      }
    });
  };

  const handleRejectClick = async () => {
    Swal.fire({
      title: "Are you sure?",
      text: "Do you want to reject this project?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Yes, reject it!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        setIsRejected(true);
        setIsAccepted(false);
        setIsPopupVisible(true);

        // const id_p = project_id;
        // const updatedData = {
        //   project_status: "rejected",
        //   type: "rejected",
        //   status: projectStatusVal,
        //   created_by: createdby,
        // };

        //   try {
        //     const response = await axios.post(
        //       `${API_URL}/api/entry_process/project-status/${id_p}`,
        //       updatedData
        //     );
        //     fetchShowData(id);
        //   } catch (error) {
        //     console.error("Error updating project status:", error);
        //   }
      }
    });
  };

  //reject fuction
  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const [reason, setReason] = useState("");

  const handleCancel = () => {
    setIsPopupVisible(false);
    setReason("");
  };

  const handleSubmit = async () => {
    if (!reason.trim()) {
      setErrors({ reason: "Reason cannot be empty." });
      return;
    }

    const updatedData = {
      project_id: project_id,
      reason: reason,
      createdby: createdby,
      createdby_name: employee_name,
      type: "rejected",
      project_status: projectStatusVal,
    };
    // console.log("createdby:", updatedData);
    document.getElementById("global-loader").style.display = "flex";
    setTimeout(async () => {
      try {
        const response = await axios.post(
          `${API_URL}/api/projects/rejectreason`,
          updatedData
        );
        Swal.fire("Success!", "Reason submitted successfully!", "success");
        setErrors({});
        setIsPopupVisible(false);
        setReason("");
        fetchShowData(id);
      } catch (error) {
        console.error("Error updating project status", error);
        Swal.fire("Error", "Failed to update", "error");
      } finally {
        document.getElementById("global-loader").style.display = "none";
      }
    }, 500);
  };

  const handleReasonChange = (e) => {
    setReason(e.target.value);

    // Clear error when user starts typing
    if (errors.reason) {
      setErrors({});
    }
  };

  //upload documents

  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [files, setFiles] = useState([]);
  const [file, setFile] = useState(null);
  const [submittedFiles, setSubmittedFiles] = useState([]);

  const [otherInput, setOtherInput] = useState("");

  const initialCategory = type_of_work;

  const togglePopup = () => {
    setIsPopupOpen((prev) => !prev);
  };

  // reject icon

  const [isrejectapp, setRejectapp] = useState(false);

  const rejectallicon = () => {
    setRejectapp((prev) => !prev);
  };

  const optionsMapping = {
    statistics: [
      { value: "sample_size", label: "Sample Size" },
      { value: "paper_statistics", label: "Paper Statistics" },
      {
        value: "thesis_statistics_with_text",
        label: "Thesis Statistics - With Text",
      },
      {
        value: "thesis_statistics_without_text",
        label: "Thesis Statistics - Without Text",
      },
    ],
    manuscript: [
      { value: "writing", label: "Writing" },
      { value: "with_statistics", label: "With Statistics" },
      { value: "with_publication", label: "With Publication" },
    ],
    thesis: [
      {
        value: "supporting_thesis_with_ms",
        label: "Supporting Thesis with MS",
      },
      {
        value: "supporting_thesis_without_ms",
        label: "Supporting Thesis without MS",
      },
      { value: "supporting_thesis_part1", label: "Supporting Thesis Part - 1" },
      { value: "supporting_thesis_part2", label: "Supporting Thesis Part - 2" },
      {
        value: "supporting_thesis_part_with_ms",
        label: "Supporting Thesis Part - With MS",
      },
      {
        value: "supporting_thesis_part_without_ms",
        label: "Supporting Thesis Part - Without MS",
      },
      { value: "thesis_reviewing", label: "Thesis Reviewing" },
    ],
    presentation: [
      { value: "conference_presentation", label: "Conference Presentation" },
      { value: "with_statistics", label: "With Statistics" },
      { value: "poster_presentation", label: "Poster Presentation" },
    ],
    others: [],
  };

  const handleOtherInputChange = (event) => {
    setOtherInput(event.target.value);
  };

  const [uploadfile, setFileData] = useState([]);

  const handleFileChange = (event) => {
    const selectedFiles = Array.from(event.target.files);
    setFileAcData(selectedFiles);

    setErrors((prevErrors) => ({
      ...prevErrors,
      file: "",
    }));
  };

  const [projectStatus, setProjectOption] = useState([]);
  const [isDropdowncheck, setIsDropdowncheck] = useState(false);

  const handleOptionChange = (event) => {
    const option = event.target.value;
    if (event.target.checked) {
      setProjectOption((prevStatus) => [...prevStatus, option]);
    } else {
      setProjectOption((prevStatus) =>
        prevStatus.filter((status) => status !== option)
      );
    }

    if (option !== "Other") {
      setOtherInput("");
    }
  };

  const toggleDropcheck = () => {
    setIsDropdowncheck(!isDropdownOpen);
  };
  const dropselectRef = useRef(null);
  const handleClickOutsideselect = (event) => {
    if (
      isDropdowncheck &&
      dropselectRef.current &&
      !dropselectRef.current.contains(event.target)
    ) {
      setIsDropdowncheck(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutsideselect);
    return () => {
      document.removeEventListener("mousedown", handleClickOutsideselect);
    };
  }, [isDropdowncheck]);

  const handleUploadSubmit = async () => {
    let validationErrors = {};
    if (uploadAfile.length === 0) {
      validationErrors.file = "Please upload a file.";
    }
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    const updatedData = {
      project_id: project_id,
      createdby: createdby,
      createdby_name: employee_name,
    };

    const formDataToSend = new FormData();
    for (const key in updatedData) {
      formDataToSend.append(key, updatedData[key]);
    }

    if (uploadAfile.length > 0) {
      uploadAfile.forEach((file) => {
        formDataToSend.append("activity_file[]", file);
      });
    }

    try {
      document.getElementById("global-loader").style.display = "flex";

      // Upload files
      await axios.post(
        `${API_URL}/api/projects/document_uploads`,
        formDataToSend,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      const statusUpdateData = {
        status: assigneeStatus,
        position: initialstatus,
        type: "assignstatus",
        created_by: createdby,
        createdby_name: employee_name,
      };

      try {
        await axios.post(
          `${API_URL}/api/entry_process/project-status/${project_id}`,
          statusUpdateData
        );

        setFileData([]);
        setSubmittedFiles([]);
        setProjectOption([]);
        setIsDropdowncheck(false);
        setFile(null);
        setErrors({});
        setReason("");
        setIsPopupOpen(false);

        setSelectedStatus(assigneeLStatus);
        setIsDropdownOpenAssigne(false);
        setSearchQueryAssigne("");
        fetchShowData(id);
        Swal.fire(
          "Success!",
          "The assignee status has been updated.",
          "success"
        );
      } catch (error) {
        console.error("Error updating project status", error);
        Swal.fire("Error", "Failed to update the assignee", "error");
      }
    } catch (error) {
      console.error("Error uploading files:", error);
      Swal.fire("Error", "Failed to upload files. Please try again.", "error");
    } finally {
      document.getElementById("global-loader").style.display = "none";
    }
  };

  //assigne status
  const [isDropdownOpenAssigne, setIsDropdownOpenAssigne] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState("");
  const [searchQueryAssigne, setSearchQueryAssigne] = useState("");
  const dropdownRefAssigne = useRef(null);

  const AssgineStatus = {
    writer: [
      { value: "on_going", label: "On Going" },
      { value: "completed", label: "Completed" },
      { value: "need_support", label: "Need Support" },
      { value: "revert", label: "Revert" },
    ],
    reviewer: [
      { value: "on_going", label: "On Going" },
      { value: "completed", label: "Completed" },
      { value: "need_support", label: "Need Support" },
      { value: "revert", label: "Revert" },
    ],
    statistican: [
      { value: "on_going", label: "On going" },
      { value: "completed", label: "Completed" },
      { value: "need_support", label: "Need Support" },
      { value: "revert", label: "Revert" },
    ],
  };

  const initialstatus = selectedOption?.position?.toLowerCase();
  // console.log("initialstatus", initialstatus);
  const filteredStatusOptions =
    AssgineStatus[initialstatus]?.filter((status) =>
      status.label.toLowerCase().includes(searchQueryAssigne.toLowerCase())
    ) || [];
  // console.log("filter", filteredStatusOptions);
  const toggleDropdownAssigne = () => {
    setIsDropdownOpenAssigne(!isDropdownOpenAssigne);
  };

  const [assigneeStatus, setAssigneeStatus] = useState("");
  const [assigneeLStatus, setAssigneeLStatus] = useState("");

  const handleStatusSelect = async (status) => {
    if (status.value === "completed") {
      togglePopup();
      setAssigneeStatus(status.value);
      setAssigneeLStatus(status.label);
    } else {
      Swal.fire({
        title: "Are you sure?",
        text: "Do you want to change the assignee status?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, change it!",
        cancelButtonText: "Cancel",
      }).then(async (result) => {
        if (result.isConfirmed) {
          const id = project_id;
          const updatedData = {
            status: status.value,
            position: initialstatus,
            type: "assignstatus",
            created_by: createdby,
            createdby_name: employee_name,
          };

          try {
            const response = await axios.post(
              `${API_URL}/api/entry_process/project-status/${id}`,
              updatedData
            );

            setSelectedStatus(status.label);
            setIsDropdownOpenAssigne(false);
            setSearchQueryAssigne("");
            Swal.fire(
              "Success!",
              "The assignee status has been updated.",
              "success"
            );
            fetchShowData(id);
          } catch (error) {
            console.error("Error updating project status", error);
            Swal.fire("Error", "Failed to update the assignee", "error");
          }
        }
      });
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownRefAssigne.current &&
        !dropdownRefAssigne.current.contains(event.target)
      ) {
        setIsDropdownOpenAssigne(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  //reject reason
  const [isPopupVisibleReject, setIsRejectPopupVisible] = useState(false);
  const [rejectReasonData, setRejectReasonData] = useState([]);

  const handleViewRejectReason = async (createduserid) => {
    setIsRejectPopupVisible(true);

    try {
      const response = await axios.post(
        `${API_URL}/api/projects/rejectreason-view`,
        {
          created_by: createduserid,
          project_id: project_id,
        }
      );
      setRejectReasonData(response.data?.reasonlist || []);
      setIsRejectPopupVisible(true);
    } catch (error) {
      console.error("Error fetching reject reasons:", error);
      setRejectReasonData([{ reason: "Unable to fetch reject reasons" }]);
      setIsRejectPopupVisible(true);
    }
  };

  const toggleRejectPopup = () => {
    setIsRejectPopupVisible((prev) => !prev);
  };

  const [replyText, setReplyText] = useState("");
  const [activeReplyId, setActiveReplyId] = useState(null);

  const [replies, setReplies] = useState(reason.replies || []);

  const handleReplyClick = (id) => {
    setActiveReplyId(id === activeReplyId ? null : id);
  };

  const handleReplyChange = (e) => {
    setReplyText(e.target.value);
  };

  const handleReplySubmit = async (replyid) => {
    if (replyText.trim()) {
      setReplies((prevReplies) => ({
        ...prevReplies,
        [replyid]: [...(prevReplies[replyid] || []), replyText],
      }));
      setReplyText("");
      setActiveReplyId(null);

      const updatedData = {
        activity_id: replyid,
        project_id: project_id,
        createdby: createdby,
        createdby_name: employee_name,
        content: replyText,
      };

      try {
        const response = await axios.post(
          `${API_URL}/api/projects/project-reply-activity`,
          updatedData
        );
        Swal.fire("Success!", "Reply submitted successfully!", "success");

        // Clear errors, reset popup visibility, and fetch updated data
        setErrors({});
        setIsPopupVisible(false);
        setReason(""); // Assuming this is another state you're clearing
        fetchShowData(id); // Fetch updated data (ensure this works properly)
      } catch (error) {
        Swal.fire("Error", "Failed to submit reply", "error");
      }
    } else {
      Swal.fire("Warning", "Please enter a valid reply.", "warning");
    }
  };

  const removeHtmlTags = (html) => {
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = html;
    return tempDiv.textContent || tempDiv.innerText || "";
  };

  // writer dropdown all

  const [writter, setWritter] = useState([]);

  // console.log("writerdata:", writter);
  const [reviewerdrop, setReviewer] = useState([]);
  const [statistical, setStatistical] = useState([]);
  const [journal, setJournal] = useState([]);

  const [rejectedAssignIds, setRejectedAssignIds] = useState([]);

  const fetchDataall = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/getEmployeeName`
      );
      const data = response.data;
      // console.log('data :', data);

      if (data) {
        // console.log('rejectUserData :',rejectUserData);
        // Extract assign_ids from rejected list
        // const rejectedAssignIds = rejectUserData
        //   .map((item) => (item?.assign_id ? String(item.assign_id) : null))
        //   .filter((id) => id !== null);

        const assignIds = rejectUserData
          .map((item) => (item?.assign_id ? String(item.assign_id) : null))
          .filter((id) => id !== null);

        setRejectedAssignIds(assignIds);

        // DO NOT filter out rejected writers here — keep all

        // console.log('rejectedAssignIds :', rejectedAssignIds);
        // Filter writers - keep only those not in rejected list
        // const filteredWriters = (data.writer || []).filter(
        //   (writer) => !rejectedAssignIds.includes(writer.id.toString())
        // );

        // Filter statisticans - keep only those not in rejected list
        const filteredStatisticans = (data.statistican || []).filter(
          (stat) => !rejectedAssignIds.includes(stat.id.toString())
        );

        // Filter reviewer - keep only those not in rejected list
        const filteredReviewer = (data.reviewer || []).filter(
          (stat) => !rejectedAssignIds.includes(stat.id.toString())
        );

        // Filter journal - keep only those not in rejected list
        const filteredournal = (data.journal || []).filter(
          (stat) => !rejectedAssignIds.includes(stat.id.toString())
        );

        // console.log('data.reviewer :',data.reviewer);
        // console.log('filteredReviewer :',filteredReviewer);

        // Update state with filtered data
        // setWritter(filteredWriters);
        setWritter(data.writer || []);
        setReviewer(data.reviewer || []);
        setStatistical(data.statistican || []);
        setJournal(filteredournal);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };


    const [showFilesModal, setShowFilesModal] = useState(false);
    const [modalFiles, setModalFiles] = useState([]);
  
    const openFilesModal = (files) => {
      setModalFiles(files);
      setShowFilesModal(true);
    };
  
    const closeFilesModal = () => {
      setShowFilesModal(false);
      setModalFiles([]);
    };

  useEffect(() => {
    fetchDataall();
  }, [rejectUserData]);

  //status change
  const [statisticanStatus, setStatisticanStatus] = useState("");
  const [writerStatus, setWriterStatus] = useState("");
  const [reviewerStatus, setReviewerStatus] = useState("");
  const [journalStatus, setJournalStatus] = useState("");
  const [smeStatus, setSmeStatus] = useState("");

  const [oldid, setoldid] = useState([]);
  // console.log("oldid:", oldid);

  // writer

  const handleReassignWriter = async (new_employee_id, assign_id) => {
    const payload1 = {
      project_id: project_id,
      employee_id: assign_id,
      new_employee_id: new_employee_id,
    };
    // console.log("payloadwriter:", payload1);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to reassign this writer?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, reassign!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/update_status`,
            payload1
          );

          if (response.status === 200) {
            Swal.fire(
              "Success",
              "Writer reassigned successfully",
              "success"
            ).then(() => {
              window.location.reload();
            });
            // Call any data-refreshing function here, e.g. fetchShowData(project_id);
          } else {
            Swal.fire("Error", "Failed to reassign writer", "error");
          }
        } catch (error) {
          console.error("Reassign error:", error);
          Swal.fire("Error", "Failed to reassign writer", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  const handleReassignReviwer = async (new_employee_id, assign_id) => {
    const payload1 = {
      project_id: project_id,
      employee_id: assign_id,
      new_employee_id: new_employee_id,
    };
    // console.log("payloadwriter:", payload1);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to reassign this writer?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, reassign!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/update_status`,
            payload1
          );

          if (response.status === 200) {
            Swal.fire(
              "Success",
              "Writer reassigned successfully",
              "success"
            ).then(() => {
              window.location.reload();
            });
            // Call any data-refreshing function here, e.g. fetchShowData(project_id);
          } else {
            Swal.fire("Error", "Failed to reassign writer", "error");
          }
        } catch (error) {
          console.error("Reassign error:", error);
          Swal.fire("Error", "Failed to reassign writer", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  const handleReassignstatistican = async (new_employee_id, assign_id) => {
    const payload1 = {
      project_id: project_id,
      employee_id: assign_id,
      new_employee_id: new_employee_id,
    };
    // console.log("payloadwriter:", payload1);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to reassign this writer?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, reassign!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/update_status`,
            payload1
          );

          if (response.status === 200) {
            Swal.fire(
              "Success",
              "Writer reassigned successfully",
              "success"
            ).then(() => {
              window.location.reload();
            });
            // Call any data-refreshing function here, e.g. fetchShowData(project_id);
          } else {
            Swal.fire("Error", "Failed to reassign writer", "error");
          }
        } catch (error) {
          console.error("Reassign error:", error);
          Swal.fire("Error", "Failed to reassign writer", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  // Assign
  // const Duration = getTotalDuration(selectedOption, type_of_work)

  const handleAssignWriter = async (new_employee_id) => {
    // console.log("summacheck:", documentname, type_of_work);
    const Duration = getTotalDuration(documentname, type_of_work);
    // console.log("Duration :", Duration);

    const payloadwriter = {
      project_id: project_id,
      assign_user: new_employee_id,
      created_by: createdby,
      type: "writer",
      project_duration: Duration.writer,
    };
    // console.log("payloadwriter:", payloadwriter);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to Assign this writer?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Assign!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/assign-user-tc`,
            payloadwriter
          );

          if (response.status === 200) {
            Swal.fire(
              "Success",
              "Writer assigned successfully",
              "success"
            ).then(() => {
              window.location.reload();
            });
            // Call any data-refreshing function here, e.g. fetchShowData(project_id);
          } else {
            Swal.fire("Error", "Failed to assign writer", "error");
          }
        } catch (error) {
          console.error("assign error:", error);
          Swal.fire("Error", "Failed to assign writer", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  const handleAssignReviewer = async (new_employee_id) => {
    // console.log("summacheck:", documentname, type_of_work);
    const Duration = getTotalDuration(documentname, type_of_work);
    // console.log("Duration :", Duration);

    const payloadwriter = {
      project_id: project_id,
      assign_user: new_employee_id,
      created_by: createdby,
      type: "reviewer",
      project_duration: Duration.reviewer,
    };
    // console.log("payloadwriter:", payloadwriter);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to Assign this reviewer?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Assign!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/assign-user-tc`,
            payloadwriter
          );

          if (response.status === 200) {
            Swal.fire(
              "Success",
              "Reviewer assigned successfully",
              "success"
            ).then(() => {
              window.location.reload();
            });
            // Call any data-refreshing function here, e.g. fetchShowData(project_id);
          } else {
            Swal.fire("Error", "Failed to assign writer", "error");
          }
        } catch (error) {
          console.error("assign error:", error);
          Swal.fire("Error", "Failed to assign writer", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  const handleAssignStatistican = async (new_employee_id) => {
    // console.log("summacheck:", documentname, type_of_work);
    const Duration = getTotalDuration(documentname, type_of_work);
    // console.log("Duration :", Duration);

    const payloadwriter = {
      project_id: project_id,
      assign_user: new_employee_id,
      created_by: createdby,
      type: "statistican",
      project_duration: Duration.statistician,
    };
    // console.log("payloadwriter:", payloadwriter);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to Assign this statistican?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Assign!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      document.getElementById("global-loader").style.display = "flex";

      setTimeout(async () => {
        try {
          const response = await axios.post(
            `${API_URL}/api/entry_process/assign-user-tc`,
            payloadwriter
          );

          if (response.status === 200) {
            Swal.fire(
              "Success",
              "statistican Assigned successfully",
              "success"
            ).then(() => {
              window.location.reload();
            });
            // Call any data-refreshing function here, e.g. fetchShowData(project_id);
          } else {
            Swal.fire("Error", "Failed to assign writer", "error");
          }
        } catch (error) {
          console.error("assign error:", error);
          Swal.fire("Error", "Failed to assign writer", "error");
        } finally {
          document.getElementById("global-loader").style.display = "none";
        }
      }, 500);
    }
  };

  // useEffect(() => {
  //   const handleLoad = () => {
  //     setTimeout(() => {
  //       setLoading(false);
  //     }, 1000);
  //   };

  //   if (document.readyState === "complete") {
  //     handleLoad();
  //   } else {
  //     window.addEventListener("load", handleLoad);
  //   }

  //   return () => window.removeEventListener("load", handleLoad);
  // }, []);

  // if (loading) {
  //   return <Loader />;
  // }

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <section className="container container d-flex flex-column justify-content-between min-vh-100">
          <div className="mt-4 w-100">
            <div className="col-12 ">
              <div className="col-12">
                <Header></Header>
              </div>
              <div className=" pt-1 mt-3 py-3 project-manage w-100 ">
                <div className=" row mt-3 d-flex   w-100 ">
                  <div className="col-12 col-md-6  px-3 pt-3">
                    <h1 className="view-heading">
                      {CapitalizeCaseU(progess.project_id)}
                    </h1>
                  </div>

                  <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                    <Breadcrumbs></Breadcrumbs>
                  </div>
                </div>
                {/* ............... */}

                <div className="row">
                  <section className="col-7 view-border-div">
                    <section className="p-3">
                      <div className="file-table-container mt-0 ">
                        <table className="file-table">
                          <thead>
                            <tr className="text-center tr-head">
                              <th className="table-task-view">Date</th>
                              <th className="table-task-view">
                                Created by
                              </th>

                              <th className="table-task-view">Files</th>
                              <th className="table-task-view " rowSpan={5}>
                                Comments
                              </th>
                              {/* <th className="table-task-view">ACTIONS</th> */}
                            </tr>
                          </thead>
                          <tbody>
                            {createdbyFiles.length === 0 ? (
                              <tr className="text-center">
                                <td colSpan="6">No records found</td>
                              </tr>
                            ) : (
                              createdbyFiles.map((file, index) => (
                                <tr key={index} className="text-center tr-head">
                                  <td className="task-view-table-name">
                                    {/* {getTimeDateFormate(file.added_at)} */}
                                    {file.added_at}
                                  </td>

                              
                                  <td className="task-view-table-name">
                                    {(file.role_name || "")
                                      .split(",")
                                      .map(
                                        (role) =>
                                          ({ 7: "Writer", 8: "Reviewer" }[
                                            role.trim()
                                          ] || role.trim())
                                      )
                                      .join(", ")}
                                  </td>
                                  {/* <td className="task-view-table-name">
                                    <div className="d-flex flex-row gap-2">
                                      {file.files?.map(
                                        (singleFile, fileIndex) => (
                                          <div
                                            key={fileIndex}
                                            title={`${singleFile.file_name}\nUploaded: ${singleFile.created_at}\nType`}
                                            style={{ position: "relative" }}
                                          >
                                            <span
                                              onClick={() =>
                                                handleDownload(
                                                  singleFile.file_path
                                                )
                                              }
                                              style={{ cursor: "pointer" }}
                                            >
                                              {getFileIcon(
                                                singleFile.extension
                                              )}
                                            </span>
                                          
                                          </div>
                                        )
                                      )}
                                    </div>
                                  </td> */}

                                  
                                    <td className="task-view-table-name">
                                      <div className="d-flex flex-row gap-2 align-items-center">
                                        {file.files?.slice(0, 2).map((singleFile, fileIndex) => (
                                          <span
                                            key={fileIndex}
                                            title={singleFile.file_name}
                                            onClick={() =>
                                              handleDownload(singleFile.file_path, singleFile.file_name)
                                            }
                                            style={{ cursor: "pointer" }}
                                          >
                                            {getFileIcon(singleFile.extension)}
                                          </span>
                                        ))}

                                        {/* Show ... if more than 2 files */}
                                        {file.files?.length > 2 && (
                                          <span
                                            className="fw-bold cursor-pointer"
                                            style={{ cursor: "pointer" }}
                                            onClick={() => openFilesModal(file.files)}
                                          >
                                            ...
                                          </span>
                                        )}
                                      </div>
                                    </td>
                                  <td className="task-view-table-name-scroll">
                                    <div className="task-view-table-content commend-width">
                                      <div key={index}>
                                        <span
                                          // className="span-view-task"
                                          dangerouslySetInnerHTML={{
                                            __html: file.comments,
                                          }}
                                        />
                                      </div>
                                    </div>
                                  </td>
                                  {/* <td>
                                                  <button
                                                    className="download-button-file"
                                                    onClick={() => handleDownload(file.files)}
                                                  >
                                                    <FiDownload />
                                                  </button>
                                                </td> */}
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>
                    </section>
                    {widthdraw === "withdrawal" && (
                      <div class="withdrawn-style">Withdrawn</div>
                    )}
                  </section>

                  <section className="col-sm-12 col-md-5 pt-5">
                    <div className="col-12 px-1">
                      <div className="view-heading-title ">
                        Project Title:
                        <span className="view-project-title mx-2 ">
                          {CapitalizeCaseU(progess.title)}
                        </span>
                      </div>

                      <div className="view-heading-title mt-1">
                        Project Comments:
                        <span className="command-project mx-2">
                          {projectcomments.map((comment, index) => (
                            <span key={index}>
                              <span
                                dangerouslySetInnerHTML={{
                                  __html: removeEmptyTags(
                                    CapitalizeCaseU(comment.commend_box || "")
                                      .replace(/<p>/g, "<span>")
                                      .replace(/<\/p>/g, "</span>")
                                  ),
                                }}
                              />
                            </span>
                          ))}
                        </span>
                      </div>

                      <div className="view-heading-title mt-1">
                        Project Requirement:
                        <span className="mx-1">
                          {alldocumnts.map((item, index) => (
                            <span key={index} className="mx-1">
                              {CapitalizeCase(item)}
                              {index !== alldocumnts.length - 1 && ","}
                            </span>
                          ))}
                        </span>
                      </div>

                      {/* <div className="view-heading-title mt-1">
                      Journal Name:
                      <span className="mx-1">
                        {CapitalizeCase(journaldata.assign_user)}
                      </span>
                    </div> */}
                      <div className="view-heading-title mt-1 ">
                        Journal Comments:
                        <span className="view-project-title mx-2 ">
                          {CapitalizeCaseU(journalcomments)}
                        </span>
                      </div>
                      {/* <div className="view-heading-title mt-1">
                      Type of Article:
                      <span className="mx-1">
                        {CapitalizeCase(journaldata.type_of_article)}
                      </span>
                    </div>
                    <div className="view-heading-title mt-1">
                      Type of Review:
                      <span className="mx-1">
                        {CapitalizeCase(journaldata.review)}
                      </span>
                    </div> */}
                    </div>

                    <div className="col-12  pb-0 px-1">
                      <div className="view-heading-title mt-3 ">
                        Common Files :
                      </div>
                      <div className="d-flex flex-row gap-2">
                        {commonFilesall.map(
                          (fileName, index) =>
                            fileName && (
                              <div
                                key={index}
                                title={`${fileName.files}\nUploaded`}
                                style={{ position: "relative" }}
                              >
                                <span
                                  onClick={() =>
                                    handleCommonFileDownload(fileName.files)
                                  }
                                  style={{ cursor: "pointer" }}
                                >
                                  {getFileIcon(
                                    fileName.files
                                      ? fileName.files.split(".").pop()
                                      : ""
                                  )}
                                </span>
                              </div>
                            )
                        )}
                      </div>
                    </div>

                    <div>
                      <div className="row px-2 pb-0">
                        <div className="col-12  pb-0">
                          <div className="view-heading-title mt-3 ">
                            Activity
                          </div>
                        </div>
                      </div>

                      <section className="">
                        <div className="px-2 mx-1  all-boder">
                          <div className="col-10  pt-0 box-line mt-2">
                            <Editor
                              key={editorKey}
                              placeholder="Type your comment..."
                              name="commandbox"
                              value={formData.commandbox}
                              onTextChange={handleTextChange}
                            />
                          </div>

                          <section className="mt-2">
                            <div className="d-flex gap-2 align-items-center">
                              <div className="view-heading-title">
                                Files Upload :
                              </div>{" "}
                              <input
                                ref={fileInputRef}
                                type="file"
                                multiple
                                className="input-file-upload"
                                onChange={(e) => {
                                  handleActivityFileChange(e);
                                }}
                              />
                            </div>
                            <div>
                              <button
                                className="save-form-task mb-2 mt-1 pt-1"
                                onClick={handleEditorChange}
                              >
                                Submit
                              </button>
                            </div>
                          </section>
                        </div>
                      </section>
                    </div>

                    <div className="w-100 d-flex align-items-center mt-3">
                      <p className="created-by mb-0">Publication Status</p>
                      <div className="w-100">
                        <div className="pb-2">
                          <div className="view-project-title d-flex align-items-center w-100"></div>

                          <div className="dropdown-container1 w-55">
                            {/* <div className="mb-2 text-primary">
                              {publicdataa ? publicdataa : "No status"}
                            </div> */}
                            <select
                              className="form-select dropdown-header-view pt-2"
                              name="publication_manager"
                              // value={publicdata}
                              onChange={(e) => handleNeedChange(e)}
                              value={publicdataa}
                            >
                              <option value="" disabled selected>
                                Select Status
                              </option>
                              <option value="submit_to_journal">
                                Submit to Journal
                              </option>
                              <option value="pending_author">
                                Pending Author
                              </option>
                              <option value="submitted">Submitted</option>
                              <option value="rejected">Rejected</option>
                              <option value="peer_review">Peer Review</option>
                              <option value="resubmission">Resubmission</option>
                              <option value="reviewer_comments">
                                Reviewer Comments
                              </option>
                              <option value="published">Published</option>
                              <option value="withdrawal">Withdrawal</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                </div>

                 {showFilesModal && (
                      <>
                        <div className="custom-modal-box">
                          <div className="modal-dialog-box modal-dialog-centered">
                            <div className="modal-content">
                              <div className="modal-header">
                                <h5 className="modal-title">Files</h5>
                                <button
                                  type="button"
                                  className="btn-close"
                                  onClick={closeFilesModal}
                                ></button>
                              </div>

                              <div className="modal-body pdf-modal-body">
                                {modalFiles
                                  .filter((file) => file.extension)
                                  .map((file, index) => (
                                    <div
                                      key={index}
                                      className="pdf-row"
                                      onClick={() =>
                                        handleDownload(file.file_path, file.file_name)
                                      }
                                    >
                                      <div className="pdf-icon">
                                        {getFileIcon(file.extension)}
                                      </div>

                                      <div className="pdf-name">
                                        {file.file_name}
                                      </div>
                                    </div>
                                  ))}
                              </div>


                              <div className="modal-footer">
                                <button
                                  className="btn btn-secondary"
                                  onClick={closeFilesModal}
                                >
                                  Close
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="custom-backdrop" onClick={closeFilesModal}></div>
                      </>
                    )}

                {/* ...................... */}
                <section className=" pt-1 mt-4 ">
                  <div className="form-border-public mt-2">
                    <div className="side-form">
                      {" "}
                      <Public_form_side
                        onSelectForm={setSelectedForm}
                        activeForm={selectedForm}
                        allid={allid}
                      />
                    </div>
                    <div className="form-content-public">
                      {selectedForm ? (
                        formComponents[selectedForm]
                      ) : (
                        <p>Select a form to view</p>
                      )}
                    </div>
                  </div>
                </section>
              </div>
            </div>
          </div>
          <div>
            <Footer />
          </div>
        </section>
      )}
    </>
  );
}

export default Public_view;
