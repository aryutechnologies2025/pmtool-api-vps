import React from "react";

function Coverletter() {
  
  return (
    <>
      <div className="container my-5">
        <div className="text-end">
          From:
          <br />
          Date: DD/MM/YYYY
        </div>
        <br />
        <h5>CORRESPONDING AUTHOR NAME</h5>
        <br />
        <p>To,</p>
        <p>
          The Editor,
          <br />
          JOURNAL NAME
        </p>
        <br />
        <p>
          <strong>Sub:</strong> Submission of manuscript for publication as a
          research article.
        </p>
        <p>Dear Editor,</p>
        <p>
          I <strong>CORRESPONDING AUTHOR NAME</strong> on behalf of my
          co-authors submit the following manuscript for publication
          consideration. I understand the objectives of the journal and have
          formatted the manuscript to fit the style and needs of the journal. I
          confirm that the manuscript has been prepared for and sent only to the
          <strong>(JOURNAL NAME)</strong> for publication consideration and not
          submitted to any other journal or any other type of publication either
          by me or any of my co-authors.
        </p>
        <p>
          <strong>Title of the Article:</strong> TITLE OF THE PROJECT
        </p>
        <p>
          <strong>Type of Article:</strong> TYPE OF ARTICLE
        </p>
        <p>
          <strong>Conflict of interest:</strong> Nil
        </p>
        <p>
          <strong>Source of funding:</strong> Nil
        </p>
        <br />
        <p>
          <strong>Author Name and Affiliation (In sequence):</strong>
        </p>
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Author Order</th>
              <th>Author Name</th>
              <th>Affiliation (Department, Institution, State, Country)</th>
            </tr>
          </thead>
          <tbody>
            
          </tbody>
        </table>
        <br />
        <p>
          <strong>Corresponding Author:</strong>
        </p>
       

<table className="table table-bordered">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email id / Phone Number</th>
              <th>Affiliation</th>
            </tr>
          </thead>
          <tbody>
          
          </tbody>
        </table>
      </div>
    </>
  );
}

export default Coverletter;


