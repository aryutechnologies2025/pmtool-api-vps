import React from "react";
import "../assests/css/entryprocess.css";
import { API_URL } from "../config.js";
import { IoIosSearch } from "react-icons/io";
// import { IoFilter } from "react-icons/io5";
import { IoMdAdd } from "react-icons/io";
import { VscGitStashPop } from "react-icons/vsc";
import { VscEye } from "react-icons/vsc";
import { NavLink } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";
import Breadcrumbs from "../routes/Breadcrumbs";

import "react-datepicker/dist/react-datepicker.css";
import Header from "../components/Header.js";
import ReactDOM from "react-dom";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";

import { Capitalize } from "../campsCase.js";

import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";

import { useLocation } from "react-router-dom";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";



DataTable.use(DT);
function Public_list_view() {
  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const location = useLocation();
  const { type } = location.state || {};
  // console.log("type :",type);
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  // console.log("alldata:",filteredData)
  const[important,setImportant]=useState([]);
  // console.log("emegergy:",important)

  const fetchData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/author/publication-status`,
        {
            params: {
              type: type || "",
              position: "28"
              
            },
          });
        console.log("response:",response);

        const originaltodoData = response.data.data;
        const flattenedToData = originaltodoData.map(item => ({
         id: item.id,
         project_id: item.project_id,
         type_of_work: item.type_of_work,
         journal_status: item.journal_status[0].status,
         project_status: item.process_status,
         payment_status: item.payment_status.payment_status,
         department: item.department.name,
        }));

      setData(flattenedToData);
      setFilteredData(flattenedToData);
      setImportant(response.data.data);
      
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const navigate = useNavigate();


  const handleViewClick = (id) => {
    navigate("/public-list-view/public-view-details", {
      state: { rowId: id },
    });
  };


  const columns = [

    { title: "PROJECT ID", data: "project_id", render: (data) => Capitalize(data) },
    {
      title: "TYPE OF WORK",
      data: "type_of_work",
      render: (data) => Capitalize(data)
    },
    // {
    //   title: "WRITER STATUS",
    //   data: "writer_status",
    //   render: (data) => data ? CapitalizeCaseU(data.replace(/,/g, ", ")) : "-"
    // },
    // {
    //   title: "REVIEWER STATUS",
    //   data: "reviewer_status",
    //   render: (data) => data ? CapitalizeCaseU(data.replace(/,/g, ", ")) : "-"
    // },
    // {
    //   title: "STATISTICAN STATUS",
    //   data: "statistican_status",
    //   render: (data) => data ? CapitalizeCaseU(data.replace(/,/g, ", ")) : "-"
    // },
    {
      title: "JOURNAL STATUS",
      data: "journal_status",
      render: (data) => data ? CapitalizeCaseU(data) : "-"
    },
    {
      title: "PROJECT STATUS",
      data: "project_status",
      render: (data) => data ? CapitalizeCaseU(data) : "-"
    },
    {
      title: "PAYMENT STATUS",
      data: "payment_status",
      render: (data) => data ? CapitalizeCaseU(data) : "-"
    },
    {
      title: "ACTIONS",
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                <div className="" title="View">
                  <span>
                    <VscEye
                      onClick={() => handleViewClick(row.id)}
                      className="open-icon"
                    />
                  </span>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    }
  ];

  return (
    <section className="container d-flex flex-column min-vh-100 justify-content-between">
      <div className=" row mt-4">
        {/* <div className=" col-1   d-flex justify-content-center">
          <Sider></Sider>
        </div> */}

        <div className="col-12  ">
          <div className="col-12">
            <Header></Header>
          </div>

          <div className="col-12 mt-3 pt-1 wapper w-100 py-5">
            <div className=" row mt-3 d-flex   w-100 ">
              <div className="col-12 col-md-9  px-4 ">
                <p className="heading-entr">Project View</p>
              </div>
              <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>

            <div className="px-1">
              <DataTable
                id="example"
                data={filteredData}
                columns={columns}
                className="display"
                options={{
                  scrollX: true,
                  select: true,
                  pageLength: 20, // Default number of rows per page
                  lengthMenu: [
                    [20, 30, 50],
                    [20, 30, 50],
                  ],
                }}
              />
            </div>
          </div>
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </section>
  );
}

export default Public_list_view;
