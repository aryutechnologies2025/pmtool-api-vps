import React from "react";
import "../assests/css/public.css";

import { BsBarChartLine } from "react-icons/bs";
import Sider from "../components/Sider.js";

import Header from "../components/Header.js";
import { AiOutlineAlert } from "react-icons/ai";
import { MdDoNotDisturb } from "react-icons/md";
import { FaFileInvoiceDollar } from "react-icons/fa6";
import { GiPiggyBank } from "react-icons/gi";
import "../assests/css/project_management.css";
import ReactDOM from "react-dom";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { useState, useEffect } from "react";
import { VscGitStashPop } from "react-icons/vsc";

import { IoMdAdd } from "react-icons/io";
import Footer from "../components/Footer.js";
import Tooltip from "@mui/material/Tooltip";
import { useNavigate } from "react-router-dom";
import Breadcrumbs from "../routes/Breadcrumbs.js";
import { VscEye } from "react-icons/vsc";

// icon
import { TbHourglassLow } from "react-icons/tb";
import { SiFreelancer } from "react-icons/si";
import { SiQuicklook } from "react-icons/si";
import { MdOutlineComment } from "react-icons/md";
import { FaFilePrescription } from "react-icons/fa6";

import axios from "axios";
import { Link } from "react-router-dom";
// import { combineEventHandlers } from "recharts/types/util/ChartUtils.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import Public_form_side from "./Public_form_side.js";
import Authour_form from "./Authour_form.js";
import Upload_files from "./Upload_files.js";
import Submission_form from "./Submission_form.js";
import Reviewer_comments from "./Reviewer_comments.js";
import Rejection_form from "./Rejection_form.js";
import Resubmission from "./Resubmission.js";
import Loader from "../components/Loader.js";

DataTable.use(DT);

function Publication_dashboard() {
  const [data, setData] = useState([]);
  const [dataFoot, setFootData] = useState([]);
  // const [dataPeople, setDataPeople] = useState([]);
  const [dataPeopleInhouse, setDataPeopleInHouse] = useState([]);
  const [dataPeopleExtranel, setDataPeopleExternal] = useState([]);

  useEffect(() => {
    // fetchProjectManagerData();
    const interval = setInterval(() => {
      fetchProjectManagerData();
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  

  // const handleNavigate = (type, createdby) => {
  //   // navigate(`/employee-project-list`, { state: { type, createdby } });
  //   navigate(`/employe-project-list`, { state: { type, createdby } });
  // };

  const handleProNavigate = (params) => {
    navigate(`/public-list-view`, { state: params });
  };
    const [loading, setLoading] = useState(true);


  //dashboard list

  const [journalTotal, setJournal] = useState([]);
  const [dasCount, setCountVal] = useState([]);
  const [progess, setProgess] = useState([]);
  const [resubmission, setResubmission] = useState([]);
  const [reviewercomment, setReviewercomment] = useState([]);

  // console.log("journaltotal", journalTotal);
  // console.log("dascount:", dasCount);
  // console.log("progresscount:", progess);
  // console.log("resubmission:", resubmission);
  // console.log("reviewercomment:", reviewercomment);

  const fetchProjectManagerData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/publication_manager/publication-list`
      );
      console.log("fetchProjectManagerData:", response.data);

      const data = response.data?.data || {};

      // console.log("alldetails:", data);

      setJournal(data.publication_count || 0);
      setCountVal(data);
      setProgess(data.in_progress || []);
      setResubmission(data.resubmission_list || []);
      setReviewercomment(data.reviewerComments_list || []);
            setLoading(false);

    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const navigate = useNavigate();

  const handleEditClick = (id) => {
    navigate("/entry-process/entryprocess-update-form", {
      state: { rowId: id },
    });
  };
      // console.log('loading :', loading)
      // useEffect(() => {
      //   const handleLoad = () => {
      //     setTimeout(() => {
      //       setLoading(false);
      //     }, 5000);
      //   };
      //   if (document.readyState === "complete") {
      //   handleLoad();
      // } else {
      //   window.addEventListener("load", handleLoad);
      // }
      //       return () => window.removeEventListener("load", handleLoad);
  
      // }, []);
     
      // if (loading) {
      //     return <Loader />;
      //   }
  // jour

  const freelancerId = localStorage.getItem("empname");
  const projectIds = JSON.parse(localStorage.getItem("projectallid"));

  // console.log("Freelancer ID:", freelancerId);
  // console.log("Project IDs:", projectIds);

  const handleEmergencyClick = () => {
    // const freelancerId = freelancer_id;
    const projectIds = dasCount.urgentImport_ids.map((item) => item);

    // Store in localStorage
    localStorage.setItem("empname", freelancerId);
    localStorage.setItem("projectallid", JSON.stringify(projectIds));

    // Open the project list page in a new tab
    window.open("/projectlist", "_blank");
  };

  return (
    <>
    {loading ? (
            <Loader />
          ) : (
      <section className="container d-flex flex-column justify-content-between min-vh-100">
        <div className="mt-4 w-100">
          {/* <div className="col-1 d-flex    justify-content-center">
            <Sider />
          </div> */}
          <div className="col-12 ">
            <div className="col-12">
              <Header></Header>
            </div>
            <div className=" pt-1 mt-3 py-3 project-manage w-100 ">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className="col-12 col-md-6  px-4 pt-3">
                  <h1 className="heading-entr">Publication Dashboard</h1>
                </div>

                <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>
              <section className="col-12  ">
                <div className="row  px-3">
                  <div className="row ">
                    <div className=" col-xl-3 col-lg-4 total-project   ">
                      <div className=" w-100 d-flex px-3 mt-3">
                        <div className="graphic-box  mt-2 ">
                          <BsBarChartLine className=" graphic-icon m-2" />
                        </div>
                        <div>
                          <div className="status-title px-2 mt-3 mx-3">
                            Journal Status
                          </div>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-4"
                        onClick={() =>
                          handleProNavigate({ type: "submit_to_journal" })
                        }
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">
                          Waiting for Submission
                        </p>
                        <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2">
                            {journalTotal.submit_to_journal || 0}
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3"
                        onClick={() =>
                          handleProNavigate({ type: "peer_review" })
                        }
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">Peer Review</p>
                        <div className="manage-num mt-1    pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">
                            {journalTotal.peer_review || 0}
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3"
                        onClick={() =>
                          handleProNavigate({ type: "pending_author" })
                        }
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">Pending Author</p>
                        <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">
                            {journalTotal.pending_author || 0}
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                        onClick={() => handleProNavigate({ type: "submitted" })}
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">Submitted</p>
                        <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">
                            {journalTotal.submitted || 0}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className=" col-xl-3 col-lg-4 total-project   mx-2">
                      <div className=" w-100 d-flex px-3 mt-3">
                        <div className="graphic-box  mt-2 ">
                          <BsBarChartLine className=" graphic-icon m-2" />
                        </div>
                        <div>
                          <div className="status-title px-2 mt-3 mx-3">
                            Journal Status
                          </div>
                        </div>
                      </div>
                      <div className="manage-title  mx-3 d-flex justify-content-around mt-3">
                        <p className="mt-1 pt-2 px-2 p-tag">Resubmission</p>
                        <div
                          className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center"
                          onClick={() =>
                            handleProNavigate({ type: "resubmission" })
                          }
                        >
                          <p className="p-tag2 ">
                            {journalTotal.resubmission || 0}
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                        onClick={() => handleProNavigate({ type: "rejected" })}
                      >
                        <p className="mt-1 px-2 pt-2 p-tag">Rejected</p>
                        <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">
                            {journalTotal.rejected || 0}
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3"
                        onClick={() =>
                          handleProNavigate({ type: "reviewer_comments" })
                        }
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">
                          Reviewer Comments
                        </p>
                        <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">
                            {journalTotal.reviewer_comments || 0}
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3"
                        onClick={() => handleProNavigate({ type: "published" })}
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">Published</p>
                        <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">
                            {journalTotal.published || 0}
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3"
                        onClick={() =>
                          handleProNavigate({ type: "withdrawal" })
                        }
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">Withdrawn</p>
                        <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">
                            {journalTotal.withdrawal || 0}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <section className="col-12">
                  <div className="row mx-3 py-2 gap-4 d-flex  flex-wrap">
                    {/* Task Count Boxes */}

                    <div
                      className="col project-task-project1 px-1 align-items-center d-flex justify-content-around"
                      onClick={handleEmergencyClick}
                    >
                      <AiOutlineAlert className="project-icon" />

                      <div className="project-writer-dashboard pt-1">
                        Emergency Work
                      </div>
                      <div className="project-writer-dashboard-font mt-1 ">
                        {dasCount.urgentImportantCount || 0}
                      </div>
                    </div>
                    <div
                      className="col project-task-project2 px-1 align-items-center d-flex justify-content-around"
                      onClick={() =>
                        handleProNavigate({ type: "quickReview_list" })
                      }
                    >
                      <SiQuicklook className="project-icon3 " />

                      <div className="project-writer-dashboard-black pt-2 ">
                        Quick Review
                      </div>
                      <div className="project-writer-dashboard-font-black mt-1 ">
                        {dasCount.quickReview || 0}
                      </div>
                    </div>
                    <div
                      className="col project-task-project-orange px-1 align-items-center d-flex justify-content-around"
                      onClick={() =>
                        handleProNavigate({ type: "reviewer_comments" })
                      }
                    >
                      {/* <div className="task-box2-dash-orange align-items-center pt-1"> */}
                      <MdOutlineComment className="project-icon3" />

                      <div className="project-writer-dashboard-black mt-1">
                        Reviewers Comment
                      </div>
                      <div className="project-writer-dashboard-font-black mt-1">
                        {dasCount.reviewerComments || 0}
                      </div>
                    </div>
                    <div
                      className="col  project-task-project-blue px-1 align-items-center d-flex justify-content-around"
                      onClick={() =>
                        handleProNavigate({ type: "resubmission" })
                      }
                    >
                      <FaFilePrescription className="project-icon" />

                      <div className="project-writer-dashboard mt-1 ">
                        Resubmission
                      </div>
                      <div className="project-writer-dashboard-font mt-1">
                        {dasCount.resubmission || 0}
                      </div>
                    </div>
                  </div>
                </section>
              </section>
            </div>
            <section className=" pt-1 mt-3  project-manage-view w-100   ">
              <div className="d-flex flex-wrap  p-3  pt-0  scrollable-section ">
                <div className="col m-0  ">
                  <div className="public-todo d-flex justify-content-between pb-2 m-1 pt-1">
                    <div>IN PROGRESS</div>
                    <div className="project-todo-round ">
                      {dasCount.in_progress_count}
                    </div>
                  </div>
                  <div className="task-list ">
                    {Array.isArray(progess) &&
                      progess.length > 0 &&
                      progess.map((task, index) => {
                        let level;
                        let bgColor = "";

                        switch (task.project_datas?.hierarchy_level) {
                          case "urgent_important":
                            level = "U/I";
                            bgColor = "bg-red";

                            break;
                          case "important_not_urgent":
                            level = "I/NU";
                            break;
                          case "urgent_not_important":
                            level = "U/NI";
                            break;
                          case "not_urgent_not_important":
                            level = "NU/NI";
                            break;
                        }
                        return (
                          <Link
                            key={task.project_datas?.id}
                            to={`/public-view/${task.project_datas?.project_id}`}
                            className="text-decoration-none"
                          >
                            <div
                              className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                            >
                              <p className="m-0 task-name-todo">
                                {Capitalize(task.project_datas?.project_id)}
                              </p>
                              <div
                                className="task-comments"
                                style={{
                                  color:
                                    task.project_datas?.hierarchy_level ===
                                    "urgent_important"
                                      ? "#FF0909" // Red
                                      : task.project_datas?.hierarchy_level ===
                                        "important_not_urgent"
                                      ? "#FFFF00" // Yellow
                                      : task.project_datas?.hierarchy_level ===
                                        "urgent_not_important"
                                      ? "#FFA500" // Orange
                                      : task.project_datas?.hierarchy_level ===
                                        "not_urgent_not_important"
                                      ? "#00A300" // Green
                                      : "inherit", // Default
                                }}
                              >
                                {level}
                              </div>
                            </div>
                          </Link>
                        );
                      })}
                  </div>
                </div>

                <div className="col ">
                  <div className="project-todo2 d-flex justify-content-between pb-2 m-1 pt-1">
                    <div>REVIEWER COMMENTS</div>
                    <div className="project-todo-round ">
                      {reviewercomment.length}
                    </div>
                  </div>
                  <div className="task-list ">
                    {Array.isArray(reviewercomment) &&
                      reviewercomment.length > 0 &&
                      reviewercomment.map((task, index) => {
                        let level;
                        let bgColor = "";

                        switch (task.project_datas?.hierarchy_level) {
                          case "urgent_important":
                            level = "U/I";
                            bgColor = "bg-red";

                            break;
                          case "important_not_urgent":
                            level = "I/NU";
                            break;
                          case "urgent_not_important":
                            level = "U/NI";
                            break;
                          case "not_urgent_not_important":
                            level = "NU/NI";
                            break;
                        }
                        return (
                          <Link
                            key={task.project_datas?.id}
                            to={`/public-view/${task.project_datas?.project_id}`}
                            className="text-decoration-none"
                          >
                            <div
                              className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                            >
                              <p className="m-0 task-name-todo">
                                {Capitalize(task.project_datas?.project_id)}
                              </p>
                              <div
                                className="task-comments"
                                style={{
                                  color:
                                    task.project_datas?.hierarchy_level ===
                                    "urgent_important"
                                      ? "#FF0909" // Red
                                      : task.project_datas?.hierarchy_level ===
                                        "important_not_urgent"
                                      ? "#FFFF00" // Yellow
                                      : task.project_datas?.hierarchy_level ===
                                        "urgent_not_important"
                                      ? "#FFA500" // Orange
                                      : task.project_datas?.hierarchy_level ===
                                        "not_urgent_not_important"
                                      ? "#00A300" // Green
                                      : "inherit", // Default
                                }}
                              >
                                {level}
                              </div>
                            </div>
                          </Link>
                        );
                      })}
                  </div>
                </div>

                <div className="col ">
                  <div className="project-todo-public d-flex justify-content-between pb-2 m-1 pt-1">
                    <div>RESUBMISSION</div>
                    <div className="project-todo-round ">
                      {resubmission.length}
                    </div>
                  </div>
                  <div className="task-list ">
                    {Array.isArray(resubmission) &&
                      resubmission.length > 0 &&
                      resubmission.map((task, index) => {
                        let level;
                        let bgColor = "";

                        switch (task.project_datas?.hierarchy_level) {
                          case "urgent_important":
                            level = "U/I";
                            bgColor = "bg-red";

                            break;
                          case "important_not_urgent":
                            level = "I/NU";
                            break;
                          case "urgent_not_important":
                            level = "U/NI";
                            break;
                          case "not_urgent_not_important":
                            level = "NU/NI";
                            break;
                        }
                        return (
                          <Link
                            key={task.project_datas?.id}
                            to={`/public-view/${task.project_datas?.project_id}`}
                            className="text-decoration-none"
                          >
                            <div
                              className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                            >
                              <p className="m-0 task-name-todo">
                                {Capitalize(task.project_datas?.project_id)}
                              </p>
                              <div
                                className="task-comments"
                                style={{
                                  color:
                                    task.project_datas?.hierarchy_level ===
                                    "urgent_important"
                                      ? "#FF0909" // Red
                                      : task.project_datas?.hierarchy_level ===
                                        "important_not_urgent"
                                      ? "#FFFF00" // Yellow
                                      : task.project_datas?.hierarchy_level ===
                                        "urgent_not_important"
                                      ? "#FFA500" // Orange
                                      : task.project_datas?.hierarchy_level ===
                                        "not_urgent_not_important"
                                      ? "#00A300" // Green
                                      : "inherit", // Default
                                }}
                              >
                                {level}
                              </div>
                            </div>
                          </Link>
                        );
                      })}
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
        <div>
          <Footer />
        </div>
      </section>
      )}
    </>
  );
}

export default Publication_dashboard;
