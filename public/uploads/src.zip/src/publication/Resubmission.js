import React, { useState, useEffect } from "react";
import DataTable from "datatables.net-react";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import axios from "axios";
import Swal from "sweetalert2";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import { useParams } from "react-router-dom";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import { getDateFormate } from "../dateFormate.js";


function Resubmission({ project_id }) {


  const [allid, setId] = useState(null);
  const { id } = useParams();
  const [formData, setFormData] = useState({
    journalName: "",
    articleId: "",
    submissionDate: "",
    rejectedDate: "",
  });
  const [data, setData] = useState([]);
      // console.log("alllistdata:", data);

  const [progess, setProgess] = useState([]);
  const [journaldata, setJounaldata] = useState([]);

  const [articleid,setArticleid]=useState([]);
  const [reject, setReject] =useState([]);

  // console.log("reject:",reject);
  // console.log("article:",articleid);
  // console.log("allidsubmission:", allid);
  // console.log("progresscountto:", progess);
  // console.log("journalall:", journaldata);


  // Get user details from localStorage once
  const storedDetails = localStorage.getItem("medicsuser");
  const parsedDetails = storedDetails ? JSON.parse(storedDetails) : null;
  const createdby = parsedDetails ? parsedDetails.id : null;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    document.getElementById("global-loader").style.display = "flex";
    
    try {
      const response = await axios.post(
        `${API_URL}/api/author/resubmission-form`,
        {
          project_id: allid,
          journal_name: formData.journalName,
          article_id: formData.articleId,
          date_of_submission: formData.submissionDate,
          date_of_rejected: formData.rejectedDate,
          created_by: createdby,
        }
      );

      Swal.fire({
        icon: "success",
        title: "Resubmission Added!",
        text: "The Resubmission has been successfully saved.",
        confirmButtonText: "OK",
      });
      
      // Refresh data after successful submission
      await fetchProjectManagerData();
    } catch (error) {
      console.error(error);
      Swal.fire({
        icon: "error",
        title: "Submission Failed",
        text: "There was an error submitting the author details. Please try again.",
        confirmButtonText: "Retry",
      });
    } finally {
      document.getElementById("global-loader").style.display = "none";
    }
  };

  // Consolidated data fetching
  // const fetchProjectManagerData = async () => {
  //   if (!id) return;

  //   try {
  //     // 1. Fetch author data
  //     const responseShow = await axios.get(
  //       `${API_URL}/api/author/author-view/${id}`
  //     );
      
  //     // 2. Set all the main data
  //     setProgess(responseShow.data.author);
  //     setJounaldata(responseShow.data.author.journal_data[0]);
  //     setArticleid(responseShow.data.author.submission);
  //     setReject(responseShow.data.author.rejected_form[0]);
  //     setId(responseShow.data.author.id);
      
  //     // 3. Fetch resubmission data using the new ID
  //     const resubmissionResponse = await axios.get(
  //       `${API_URL}/api/author/resubmission-list`,
  //       { params: { project_id: responseShow.data.id } }
  //     );
      
  //     setData(resubmissionResponse.data);
      
  //     // 4. Update formData based on all fetched data
  //     setFormData({
  //       journalName: CapitalizeCaseU(responseShow.data.author.journal_data[0]?.assign_user || ""),
  //       articleId: responseShow.data.submission[0]?.article_id || "-",
  //       submissionDate: responseShow.data.submission[0]?.date_of_submission || "-",
  //       rejectedDate: responseShow.data.rejected_form?.[0]?.date_of_rejected || "-",
  //     });
      
  //     // If there's existing resubmission data, use that instead
  //     if (resubmissionResponse.data?.[0]) {
  //       const article = resubmissionResponse.data[0];
  //       setFormData(prev => ({
  //         ...prev,
  //         journalName: article.journal_name || prev.journalName,
  //         articleId: article.article_id || prev.articleId,
  //         submissionDate: article.date_of_submission || prev.submissionDate,
  //         rejectedDate: article.date_of_rejected || prev.rejectedDate,
  //       }));
  //     }
  //   } catch (error) {
  //     console.error("Error fetching data", error);
  //   }
  // };

  const fetchProjectManagerData = async () => {
    if (!id) return;
  
    try {
      // 1. Fetch author data
      const responseShow = await axios.get(`${API_URL}/api/author/author-view/${id}`);
      const author = responseShow.data.author;
      const journalData = author.journal_data?.[0] || {};
      const submissionData = author.submission?.[0] || {};
      const rejectedData = author.rejected_form?.[0] || {};
      const projectId = journalData.project_id;
  
      // 2. Set state from author data
      setProgess(author);
      setJounaldata(journalData);
      setArticleid(author.submission || []);
      setReject(rejectedData);
      setId(author.id);
  
      // 3. Fetch resubmission data using correct project_id
      const resubmissionResponse = await axios.get(
        `${API_URL}/api/author/resubmission-list`,
        { params: { project_id: projectId } }
      );
      const resubmission = resubmissionResponse.data?.[0] || {};
  
      // 4. Set main form data (initially from author data)
      setFormData({
        journalName: CapitalizeCaseU(journalData.assign_user || ""),
        articleId: submissionData.article_id || "-",
        submissionDate: submissionData.date_of_submission || "-",
        rejectedDate: rejectedData.date_of_rejected || "-",
      });
  
      // 5. Override formData with resubmission if available
      if (resubmissionResponse.data?.length > 0) {
        setFormData(prev => ({
          ...prev,
          journalName: resubmission.journal_name || prev.journalName,
          articleId: resubmission.article_id || prev.articleId,
          submissionDate: resubmission.date_of_submission || prev.submissionDate,
          rejectedDate: resubmission.date_of_rejected || prev.rejectedDate,
        }));
      }
  
      // 6. Set full resubmission list
      setData(resubmissionResponse.data);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  

  // Single useEffect to trigger initial load
  useEffect(() => {
    fetchProjectManagerData();
  }, [id]);


  const columns = [
        {
          title: "Journal Name",
          data: "journal_name",
          render: function (data) {
            return data?.trim() ? Capitalize(data) : "-";
          },
        },
        
        {
          title: "Article ID",
          data: "article_id",
          render: function (data) {
            return data?.trim() ? Capitalize(data) : "-";
          },
        },
        {
          title: "Date of Rejected",
          data: "date_of_rejected",
          render: function (data) {
            return data?.trim() ? getDateFormate(data) : "-";
          },
        },
        {
          title: "Date of Submission",
          data: "date_of_submission",
          render: function (data) {
            return data?.trim() ? Capitalize(data) : "-";
          },
        },
       
      ];

  return (
    <>
      <div className="container ">
        <div className="form-all-form">Resubmission Form</div>

        <form>
          <div className="d-flex justify-content-around">
            <div className="col-md-5">
              <label className="label-public-name">Journal Name</label>
              <input
                type="text"
                className="form-control1"
                name="journalName"
                value={formData.journalName}
                onChange={handleChange}
                readOnly
              />
            </div>
            <div className="col-md-5">
              <label className="label-public-name">Article Id</label>
              <input
                type="text"
                className="form-control1"
                name="articleId"
                value={formData.articleId}
                onChange={handleChange}
                readOnly
              />
            </div>
          </div>
          <div className="d-flex justify-content-around mt-2">
            <div className="col-md-5">
              <label className="label-public-name">Date Of Submission</label>
              <input
                type="text"
                className="form-control1"
                name="submissionDate"
                value={formData.submissionDate}
                onChange={handleChange}
                readOnly
              />{" "}
            </div>

            <div className="col-md-5">
              <label className="label-public-name">Date Of Rejected</label>
              <input
                type="text"
                className="form-control1"
                name="rejectedDate"
                value={formData.rejectedDate}
                onChange={handleChange}
                readOnly
              />
            </div>
          </div>

          <div className="d-flex justify-content-end px-5 pt-2">
            <button className="save-form-task mb-2 pt-1" onClick={handleSubmit}>
              Resubmit
            </button>
          </div>
        </form>
        <section className="pb-2">
          <div>
            <DataTable
              id="example"
              data={data}
              columns={columns}
              className="display"
              options={{
                scrollX: true,
                select: true,
                pageLength: 20, // Default number of rows per page
                lengthMenu: [
                  [20, 30, 50],
                  [20, 30, 50],
                ],
                search: {
                  return: true, // Ensures search starts fresh
                },
              }}
            />
          </div>
        </section>
      </div>
    </>
  );
}

export default Resubmission;
