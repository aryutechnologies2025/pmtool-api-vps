export const getTimeDateFormate = (dateString) => {
  if (!dateString) return ""; // Handle null or undefined input

  const date = new Date(dateString);

  const dd = String(date.getDate()).padStart(2, "0");
  const mm = String(date.getMonth() + 1).padStart(2, "0"); // Months are zero-based
  const yyyy = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const seconds = String(date.getSeconds()).padStart(2, "0");

  return `${dd}/${mm}/${yyyy} ${hours}:${minutes}:${seconds}`;
};