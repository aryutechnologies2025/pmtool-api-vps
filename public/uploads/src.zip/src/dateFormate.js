export const getDateFormate = (dateString) => {
  if (!dateString) return ""; // Handle null or undefined input
  const date = new Date(dateString);
  const dd = String(date.getDate()).padStart(2, "0");
  const mm = String(date.getMonth() + 1).padStart(2, "0"); // Months are zero-based
  const yyyy = date.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
};