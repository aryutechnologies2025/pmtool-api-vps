export const CapitalizeCaseU = (status) => {
    if (!status || typeof status !== 'string') {
        return ''; // Return an empty string or handle it as needed
    }
    return status
        .replace(/_/g, ' ') // Replace underscores with spaces
        .trim() // Remove any leading or trailing spaces
        .split(' ') // Split into words
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()) // Capitalize each word
        .join(' '); // Rejoin the words
};
