import React, { useState, useEffect } from "react";
import axios from "axios";
import ReactDOM from "react-dom";
import { IoMdAdd } from "react-icons/io";
import { TfiPencilAlt } from "react-icons/tfi";
import { RiDeleteBin6Line } from "react-icons/ri";
import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import Sider from "../components/Sider";
import Header from "../components/Header";
import Tooltip from '@mui/material/Tooltip';
import Swal from 'sweetalert2';

import { API_URL } from "../config";

import { VscGitStashPop } from "react-icons/vsc";

import Modula_header from "./Modula_header";
import Footer from "../components/Footer";
import Breadcrumbs from "../routes/Breadcrumbs";
import Loader from "../components/Loader.js";

DataTable.use(DT);

function Modula() {
  const [data, setData] = useState([]);
  const [formData, setFormData] = useState({ name: "", status: " 1" });
  const [errors, setErrors] = useState({});
  const [isOpen, setIsOpen] = useState(false);
  const [isOpenAdd, setIsOpenadd] = useState(false);
  const [selectedId, setSelectedId] = useState(null);
  const [showData, setShowData] = useState(null);
  const [editMessage, setEditMessage] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [message, setMessage] = useState(null);
  const [isReadOnly, setIsReadOnly] = useState(true);


  const fetchData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/institutions/list`
      );
      setData(response.data);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };



  const openPopup = (id) => {
    setIsOpen(true);
    setSelectedId(id);
    fetchShowData(id);
  };
  const closePopup = () => {
    setEditMessage(null);
    setIsOpen(false);
  }

  const openPopupadd = () => setIsOpenadd(true);
  const closePopupadd = () => {
    setErrors("");
    setSuccessMessage(null);
    setIsOpenadd(false);
  }




  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };


  const validateForm = () => {
    const formErrors = {};

    // Allow only letters, numbers, and spaces
    const nameRegex = /^[A-Za-z0-9 ., -]+$/;

    if (!formData.name) {
      formErrors.name = "Name is required";
    } else if (!nameRegex.test(formData.name)) {
      formErrors.name = "Special characters are not allowed to be entered.";
    }

    setErrors(formErrors);
    return Object.keys(formErrors).length === 0;
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    // if (!validateForm()) {
    //   return;
    // }
    try {
      const response = await axios.post(
        `${API_URL}/api/institutions/store`,
        formData,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      setMessage(response.data);
      fetchData();
      setIsOpenadd(false);
      setErrors("");
      setFormData({ name: "", status: "" });
      Swal.fire({
        icon: "success",
        title: "Success!",
        text: "Institution saved successfully.",
        confirmButtonText: "OK",
      });
    } catch (err) {
      if (err.response && err.response.status === 422) {
        const validationErrors = err.response.data.errors;
        setErrors(validationErrors);
        console.log("Validation Errors:", validationErrors);
      } else {
        setErrors({ general: "An unexpected error occurred." });
      }
    }
  };

  const fetchShowData = async (id) => {
    try {
      const responseShow = await axios.get(
        `${API_URL}/api/institutions/view/${id}`
      );
      setFormData(responseShow.data);
      setShowData(responseShow.data);
      fetchData();
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const handleEditClick = () => {
    setIsReadOnly(false);
  };

  const handleInputUpdate = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmitedit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }
    try {
      await axios.put(
        `${API_URL}/api/institutions/update/${selectedId}`,
        formData
      );
      fetchData();
      setIsOpen(false);
      setErrors("");
      setFormData({ name: "", status: "" });
      Swal.fire({
        icon: "success",
        title: "Success!",
        text: "Institution updated successfully.",
        confirmButtonText: "OK",
      });
    } catch (err) {
      if (err.response && err.response.status === 422) {
        const validationErrors = err.response.data.errors;
        setErrors(validationErrors);
      } else {
        setErrors({ general: "An unexpected error occurred." });
      }
    }
  };

  const handleDeleteClick = async (id) => {
    const result = await Swal.fire({
      title: 'Are you sure?',
      text: "Are you sure you want to delete this institution?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'Cancel'
    });

    // If the user confirms the delete
    if (result.isConfirmed) {
      try {
        await axios.delete(`${API_URL}/api/institutions/delete/${id}`);
        fetchData();
        Swal.fire({
          icon: "success",
          title: "Deleted!",
          text: "Institution deleted successfully.",
          confirmButtonText: "OK",
        });
      } catch (error) {
        if (error.response?.data?.status === "error") {
          Swal.fire({
            icon: "error",
            title: "Deletion Not Allowed",
            text: error.response?.data?.message,
            confirmButtonText: "OK",
          });
          return;
        }
      }
    }
  };
  useEffect(() => {
    fetchData();
  }, []);




  const handleDelete = (rowData) => {
    console.log("Deleting row: ", rowData);
  };

  const columns = [
   
    { title: "NAME", data: "name" },
    {
      title: "ACTIONS",
      data: null,
      render: (data, type, row) => {
        const id = `actions-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                <div className="d-flex justify-content-around modula-main mt-1">
                  <div className="modula-icon-edit" onClick={() => openPopup(data.id)}>
                    <TfiPencilAlt />
                  </div>
                  <div className="border border-1"></div>
                  <div className="modula-icon-del" onClick={() => handleDeleteClick(data.id)}>
                    <RiDeleteBin6Line />
                  </div>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }

  return (
    <section className="container">
      <div className="row mt-4">
        {/* <div className="col-1 d-flex justify-content-center">
          <Sider />
        </div> */}
        <div className="col-12">
          <div className="col-12">
            <Header />
          </div>
          <div className="col-12 mt-3 pt-1 wapper w-100 ">
            <div className=" row mt-3 d-flex   w-100 ">

              <div className="col-12 col-md-5 d-flex ">
                <Modula_header />
              </div>
              <div className="col-12 col-md-2 text-center mt-2">
                <div className="d-flex justify-content-center">
                  <Tooltip title="Add Institution" >
                    <div className="add-icon">
                      <IoMdAdd
                        onClick={() => {
                          setFormData({ name: "", status: "" });
                          openPopupadd();
                        }}
                        className="add1-icon"
                      />
                    </div>
                  </Tooltip>
                  {isOpenAdd && (
                    <div className="popup-container">
                      <div className="popup-add">
                        <div className="popup-content-add">
                          <span className="close" onClick={closePopupadd}>
                            &times;
                          </span>
                          <div className="popup-content1 px-5 ">
                            <form onSubmit={handleFormSubmit}>
                              <div className="row w-100 mt-2">
                                <div className="col-12 float-start p-3">
                                  {successMessage && (
                                    <div className="alert alert-success">
                                      {successMessage}
                                    </div>
                                  )}
                                  <label className="form-label">Name</label>
                                  <input
                                    type="text"
                                    className={`form-control ${errors.name ? "error" : ""
                                      }`}
                                    name="name"
                                    value={formData.name}
                                    onChange={handleInputChange}
                                  />
                                  {errors.name && (
                                    <span className="error-text">{errors.name}</span>
                                  )}
                                </div>
                              </div>
                              <div className="col-md-12 d-flex justify-content-center mt-3 pb-3">
                                <button type="submit" className="save-form">
                                  Save
                                </button>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                </div>
              </div>
              <div className=" col-12 col-md-5 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>


            <div className="px-1">
              <DataTable
                id="example"
                data={data}
                columns={columns}
                className="display"
                options={{
                  paging: true,
                  pageLength: 20,
                  lengthMenu: [[20, 30, 50], [20, 30, 50]],
                  scrollX: true,
                }} />
            </div>
          </div>
        </div>
        {/* edit */}
        {isOpen && (
          <div className="popup-container">
            <div className="popup">
              <div className="popup-content">
                <span className="close" onClick={closePopup}>
                  &times;
                </span>

                <div className="popup-content1 px-5 ">
                  <form onSubmit={handleSubmitedit}>
                    <div className="row w-100 mt-2  ">
                      <div className="col-12  float-start p-3  ">
                        {editMessage && (
                          <div className="alert alert-success">
                            {editMessage}
                          </div>
                        )}
                        <label className="form-label d-flex justify-content-center">
                          Name
                        </label>
                        <input
                          type="text"
                          name="name"
                          className={`form-control ${errors.name ? "error" : ""
                            }`}

                          value={formData.name || ""}
                          onChange={handleInputUpdate}
                        />
                        {errors.name && (
                          <span className="error-text">{errors.name}</span>
                        )}
                      </div>
                    </div>
                    <div className="col-md-12 d-flex justify-content-center mt-3 pb-3 ">
                      <button className="save-form " >
                        update
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      <div>

        <Footer />
      </div>
    </section>
  );
}

export default Modula;