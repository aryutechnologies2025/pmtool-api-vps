// export const API_URL = "https://pmtool-api.medicsresearch.com";  //main
// export const API_URL = "https://pmtoolapi.medicsresearch.com";  //hostinger main
export const API_URL = "https://pmtoolstaging-api.medicsresearch.com";   //staging
// export const API_URL = "http://localhost:8000"; //local
// export const API_URL = "http://192.168.29.54:5000";

export const HRMS_API_URL = "https://hrmsapi.medicsresearch.com";
// export const HRMS_API_URL = "http://localhost:8000";
// 
export const BASE_URL = "https://pmtool-api.medicsresearch.com/";
// export const BASE_URL = "http://localhost:8000/";

export const CAPCHA_URL = "6LdBR6wqAAAAAKiqjNXKIxWOyBtdn3Vx_-MdRc8-"; //local
// export const CAPCHA_URL = "6Ld9n2grAAAAALcat3FJusJ3m47dxwAy7tPthx1c"; //live
