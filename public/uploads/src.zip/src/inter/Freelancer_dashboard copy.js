import React, { useEffect, useState } from "react";
import "../assests/css/team_coordinator.css";
import "../assests/css/project_management.css";
import "../assests/css/project-management-view.css";

import { BsBarChartLine } from "react-icons/bs";
import Sider from "../components/Sider";
import Header from "../components/Header";
import { AiOutlineAlert } from "react-icons/ai";
import { MdDoNotDisturb } from "react-icons/md";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import axios from "axios";

import { VscGitStashPop } from "react-icons/vsc";
import { IoMdAdd } from "react-icons/io";
import { Link } from "react-router-dom";
import Footer from "../components/Footer";

DataTable.use(DT);


function Internal_dashboard() {


  useEffect(() => {
    // fetchData();
    fetchProjectManagerData();
  }, []);
  const [setdata, setFetchData] = useState(0);
  const [menuscriptdata, setMenuscriptData] = useState([]);
  const [thesisdata, setThesisData] = useState([]);
  const [tododata, setToDoData] = useState([]);
  const [inworkdata, setInWorkData] = useState([]);
  const [reviewdata, setReviewData] = useState([]);
  const [completeddata, setCompletedData] = useState([]);
  const [correctiondata, setCorrectionData] = useState([]);
  const [writerCount, setWriterCount] = useState(0);
  const [reviewerCount, setReviewerCount] = useState(0);

  const storedDetatis = localStorage.getItem('medicsuser');
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;
  const createdpositionby = parsedDetails ? parsedDetails.position : null;

  const fetchProjectManagerData = async () => {
    try {
      console.log('created_by', createdby);
      const response = await axios.get(`${API_URL}/api/entry_process/dashboarprocessList`, {
        params: {
          position: 'writer',
          created_by: createdby
        }
      });

      const responsedata = response.data;

      setFetchData(responsedata);
      setMenuscriptData(responsedata.manuscript_data);
      setThesisData(responsedata.thesisData);
      setToDoData(responsedata.to_do_data);
      setInWorkData(responsedata.inWorks);
      setReviewData(responsedata.reviews);
      setCompletedData(responsedata.completed);
      setCorrectionData(responsedata.corrections);
      setWriterCount(responsedata.writerCount);
      setReviewerCount(responsedata.reviewerCount);

    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  const formatStatus = (status) => {
    return status
      .replace(/_/g, " ") // Replace underscores with spaces
      .toLowerCase() // Convert all text to lowercase
      .replace(/\b\w/g, (char) => char.toUpperCase()); // Capitalize the first letter of each word
  };

  return (
    <>
      <section className="container ">
        <div className="row mt-4  ">
          {/* {createdpositionby !== '7' && (
            <div className="col-1 d-flex  justify-content-center">
              <Sider />
            </div>
          )} */}
          <div className="col-12 ">
            <div className="col-12">
              <Header></Header>
            </div>
            <div className=" pt-1 mt-3 py-3 project-manage w-100 ">
              <section className="col-12 ">
                <div className="row  px-3">
                  <div className="col-12 mt-4 d-flex justify-content-between">
                    <p className="heading-entr">Writer  Dashboard</p>
                    <div className="col-2 text-center  ">
                      <div className="d-flex justify-content-center ">

                      </div>
                    </div>
                  </div>
                  <div className="row  a ">
                    <div className="col-12 col-md-6 pt-5 total-project-team ">
                      {/* <div className="  d-flex px-3  mt-3">
                        <div className="graphic-box  mt-2 ">
                          <BsBarChartLine className=" graphic-icon m-2" />
                        </div>
                        <div>
                          <div className=" d-flex mx-2 project-head gap-3 ">
                            <p className=" text-muted dash-year ">2024</p>
                            <p className=" text-muted dash-project ">
                              Total Projects
                            </p>
                          </div>
                          <div className=" h1  px-2">1000</div>
                        </div>
                      </div> */}
                      <div className=" d-flex">
                        <div className="manage-title  mx-3 d-flex justify-content-around ">
                          <p className="mt-1 px-2 pt-2 p-tag-round">Writer</p>
                          <div className="manage-num-round mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2">{setdata.writerCount || 0}</p>
                          </div>
                        </div>
                        <div className="manage-title  mx-3 d-flex justify-content-around ">
                          <p className="mt-1 pt-2 px-2 p-tag-round">
                            Reviewing
                          </p>
                          <div className="manage-num-round mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">{setdata.reviewerCount || 0}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-xl-3">
                      <div className=" project-task px-1 align-items-center d-flex justify-content-center gap-3">
                        <div className="task-box align-items-center pt-3">
                          <AiOutlineAlert className="project-icon" />
                        </div>
                        <div className="align-items-center">
                          <p className="project-writer pt-2">
                            Emergency work
                          </p>
                          <div className="h4">{setdata.emergencywork}</div>
                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-xl-3">
                      <div className=" project-task px-1 align-items-center d-flex justify-content-center gap-3">
                        <div className="task-box1 align-items-center pt-1">
                          <MdDoNotDisturb className="project-icon1 mt-3" />
                        </div>
                        <div className="align-items-center">
                          <p className="project-writer pt-2">
                            Not Assgined Work
                          </p>
                          <div className="h4">{setdata.not_assigned}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </div>
           <div className="col-12">
           <div className="d-flex flex-wrap pt-1 mt-1   w-100 gap-3   ">
              <div className="col project-manage-view">
                <div className=" p-2 pt-1 mt-1   w-100  ">
                  <p className="heading-entr mt-2">
                    Manuscript Count and Status
                  </p>
                  <div class="mt-3  table-responsive  table-wrapper-scroll-y my-custom-scrollbar1  ">
                    <table>
                      <thead className>
                        <tr>
                          <th>Status</th>
                          <th>Writing</th>
                          <th>Reviewing</th>
                        </tr>
                      </thead>
                      <tbody className="">
                        {Object.entries(menuscriptdata).map(([status, counts]) => (
                          <tr>
                            <td className="td-no">{formatStatus(status)}</td>
                            <td className="td-no">{counts.writer}</td>
                            <td className="td-no">{counts.reviewing}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div className="col project-manage-view">
                <div className="p-2 pt-1 mt-1   w-100  ">
                  <p className="heading-entr mt-2">Thesis Count and Status</p>
                  <div class="mt-3 table-responsive  table-wrapper-scroll-y my-custom-scrollbar1 ">
                    <table>
                      <thead className>
                        <tr>
                          <th>Status</th>
                          <th>Writing</th>
                          <th>Reviewing</th>
                        </tr>
                      </thead>
                      <tbody className="">
                        {Object.entries(thesisdata).map(([status, counts]) => (
                          <tr>
                            <td className="td-no">{formatStatus(status)}</td>
                            <td className="td-no">{counts.writer}</td>
                            <td className="td-no">{counts.reviewing}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
           </div>

            <section className=" pt-1   project-manage-view w-100   ">
              <div className="d-flex flex-wrap  p-3 pt-0 scrollable-section  ">
                <div className="col m-0  ">
                <div className="project-todo d-flex gap-5 pb-2 m-1 pt-1">
                      <div>TO DO</div>
                      <div className="project-todo-round ">2</div>
                    </div>
                    <div className="task-list ">
                    {Array.isArray(tododata) &&
                      tododata.length > 0 &&
                      tododata.map((task, index) => {
                        return (
                          <div className=" task-details m-2 p-2">
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="  text-decoration-none"
                            >
                              <p className="m-0 task-name-todo">
                                {Capitalize(task.project_id)}
                              </p>
                              <p className="task-comments">
                                {CapitalizeCaseU(task.hierarchy_level)}
                              </p>

                              {task.writer_status_date && (
                                <p className="task-comments">
                                  Assigned Date: {task.writer_status_date}
                                </p>
                              )}
                              {task.reviewer_status_date && (
                                <p className="task-comments">
                                  Assigned Date: {task.reviewer_status_date}
                                </p>
                              )}
                              {task.statistican_assigned_date && (
                                <p className="task-comments">
                                  Assigned Date:{" "}
                                  {task.statistican_assigned_date}
                                </p>
                              )}
                              {task.journal_status_date && (
                                <p className="task-comments">
                                  Assigned Date: {task.journal_status_date}
                                </p>
                              )}
                            </Link>
                            <div className="d-flex justify-content-between">
                              <div className="task-thesis-head">
                                <p className="task-thesis">
                                  {Capitalize(task.type_of_work)}
                                </p>
                              </div>
                              {/* <div className="task-thesis-head1">
                                task?.project_data?.writer == 
                                  <p className="task-thesis1">{task?.project_data?.writer?.created_by_user?.name
                                    ? Capitalize(task?.project_data?.writer?.created_by_user?.name)
                                    : "N/A"}</p>
                                </div> */}
                              {/* <div className="task-thesis-head2">
                                  <p className="task-thesis2">{Capitalize(task.process_status)}</p>
                                </div> */}
                              <div>
                                {/* <div
                                    className="task-thesis-head2"
                                    onClick={togglePopup}
                                  > */}
                              </div>

                              {task.payment_process !== null && (
                                <div
                                  className="task-thesis-head2 "
                                  onClick={() => fetchTaskData(task.id)}
                                >
                                  <div
                                    className="task-thesis2"
                                    style={{ cursor: "pointer" }}
                                  >
                                    View Pay
                                  </div>
                                </div>
                              )}
                              {/* </div> */}

                              {isOpen && (
                                <div className="modal-container-view">
                                  <div className="modal-box">
                                    <div className="d-flex justify-content-end">
                                      <span
                                        className="modal-close "
                                        onClick={togglePopupClose}
                                      >
                                        &times;
                                      </span>
                                    </div>
                                    <div className="modal-body">
                                      <div className="row mb-3">
                                        <div className="col-6 text-end project-account ">
                                          Project ID :
                                        </div>
                                        <div className="col-6 text-start view-project-title1 ">
                                          {CapitalizeCaseU(
                                            taskData.projectId
                                          ) || "N/A"}
                                        </div>
                                      </div>
                                      <div className="row mb-3">
                                        <div className="col-6 text-end project-account">
                                          Project Status :
                                        </div>
                                        <div className="col-6 text-start view-project-title1">
                                          {CapitalizeCaseU(
                                            taskData.projectStatus
                                          ) || "N/A"}
                                        </div>
                                      </div>
                                      <div className="row mb-3">
                                        <div className="col-6 text-end project-account">
                                          Payment Date :
                                        </div>
                                        <div className="col-6 text-start view-project-title1">
                                          {/* {getDateFormate(taskData.paymentDate) || 'N/A'} */}
                                        </div>
                                      </div>
                                      <div className="row mb-3">
                                        <div className="col-6 text-end project-account">
                                          Payment Status :
                                        </div>
                                        <div className="col-6 text-start view-project-title1">
                                          {CapitalizeCaseU(
                                            taskData.paymentStatus
                                          ) || "N/A"}
                                        </div>
                                      </div>
                                    </div>
                                    <hr></hr>
                                    <div className="col text-center view-project-title">
                                      Once Project Will Completed After 21 days
                                      Amount Will Be Credited
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                  
                  
                </div>
                <div className="col ">
                <div className="project-todo1 d-flex gap-5 pb-2 m-1 pt-1">
                      <div>IN WORK</div>
                      <div className="project-todo-round ">2</div>
                    </div>
                  <div className="task-list ">
                    {Array.isArray(inworkdata) && inworkdata.length > 0 && (
                      inworkdata.map((task, index) => {
                        return (
                          <Link key={task.id} to={`/project-view/${task.project_id}`} className="text-decoration-none">
                            <div className=" task-details m-2 p-2">
                              <p className="m-0 task-name-todo">{task.project_id}/{task.entry_date}</p>
                              <p className="task-comments">
                                {task.title}
                              </p>
                              <div className="d-flex justify-content-between">
                                <div className="task-thesis-head">
                                  <p className="task-thesis">{Capitalize(task.type_of_work)}</p>
                                </div>
                                <div className="task-thesis-head1">
                                  <p className="task-thesis1">{task?.user_data?.created_by_user?.name
                                    ? Capitalize(task.user_data.created_by_user.name)
                                    : "N/A"}</p>
                                </div>
                                <div className="task-thesis-head2">
                                  <p className="task-thesis2">{Capitalize(task.process_status)}</p>
                                </div>
                              </div>
                            </div>
                          </Link>
                        );
                      })
                    )}
                  </div>
                </div>
                <div className="col ">
                <div className="project-todo2 d-flex gap-5 pb-2 m-1 pt-1 ">
                      <div>REVIEWS</div>
                      <div className="project-todo-round ">2</div>
                    </div>
                  <div className="task-list ">
                    {Array.isArray(inworkdata) && inworkdata.length > 0 && (
                      reviewdata.map((task, index) => {
                        return (
                          <Link key={task.id} to={`/project-view/${task.project_id}`} className="text-decoration-none">
                            <div className=" task-details m-2 p-2">
                              <p className="m-0 task-name-todo">{task.project_id}/{task.entry_date}</p>
                              <p className="task-comments">
                                {task.title}
                              </p>
                              <div className="d-flex justify-content-between">
                                <div className="task-thesis-head">
                                  <p className="task-thesis">{Capitalize(task.type_of_work)}</p>
                                </div>
                                <div className="task-thesis-head1">
                                  <p className="task-thesis1">{task?.user_data?.created_by_user?.name
                                    ? Capitalize(task.user_data.created_by_user.name)
                                    : "N/A"}</p>
                                </div>
                                <div className="task-thesis-head2">
                                  <p className="task-thesis2">{Capitalize(task.process_status)}</p>
                                </div>
                              </div>
                            </div>
                          </Link>
                        );
                      })
                    )}
                  </div>
                </div>
                <div className="col ">
                <div className="project-todo3 d-flex gap-5 pb-2 m-1 pt-1">
                      <div>CORRECTION</div>
                      <div className="project-todo-round ">2</div>
                    </div>
                  <div className="task-list ">
                    {Array.isArray(correctiondata) && correctiondata.length > 0 && (
                      correctiondata.map((task, index) => {
                        return (
                          <Link key={task.id} to={`/project-view/${task.project_id}`} className="text-decoration-none">
                            <div className=" task-details m-2 p-2">
                              <p className="m-0 task-name-todo">{task.project_id}/{task.entry_date}</p>
                              <p className="task-comments">
                                {task.title}
                              </p>
                              <div className="d-flex justify-content-between">
                                <div className="task-thesis-head">
                                  <p className="task-thesis">{Capitalize(task.type_of_work)}</p>
                                </div>
                                <div className="task-thesis-head1">
                                  <p className="task-thesis1">{task?.user_data?.created_by_user?.name
                                    ? Capitalize(task.user_data.created_by_user.name)
                                    : "N/A"}</p>
                                </div>
                                <div className="task-thesis-head2">
                                  <p className="task-thesis2">{Capitalize(task.process_status)}</p>
                                </div>
                              </div>
                            </div>
                          </Link>
                        );
                      })
                    )}
                  </div>
                </div>
                <div className="col ">
                <div className="project-todo4 d-flex gap-5 pb-2 m-1 pt-1">
                      <div>COMPLETED</div>
                      <div className="project-todo-round ">2</div>
                    </div>
                  <div className="task-list ">
                    {Array.isArray(completeddata) && completeddata.length > 0 && (
                      completeddata.map((task, index) => {
                        return (
                          <Link key={task.id} to={`/project-view/${task.project_id}`} className="text-decoration-none">
                            <div className=" task-details m-2 p-2">
                              <p className="m-0 task-name-todo">{task.project_id}/{task.entry_date}</p>
                              <p className="task-comments">
                                {task.title}
                              </p>
                              <div className="d-flex justify-content-between">
                                <div className="task-thesis-head">
                                  <p className="task-thesis">{Capitalize(task.type_of_work)}</p>
                                </div>
                                <div className="task-thesis-head1">
                                  <p className="task-thesis1">{task?.user_data?.created_by_user?.name
                                    ? Capitalize(task.user_data.created_by_user.name)
                                    : "N/A"}</p>
                                </div>
                                <div className="task-thesis-head2">
                                  <p className="task-thesis2">{Capitalize(task.process_status)}</p>
                                </div>
                              </div>
                            </div>
                          </Link>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
        <div>

          <Footer />
        </div>
      </section>
    </>
  );
}

export default Internal_dashboard;
