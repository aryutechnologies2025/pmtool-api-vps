import React from "react";

import "../assests/css/entryprocess.css";
import { API_URL } from "../config.js";
import { IoIosSearch } from "react-icons/io";
// import { IoFilter } from "react-icons/io5";
import { IoMdAdd } from "react-icons/io";
import { VscGitStashPop } from "react-icons/vsc";
import { VscEye } from "react-icons/vsc";
import { NavLink } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
// import { MdKeyboardArrowDown } from "react-icons/md";
import axios from "axios";
// import axios from '../api/axiosConfig.js';

import { FaBookReader } from "react-icons/fa";
import Swal from "sweetalert2";

import DatePicker from "react-datepicker";
import Breadcrumbs from "../routes/Breadcrumbs";

import "react-datepicker/dist/react-datepicker.css";
import Header from "../components/Header.js";

import ReactDOM from "react-dom";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { TfiPencilAlt } from "react-icons/tfi";
import { RiDeleteBin6Line } from "react-icons/ri";
import { TbClockExclamation } from "react-icons/tb";
import { Capitalize } from "../campsCase.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { IoIosMailOpen } from "react-icons/io";

import Tooltip from "@mui/material/Tooltip";
import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";
import { getDateFormate } from "../dateFormate.js";
import { saveAs } from "file-saver";
import Papa from "papaparse";
import { Link } from "react-router-dom";
import { FaIndianRupeeSign } from "react-icons/fa6";

import { LuBadgeDollarSign } from "react-icons/lu";
import { format, parseISO } from "date-fns";
import Loader from "../components/Loader.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import { useLocation } from "react-router-dom";
import { formatIndianCurrency } from "../AmountFormet.js";

function Freelancer_projectlist() {
  const location = useLocation();
  const { type } = location.state || {};

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;
  const employee_type = localStorage.getItem("medicsEmpName");

  const roletype =localStorage.getItem("medicsroleName");

  console.log("emp:",roletype)


  console.log("location.state", location.state);

  const [data, setData] = useState([]);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [showData, setShowData] = useState({});
  const [selectedId, setSelectedId] = useState(null);
  const [filteredData, setFilteredData] = useState([]);
  const [typeofwork, setTypeOfWork] = useState([]);
  const [filtertypeofwork, getTypeOfwork] = useState("all");
  const [projectcount, setDataCount] = useState(0);

  console.log("alldatafere:", projectcount);

  // const [formData, setFormData] = useState({});
  console.log("alldata:", data);

  const fetchData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/freelancer-project-list`,
        {
          params: {
            start_date: startDate,
            end_date: endDate,
            type: type,
            createdby: createdby,
            type_of_work: filtertypeofwork,
            assign_user: createdby,
            position: roletype,
          },
        }
      );

      setDataCount(response.data);
      setData(response.data.details);
      setFilteredData(response.data.details);
      setTypeOfWork(response.data.typeofwork);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);

  const truncateText = (text, limit) => {
    if (text && text.length > limit) {
      return text.slice(0, limit) + "..."; // Truncate and add ellipsis if text is longer
    }
    return text;
  };


    const navigate = useNavigate();
  
  const columns = [
    {
      title: "Project ID",
      data: "project_id",
      render: (data) => Capitalize(data),
    },
    // {
    //   title: "DATE",
    //   data: "entry_date",
    //   render: (data) => getDateFormate(data),
    // },
    {
      title: "DATE",
      data: "entry_date",
      render: (data, type) => {
        if (!data) return "";
    
        if (type === "sort" || type === "filter") {
          return new Date(data).getTime();
        }
    
        return getDateFormate(data);
      },
    },
   
    // {
    //   title: "TITLE",
    //   data: null,
    //   render: (data, type, row) => {
    //     const id = `title-${row.sno || Math.random()}`;

    //     setTimeout(() => {
    //       const container = document.getElementById(id);
    //       if (container && !container.hasChildNodes()) {
    //         ReactDOM.render(
    //           <div
    //             className="d-flex justify-content-center"
    //             // onClick={togglePopuptitle}
    //             onMouseEnter={() => row.title} // Pass title dynamically
    //             // onMouseLeave={handleMouseLeave}
    //             id={`title-${row.sno || Math.random()}`}
    //           >
    //             {truncateText(row.title, 10)}
    //           </div>,

    //           container
    //         );
    //       }
    //     }, 0);

    //     return `<div id="${id}"></div>`;
    //   },
    // },
    {
  title: "TITLE",
  data: null,
  render: (data, type, row) => {

    if (type === "filter" || type === "sort") {
      return row.title || "";
    }

    const id = `title-${row.sno || Math.random()}`;

    setTimeout(() => {
      const container = document.getElementById(id);
      if (container && !container.hasChildNodes()) {
        ReactDOM.render(
          <div className="d-flex justify-content-center">
            {truncateText(row.title, 10)}
          </div>,
          container
        );
      }
    }, 0);

    return `<div id="${id}"></div>`;
  },
},

    {
      title: "Process Status".toUpperCase(),
      data: null,
      render: (data) => CapitalizeCaseU(data.process_status),
    },
   
    {
      title: "Duration".toUpperCase(),
      data: "projectduration",
      render: (data) => getDateFormate(data),
    },
// {
//       title: "ACTIONS",
//       data: null,
//       render: (data, type, row) => {
//         const id = `process-${row.sno || Math.random()}`;
//         setTimeout(() => {
//           const container = document.getElementById(id);
//           if (container && !container.hasChildNodes()) {
//             ReactDOM.render(
//               <div className="">
//                 <div className="d-flex  justify-content-around  mt-1  ">
//                   <div className="" title="Task View">
//                     <span>
//                       <FaBookReader
//                         onClick={() =>
//                           navigate(`/project-view/${row.project_id}`)
//                         }
//                         className="view-icon-task"
//                       />
//                     </span>
//                   </div>
//                 </div>
//               </div>,

//               container
//             );
//           }
//         }, 0);
//         return `<div id="${id}"></div>`;
//       },
//     },


    
    
  ];
    if (employee_type === "freelancers") {
      columns.push(
        {
          title: "Freelancer Fee".toUpperCase(),
          data: null,
          render: (data) =>
            data?.employee_payment_details?.length
              ? data.employee_payment_details
                  .map((detail) => formatIndianCurrency(detail.payment))
                  .join(", ")
              : "-",
        },
        {
          title: "Payment Status Date".toUpperCase(),
          data: null,
          render: (data) =>
            data?.employee_payment_details?.length
              ? data.employee_payment_details
                  .map((detail) => getDateFormate(detail.payment_date))
                  .join(", ")
              : "-",
        },
        {
          title: "Payment Status".toUpperCase(),
          data: null,
          render: (data) =>
            data?.employee_payment_details?.length
              ? data.employee_payment_details
                  .map((detail) => CapitalizeCaseU(detail.status))
                  .join(", ")
              : "-",
        }
      );
    }

  columns.push({
  title: "ACTIONS",
  data: null,
  render: (data, type, row) => {
    const id = `process-${row.sno || Math.random()}`;
    setTimeout(() => {
      const container = document.getElementById(id);
      if (container && !container.hasChildNodes()) {
        ReactDOM.render(
          <div className="d-flex justify-content-around mt-1">
            <div title="Task View">
              <span>
                <FaBookReader
                  onClick={() => navigate(`/project-view/${row.project_id}`)}
                  className="view-icon-task"
                />
              </span>
            </div>
          </div>,
          container
        );
      }
    }, 0);
    return `<div id="${id}"></div>`;
  },
});  
  
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }

  return (
    <section className="container d-flex flex-column justify-content-between min-vh-100">
      <div className=" row mt-4">
        {/* <div className=" col-1   d-flex justify-content-center">
          <Sider></Sider>
        </div> */}

        <div className="col-12  ">
          <div className="col-12">
            <Header></Header>
          </div>
          <div className="col-12 mt-3 pt-1 wapper w-100 py-5">
            <div className=" row mt-3 d-flex   w-100 ">
              <div className="col-12 col-md-9  px-4 ">
                <p className="heading-entr">Project List</p>
              </div>
              <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>

            <div className="px-1">
              <DataTable
                id="example"
                data={filteredData}
                columns={columns}
                className="display"
                options={{
                  scrollX: true,
                  select: true,
                  pageLength: 20,
                  lengthMenu: [
                    [20, 30, 50],
                    [20, 30, 50],
                  ],
                  order: [],
                     columnDefs: [{ width: "100px", targets: "_all" }],
                        // columnDefs: [{ width: "100px", targets: "_all" }],
                  columnDefs: [
                    {
                      targets: [1,4],
                      searchable: false,
                    },
                  ],
                }}
              />
            </div>
          </div>
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </section>
  );
}

export default Freelancer_projectlist;
