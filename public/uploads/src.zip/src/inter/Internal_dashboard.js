import React, { useEffect, useState } from "react";
import "../assests/css/team_coordinator.css";
import "../assests/css/project_management.css";
import "../assests/css/project-management-view.css";

import { BsBarChartLine } from "react-icons/bs";
import Sider from "../components/Sider";
import Header from "../components/Header";
import { AiOutlineAlert } from "react-icons/ai";
import { MdDoNotDisturb } from "react-icons/md";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import { useNavigate } from "react-router-dom";

import axios from "axios";

import { VscGitStashPop } from "react-icons/vsc";
import { IoMdAdd } from "react-icons/io";
import { Link } from "react-router-dom";
import Footer from "../components/Footer";
import Breadcrumbs from "../routes/Breadcrumbs";
import Loader from "../components/Loader.js";
DataTable.use(DT);

function Internal_dashboard() {
  const navigate = useNavigate();

  const handleNavigate = (type, createdby) => {
    navigate(`/project-list`, { state: { type, createdby } });
  };

  const handleProEmpNavigate = (count_type) => {
    navigate(`/employee-project-lists`, { state: { count_type } });
  };

  const allrole_type = localStorage.getItem("medicsroleName");

  console.log("allrole_type:", allrole_type);

  useEffect(() => {
    // fetchData();
    // fetchProjectManagerData();
    const interval = setInterval(() => {
      fetchProjectManagerData();
    }, 5000);
    return () => clearInterval(interval);
  }, []);
  const [setdata, setFetchData] = useState(0);
  const [menuscriptdata, setMenuscriptData] = useState({});
  const [thesisdata, setThesisData] = useState([]);

  const [menuscriptdata1, setMenuscriptData1] = useState({});
  console.log("stats:", menuscriptdata1);
  const [thesisdata1, setThesisData1] = useState([]);

  const [tododata, setToDoData] = useState([]);
  console.log("ongoing:", tododata);
  const [inworkdata, setInWorkData] = useState([]);
  const [reviewdata, setReviewData] = useState([]);
  const [completeddata, setCompletedData] = useState([]);
  const [correctiondata, setCorrectionData] = useState([]);
  const [writerCount, setWriterCount] = useState(0);
  const [reviewerCount, setReviewerCount] = useState(0);

  const [clientReview, setClientReviewData] = useState([]);
  const [pcList, setPcData] = useState([]);
  const [needSupport, setNeedSupportData] = useState([]);
  // console.log("client:",pcList);

  const [ongoingL, setOngoingData] = useState([]);

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;
  const position = parsedDetails ? parsedDetails.position : null;
  console.log("API_URL :", API_URL);
  console.log("position :", position);
  console.log("createdby :", createdby);
  const fetchProjectManagerData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/dashboarwrprocessList`,
        {
          params: {
            position: position,
            created_by: createdby,
          },
        }
      );
      const responsedata = response.data;
      console.log("check response", responsedata);
      setFetchData(responsedata);
      setMenuscriptData(responsedata.manuscript_data);
      setThesisData(responsedata.thesisData);
      setMenuscriptData1(responsedata.manuscript_data1);
      setThesisData1(responsedata.thesisData1);
      const flatendata = responsedata.to_do_data.map((item) => {
        return {
          entry_date: item.entry_date,
          hierarchy_level: item.hierarchy_level,
          id: item.id,
          payment_process: item.payment_process,
          process_status: item.process_status,
          project_id: item.project_id,
          reviewer_data: item.reviewer_data,
          statistican_data: item.statistican_data,
          title: item.title,
          type_of_work: item.type_of_work,
          writer_data: item.writer_data?.[0]?.status || "",
          created_at: item.created_at,
        };
      });
      setToDoData(flatendata.sort(
          (a, b) => new Date(b.created_at) - new Date(a.created_at)
        ));
      setClientReviewData(responsedata.clientReview);
      setPcData(responsedata.pcList.sort(
          (a, b) => new Date(b.created_at) - new Date(a.created_at)
        ));
      setNeedSupportData(responsedata.needSupport.sort(
          (a, b) => new Date(b.created_at) - new Date(a.created_at)
        ));
      // setOngoingData(responsedata.ongoing);
      setOngoingData(
        responsedata.ongoing.sort(
          (a, b) => new Date(b.created_at) - new Date(a.created_at)
        )
      );

      setInWorkData(responsedata.inWorks);
      setReviewData(responsedata.reviews);
      setCompletedData(responsedata.completed);
      setCorrectionData(responsedata.corrections.sort(
          (a, b) => new Date(b.created_at) - new Date(a.created_at)
        ));
      setWriterCount(responsedata.writerCount);
      setReviewerCount(responsedata.reviewerCount);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  const formatStatus = (status) => {
    return status
      .replace(/_/g, " ") // Replace underscores with spaces
      .toLowerCase() // Convert all text to lowercase
      .replace(/\b\w/g, (char) => char.toUpperCase()); // Capitalize the first letter of each word
  };
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 5000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }

  return (
    <>
      <section className="container ">
        <div className="row mt-4 ">
          {/* {createdpositionby !== '7' && ( */}
          {/* <div className="col-1 d-flex  justify-content-center">
              <Sider />
            </div> */}
          {/* )} */}
          <div className="col-12 ">
            <div className="col-12">
              <Header></Header>
            </div>
            <div className=" pt-1 mt-3 py-3 project-manage w-100 ">
              <div className=" row mt-3 d-flex  w-100 ">
                <div className="col-12 col-md-9  px-4 ">
                  <p className="heading-entr">Dashboard</p>
                </div>
                <div className=" col-3 pt-3 px-2 d-none d-md-block ">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>
              <section className="col-12 ">
                <div className="row px-3">
                  {/* <div className="col-12 mt-4 d-flex justify-content-between">
                    <div className="col-2 text-center  ">
                      <div className="d-flex justify-content-center ">

                      </div>
                    </div>
                  </div> */}
                  <div className="row align-items-center p-3 ">
                    {position !== "11" && (
                      <>
                        <div className="col-12 col-md-3 pt-4 total-project-intern">
                          <div className=" d-flex">
                            {position !== "8" && (
                              <div
                                className="manage-title  mx-3 d-flex justify-content-around"
                                onClick={() =>
                                  handleNavigate("writer", createdby)
                                }
                              >
                                <p className="mt-1 px-2 pt-2 p-tag-round">
                                  Writing
                                </p>
                                <div className="manage-num-round mt-1 pt-3 d-flex justify-content-around align-items-center">
                                  <p className="p-tag2">
                                    {setdata.writerCount || 0}
                                  </p>
                                </div>
                              </div>
                            )}
                            {position !== "7" && (
                              <div
                                className="manage-title  mx-3 d-flex justify-content-around"
                                onClick={() =>
                                  handleNavigate("reviewer", createdby)
                                }
                              >
                                <p className="mt-1 pt-2 px-2 p-tag-round">
                                  Reviewing
                                </p>
                                <div className="manage-num-round mt-1 pt-3 d-flex justify-content-around align-items-center">
                                  <p className="p-tag2 ">
                                    {setdata.reviewerCount || 0}
                                  </p>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </>
                    )}

                    {position === "11" && (
                      <div className="col-12 col-md-4 pt-4 total-project-intern">
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around"
                          onClick={() =>
                            handleNavigate("statistican", createdby)
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag-round">
                            Statistician
                          </p>
                          <div className="manage-num-round mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">
                              {setdata.statisticanCount || 0}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                {/* Hierarchy Level*/}
                <div className="row px-5 py-2 gap-5 d-flex justify-content-center flex-wrap">
                  {/* Task Count Boxes */}

                  <div
                    className="col project-task-project1 px-1 align-items-center d-flex justify-content-around"
                    onClick={() =>
                      handleProEmpNavigate({ count_type: "urgent_important" })
                    }
                  >
                    {/* <div className="task-box-dash align-items-center pt-3"> */}
                    <AiOutlineAlert className="project-icon" />
                    {/* </div> */}
                    <div className="project-writer-dashboard pt-1">
                      Emergency work
                    </div>
                    <div className="project-writer-dashboard-font mt-1 ">
                      {setdata.emergencywork}
                    </div>
                  </div>
                  <div
                    className="col project-task-project2 px-1 align-items-center d-flex justify-content-around"
                    onClick={() =>
                      handleProEmpNavigate({
                        count_type: "important_not_urgent",
                      })
                    }
                  >
                    {/* <div className="task-box-dash align-items-center pt-3"> */}
                    <AiOutlineAlert className="project-icon3" />
                    {/* </div> */}
                    <div className="project-writer-dashboard-black pt-1 ">
                      Important Not Urgent
                    </div>
                    <div className="project-writer-dashboard-font-black mt-1 ">
                      {setdata.importantNotUrgentCount}
                    </div>
                  </div>
                  <div
                    className="col project-task-project-orange px-1 align-items-center d-flex justify-content-around"
                    onClick={() =>
                      handleProEmpNavigate({
                        count_type: "urgent_not_important",
                      })
                    }
                  >
                    {/* <div className="task-box-dash align-items-center pt-3"> */}
                    <AiOutlineAlert className="project-icon3" />
                    {/* </div> */}
                    <div className="project-writer-dashboard-black pt-1">
                      Urgent Not Important
                    </div>
                    <div className="project-writer-dashboard-font-black mt-1 ">
                      {setdata.urgentNotImportantCount}
                    </div>
                  </div>
                  <div
                    className="col project-task-project4 px-1 align-items-center d-flex justify-content-around"
                    onClick={() =>
                      handleProEmpNavigate({
                        count_type: "not_urgent_not_important",
                      })
                    }
                  >
                    {/* <div className="task-box-dash align-items-center pt-3"> */}
                    <AiOutlineAlert className="project-icon" />
                    {/* </div> */}
                    <div className="project-writer-dashboard pt-1">
                      Not Urgent Not Important
                    </div>
                    <div className="project-writer-dashboard-font mt-1 ">
                      {setdata.notUrgentNotImportantCount}
                    </div>
                  </div>
                </div>
              </section>
            </div>
            {position !== "11" && (
              <section className=" pt-1   project-manage-view w-100 mt-2  ">
                <div className="d-flex flex-wrap  p-3 pt-0 scrollable-section ">
                  <div className="col  ">
                    <div className="project-todo d-flex gap-5 pb-2 m-1 pt-1">
                      <div>TO DO</div>
                      <div className="project-todo-round ">
                        {setdata.to_do_count}
                      </div>
                    </div>
                    <div className="task-list ">
                      {Array.isArray(tododata) &&
                        tododata.length > 0 &&
                          tododata.map((task, index) => {
                            const isAllEmpty =
                              task.hierarchy_level === "urgent_important";

                            let level;

                            switch (task.hierarchy_level) {
                              case "urgent_important":
                                level = "U/I";
                                break;
                              case "important_not_urgent":
                                level = "I/NU";
                                break;
                              case "urgent_not_important":
                                level = "U/NI";
                                break;
                              case "not_urgent_not_important":
                                level = "NU/NI";
                                break;
                            }
                            return (
                              <>
                                {(allrole_type === "Reviewer" &&
                                  task.writer_data === "completed") ||
                                allrole_type === "Writer" ||
                                allrole_type === "Statistican" ||
                                allrole_type === "Writer,Reviewer" ? (
                                  <Link
                                    key={task.id}
                                    to={`/project-view/${task.project_id}`}
                                    className="text-decoration-none"
                                  >
                                    <div
                                      className={`task-details d-flex justify-content-between m-2 p-2 ${
                                        isAllEmpty ? "bg-red" : ""
                                      }`}
                                    >
                                      <p className="m-0 task-name-todo">
                                        {Capitalize(task.project_id)}
                                      </p>
                                      <div
                                        className="task-comments"
                                        style={{
                                          color:
                                            task.hierarchy_level ===
                                            "urgent_important"
                                              ? "#FF0909" // Red
                                              : task.hierarchy_level ===
                                                "important_not_urgent"
                                              ? "#9932cc" // Yellow
                                              : task.hierarchy_level ===
                                                "urgent_not_important"
                                              ? "#FFA500" // Orange
                                              : task.hierarchy_level ===
                                                "not_urgent_not_important"
                                              ? "#00A300" // Green
                                              : "inherit", // Default
                                        }}
                                      >
                                        {level}
                                      </div>
                                    </div>
                                  </Link>
                                ) : (
                                  <div
                                    className={`task-details d-flex justify-content-between m-2 p-2 ${
                                      isAllEmpty ? "bg-red" : ""
                                    }`}
                                  >
                                    <p className="m-0 task-name-todo">
                                      {Capitalize(task.project_id)}
                                    </p>
                                    <div
                                      className="task-comments"
                                      style={{
                                        color:
                                          task.hierarchy_level ===
                                          "urgent_important"
                                            ? "#FF0909" // Red
                                            : task.hierarchy_level ===
                                              "important_not_urgent"
                                            ? "#9932cc" // Yellow
                                            : task.hierarchy_level ===
                                              "urgent_not_important"
                                            ? "#FFA500" // Orange
                                            : task.hierarchy_level ===
                                              "not_urgent_not_important"
                                            ? "#00A300" // Green
                                            : "inherit", // Default
                                      }}
                                    >
                                      {level}
                                    </div>
                                  </div>
                                )}
                              </>
                            );
                          })}
                    </div>
                  </div>
                  <div className="col  ">
                    <div className="project-todo d-flex gap-5 pb-2 m-1 pt-1">
                      <div>ON GOING</div>
                      <div className="project-todo-round ">
                        {setdata.ongoingCount}
                      </div>
                    </div>
                    <div className="task-list ">
                      {Array.isArray(ongoingL) &&
                        ongoingL.length > 0 &&
                        ongoingL.map((task, index) => {
                          const isAllEmpty =
                            task.hierarchy_level === "urgent_important";

                          let level;

                          switch (task.hierarchy_level) {
                            case "urgent_important":
                              level = "U/I";
                              break;
                            case "important_not_urgent":
                              level = "I/NU";
                              break;
                            case "urgent_not_important":
                              level = "U/NI";
                              break;
                            case "not_urgent_not_important":
                              level = "NU/NI";
                              break;
                          }
                          return (
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${
                                  isAllEmpty ? "bg-red" : ""
                                }`}
                              >
                                <p className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </p>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          );
                        })}
                    </div>
                  </div>
                  <div className="col ">
                    <div className="project-todo1 d-flex gap-5 pb-2 m-1 pt-1">
                      <div>PLAG CORRECTION</div>
                      <div className="project-todo-round ">
                        {setdata.pcCount}
                      </div>
                    </div>
                    <div className="task-list ">
                      {Array.isArray(pcList) &&
                        pcList.length > 0 &&
                        pcList.map((task, index) => {
                          const isAllEmpty =
                            task.hierarchy_level === "urgent_important";

                          let level;

                          switch (task.hierarchy_level) {
                            case "urgent_important":
                              level = "U/I";
                              break;
                            case "important_not_urgent":
                              level = "I/NU";
                              break;
                            case "urgent_not_important":
                              level = "U/NI";
                              break;
                            case "not_urgent_not_important":
                              level = "NU/NI";
                              break;
                          }
                          return (
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${
                                  isAllEmpty ? "bg-red" : ""
                                }`}
                              >
                                <p className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </p>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          );
                        })}
                    </div>
                  </div>
                  <div className="col ">
                    <div className="project-todo1 d-flex gap-5 pb-2 m-1 pt-1">
                      <div>NEED SUPPORT</div>
                      <div className="project-todo-round ">
                        {setdata.needSupportCount}
                      </div>
                    </div>
                    <div className="task-list ">
                      {Array.isArray(needSupport) &&
                        needSupport.length > 0 &&
                        needSupport.map((task, index) => {
                          const isAllEmpty =
                            task.hierarchy_level === "urgent_important";

                          let level;

                          switch (task.hierarchy_level) {
                            case "urgent_important":
                              level = "U/I";
                              break;
                            case "important_not_urgent":
                              level = "I/NU";
                              break;
                            case "urgent_not_important":
                              level = "U/NI";
                              break;
                            case "not_urgent_not_important":
                              level = "NU/NI";
                              break;
                          }
                          return (
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${
                                  isAllEmpty ? "bg-red" : ""
                                }`}
                              >
                                <p className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </p>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          );
                        })}
                    </div>
                  </div>
                  <div className="col ">
                    <div className="project-todo3 d-flex gap-5 pb-2 m-1 pt-1">
                      <div>CORRECTION</div>
                      <div className="project-todo-round ">
                        {setdata.correctionsCount}
                      </div>
                    </div>{" "}
                    <div className="task-list ">
                      {Array.isArray(correctiondata) &&
                        correctiondata.length > 0 &&
                        correctiondata.map((task, index) => {
                          const isAllEmpty =
                            task.hierarchy_level === "urgent_important";

                          let level;

                          switch (task.hierarchy_level) {
                            case "urgent_important":
                              level = "U/I";
                              break;
                            case "important_not_urgent":
                              level = "I/NU";
                              break;
                            case "urgent_not_important":
                              level = "U/NI";
                              break;
                            case "not_urgent_not_important":
                              level = "NU/NI";
                              break;
                          }
                          return (
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${
                                  isAllEmpty ? "bg-red" : ""
                                }`}
                              >
                                <p className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </p>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          );
                        })}
                    </div>
                  </div>
                </div>
              </section>
            )}

            {position === "11" && (
              <section className=" pt-1   project-manage-view w-100 mt-2  ">
                <div className="d-flex flex-wrap  p-3 pt-0 scrollable-section ">
                  <div className="col  ">
                    <div className="project-todo d-flex gap-5 pb-2 m-1 pt-1">
                      <div>TO DO</div>
                      <div className="project-todo-round ">
                        {setdata.to_do_count}
                      </div>
                    </div>
                    <div className="task-list ">
                      {Array.isArray(tododata) &&
                        tododata.length > 0 &&
                        tododata.map((task, index) => {
                          const isAllEmpty =
                            task.hierarchy_level === "urgent_important";

                          let level;

                          switch (task.hierarchy_level) {
                            case "urgent_important":
                              level = "U/I";
                              break;
                            case "important_not_urgent":
                              level = "I/NU";
                              break;
                            case "urgent_not_important":
                              level = "U/NI";
                              break;
                            case "not_urgent_not_important":
                              level = "NU/NI";
                              break;
                          }
                          return (
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${
                                  isAllEmpty ? "bg-red" : ""
                                }`}
                              >
                                <p className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </p>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          );
                        })}
                    </div>
                  </div>
                  <div className="col  ">
                    <div className="project-todo d-flex gap-5 pb-2 m-1 pt-1">
                      <div>ON GOING</div>
                      <div className="project-todo-round ">
                        {setdata.ongoingCount}
                      </div>
                    </div>
                    <div className="task-list ">
                      {Array.isArray(ongoingL) &&
                        ongoingL.length > 0 &&
                        ongoingL.map((task, index) => {
                          const isAllEmpty =
                            task.hierarchy_level === "urgent_important";

                          let level;

                          switch (task.hierarchy_level) {
                            case "urgent_important":
                              level = "U/I";
                              break;
                            case "important_not_urgent":
                              level = "I/NU";
                              break;
                            case "urgent_not_important":
                              level = "U/NI";
                              break;
                            case "not_urgent_not_important":
                              level = "NU/NI";
                              break;
                          }
                          return (
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${
                                  isAllEmpty ? "bg-red" : ""
                                }`}
                              >
                                <p className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </p>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          );
                        })}
                    </div>
                  </div>
                  <div className="col ">
                    <div className="project-todo1 d-flex gap-5 pb-2 m-1 pt-1">
                      <div>CLIENT REVIEW</div>
                      <div className="project-todo-round ">
                        {setdata.clientReviewCount}
                      </div>
                    </div>
                    <div className="task-list ">
                      {Array.isArray(clientReview) &&
                        clientReview.length > 0 &&
                        clientReview.map((task, index) => {
                          const isAllEmpty =
                            task.hierarchy_level === "urgent_important";

                          let level;

                          switch (task.hierarchy_level) {
                            case "urgent_important":
                              level = "U/I";
                              break;
                            case "important_not_urgent":
                              level = "I/NU";
                              break;
                            case "urgent_not_important":
                              level = "U/NI";
                              break;
                            case "not_urgent_not_important":
                              level = "NU/NI";
                              break;
                          }
                          return (
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${
                                  isAllEmpty ? "bg-red" : ""
                                }`}
                              >
                                <p className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </p>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          );
                        })}
                    </div>
                  </div>
                  <div className="col ">
                    <div className="project-todo1 d-flex gap-5 pb-2 m-1 pt-1">
                      <div>NEED SUPPORT</div>
                      <div className="project-todo-round ">
                        {setdata.needSupportCount}
                      </div>
                    </div>
                    <div className="task-list ">
                      {Array.isArray(needSupport) &&
                        needSupport.length > 0 &&
                        needSupport.map((task, index) => {
                          const isAllEmpty =
                            task.hierarchy_level === "urgent_important";

                          let level;

                          switch (task.hierarchy_level) {
                            case "urgent_important":
                              level = "U/I";
                              break;
                            case "important_not_urgent":
                              level = "I/NU";
                              break;
                            case "urgent_not_important":
                              level = "U/NI";
                              break;
                            case "not_urgent_not_important":
                              level = "NU/NI";
                              break;
                          }
                          return (
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${
                                  isAllEmpty ? "bg-red" : ""
                                }`}
                              >
                                <p className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </p>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          );
                        })}
                    </div>
                  </div>
                  <div className="col ">
                    <div className="project-todo3 d-flex gap-5 pb-2 m-1 pt-1">
                      <div>CORRECTION</div>
                      <div className="project-todo-round ">
                        {setdata.correctionsCount}
                      </div>
                    </div>{" "}
                    <div className="task-list ">
                      {Array.isArray(correctiondata) &&
                        correctiondata.length > 0 &&
                        correctiondata.map((task, index) => {
                          const isAllEmpty =
                            task.hierarchy_level === "urgent_important";

                          let level;

                          switch (task.hierarchy_level) {
                            case "urgent_important":
                              level = "U/I";
                              break;
                            case "important_not_urgent":
                              level = "I/NU";
                              break;
                            case "urgent_not_important":
                              level = "U/NI";
                              break;
                            case "not_urgent_not_important":
                              level = "NU/NI";
                              break;
                          }
                          return (
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${
                                  isAllEmpty ? "bg-red" : ""
                                }`}
                              >
                                <p className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </p>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          );
                        })}
                    </div>
                  </div>
                </div>
              </section>
            )}
            {position !== "11" && (
              <div className=" col-12 d-flex flex-wrap gap-2  mt-2 ">
                <div className="col project-manage-view">
                  <div className="p-2 pt-1 mt-1   w-100  ">
                    <p className="heading-entr mt-2">
                      Manuscript Count and Status
                    </p>
                    <div class="mt-3 table-responsive  table-wrapper-scroll-y my-custom-scrollbar1  ">
                      <table className="table-head">
                        <thead className="text-center tr-head">
                          <tr>
                            <th>Status</th>
                            <th>Writing</th>
                            <th>Reviewing</th>
                          </tr>
                        </thead>
                        <tbody className="">
                          {Object.entries(menuscriptdata || {}).length === 0 ? (
                            <tr>
                              <td colSpan="3" className="no-data">
                                No data available
                              </td>
                            </tr>
                          ) : (
                            Object.entries(menuscriptdata).map(
                              ([status, counts]) => (
                                <tr
                                  key={status}
                                  className="text-center tr-head"
                                >
                                  <td className="td-no">
                                    {formatStatus(status)}
                                  </td>
                                  <td className="td-no">
                                    {counts?.writer || 0}
                                  </td>
                                  <td className="td-no">
                                    {counts?.reviewing || 0}
                                  </td>
                                </tr>
                              )
                            )
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                <div className="col project-manage-view">
                  <div className="p-2 pt-1 mt-1   w-100  ">
                    <p className="heading-entr mt-2">Thesis Count and Status</p>
                    <div class="mt-3 table-responsive  table-wrapper-scroll-y my-custom-scrollbar1 ">
                      <table className="table-head">
                        <thead className="text-center tr-head">
                          <tr>
                            <th>Status</th>
                            <th>Writing</th>
                            <th>Reviewing</th>
                          </tr>
                        </thead>
                        <tbody className="">
                          {/* {Object.entries(thesisdata || {}).map(
                          
                          ([status, counts]) => (
                            <tr>
                              <td className="td-no">{formatStatus(status)}</td>
                              <td className="td-no">{counts?.writer || 0}</td>
                              <td className="td-no">
                                {counts?.reviewing || 0}
                              </td>
                            </tr>
                          )
                        )} */}
                          {Object.entries(thesisdata || {}).length === 0 ? (
                            <tr>
                              <td colSpan="3" className="no-data">
                                No data available
                              </td>
                            </tr>
                          ) : (
                            Object.entries(thesisdata).map(
                              ([status, counts]) => (
                                <tr
                                  key={status}
                                  className="text-center tr-head"
                                >
                                  <td className="td-no">
                                    {formatStatus(status)}
                                  </td>
                                  <td className="td-no">
                                    {counts?.writer || 0}
                                  </td>
                                  <td className="td-no">
                                    {counts?.reviewing || 0}
                                  </td>
                                </tr>
                              )
                            )
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {position === "11" && (
              <div className=" col-12 d-flex flex-wrap gap-2  mt-2 ">
                <div className="col project-manage-view">
                  <div className="p-2 pt-1 mt-1   w-100  ">
                    <p className="heading-entr mt-2">
                      Statistican Count and Status
                    </p>
                    <div class="mt-3 table-responsive  table-wrapper-scroll-y my-custom-scrollbar1  ">
                      <table className="table-head">
                        <thead className="text-center tr-head">
                          <tr>
                            <th>Status</th>
                            <th>Statistican</th>
                          </tr>
                        </thead>
                        <tbody className="">
                          {Object.entries(menuscriptdata1 || {}).length ===
                          0 ? (
                            <tr>
                              <td colSpan="3" className="no-data">
                                No data available
                              </td>
                            </tr>
                          ) : (
                            Object.entries(menuscriptdata1).map(
                              ([status, counts]) => (
                                <tr
                                  key={status}
                                  className="text-center tr-head"
                                >
                                  <td className="td-no">
                                    {formatStatus(status)}
                                  </td>
                                  <td className="td-no">
                                    {counts?.statistican || 0}
                                  </td>
                                </tr>
                              )
                            )
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        <div>
          <Footer />
        </div>
      </section>
    </>
  );
}

export default Internal_dashboard;
