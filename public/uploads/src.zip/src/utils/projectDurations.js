export const projectDurations = {
    statistics: {
        sample_size: { duration: 5, statistician: 1, writer: 0, reviewer: 0, journal: 0 },
        paper_statistics: { duration: 15, statistician: 1, writer: 0, reviewer: 0, journal: 0 },
        thesis_statistics_without_text: { duration: 30, statistician: 1, writer: 0, reviewer: 0, journal: 0 },
        thesis_statistics_with_text: { duration: 30, statistician: 1, writer: 1, reviewer: 0, journal: 0 },
    },
    manuscript: {
        writing: { duration: 10, statistician: 0, writer: 2, reviewer: 1, journal: 0 },
        with_statistics: { duration: 10, statistician: 1, writer: 2, reviewer: 1, journal: 0 },
        with_publication: { duration: 30, statistician: 0, writer: 2, reviewer: 1, journal: 5 },
        with_statistic_and_publication: { duration: 30, statistician: 1, writer: 1, reviewer: 0, journal: 5 },
    },
    thesis: {
        supporting_thesis_with_ms: { duration: 60, statistician: 1, writer: 5, reviewer: 1, journal: 0 },
        supporting_thesis_without_ms: { duration: 60, statistician: 1, writer: 5, reviewer: 1, journal: 0 },
        supporting_thesis_part1: { duration: 30, statistician: 0, writer: 5, reviewer: 1, journal: 0 },
        supporting_thesis_part2: { duration: 30, statistician: 1, writer: 5, reviewer: 1, journal: 0 },
        thesis_reviewing: { duration: 15, statistician: 1, writer: 1, reviewer: 1, journal: 0 },
    },
    others: {
        others: { duration: 10, statistician: 1, writer: 1, reviewer: 1, journal: 0 },
    },
};


// Function to calculate total duration
export const getTotalDuration = (selectedOptions, type_of_work) => {
    // console.log('selectedOptions :',selectedOptions, type_of_work)
    if (type_of_work === "others") {
        // Directly return the "others" category duration
        const { duration, statistician, writer, reviewer, journal } = projectDurations.others.others;
        return { total: duration, statistician, writer, reviewer, journal };
    }

    if (!Array.isArray(selectedOptions)) return { total: 0, statistician: 0, writer: 0, reviewer: 0, journal: 0 };

    let total = 0;
    let statisticianDuration = 0;
    let writerDuration = 0;
    let reviewerDuration = 0;
    let journalDuration = 0;

    let hasWriting = false;
    let hasStatistics = false;
    let hasPublication = false;


    // console.log('selectedoptionview', selectedOptions);
    selectedOptions.forEach((option) => {
        for (const category in projectDurations) {
            if (projectDurations[category][option] !== undefined) {
                const { duration, statistician, writer, reviewer, journal } = projectDurations[category][option];
                
                total += duration;
                statisticianDuration += statistician;
                writerDuration += writer;
                reviewerDuration += reviewer;
                journalDuration += journal;
            }
        }

        if (option === "writing") hasWriting = true;
        if (option === "with_statistics") hasStatistics = true;
        if (option === "with_publication") hasPublication = true;
    });

    if (hasStatistics && hasPublication && !hasWriting) {
        const override = projectDurations.manuscript.with_statistic_and_publication;
        total = override.duration;
        statisticianDuration = override.statistician;
        writerDuration = override.writer;
        reviewerDuration = override.reviewer;
        journalDuration = override.journal;
    }

    return { total, statistician: statisticianDuration, writer: writerDuration, reviewer: reviewerDuration, journal: journalDuration };
};



