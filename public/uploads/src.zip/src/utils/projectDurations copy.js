export const projectDurations = {
    statistics: {
        sample_size: 5,
        paper_statistics: 15,
        thesis_statistics_without_text: 30,
        thesis_statistics_with_text: 30,
    },
    manuscript: {
        writing: 10,
        with_statistics: 10,
        with_publication: 30,
        with_statistic_and_publication: 30, // This should override if both are selected
    },
    thesis: {
        supporting_thesis_with_ms: 60,
        supporting_thesis_without_ms: 60,
        supporting_thesis_part1: 30,
        supporting_thesis_part2: 30,
        thesis_reviewing: 15,
    },
    other: {
        other: 10,
    },
};

// Function to calculate total duration
export const getTotalDuration = (selectedOptions) => {
    if (!Array.isArray(selectedOptions)) return 0;

    let total = 0;
    let hasWriting = false;
    let hasStatistics = false;
    let hasPublication = false;

    // Calculate total duration normally
    selectedOptions.forEach((option) => {
        for (const category in projectDurations) {
            if (projectDurations[category][option] !== undefined) {
                total += projectDurations[category][option];
            }
        }

        // Track selections
        if (option === "writing") hasWriting = true;
        if (option === "with_statistics") hasStatistics = true;
        if (option === "with_publication") hasPublication = true;
    });

    // If both "with_statistics" and "with_publication" are selected without "writing", use override
    if (hasStatistics && hasPublication && !hasWriting) {
        total = projectDurations.manuscript.with_statistic_and_publication;
    }

    return total;
};


