export const CapitalizeCase = (status) => {
    if (!status || typeof status !== 'string') {
        return ''; // Return an empty string or handle it as needed
    }
    return status
        .replace(/_/g, ' ') // Replace underscores with spaces
        .trim() // Remove any leading or trailing spaces
        .replace(/^\w/, (char) => char.toUpperCase()); // Capitalize the first letter of the string
};
