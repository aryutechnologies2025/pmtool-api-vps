import React, { useState, useEffect, useCallback, useRef } from "react";
import "../assests/css/enter_form.css";
import Header from "../components/Header.js";
import { Link } from "react-router-dom";
import { PiCloudArrowUpLight } from "react-icons/pi";
import { RiDeleteBin6Line } from "react-icons/ri";
import RichEditor from "../components/RichEditor.jsx";
import Breadcrumbs from "../routes/Breadcrumbs";
import axios from "axios";
import { API_URL } from "../config.js";
import { useNavigate } from "react-router-dom";
import { capitalize } from "@mui/material";
import { IoMdRefreshCircle } from "react-icons/io";
import Footer from "../components/Footer";
import { MdOutlineCancel } from "react-icons/md";
import Swal from "sweetalert2";
import Loader from "../components/Loader.js";

import { getTotalDuration } from "../utils/projectDurations";

function Enterprocess_form() {
  const navigate = useNavigate();

  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const [formFields, setFormFields] = useState([
    { specificOption: "", file: [] },
  ]);

  // Get total duration
  // const getEndDate = (duration) => {
  //   if (isNaN(duration) || duration < 0) return "Invalid duration";

  //   const startDate = new Date(); // Format YYYY-MM-DD

  //   if (duration === 0) {
  //     return startDate.toISOString().split("T")[0];
  //   }

  //   startDate.setDate(startDate.getDate() + duration);

  //   return startDate.toISOString().split("T")[0]; // Format YYYY-MM-DD
  // };

  // const endDate = getEndDate(duration);

  // useEffect(() => {
  //   const updatedEndDate = getEndDate(duration);
  //   setFormData((prevData) => ({
  //     ...prevData,
  //     project_duration: updatedEndDate,
  //   }));

  // }, [duration]);

  const formatDate = (date) => date.toISOString().split("T")[0];

  // const [projectdate, setEntryDate] = useState(formatDate(new Date()));
  const [projectdate, setEntryDate] = useState(new Date());
  const [typeofwork, setTypeofwork] = useState("");

  const getEndDate = (selectedOptions, type_of_work) => {
    // console.log(
    //   "selectedOptions, type_of_work :",
    //   selectedOptions,
    //   type_of_work
    // );
    const { total, statistician, writer, reviewer, journal } = getTotalDuration(
      selectedOptions,
      type_of_work
    );

    const formatDate = (days) => {
      if (!projectdate || isNaN(new Date(projectdate))) {
        return new Date().toISOString().split("T")[0];
      }

      const date = new Date(projectdate);
      date.setDate(date.getDate() + days);
      return date.toISOString().split("T")[0]; // Format YYYY-MM-DD
    };

    return {
      project_duration:
        total > 0 ? formatDate(total) : new Date().toISOString().split("T")[0],
      writer_project_duration:
        writer > 0
          ? formatDate(writer)
          : new Date().toISOString().split("T")[0],
      reviewer_project_duration:
        reviewer > 0
          ? formatDate(reviewer)
          : new Date().toISOString().split("T")[0],
      statistician_project_duration:
        statistician > 0
          ? formatDate(statistician)
          : new Date().toISOString().split("T")[0],
      journal_project_duration:
        journal > 0
          ? formatDate(journal)
          : new Date().toISOString().split("T")[0],
    };
  };

  // Example Usage:
  const selectedOptions = formFields[0]?.specificOption || [];
  const typeOfWork = typeofwork;

  const durations = getTotalDuration(selectedOptions, typeOfWork);

  // console.log("check data duration", durations);

  // useEffect(() => {
  //   if (!Array.isArray(selectedOptions)) return;

  //   const durations = getEndDate(selectedOptions, typeofwork);

  //   setFormData((prevData) => ({
  //     ...prevData,
  //     project_duration: durations.project_duration,
  //     writerprojectduration: durations.writer_project_duration,
  //     reviewerProjectDuration: durations.reviewer_project_duration,
  //     statisticanprojectduration: durations.statistician_project_duration,
  //     journalprojectduration: durations.journal_project_duration,
  //   }));

  //   setWriterFields((prevFields) =>
  //     prevFields.map((field, index) =>
  //       index === 0
  //         ? {
  //             ...field,
  //             writerprojectduration: durations.writer_project_duration,
  //           }
  //         : field
  //     )
  //   );

  //   setReviewerFields((prevFields) =>
  //     prevFields.map((field, index) =>
  //       index === 0
  //         ? {
  //             ...field,
  //             reviewerProjectDuration: durations.reviewer_project_duration,
  //           }
  //         : field
  //     )
  //   );

  //   setStatisticanFields((prevFields) =>
  //     prevFields.map((field, index) =>
  //       index === 0
  //         ? {
  //             ...field,
  //             statisticanProjectDuration:
  //               durations.statistician_project_duration,
  //           }
  //         : field
  //     )
  //   );

  //   setJournalFields((prevFields) =>
  //     prevFields.map((field, index) =>
  //       index === 0
  //         ? {
  //             ...field,
  //             journalProjectDuration: durations.journal_project_duration,
  //           }
  //         : field
  //     )
  //   );
  // }, [selectedOptions, typeOfWork]); 

useEffect(() => {
  if (!Array.isArray(selectedOptions) || selectedOptions.length === 0 || !typeOfWork) return;

  const durations = getEndDate(selectedOptions, typeOfWork);

  // First, update the main form data if needed
  setFormData((prevData) => {
    const shouldUpdate =
      prevData.project_duration !== durations.project_duration ||
      prevData.writerprojectduration !== durations.writer_project_duration ||
      prevData.reviewerProjectDuration !== durations.reviewer_project_duration ||
      prevData.statisticanprojectduration !== durations.statistician_project_duration ||
      prevData.journalprojectduration !== durations.journal_project_duration;

    if (!shouldUpdate) return prevData;

    return {
      ...prevData,
      project_duration: durations.project_duration,
      writerprojectduration: durations.writer_project_duration,
      reviewerProjectDuration: durations.reviewer_project_duration,
      statisticanprojectduration: durations.statistician_project_duration,
      journalprojectduration: durations.journal_project_duration,
    };
  });

  // Then, update the writer/reviewer/etc. fields — safely outside of setFormData
  setWriterFields((prevFields) =>
    prevFields.map((field, index) =>
      index === 0
        ? { ...field, writerprojectduration: durations.writer_project_duration }
        : field
    )
  );

  setReviewerFields((prevFields) =>
    prevFields.map((field, index) =>
      index === 0
        ? { ...field, reviewerProjectDuration: durations.reviewer_project_duration }
        : field
    )
  );

  setStatisticanFields((prevFields) =>
    prevFields.map((field, index) =>
      index === 0
        ? { ...field, statisticanProjectDuration: durations.statistician_project_duration }
        : field
    )
  );

  setJournalFields((prevFields) =>
    prevFields.map((field, index) =>
      index === 0
        ? { ...field, journalProjectDuration: durations.journal_project_duration }
        : field
    )
  );
}, [selectedOptions, typeOfWork]);


  const [formData, setFormData] = useState({
    entrydate: getTodayDate() || "",
    typeofwork: "",
    projectid: "",
    clientName: "",
    profession: "",
    title: "",
    institute: "",
    contactNo: "",
    department: "",
    email: "",
    hierarchy: "",
    writer: "",
    writerDate: getTodayDate() || "",
    writerStatus: "to_do",
    writerStatusDate: getTodayDate() || "",
    reviwer: "",
    reviwerAssignedDate: getTodayDate() || "",
    reviwerStatus: "to_do",
    reviwerstatusdate: getTodayDate() || "",
    statistican: "",
    statisticanDate: getTodayDate() || "",
    statisticanStatus: "to_do",
    statisticanStatusDate: getTodayDate() || "",
    journal: "",
    journalDate: getTodayDate() || "",
    journalStatus: "",
    journalStatusDate: getTodayDate() || "",
    duration: "",
    reviwerduration: "",
    statisticanduration: "",
    journalduration: "",
    processStatus: "not_assigned",
    budget: "",
    journaldurationUnit: "days",
    writerdurationUnit: "days",
    reviwerdurationUnit: "days",
    statisticandurationUnit: "days",
    commandbox: "",
    processStatusDate: getTodayDate() || "",
    else_project_manager: false,
    project_duration: "",
    writerprojectduration: "",
    reviewerProjectDuration: "",
    statisticanprojectduration: "",
    journalprojectduration: "",
    writer_comment: "",
    reviewer_comment: "",
    statistican_comment: "",
    journal_comment: "",
    payment_status: "advance_pending",
    discount: "",
    reference_number: "",
    typeofarticle: "",
    review: "",
    journalAssignedDate: "",
    file: null, // Add file
  });

  // console.log('formData :',formData);

  //  writer
  const [writerFields, setWriterFields] = useState([
    {
      writer: "",
      writerDate: getTodayDate() || "",
      writerStatus: "to_do",
      writerStatusDate: getTodayDate() || "",
      writerprojectduration: formData.writerprojectduration || getTodayDate(),
      writer_comment: "",
      error: false,
    },
  ]);

  const handlewriterChange = (index, field, value) => {
    const updatedFields = [...writerFields];
    updatedFields[index][field] = value;
    setWriterFields(updatedFields);

    if (field === "writer" && value) {
      updatedFields[index].error = false;
    }
  };

  const handleAddWriterField = () => {
    const lastEntry = writerFields[writerFields.length - 1];

    if (!lastEntry.writer) {
      const updatedFields = [...writerFields];
      updatedFields[writerFields.length - 1].error = true;
      setWriterFields(updatedFields);
      return;
    }

    setWriterFields([
      ...writerFields,
      {
        writer: "",
        writerDate: getTodayDate() || "",
        writerStatus: "to_do",
        writerStatusDate: getTodayDate() || "",
        writerprojectduration: formData.writerprojectduration,
        writer_comment: "",
      },
    ]);
  };

  const handleDeleteWriterField = (index) => {
    const updatedFields = writerFields.filter((_, i) => i !== index);
    setWriterFields(updatedFields);
  };

  // reviwer
  const [reviewerFields, setReviewerFields] = useState([
    {
      reviewer: "",
      reviewerAssignedDate: getTodayDate() || "",
      reviewerStatus: "to_do",
      reviewerStatusDate: getTodayDate() || "",
      reviewerProjectDuration:
        formData.reviewerProjectDuration || getTodayDate(),
      reviewer_comment: "",
      error: false,
    },
  ]);

  // console.log("check data", reviewerFields);

  const handleReviewerChange = (index, field, value) => {
    const updatedFields = [...reviewerFields];
    updatedFields[index][field] = value;
    setReviewerFields(updatedFields);

    if (field === "reviewer" && value) {
      updatedFields[index].error = false;
    }
  };

  const handleAddReviewerField = () => {
    const lastEntry = reviewerFields[reviewerFields.length - 1];

    if (!lastEntry.reviewer) {
      const updatedFields = [...reviewerFields];
      updatedFields[reviewerFields.length - 1].error = true;
      setReviewerFields(updatedFields);
      return;
    }

    setReviewerFields([
      ...reviewerFields,
      {
        reviewer: "",
        reviewerAssignedDate: getTodayDate() || "",
        reviewerStatus: "to_do",
        reviewerStatusDate: getTodayDate() || "",
        reviewerProjectDuration: formData.reviewerProjectDuration,
        reviewer_comment: "",
      },
    ]);
  };

  const handleDeleteReviewerField = (index) => {
    const updatedFields = reviewerFields.filter((_, i) => i !== index);
    setReviewerFields(updatedFields);
  };
  
  // statistican
  const [statisticanFields, setStatisticanFields] = useState([
    {
      statistican: "",
      statisticanAssignedDate: getTodayDate() || "",
      statisticanStatus: "to_do",
      statisticanStatusDate: getTodayDate() || "",
      statisticanProjectDuration:
        formData.statisticanprojectduration || getTodayDate(),
      statistican_comment: "",
      error: false,
    },
  ]);

  const handleStatisticanChange = (index, field, value) => {
    const updatedFields = [...statisticanFields];
    updatedFields[index][field] = value;
    setStatisticanFields(updatedFields);

    if (field === "statistican" && value) {
      updatedFields[index].error = false;
    }
  };

  const handleAddStatisticanField = () => {
    const lastEntry = statisticanFields[statisticanFields.length - 1];

    if (!lastEntry.statistican) {
      const updatedFields = [...statisticanFields];
      updatedFields[statisticanFields.length - 1].error = true;
      setStatisticanFields(updatedFields);
      return;
    }

    setStatisticanFields([
      ...statisticanFields,
      {
        statistican: "",
        statisticanAssignedDate: getTodayDate() || "",
        statisticanStatus: "to_do",
        statisticanStatusDate: getTodayDate() || "",
        statisticanProjectDuration: formData.statisticanprojectduration,
        statistican_comment: "",
      },
    ]);
  };

  const handleDeleteStatisticanField = (index) => {
    const updatedFields = statisticanFields.filter((_, i) => i !== index);
    setStatisticanFields(updatedFields);
  };

  //end

  //journal

  const [journalFields, setJournalFields] = useState([
    {
      journal: "",
      journalAssignedDate: getTodayDate() || "",
      journalStatus: "",
      journalStatusDate: getTodayDate() || "",
      journalProjectDuration: formData.journalprojectduration || getTodayDate(),
      journal_comment: "",
      type_of_article: "",
      review: "",
      error: false,
    },
  ]);

  // console.log("journalFields :", journalFields);

  const handleJournalChange = (index, field, value) => {
    const updatedFields = [...journalFields];
    updatedFields[index][field] = value;
    setJournalFields(updatedFields);

    if (field === "journal" && value) {
      updatedFields[index].error = false;
    }
  };

  const handleAddJournalField = () => {
    const lastEntry = journalFields[journalFields.length - 1];

    if (!lastEntry.journal) {
      const updatedFields = [...journalFields];
      updatedFields[journalFields.length - 1].error = true;
      setJournalFields(updatedFields);
      return;
    }

    setJournalFields([
      ...journalFields,
      {
        journal: "",
        journalAssignedDate: getTodayDate() || "",
        journalStatus: "",
        journalStatusDate: getTodayDate() || "",
        journalProjectDuration:
          formData.journalprojectduration || getTodayDate(),
        journal_comment: "",
        type_of_article: "",
        review: "",
        error: false,
      },
    ]);
  };

  const handleDeleteJournalField = (index) => {
    const updatedFields = journalFields.filter((_, i) => i !== index);
    setJournalFields(updatedFields);
  };

  const [errors, setErrors] = useState({});

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;

    // setFormData({
    //   ...formData,
    //   [name]: value,
      
    // });

     setFormData((prevFormData) => ({
    ...prevFormData,
    [name]: value,
    // If processStatus is set to "not_assigned", uncheck the checkbox
    else_project_manager:
      name === "processStatus" && value === "not_assigned"
        ? false
        : prevFormData.else_project_manager,
  }));

    if (name === "entrydate") {
      setEntryDate(value);
    }
    setErrors((prevErrors) => {
      const { [name]: removedError, ...rest } = prevErrors;
      return rest;
    });

    // Trigger specific field validations
    if (name === "email") validateEmail(value);
    if (name === "contactNo") validateContact(value);
  };
  const validateEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

    if (!email.trim()) {
      // setFormErrors((prevErrors) => ({
      //   ...prevErrors,
      //   email: "Email is required",
      // }));
    } else if (!emailRegex.test(email)) {
      setFormErrors((prevErrors) => ({
        ...prevErrors,
        email: "Invalid email format",
      }));
    } else {
      setFormErrors((prevErrors) => ({
        ...prevErrors,
        email: "",
      }));
    }
  };

  const validateContact = (contact) => {
    const phoneNumberRegex = /^[+]?[0-9]{9,15}$/;

    if (!contact.trim()) {
      setFormErrors((prevErrors) => ({
        ...prevErrors,
        contactNo: "Contact is required",
      }));
    } else if (!phoneNumberRegex.test(contact.trim())) {
      setFormErrors((prevErrors) => ({
        ...prevErrors,
        contactNo: "Invalid phone number. It must be between 10-15 digits.",
      }));
    } else {
      setFormErrors((prevErrors) => ({
        ...prevErrors,
        contactNo: "",
      }));
    }
  };

  const [formErrors, setFormErrors] = useState({});

  const validateForm = () => {
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    const phoneNumberRegex = /^[+]?[0-9]{9,15}$/;
    let formErrors = {};

    if (!formData.project_duration)
      formErrors.project_duration = "Completion date is required";
    if (!formData.entrydate) formErrors.entrydate = "EntryDate is required";
    if (!typeofwork) formErrors.typeofwork = "typeofwork is required";
    if (!formData.clientName) formErrors.clientName = "Client Name is required";
    // if (!formData.title) formErrors.title = "Title is required";
    if (!formData.profession) formErrors.profession = "Profession is required";
    if (!formData.department) formErrors.department = "Department is required";
    if (!formData.institute) formErrors.institute = "Institute is required";

    if (!formData.email == "") {
      if (!emailRegex.test(formData.email)) {
        formErrors.email = "Invalid email format";
      }
    }

    if (formData.contactNo.trim() !== "") {
      if (!phoneNumberRegex.test(formData.contactNo.trim())) {
        formErrors.contactNo =
          "Invalid phone number. It must be between 10-15 digits.";
      } else {
        delete formErrors.contactNo; // Remove validation error when valid
      }
    }

    if (!formData.contactNo) formErrors.contactNo = "contact is required";

    if (!formData.hierarchy) formErrors.hierarchy = "hierarchy is required";

    formFields.forEach((field, index) => {
      if (!field.specificOption || field.specificOption.length === 0) {
        formErrors[`specificOption_${index}`] = "Specific Option is required";
      }
      if (!field.file || field.file.length === 0) {
        formErrors[`file_${index}`] = "File is required";
      }
    });

    const hasValidPayment = paymentFields.some(
      (field) => field.amount.trim() !== "" && field.date.trim() !== ""
    );

    if (hasValidPayment && !formData.payment_status) {
      formErrors.payment_status = "Payment status is required.";
    }

    setErrors(formErrors);
    setFormErrors(formErrors);
    return formErrors;
  };

  const [currentChoice, setCurrentChoice] = useState("");
  const [query, setQuery] = useState("");
  const [dropdownItems, setProfessions] = useState([]);
  const [isDropdownVisible, setDropdownVisible] = useState(false);

  const filteredItems = dropdownItems.filter((item) =>
    item.name.toLowerCase().includes(query.toLowerCase())
  );

  const handleSelectItem = (id, name) => {
    setCurrentChoice({ id, name });
    setFormData({
      ...formData,
      profession: id,
    });
    setErrors({
      ...errors,
      profession: "",
    });
    setQuery("");
    setDropdownVisible(false);
  };

  const toggleDropmenu = () => {
    setDropdownVisible((prev) => !prev);
    setListExpanded(false);
    setIsDropdownOpen(false);
  };

  // institute...................................................=>
  const [selectedOption, setSelectedOption] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [optionsinstitute, setIntitutes] = useState([]);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const filteredOptions = optionsinstitute.filter((institute) =>
    institute.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSelectOption = (id, name) => {
    setSelectedOption({ id, name });
    setIsDropdownOpen(false);
  };

  const toggleDropdowninstitue = () => {
    setIsDropdownOpen((prev) => !prev);
    setDropdownVisible(false);
  };

  // department........................................................>
  const [chosenOption, setChosenOption] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [availableOptions, setDepartments] = useState([]);
  const [isListExpanded, setListExpanded] = useState(false);

  const filtereddepOptions = availableOptions.filter((option) =>
    option.name.toLowerCase().includes(searchInput.toLowerCase())
  );

  const handledepOptionSelect = (id, name) => {
    setChosenOption({ id, name });
    setListExpanded(false);
  };

  const toggleList = () => {
    setListExpanded((prev) => !prev);
    setDropdownVisible(false);
    setIsDropdownOpen(false);
  };

  //multiplfunction update

  const [showWriter, setShowWriter] = useState(false);
  const [showReviewer, setShowReviewer] = useState(false);
  const [showStatistican, setShowStatistican] = useState(false);
  const [showJournal, setShowJournal] = useState(false);
  const [showProject, setShowProject] = useState(false);

  const handleWriterClick = () => {
    setShowWriter(!showWriter);

    // Clear writer-related fields when unchecking
    if (showWriter) {
      setFormData((prevData) => ({
        ...prevData,
        writer: "",
        writerStatus: "",
        // writerdurationUnit: "",
        // duration: "",
        writerprojectduration: "",
      }));

      setWriterFields([
        {
          writer: "",
          writerDate: getTodayDate() || "",
          writerStatus: "to_do",
          writerStatusDate: getTodayDate() || "",
          writerprojectduration:
            formData.writerprojectduration || getTodayDate(),
          writer_comment: "",
          error: false,
        },
      ]);
    }
  };

  const handleStatisticanClick = () => {
    setShowStatistican(!showStatistican);

    if (showStatistican) {
      setFormData((prevData) => ({
        ...prevData,
        statistican: "",
        statisticanStatus: "",
        statisticanprojectduration: "",
        // statisticandurationUnit: "",
      }));

      setStatisticanFields([
        {
          statistican: "",
          statisticanAssignedDate: getTodayDate() || "",
          statisticanStatus: "to_do",
          statisticanStatusDate: getTodayDate() || "",
          statisticanProjectDuration:
            formData.statisticanprojectduration || getTodayDate(),
          statistican_comment: "",
          error: false,
        },
      ]);
    }
  };

  const handleReviewerClick = () => {
    setShowReviewer(!showReviewer);

    if (showReviewer) {
      setFormData((prevData) => ({
        ...prevData,
        reviwer: "",
        reviwerStatus: "",
        reviewerProjectDuration: "",
        // reviwerdurationUnit: "",
      }));

      setReviewerFields([
        {
          reviewer: "",
          reviewerAssignedDate: getTodayDate() || "",
          reviewerStatus: "to_do",
          reviewerStatusDate: getTodayDate() || "",
          reviewerProjectDuration:
            formData.reviewerProjectDuration || getTodayDate(),
          reviewer_comment: "",
          error: false,
        },
      ]);
    }
  };

  const handleProjectClick = (e) => {
    const isChecked = e.target.checked;

    // Update the checkbox value in the formData
    setFormData((prevData) => ({
      ...prevData,
      else_project_manager: isChecked,
    }));

    // Only toggle reviewer and other states if the checkbox is unchecked
    if (!isChecked) {
      setShowReviewer(false);

      // Clear reviewer-related data
      setFormData((prevData) => ({
        ...prevData,
        reviwer: "",
        reviwerStatus: "",
        reviewerProjectDuration: "",
        // reviwerdurationUnit: "",
      }));

      if (showStatistican) {
        setShowStatistican(false);

        setFormData((prevData) => ({
          ...prevData,
          statistican: "",
          statisticanStatus: "",
          statisticanprojectduration: "",
          // statisticandurationUnit: "",
        }));
        setStatisticanFields([
          {
            statistican: "",
            statisticanAssignedDate: getTodayDate() || "",
            statisticanStatus: "to_do",
            statisticanStatusDate: getTodayDate() || "",
            statisticanProjectDuration:
              formData.statisticanprojectduration || getTodayDate(),
            statistican_comment: "",
            error: false,
          },
        ]);
      }

      if (showWriter) {
        setShowWriter(false);
        setFormData((prevData) => ({
          ...prevData,
          writer: "",
          writerStatus: "",
          writerdurationUnit: "",
          writerprojectduration: "",
          // durationInput: "",
        }));
        setWriterFields([
          {
            writer: "",
            writerDate: getTodayDate() || "",
            writerStatus: "to_do",
            writerStatusDate: getTodayDate() || "",
            writerprojectduration:
              formData.writerprojectduration || getTodayDate(),
            writer_comment: "",
            error: false,
          },
        ]);
      }

      if (showReviewer) {
        setShowReviewer(false);
        setFormData((prevData) => ({
          ...prevData,
          reviwer: "",
          reviwerStatus: "",
          reviewerProjectDuration: "",
          // reviwerdurationUnit: "",
        }));
        setReviewerFields([
          {
            reviewer: "",
            reviewerAssignedDate: getTodayDate() || "",
            reviewerStatus: "to_do",
            reviewerStatusDate: getTodayDate() || "",
            reviewerProjectDuration:
              formData.reviewerProjectDuration || getTodayDate(),
            reviewer_comment: "",
            error: false,
          },
        ]);
      }

      if (showJournal) {
        setShowJournal(false);
        setFormData((prevData) => ({
          ...prevData,
          journal: "",
          journalStatus: "",
          journalprojectduration: "",
          // journaldurationUnit: "",
        }));
        setJournalFields([
          {
            journal: "",
            journalAssignedDate: getTodayDate() || "",
            journalStatus: "",
            journalStatusDate: getTodayDate() || "",
            journalProjectDuration:
              formData.journalprojectduration || getTodayDate(),
            journal_comment: "",
            type_of_article: "",
            review: "",
            error: false,
          },
        ]);
      }
    }
  };

  const handleJournalClick = () => {
    setShowJournal(!showJournal);
    // setJournalFields('');
    if (showJournal) {
      setFormData((prevData) => ({
        ...prevData,
        journal: "",
        journalStatus: "",
        journalprojectduration: "",
        // journaldurationUnit: "",
      }));

      // Reset journalFields to initial empty state
      setJournalFields([
        {
          journal: "",
          journalAssignedDate: getTodayDate() || "",
          journalStatus: "",
          journalStatusDate: getTodayDate() || "",
          journalProjectDuration:
            formData.journalprojectduration || getTodayDate(),
          journal_comment: "",
          type_of_article: "",
          review: "",
          error: false,
        },
      ]);
    }
  };

  const optionsMapping = {
    statistics: [
      { value: "sample_size", label: "Sample Size" },
      { value: "paper_statistics", label: "Paper Statistics" },
      {
        value: "thesis_statistics_with_text",
        label: "Thesis Statistics - With Text",
      },
      {
        value: "thesis_statistics_without_text",
        label: "Thesis Statistics - Without Text",
      },
    ],
    manuscript: [
      { value: "writing", label: "Writing" },
      { value: "with_statistics", label: "With Statistics" },
      { value: "with_publication", label: "With Publication" },
    ],
    thesis: [
      {
        value: "supporting_thesis_with_ms",
        label: "Supporting Thesis with MS",
      },
      {
        value: "supporting_thesis_without_ms",
        label: "Supporting Thesis without MS",
      },
      { value: "supporting_thesis_part1", label: "Supporting Thesis Part - 1" },
      { value: "supporting_thesis_part2", label: "Supporting Thesis Part - 2" },

      { value: "thesis_reviewing", label: "Thesis Reviewing" },
    ],
    presentation: [
      { value: "conference_presentation", label: "Conference Presentation" },
      { value: "with_statistics", label: "With Statistics" },
      { value: "poster_presentation", label: "Poster Presentation" },
    ],
    others: [],
  };

  const handleSpecificChange = useCallback((e, index) => {
    const { name, value } = e.target;
    setFormFields((prevFormFields) => {
      const updatedFormFields = [...prevFormFields];
      updatedFormFields[index][name] = value;
      return updatedFormFields;
    });
  }, []);

  const handlelistfileDelete = (index, fileIndex) => {
    setFormFields((prevFormFields) => {
      const updatedFormFields = [...prevFormFields];
      updatedFormFields[index].file = updatedFormFields[index].file.filter(
        (file, idx) => idx !== fileIndex // Remove file at the given index
      );
      return updatedFormFields;
    });
  };

  const handleFileChange = useCallback((index, e) => {
    const files = Array.from(e.target.files); // Convert file list to array

    setFormFields((prevFormFields) => {
      const updatedFormFields = [...prevFormFields];
      // Add new files to the existing ones for the current index
      updatedFormFields[index].file = [
        ...(updatedFormFields[index].file || []),
        ...files, // Append new files to the existing file array
      ];
      return updatedFormFields;
    });
  }, []);

  // Handle file delete
  const handleFileDelete = useCallback((index) => {
    setFormFields((prevFormFields) => {
      const updatedFormFields = [...prevFormFields];
      updatedFormFields[index].file = null;
      return updatedFormFields;
    });
  }, []);

  const validateFormFiles = () => {
    const validationErrors = {};

    formFields.forEach((field, index) => {
      if (!field.specificOption) {
        validationErrors[`specificOption_${index}`] =
          "Specific Option is required";
      }
      if (!field.file) {
        validationErrors[`file_${index}`] = "File is required";
      }
    });

    return validationErrors;
  };

  // Handle adding a new field
  const handleAddField = useCallback(() => {
    const validationErrors = validateFormFiles();

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors); // Set errors to state if validation fails
    } else {
      setFormFields((prevFormFields) => [
        ...prevFormFields,
        { specificOption: "", file: null },
      ]);
    }
  }, []);

  // Handle delete field
  const handleDeleteField = useCallback((index) => {
    setFormFields((prevFormFields) =>
      prevFormFields.filter((_, i) => i !== index)
    );
  }, []);

  const handleChangeselect = (e, index) => {
    const { name, value } = e.target;
    setFormFields((prevFormFields) => {
      const updatedFormFields = [...prevFormFields];
      updatedFormFields[index][name] = value;
      return updatedFormFields;
    });
  };

  const [isDropdowncheck, setIsDropdowncheck] = useState(false);

  const toggleDropcheck = () => {
    setIsDropdowncheck((prev) => !prev);
  };

  //Institiue list

  const fetchRoles = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/institutions`
      );

      setIntitutes(response.data);
    } catch (err) {
      console.log("Failed to fetch roles.");
    }
  };

  const fetchDepartments = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/departments`
      );
      setDepartments(response.data);
    } catch (err) {
      console.log("Failed to fetch roles.");
    }
  };

  const fetchProfession = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/professions`
      );

      setProfessions(response.data);
    } catch (err) {
      console.log("Failed to fetch roles.");
    }
  };

  useEffect(() => {
    fetchRoles();
    fetchDepartments();
    fetchProfession();
  }, []);

  //project id

  const [commentval, setCommentBox] = useState(""); // State to store content

  const handleCommentChange = (newContent) => {
    setCommentBox(newContent); // Set the updated content from the editor
  };

  // Handle Type of Work Change
  const [customId, setCustomId] = useState("");

  const handleTypeOfWorkChange = async (e) => {
    const selectedType = e.target.value;
    setTypeofwork(selectedType);

    try {
      const response = await axios.post(`${API_URL}/api/customId`, {
        type_of_work: selectedType,
      });
      const customId = response.data.custom_id;
      setCustomId(customId);
      setFormData((prev) => ({ ...prev, project_id: customId }));
      setFormFields((prev) => [
        {
          ...prev[0],
          specificOption: "", // Reset specificOption when type of work changes
        },
      ]);
    } catch (error) {
      console.error("Error generating custom ID:", error);
    }
  };

  const [writter, setWritter] = useState([]);
  const [reviewer, setReviewer] = useState([]);
  const [statistical, setStatistical] = useState([]);
  const [journal, setJournal] = useState([]);

  const fetchData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/getEmployeeName`
      );
      const data = response.data;

      // Update the state with the received data
      if (data) {
        setWritter(data.writer || []);
        setReviewer(data.reviewer || []);
        setStatistical(data.statistican || []);
        setJournal(data.journal || []);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    // Fetch data from the API when the component mounts
    fetchData();
  }, []);

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;
  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    const validationErrors = validateForm();

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    if (showWriter || showReviewer || showStatistican || showJournal) {
      if (Object.keys(validationErrors).length > 0) {
        setErrors(validationErrors);
        return;
      }
    }

    const formattedWriterData = writerFields.some((writer) => writer.writer)
      ? writerFields.map((writer) => ({
          writer: writer.writer,
          writerDate: writer.writerDate,
          writerStatus: writer.writerStatus,
          writerStatusDate: writer.writerStatusDate,
          writerprojectduration: writer.writerprojectduration,
          writer_comment: writer.writer_comment,
          error: writer.error,
        }))
      : [];

    const formattedReviewerData = reviewerFields.some(
      (reviewer) => reviewer.reviewer
    )
      ? reviewerFields.map((reviewer) => ({
          reviewer: reviewer.reviewer,
          reviewerAssignedDate: reviewer.reviewerAssignedDate,
          reviewerStatus: reviewer.reviewerStatus,
          reviewerStatusDate: reviewer.reviewerStatusDate,
          reviewerProjectDuration: reviewer.reviewerProjectDuration,
          reviewer_comment: reviewer.reviewer_comment,
          error: reviewer.error,
        }))
      : [];

    const formattedStatisticanData = statisticanFields.some(
      (statistican) => statistican.statistican
    )
      ? statisticanFields.map((statistican) => ({
          statistican: statistican.statistican,
          statisticanAssignedDate: statistican.statisticanAssignedDate,
          statisticanStatus: statistican.statisticanStatus,
          statisticanStatusDate: statistican.statisticanStatusDate,
          statisticanProjectDuration: statistican.statisticanProjectDuration,
          statistican_comment: statistican.statistican_comment,
          error: statistican.error,
        }))
      : [];

    const formattedJournalData = journalFields.some(
      (journal) => journal.journal
    )
      ? journalFields.map((journal) => ({
          journal: journal.journal,
          journalAssignedDate: journal.journalAssignedDate,
          journalStatus: journal.journalStatus,
          journalStatusDate: journal.journalStatusDate,
          journalProjectDuration: journal.journalProjectDuration,
          journal_comment: journal.journal_comment,
          type_of_article: journal.type_of_article,
          review: journal.review,
          error: journal.error,
        }))
      : [];

    // Map state values to backend keys
    const backendFormData = {
      entry_date: formData.entrydate,
      title: formData.title,
      type_of_work: typeofwork,
      project_id: customId,
      client_name: formData.clientName,
      email: formData.email,
      contact_number: formData.contactNo,
      institute: formData.institute,
      department: formData.department,
      profession: formData.profession,
      budget: formData.budget,
      process_status: formData.processStatus,
      process_date: formData.processStatusDate,
      hierarchy_level: formData.hierarchy,
      comment_box: formData.commandbox,
      else_project_manager: formData.else_project_manager,
      writer: formattedWriterData,
      reviewer: formattedReviewerData,
      statistican: formattedStatisticanData,
      journal: formattedJournalData,
      entryprocess_documents: formFields.filter(
        (field) => field.specificOption || field.file
      ),
      created_by: createdby,
      project_duration: formData.project_duration,
      //payment update
      payment_details: paymentFields,
      payment_status: formData.payment_status,
    };

    // console.log('check backendFormData', backendFormData);
    document.getElementById("global-loader").style.display = "flex";
    setTimeout(async () => {
      try {
        const response = await axios.post(
          `${API_URL}/api/entry_process/store`,
          backendFormData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );

        if (response.status === 200 || response.status === 201) {
          Swal.fire({
            title: "Success!",
            text: "Project added successfully.",
            icon: "success",
            confirmButtonText: "OK",
          }).then(() => {
            // Navigate after clicking "OK"
            // navigate(`/entry-process/${response.data.project_id}`);
            navigate("/entry-process/process-view-details", {
              state: { rowId: response.data.project_id },
            });
          });
        } else {
          console.error("Error occurred:", response.statusText);
        }
      } catch (error) {
        // Show error message
        Swal.fire({
          title: "Error!",
          text: "Something went wrong while creating the entry.",
          icon: "error",
          confirmButtonText: "OK",
        });
      } finally {
        document.getElementById("global-loader").style.display = "none";
      }
    }, 500);
  };

  // institute use ref
  const dropdownRef = useRef(null);

  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setIsDropdownOpen(false); // Close dropdown when clicking outside
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);
  //  department ref

  const dropdepRef = useRef(null);

  const handleClickdep = (event) => {
    if (
      isListExpanded &&
      dropdepRef.current &&
      !dropdepRef.current.contains(event.target)
    ) {
      setListExpanded(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickdep);
    return () => {
      document.removeEventListener("mousedown", handleClickdep);
    };
  }, [isListExpanded]);

  // profession

  const dropprofRef = useRef(null);
  const handleClickprof = (event) => {
    if (
      isDropdownVisible &&
      dropprofRef.current &&
      !dropprofRef.current.contains(event.target)
    ) {
      setDropdownVisible(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickprof);
    return () => {
      document.removeEventListener("mousedown", handleClickprof);
    };
  }, [isDropdownVisible]);
  const dropselectRef = useRef(null);

  const handleClickOutsideselect = (event) => {
    if (
      dropselectRef.current &&
      !dropselectRef.current.contains(event.target)
    ) {
      setIsDropdowncheck(false);
    }
  };
  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutsideselect);
    return () => {
      document.removeEventListener("mousedown", handleClickOutsideselect);
    };
  }, []);

  // paymnet
  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const [paymentFields, setPaymentFields] = useState([
    { amount: "", date: "" },
  ]);

  const validatePaymentFormFiles = () => {
    const validationErrors = {};

    // Validate payment fields
    paymentFields.forEach((paymentField, index) => {
      if (!paymentField.amount) {
        validationErrors[`amount_${index}`] = "Amount is required";
      }
      if (!paymentField.date) {
        validationErrors[`date_${index}`] = "Date is required";
      }
    });

    return validationErrors;
  };

  const handleAddFieldpayment = () => {
    const validationErrors = validatePaymentFormFiles(); // Run validation

    if (Object.keys(validationErrors).length === 0) {
      // No errors, add new payment field
      setPaymentFields((prevPaymentFields) => [
        ...prevPaymentFields,
        { amount: "", date: "" },
      ]);
    } else {
      // Show validation errors
      setErrors(validationErrors);
    }
  };

  const handlePaymentRemoveField = (index) => {
    setPaymentFields(paymentFields.filter((_, i) => i !== index));
  };

  const handlePaymentChange = (index, field, value) => {
    const updatedFields = [...paymentFields];
    updatedFields[index][field] = value;
    setPaymentFields(updatedFields);
  };

  const handlePChange = (index, field, value) => {
    const updatedFields = [...paymentFields];
    updatedFields[index][field] = value;
    setPaymentFields(updatedFields);
  };
  //payment update

  const fileInputRef = useRef(null);
  const handleRefFileDelete = useCallback(() => {
    setFormData((prevData) => ({
      ...prevData,
      file: null,
    }));

    setErrors((prevErrors) => {
      const updatedErrors = { ...prevErrors };
      delete updatedErrors.reference_number;
      return updatedErrors;
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  }, []);

  const handleRefFileChange = useCallback((e) => {
    const file = e.target.files[0];
    setFormData((prevData) => ({
      ...prevData,
      file, // Update file in formData
    }));
  }, []);

  // enter click
  useEffect(() => {
    const listener = (event) => {
      if (event.code === "Enter" || event.code === "NumpadEnter") {
        event.preventDefault();
      }
    };
    document.addEventListener("keydown", listener);
    return () => {
      document.removeEventListener("keydown", listener);
    };
  }, []);

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }

  return (
    <>
      <section className="container">
        <div className=" row mt-4">
          {/* <div className=" col-1 d-flex justify-content-center">
            <Sider></Sider>
          </div> */}
          <div className="col-12">
            <div className="col-12">
              <Header></Header>
            </div>

            <div className="col-12 pt-1 wapper w-100 mt-3  ">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className="col-12 col-md-6  px-4 ">
                  <p className="heading-entr">New Project</p>
                </div>
                <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>
              <form>
                <div className="row w-100 mt-0 px-3 ">
                  <div className="col-12  d-flex flex-wrap justify-content-between">
                    <div className="col-12 col-md-4 d-flex flex-column">
                      <div className="col-md-12 float-start  ">
                        <label className="client-name-pop ">
                          Enter Details
                        </label>
                      </div>
                      <div className="col-12 col-md-8 pt-2 ">
                        <label className="statis-name ">Entry Date</label>
                        <input
                          type="date"
                          className={`form-control ${
                            errors.entrydate ? "error" : ""
                          }`}
                          name="entrydate"
                          value={formData.entrydate}
                          onChange={handleChange}
                          required
                        />
                      </div>

                      <div className="col-12 col-md-8  float-6tart pt-2">
                        <label className="statis-name">Type of Work</label>
                        <select
                          className={`form-select ${
                            errors.typeofwork ? "error" : ""
                          }`}
                          name="typeofwork"
                          value={typeofwork}
                          // onChange={handleTypeOfWorkChange}
                          onChange={(e) => {
                            handleTypeOfWorkChange(e); // Update form data
                            if (errors.typeofwork) {
                              setErrors((prevErrors) => ({
                                ...prevErrors,
                                typeofwork: "",
                              })); // Clear title error
                            }
                          }}
                          required
                        >
                          <option value="" disabled>
                            Select an option
                          </option>
                          <option value="statistics">Statistics</option>
                          <option value="manuscript">Manuscript</option>
                          <option value="thesis">Thesis</option>
                          {/* /*---<option value="presentation">Presentation</option> */}
                          <option value="others">Others</option>
                        </select>
                      </div>

                      <div className="col-12 col-md-8  float-6tart pt-2 ">
                        <label className="statis-name ">Project ID</label>
                        <input
                          className={`form-control`}
                          name="project_id"
                          id="project_id"
                          value={capitalize(customId)}
                          placeholder="Enter the Project Id"
                          onChange={handleChange}
                          required
                        />
                      </div>

                      <div className=" col-12 col-md-8  float-6tart pt-2 ">
                        <label className="statis-name ">Title</label>
                        <input
                          type="text"
                          className={`form-control`}
                          name="title"
                          placeholder="Enter the Title"
                          value={formData.title}
                          // onChange={handleChange}
                          onChange={(e) => {
                            handleChange(e); // Update form data
                            if (errors.title) {
                              setErrors((prevErrors) => ({
                                ...prevErrors,
                                title: "",
                              })); // Clear title error
                            }
                          }}
                          required
                        />
                      </div>

                      {formFields.map((formData, index) => (
                        <div className=" mt-2  " key={index}>
                          <div className="col-12 col-md-8">
                            {index === 0 && (
                              <>
                                <label className="statis-name">
                                  Project Requirement
                                </label>
                                {typeofwork === "others" ? (
                                  <input
                                    type="text"
                                    className={`form-control ${
                                      errors[`specificOption_${index}`]
                                        ? "error"
                                        : ""
                                    }`}
                                    name="specificOption"
                                    value={formData.specificOption}
                                    onChange={(e) => {
                                      handleSpecificChange(e, index);
                                      // Remove validation error for this specific field
                                      const updatedErrors = { ...errors };
                                      delete updatedErrors[
                                        `specificOption_${index}`
                                      ];
                                      setErrors(updatedErrors); // Assuming setErrors is your function to manage errors state
                                    }}
                                    placeholder="Enter Others Option"
                                    required
                                  />
                                ) : (
                                  <div
                                    ref={dropselectRef}
                                    className="dropdown-container position-relative"
                                    onBlur={(e) => {
                                      if (
                                        !e.currentTarget.contains(
                                          e.relatedTarget
                                        )
                                      ) {
                                        setIsDropdowncheck(false);
                                      }
                                    }}
                                  >
                                    <div
                                      className={`form-select ${
                                        isDropdowncheck ? "open" : ""
                                      } ${
                                        errors[`specificOption_${index}`]
                                          ? "error"
                                          : ""
                                      }`}
                                      tabIndex={0}
                                      onClick={toggleDropcheck}
                                      onKeyDown={(e) => {
                                        if (
                                          e.key === "Enter" ||
                                          e.key === "Tab"
                                        ) {
                                          e.preventDefault();
                                          setIsDropdowncheck((prev) => !prev);
                                          if (!isDropdowncheck) {
                                            // Move focus to first option when opening
                                            setTimeout(() => {
                                              document
                                                .querySelector(
                                                  `.dropdown-list label:first-child`
                                                )
                                                ?.focus();
                                            }, 0);
                                          }
                                        } else if (
                                          e.key === "Tab" &&
                                          isDropdowncheck
                                        ) {
                                          e.preventDefault(); // Prevent dropdown reopening
                                          setIsDropdowncheck(false);
                                        }
                                      }}
                                    >
                                      {formData.specificOption?.length > 0
                                        ? formData.specificOption.join(", ")
                                        : "Select specific options"}
                                    </div>

                                    {isDropdowncheck && (
                                      <div className="dropdown-list">
                                        {optionsMapping[typeofwork]?.map(
                                          (option, optionIndex) => (
                                            <label
                                              key={option.value}
                                              className="checkbox-label"
                                              tabIndex={0} // Makes options focusable
                                              onKeyDown={(e) => {
                                                if (
                                                  e.key === "Enter" ||
                                                  e.key === " "
                                                ) {
                                                  e.preventDefault();
                                                  const updatedSelections =
                                                    formData.specificOption.includes(
                                                      option.value
                                                    )
                                                      ? formData.specificOption.filter(
                                                          (val) =>
                                                            val !== option.value
                                                        )
                                                      : [
                                                          ...(formData.specificOption ||
                                                            []),
                                                          option.value,
                                                        ];

                                                  handleSpecificChange(
                                                    {
                                                      target: {
                                                        name: "specificOption",
                                                        value:
                                                          updatedSelections,
                                                      },
                                                    },
                                                    index
                                                  );

                                                  const updatedErrors = {
                                                    ...errors,
                                                  };
                                                  delete updatedErrors[
                                                    `specificOption_${index}`
                                                  ];
                                                  setErrors(updatedErrors);

                                                  // Move focus to next option
                                                  const nextOption =
                                                    e.target.nextElementSibling;
                                                  if (nextOption) {
                                                    nextOption.focus();
                                                  } else {
                                                    // If it's the last option, close dropdown
                                                    setIsDropdowncheck(false);
                                                  }
                                                } else if (e.key === "Escape") {
                                                  setIsDropdowncheck(false);
                                                  // Return focus to dropdown button
                                                  document
                                                    .querySelector(
                                                      ".form-select"
                                                    )
                                                    ?.focus();
                                                }
                                              }}
                                            >
                                              <input
                                                type="checkbox"
                                                value={option.value}
                                                checked={
                                                  formData.specificOption?.includes(
                                                    option.value
                                                  ) || false
                                                }
                                                onChange={(e) => {
                                                  const updatedSelections = e
                                                    .target.checked
                                                    ? [
                                                        ...(formData.specificOption ||
                                                          []),
                                                        option.value,
                                                      ]
                                                    : formData.specificOption.filter(
                                                        (val) =>
                                                          val !== option.value
                                                      );

                                                  handleSpecificChange(
                                                    {
                                                      target: {
                                                        name: "specificOption",
                                                        value:
                                                          updatedSelections,
                                                      },
                                                    },
                                                    index
                                                  );

                                                  const updatedErrors = {
                                                    ...errors,
                                                  };
                                                  delete updatedErrors[
                                                    `specificOption_${index}`
                                                  ];
                                                  setErrors(updatedErrors);
                                                }}
                                              />
                                              {option.label}
                                            </label>
                                          )
                                        )}
                                      </div>
                                    )}
                                  </div>
                                )}
                              </>
                            )}
                          </div>

                          <div className="col-12 col-md-8 pt-2">
                            <label className="statis-name">File</label>
                            <div
                              className={`form-control d-flex justify-content-end ${
                                errors[`file_${index}`] ? "error" : ""
                              }`}
                            >
                              <input
                                type="file"
                                accept="file/*"
                                id="listfile"
                                multiple
                                onChange={(e) => {
                                  handleFileChange(index, e);
                                  const updatedErrors = { ...errors };
                                  delete updatedErrors[`file_${index}`];
                                  setErrors(updatedErrors);

                                  e.target.value = null;
                                }}
                                className="file-upload-input"
                              />
                              <br />

                              {formData.file && (
                                <RiDeleteBin6Line
                                  className="file-del-icon"
                                  onClick={() => handleFileDelete(index)}
                                />
                              )}
                              {!formData.file && (
                                <label className="file-icon" htmlFor="listfile">
                                  <PiCloudArrowUpLight />
                                </label>
                              )}
                            </div>

                            {/* {errors[index]?.file && (
                          <p className="text-danger">{errors[index].file}</p>
                        )} */}
                          </div>
                          {formFields[index].file &&
                            formFields[index].file.length > 0 && (
                              <div className="px-1 col-12 ">
                                {formFields[index].file.map(
                                  (file, fileIndex) => (
                                    <div>
                                      <MdOutlineCancel
                                        className="cancel-list  mx-1"
                                        onClick={() =>
                                          handlelistfileDelete(index, fileIndex)
                                        }
                                      />
                                      {file.name}
                                    </div>
                                  )
                                )}
                              </div>
                            )}

                          <div className="col d-flex justify-content-start  mt-4">
                            {/* {index === 0 && (
                              <button
                                type="button"
                                className="save-form-add mt-1"
                                onClick={handleAddField}
                              >
                                Add +
                              </button>
                            )} */}
                            {index !== 0 && (
                              <button
                                type="button"
                                className="save-form-del mt-1"
                                onClick={() => handleDeleteField(index)}
                              >
                                Delete
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="col-12 col-md-8 d-flex flex-column ">
                      <div className="col-md-12 float-start   ">
                        <label className="client-name-pop   ">
                          Client Information
                        </label>
                      </div>
                      <div className="row mt-2">
                        <div className="col-6 ">
                          <div className="col-12 col-md-10 float-start   ">
                            <label className="statis-name ">Client Name</label>
                            <input
                              type="text"
                              className={`form-control  ${
                                errors.clientName ? "error" : ""
                              }`}
                              name="clientName"
                              placeholder="Enter the name"
                              value={formData.clientName}
                              autoComplete="off"
                              // onChange={handleChange}
                              onChange={(e) => {
                                handleChange(e); // Update form data
                                if (errors.clientName) {
                                  setErrors((prevErrors) => ({
                                    ...prevErrors,
                                    clientName: "",
                                  })); // Clear title error
                                }
                              }}
                              required
                            />
                          </div>
                          <div className="col-12 col-md-10 float-start pt-2 ">
                            <label className="statis-name  ">Email ID</label>

                            <input
                              type="email"
                              className={`form-control`}
                              name="email"
                              placeholder="Enter the Email"
                              value={formData.email}
                              autoComplete="off"
                              onChange={(e) => {
                                handleChange(e);
                                // if (e.key !== 'Tab') {
                                // validateForm(e.target.value);
                                // }
                              }}
                              // onBlur={(e) => {
                              //   setFormErrors((prevErrors) => ({
                              //     ...prevErrors,
                              //     email: "",
                              //   }));
                              // }}
                              onBlur={(e) => validateEmail(e.target.value)}

                              // onKeyUp={(e) => {
                              //   // if (e.key === 'Tab') {
                              //     setFormErrors((prevErrors) => ({ ...prevErrors, email: '' }));
                              //   // }
                              // }}
                            />
                            {formErrors.email && (
                              <div className="error-text">
                                {formErrors.email}
                              </div>
                            )}
                          </div>

                          <div className="col-12 col-md-10 float-start pt-2">
                            <label className="statis-name  ">Contact No</label>
                            <input
                              type="number"
                              className={`form-control ${
                                formErrors.contactNo ? "error" : ""
                              }`}
                              placeholder="Enter the Contact No"
                              name="contactNo"
                              value={formData.contactNo}
                              autoComplete="off"
                              // onChange={handleChange}
                              onChange={(e) => {
                                handleChange(e); // Update form data
                                validateForm(e.target.value);
                              }}
                              // onBlur={(e) => {
                              //   setFormErrors((prevErrors) => ({
                              //     ...prevErrors,
                              //     contactNo: "",
                              //   }));
                              // }}
                              onBlur={(e) => validateContact(e.target.value)}
                              required
                            />
                            {formErrors.contactNo && (
                              <div className="error-text">
                                {formErrors.contactNo}
                              </div>
                            )}
                          </div>

                          <div className="col-12 col-md-10 float-start pt-2">
                            <label className="statis-name ">Institute</label>
                            <div className="d-flex  gap-2">
                              {/* <div
                                className="dropdown-container position-relative"
                                ref={dropdownRef}
                               
                              >

                                <input
                                  type="text"
                                  className={`form-control dropdown-search-header ${errors.institute ? "error" : ""
                                    }`}
                                  placeholder="Search Institute..."
                                  value={searchQuery || selectedOption.name || ""}
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    if (value === "") {
                                      setSelectedOption({});
                                    }
                                    setSearchQuery(value);
                                  }}
                                  onClick={toggleDropdowninstitue}
                                />

                                {isDropdownOpen && (
                                  <div className="dropdown  position-absolute">
                                    <div className="dropdown-options ">
                                      {filteredOptions.length > 0 ? (
                                        filteredOptions.map(
                                          (optionsinstitute, index) => (
                                            <div
                                              key={optionsinstitute.id}
                                              className="dropdown-option"
                                              onClick={() => {
                                                handleSelectOption(
                                                  optionsinstitute.id,
                                                  optionsinstitute.name
                                                ); 
                                                setFormData({
                                                  ...formData,
                                                  institute: optionsinstitute.id,
                                                }); 
                                                setErrors({
                                                  ...errors,
                                                  institute: "",
                                                }); 
                                                setSearchQuery("");
                                              }}
                                            >
                                              {optionsinstitute.name}
                                            </div>
                                          )
                                        )
                                      ) : (
                                        <div className="dropdown-no-options">
                                          No options found
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                )}
                              </div> */}

                              <div
                                className="dropdown-container position-relative"
                                ref={dropdownRef}
                              >
                                <input
                                  type="text"
                                  className={`form-control dropdown-search-header ${
                                    errors.institute ? "error" : ""
                                  }`}
                                  placeholder="Search Institute..."
                                  value={
                                    searchQuery || selectedOption.name || ""
                                  }
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    if (value === "") {
                                      setSelectedOption({});
                                    }
                                    setSearchQuery(value);
                                    setIsDropdownOpen(true); // Open dropdown when typing
                                  }}
                                  onClick={toggleDropdowninstitue}
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter" || e.key === "Tab") {
                                      e.preventDefault();
                                      setIsDropdownOpen(true);
                                      setTimeout(() => {
                                        document
                                          .querySelector(
                                            ".dropdown-option:first-child"
                                          )
                                          ?.focus();
                                      }, 0);
                                    } else if (e.key === "ArrowDown") {
                                      e.preventDefault();
                                      document
                                        .querySelector(
                                          ".dropdown-option:first-child"
                                        )
                                        ?.focus();
                                    }
                                  }}
                                  tabIndex={0} // Ensure focusable for Tab key
                                  onBlur={(e) => {
                                    // Close dropdown only if focus moves outside dropdown container
                                    if (
                                      !dropdownRef.current.contains(
                                        e.relatedTarget
                                      )
                                    ) {
                                      setIsDropdownOpen(false);
                                      setTimeout(() => {
                                        document.activeElement.nextElementSibling?.focus(); // Move to next input field
                                      }, 0);
                                    }
                                  }}
                                />

                                {isDropdownOpen && (
                                  <div className="dropdown position-absolute">
                                    <div className="dropdown-options">
                                      {filteredOptions.length > 0 ? (
                                        filteredOptions.map(
                                          (optionsinstitute, index) => (
                                            <div
                                              key={optionsinstitute.id}
                                              className="dropdown-option"
                                              tabIndex={0} // Makes options focusable
                                              onClick={() => {
                                                handleSelectOption(
                                                  optionsinstitute.id,
                                                  optionsinstitute.name
                                                );
                                                setFormData({
                                                  ...formData,
                                                  institute:
                                                    optionsinstitute.id,
                                                });
                                                setErrors({
                                                  ...errors,
                                                  institute: "",
                                                });
                                                setSearchQuery("");
                                                setIsDropdownOpen(false);
                                                setTimeout(() => {
                                                  document.activeElement.nextElementSibling?.focus(); // Move to next input field
                                                }, 0);
                                              }}
                                              onKeyDown={(e) => {
                                                if (e.key === "Enter") {
                                                  e.preventDefault();
                                                  handleSelectOption(
                                                    optionsinstitute.id,
                                                    optionsinstitute.name
                                                  );
                                                  setFormData({
                                                    ...formData,
                                                    institute:
                                                      optionsinstitute.id,
                                                  });
                                                  setErrors({
                                                    ...errors,
                                                    institute: "",
                                                  });
                                                  setSearchQuery("");
                                                  setIsDropdownOpen(false);
                                                  setTimeout(() => {
                                                    document.activeElement.nextElementSibling?.focus(); // Move to next input field
                                                  }, 0);
                                                  // document
                                                  //   .querySelector(
                                                  //     ".dropdown-search-header"
                                                  //   )
                                                  //   ?.focus();
                                                } else if (
                                                  e.key === "ArrowDown"
                                                ) {
                                                  e.preventDefault();
                                                  e.target.nextElementSibling?.focus();
                                                } else if (
                                                  e.key === "ArrowUp"
                                                ) {
                                                  e.preventDefault();
                                                  e.target.previousElementSibling?.focus();
                                                } else if (e.key === "Tab") {
                                                  // Move focus to next element
                                                  if (
                                                    !e.target.nextElementSibling
                                                  ) {
                                                    setIsDropdownOpen(false);
                                                  }
                                                } else if (e.key === "Tab") {
                                                  setIsDropdownOpen(false);
                                                  // document
                                                  //   .querySelector(
                                                  //     ".dropdown-search-header"
                                                  //   )
                                                  //   ?.focus();
                                                }
                                              }}
                                            >
                                              {optionsinstitute.name}
                                            </div>
                                          )
                                        )
                                      ) : (
                                        <div
                                          className="dropdown-no-options"
                                          tabIndex={0}
                                        >
                                          No options found
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                )}
                              </div>

                              <div className="">
                                <IoMdRefreshCircle
                                  className=" refe-button"
                                  onClick={fetchRoles}
                                  title="Refresh Institute"
                                />
                              </div>
                            </div>
                            <Link to="/modula-institution" target="_blank">
                              <span className="mx-2">Add Institute</span>
                            </Link>
                          </div>

                          <div className="col-12 col-md-10 float-start pt-2 ">
                            <label className="statis-name  ">Department</label>
                            <div className="d-flex gap-2 ">
                              <div
                                className="dropdown-container position-relative"
                                ref={dropdepRef}
                              >
                                <input
                                  type="text"
                                  className={`form-control dropdown-search-header ${
                                    errors.department ? "error" : ""
                                  }`}
                                  placeholder="Search Department..."
                                  value={searchInput || chosenOption.name || ""}
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    if (value === "") {
                                      setChosenOption({});
                                    }
                                    setSearchInput(value);
                                    setListExpanded(true); // Open dropdown when typing
                                  }}
                                  onClick={() => setListExpanded(true)}
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter" || e.key === "Tab") {
                                      e.preventDefault();
                                      setListExpanded(true);
                                      setTimeout(() => {
                                        document
                                          .querySelector(
                                            ".dropdown-option:first-child"
                                          )
                                          ?.focus();
                                      }, 0);
                                    } else if (e.key === "ArrowDown") {
                                      e.preventDefault();
                                      document
                                        .querySelector(
                                          ".dropdown-option:first-child"
                                        )
                                        ?.focus();
                                    }
                                  }}
                                  tabIndex={0}
                                  onBlur={(e) => {
                                    if (
                                      !dropdepRef.current.contains(
                                        e.relatedTarget
                                      )
                                    ) {
                                      setListExpanded(false);
                                    }
                                  }}
                                />

                                {isListExpanded && (
                                  <div className="dropdown position-absolute">
                                    <div className="dropdown-options">
                                      {filtereddepOptions.length > 0 ? (
                                        filtereddepOptions.map((option) => (
                                          <div
                                            key={option.id}
                                            className="dropdown-option"
                                            tabIndex={0}
                                            onClick={() => {
                                              handledepOptionSelect(
                                                option.id,
                                                option.name
                                              );
                                              setFormData({
                                                ...formData,
                                                department: option.id,
                                              });
                                              setErrors({
                                                ...errors,
                                                department: "",
                                              });
                                              setSearchInput("");
                                              setListExpanded(false);
                                              setTimeout(() => {
                                                document.activeElement.nextElementSibling?.focus(); // Move to next input field
                                              }, 0);
                                            }}
                                            onKeyDown={(e) => {
                                              if (e.key === "Enter") {
                                                e.preventDefault();
                                                handledepOptionSelect(
                                                  option.id,
                                                  option.name
                                                );
                                                setFormData({
                                                  ...formData,
                                                  department: option.id,
                                                });
                                                setErrors({
                                                  ...errors,
                                                  department: "",
                                                });
                                                setSearchInput("");
                                                setListExpanded(false);
                                                // document.querySelector(".dropdown-search-header")?.focus();
                                              } else if (
                                                e.key === "ArrowDown"
                                              ) {
                                                e.preventDefault();
                                                e.target.nextElementSibling?.focus();
                                              } else if (e.key === "ArrowUp") {
                                                e.preventDefault();
                                                e.target.previousElementSibling?.focus();
                                              } else if (e.key === "Escape") {
                                                setListExpanded(false);
                                                // document.querySelector(".dropdown-search-header")?.focus();
                                              }
                                            }}
                                          >
                                            {option.name}
                                          </div>
                                        ))
                                      ) : (
                                        <div
                                          className="dropdown-no-options"
                                          tabIndex={0}
                                        >
                                          No options found
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                )}
                              </div>
                              <div className="">
                                <IoMdRefreshCircle
                                  className=" refe-button"
                                  onClick={fetchDepartments}
                                  title="Refresh Department"
                                />
                              </div>
                            </div>
                            <Link to="/modula-department" target="_blank">
                              <span className="mx-2">Add Department</span>
                            </Link>
                          </div>
                          <div className=" col-12 col-md-10 float-start pt-2 ">
                            <label className="statis-name ">Profession</label>
                            {/* input */}
                            <div className="d-flex justify-content-between gap-2 ">
                              <div
                                className="dropdown-container position-relative"
                                ref={dropprofRef}
                              >
                                <input
                                  type="text"
                                  className={`form-control dropdown-search-header ${
                                    errors.profession ? "error" : ""
                                  }`}
                                  placeholder="Search Profession..."
                                  value={query || currentChoice.name || ""}
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    if (value === "") {
                                      setCurrentChoice({});
                                    }
                                    setQuery(value);
                                    setDropdownVisible(true); // Open dropdown when typing
                                  }}
                                  onClick={() => setDropdownVisible(true)}
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter" || e.key === "Tab") {
                                      e.preventDefault();
                                      setDropdownVisible(true);
                                      setTimeout(() => {
                                        document
                                          .querySelector(
                                            ".dropdown-option:first-child"
                                          )
                                          ?.focus();
                                      }, 0);
                                    } else if (e.key === "ArrowDown") {
                                      e.preventDefault();
                                      document
                                        .querySelector(
                                          ".dropdown-option:first-child"
                                        )
                                        ?.focus();
                                    }
                                  }}
                                  tabIndex={0}
                                  onBlur={(e) => {
                                    if (
                                      !dropprofRef.current.contains(
                                        e.relatedTarget
                                      )
                                    ) {
                                      setDropdownVisible(false);
                                    }
                                  }}
                                />

                                {isDropdownVisible && (
                                  <div className="dropdown position-absolute">
                                    <div className="dropdown-options">
                                      {filteredItems.length > 0 ? (
                                        filteredItems.map((item) => (
                                          <div
                                            key={item.id}
                                            className="dropdown-option"
                                            tabIndex={0}
                                            onClick={() => {
                                              handleSelectItem(
                                                item.id,
                                                item.name
                                              );
                                              setFormData({
                                                ...formData,
                                                profession: item.id,
                                              });
                                              setErrors({
                                                ...errors,
                                                profession: "",
                                              });
                                              setQuery("");
                                              setDropdownVisible(false);
                                              setTimeout(() => {
                                                document.activeElement.nextElementSibling?.focus(); // Move to next input field
                                              }, 0);
                                            }}
                                            onKeyDown={(e) => {
                                              if (e.key === "Enter") {
                                                e.preventDefault();
                                                handleSelectItem(
                                                  item.id,
                                                  item.name
                                                );
                                                setFormData({
                                                  ...formData,
                                                  profession: item.id,
                                                });
                                                setErrors({
                                                  ...errors,
                                                  profession: "",
                                                });
                                                setQuery("");
                                                setDropdownVisible(false);
                                                // document.querySelector(".dropdown-search-header")?.focus();
                                              } else if (
                                                e.key === "ArrowDown"
                                              ) {
                                                e.preventDefault();
                                                e.target.nextElementSibling?.focus();
                                              } else if (e.key === "ArrowUp") {
                                                e.preventDefault();
                                                e.target.previousElementSibling?.focus();
                                              } else if (e.key === "Escape") {
                                                setDropdownVisible(false);
                                                // document.querySelector(".dropdown-search-header")?.focus();
                                              }
                                            }}
                                          >
                                            {item.name}
                                          </div>
                                        ))
                                      ) : (
                                        <div
                                          className="dropdown-no-options"
                                          tabIndex={0}
                                        >
                                          No options found
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                )}
                              </div>
                              <div className="">
                                <IoMdRefreshCircle
                                  className=" refe-button"
                                  onClick={fetchProfession}
                                  title="Refresh Profession"
                                />
                              </div>
                            </div>
                            <Link to="/modula-profession" target="_blank">
                              <span className="mx-2">Add Profession</span>
                            </Link>
                          </div>
                        </div>

                        <div className="col-6">
                          <div className="col-12 col-md-10 float-start  ">
                            <label className="statis-name ">Budget</label>
                            <input
                              type="number"
                              className={`form-control ${
                                errors.budget ? "error" : ""
                              }`}
                              placeholder="Enter Budget"
                              name="budget"
                              value={formData.budget}
                              onChange={(e) => {
                                handleChange(e);
                                if (errors.budget) {
                                  setErrors((prevErrors) => ({
                                    ...prevErrors,
                                    budget: "",
                                  }));
                                }
                              }}
                              required
                            />
                          </div>

                          <div className="col-12 col-md-10 float-start  pt-2 ">
                            <label className="statis-name ">
                              Process Status
                            </label>
                            <select
                              className={`form-select  ${
                                errors.processStatus ? "error" : ""
                              }`}
                              name="processStatus"
                              value={formData.processStatus}
                              onChange={(e) => {
                                handleChange(e);
                                if (errors.processStatus) {
                                  setErrors((prevErrors) => ({
                                    ...prevErrors,
                                    processStatus: "",
                                  }));
                                }
                              }}
                              required
                            >
                              <option value="not_assigned">Not Assigned</option>
                              <option value="pending_author">
                                Pending - Author
                              </option>
                              <option value="completed">Completed</option>
                              <option value="withdrawal">Withdrawn</option>
                              <option value="in_progress">In Progress</option>
                              <option value="client_review">
                                Client Review
                              </option>
                            </select>
                          </div>

                          <div className="col-12 col-md-10 float-start  pt-2">
                            <label className="statis-name ">
                              Process Status Date
                            </label>
                            <input
                              type="date"
                              className={`form-control ${
                                errors.processStatusDate ? "error" : ""
                              }`}
                              name="processStatusDate"
                              value={formData.processStatusDate}
                              onChange={handleChange}
                              required
                            />
                          </div>
                          <div className="col-12 col-md-10 float-start pt-2 ">
                            <label className="statis-name ">
                              Project Completion Date
                            </label>
                            <input
                              type="date"
                              className={`form-control ${
                                errors.project_duration ? "error" : ""
                              }`}
                              placeholder="Enter Duration"
                              name="project_duration"
                              value={formData.project_duration}
                              // min={new Date().toISOString().split("T")[0]}
                              onChange={(e) => {
                                handleChange(e);
                                if (errors.budget) {
                                  setErrors((prevErrors) => ({
                                    ...prevErrors,
                                    project_duration: "",
                                  }));
                                }
                              }}
                              required
                            />
                          </div>

                          <div className="col-12 col-md-10 float-start pt-2 ">
                            <label className="statis-name ">
                              Hierarchy Level
                            </label>
                            <select
                              className={`form-select ${
                                errors.hierarchy ? "error" : ""
                              } ${
                                formData.hierarchy === "urgent_important"
                                  ? "hierarchy-red"
                                  : formData.hierarchy ===
                                    "important_not_urgent"
                                  ? "hierarchy-yellow"
                                  : formData.hierarchy ===
                                    "urgent_not_important"
                                  ? "hierarchy-orange"
                                  : formData.hierarchy ===
                                    "not_urgent_not_important"
                                  ? "hierarchy-green"
                                  : ""
                              }`}
                              name="hierarchy"
                              value={formData.hierarchy}
                              // onChange={handleChange}
                              onChange={(e) => {
                                handleChange(e); // Update form data
                                if (errors.hierarchy) {
                                  setErrors((prevErrors) => ({
                                    ...prevErrors,
                                    hierarchy: "",
                                  })); // Clear title error
                                }
                              }}
                              required
                              aria-label="Priority hierarchy"
                            >
                              <option value="" disabled>
                                Select an option
                              </option>
                              <option value="urgent_important">
                                Urgent/Important
                              </option>
                              <option value="important_not_urgent">
                                Important/Not Urgent
                              </option>
                              <option value="urgent_not_important">
                                Urgent/Not Important
                              </option>
                              <option value="not_urgent_not_important">
                                Not Urgent/Not Important
                              </option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="row p-4">
                    <div className="col d-flex gap-1">
                      <input
                        type="checkbox"
                        id="project"
                        onClick={handleProjectClick}
                        checked={formData.else_project_manager}
  disabled={formData.processStatus === "not_assigned"}

                        className=""
                      />
                      <label className="statis-name1 " htmlFor="project">
                        Assign Process.
                      </label>
                    </div>
                  </div>
                  {formData.else_project_manager && (
                    <>
                      <div className="gap-3 px-4 d-flex  flex-wrap">
                        {/* {['manuscript', 'thesis', 'presentation', 'others'].includes(typeofwork) && ( */}
                        <div>
                          <input
                            type="checkbox"
                            id="writer"
                            onClick={handleWriterClick}
                            // disabled={durations.writer <= 0}
                            // checked={durations.writer >=1}
                            // disabled={durations.writer >=1}
                          />
                          <label className="statis-name1 " htmlFor="writer">
                            Writer
                          </label>
                        </div>
                        {/* )} */}
                        <div>
                          <input
                            type="checkbox"
                            id="reviewer"
                            onClick={handleReviewerClick}
                            // disabled={durations.reviewer > 0}
                            // disabled={durations.reviewer <= 0}
                          />
                          <label className="statis-name1" htmlFor="reviewer">
                            Reviewer
                          </label>
                        </div>

                        {/* {['statistics', 'others'].includes(typeofwork) && ( */}
                        <div>
                          <input
                            type="checkbox"
                            id="statistican"
                            onClick={handleStatisticanClick}
                            // disabled={
                            //   durations.statistician > 0
                            // }
                            // disabled={durations.statistician <= 0}
                          />
                          <label className="statis-name1" htmlFor="statistican">
                            Statistician
                          </label>
                        </div>
                        {/* )} */}
                        <div>
                          <input
                            type="checkbox"
                            id="journal"
                            onClick={handleJournalClick}
                            // disabled={durations.journal <= 0}
                          />
                          <label className="statis-name1" htmlFor="journal">
                            Journal
                          </label>
                        </div>
                      </div>
                    </>
                  )}

                  {showWriter && (
                    <>
                      {writerFields.map((formData, index) => (
                        <div
                          key={index}
                          className="row w-100 pt-2 d-flex flex-wrap"
                        >
                          <div className="col-12 col-md-8 col-lg w-100 pt-2">
                            <label className="statis-name">Writer</label>
                            <select
                              className={`form-select ${
                                formData.error ? "error" : ""
                              }`}
                              name="writer"
                              required
                              value={formData.writer}
                              onChange={(e) =>
                                handlewriterChange(
                                  index,
                                  "writer",
                                  e.target.value
                                )
                              }
                            >
                              <option value="" disabled>
                                Select writer
                              </option>
                              {writter.map((writer) => (
                                <option key={writer.id} value={writer.id}>
                                  {writer.name.charAt(0).toUpperCase() +
                                    writer.name.slice(1)}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">
                              Writer Assigned Date
                            </label>
                            <input
                              type="date"
                              className={`form-control ${
                                errors.writerDate ? "error" : ""
                              }`}
                              name="writerDate"
                              value={formData.writerDate}
                              onChange={(e) =>
                                handlewriterChange(
                                  index,
                                  "writerDate",
                                  e.target.value
                                )
                              }
                              required
                            />
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">Writer Status</label>
                            <select
                              // className={`form-select ${
                              //   errors.writerStatus ? "error" : ""
                              // }`}
                              className="form-select"
                              name="writerStatus"
                              value={formData.writerStatus}
                              onChange={(e) =>
                                handlewriterChange(
                                  index,
                                  "writerStatus",
                                  e.target.value
                                )
                              }
                              required
                            >
                              <option value="to_do">To do</option>
                              <option value="plag_correction">
                                Plag correction
                              </option>
                              <option value="correction">Correction </option>
                            </select>
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">
                              Writer Status Date
                            </label>
                            <input
                              type="date"
                              className={`form-control ${
                                errors.writerStatusDate ? "error" : ""
                              }`}
                              name="writerStatusDate"
                              value={formData.writerStatusDate}
                              onChange={(e) =>
                                handlewriterChange(
                                  index,
                                  "writerStatusDate",
                                  e.target.value
                                )
                              }
                              required
                            />
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">
                              Writer Project Duration
                            </label>
                            <input
                              type="date"
                              className="form-control"
                              // className={`form-control ${errors.writerprojectduration ? "error" : ""}`}
                              name="writerprojectduration"
                              value={formData.writerprojectduration}
                              onChange={(e) =>
                                handlewriterChange(
                                  index,
                                  "writerprojectduration",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">Comment Box</label>
                            <textarea
                              className="form-control"
                              name="writer_comment"
                              placeholder="Enter your comment here..."
                              value={formData.writer_comment}
                              onChange={(e) =>
                                handlewriterChange(
                                  index,
                                  "writer_comment",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          {index === 0 && (
                            <div className="col-12 col-md-6 col-lg-1 pt-4">
                              <button
                                type="button"
                                className="save-form-add mt-1"
                                onClick={handleAddWriterField}
                              >
                                Add +
                              </button>
                            </div>
                          )}

                          {index > 0 && (
                            <div className="col-12 col-md-6 col-lg-1 mt-4">
                              <button
                                type="button"
                                className="save-form-del mt-1"
                                onClick={() => handleDeleteWriterField(index)}
                              >
                                Delete
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </>
                  )}

                  {showReviewer && (
                    <>
                      {reviewerFields.map((formData, index) => (
                        <div
                          key={index}
                          className="row w-100 pt-2 d-flex flex-wrap"
                        >
                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">Reviewer</label>
                            <select
                              className={`form-select ${
                                formData.error ? "error" : ""
                              }`}
                              name="reviewer"
                              value={formData.reviewer}
                              onChange={(e) =>
                                handleReviewerChange(
                                  index,
                                  "reviewer",
                                  e.target.value
                                )
                              }
                            >
                              <option value="" disabled>
                                Select Reviewer
                              </option>
                              {reviewer.map((reviewer) => (
                                <option key={reviewer.id} value={reviewer.id}>
                                  {reviewer.name.charAt(0).toUpperCase() +
                                    reviewer.name.slice(1)}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">
                              Reviewer Assigned Date
                            </label>
                            <input
                              type="date"
                              className="form-control"
                              name="reviewerAssignedDate"
                              value={formData.reviewerAssignedDate}
                              onChange={(e) =>
                                handleReviewerChange(
                                  index,
                                  "reviewerAssignedDate",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">
                              Reviewer Status
                            </label>
                            <select
                              className="form-select"
                              name="reviewerStatus"
                              value={formData.reviewerStatus}
                              onChange={(e) =>
                                handleReviewerChange(
                                  index,
                                  "reviewerStatus",
                                  e.target.value
                                )
                              }
                            >
                              <option value="to_do">To do</option>
                              <option value="plag_correction">
                                Plag correction
                              </option>
                              <option value="correction">Correction</option>
                            </select>
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">
                              Reviewer Status Date
                            </label>
                            <input
                              type="date"
                              className="form-control"
                              name="reviewerStatusDate"
                              value={formData.reviewerStatusDate}
                              onChange={(e) =>
                                handleReviewerChange(
                                  index,
                                  "reviewerStatusDate",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name-small">
                              Reviewer Project Duration
                            </label>
                            <input
                              type="date"
                              className="form-control"
                              name="reviewerProjectduration"
                              // value={formData.reviewerProjectduration}
                              value={formData.reviewerProjectDuration}
                              onChange={(e) =>
                                handleReviewerChange(
                                  index,
                                  "reviewerProjectduration",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">Comment Box</label>
                            <textarea
                              className="form-control"
                              name="reviewer_comment"
                              value={formData.reviewer_comment}
                              onChange={(e) =>
                                handleReviewerChange(
                                  index,
                                  "reviewer_comment",
                                  e.target.value
                                )
                              }
                              placeholder="Enter your comment here..."
                            />
                          </div>

                          {index === 0 && (
                            <div className="col-12 col-md-6 col-lg-1 pt-4">
                              <button
                                type="button"
                                className="save-form-add mt-1"
                                onClick={handleAddReviewerField}
                              >
                                Add +
                              </button>
                            </div>
                          )}

                          {index > 0 && (
                            <div className="col-12 col-md-6 col-lg-1 mt-4">
                              <button
                                type="button"
                                className="save-form-del mt-1"
                                onClick={() => handleDeleteReviewerField(index)}
                              >
                                Delete
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </>
                  )}

                  {showStatistican && (
                    <>
                      {statisticanFields.map((formData, index) => (
                        <div
                          key={index}
                          className="row w-100 pt-2 d-flex flex-wrap"
                        >
                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">Statistican</label>
                            <select
                              className={`form-select ${
                                formData.error ? "error" : ""
                              }`}
                              name="statistican"
                              value={formData.statistican}
                              onChange={(e) =>
                                handleStatisticanChange(
                                  index,
                                  "statistican",
                                  e.target.value
                                )
                              }
                            >
                              <option value="" disabled>
                                Select Statistican
                              </option>
                              {statistical.map((statistican) => (
                                <option
                                  key={statistican.id}
                                  value={statistican.id}
                                >
                                  {statistican.name.charAt(0).toUpperCase() +
                                    statistican.name.slice(1)}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">Assigned Date</label>
                            <input
                              type="date"
                              className="form-control"
                              name="statisticanAssignedDate"
                              value={formData.statisticanAssignedDate}
                              onChange={(e) =>
                                handleStatisticanChange(
                                  index,
                                  "statisticanAssignedDate",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">Status</label>
                            <select
                              className="form-select"
                              name="statisticanStatus"
                              value={formData.statisticanStatus}
                              onChange={(e) =>
                                handleStatisticanChange(
                                  index,
                                  "statisticanStatus",
                                  e.target.value
                                )
                              }
                            >
                              {/* <option value="to_do">To do</option>
                              <option value="completed">Completed</option>
                              <option value="client_review">
                                Client Review
                              </option> */}
                              <option value="to_do">To do</option>
                              <option value="correction">Correction</option>
                              <option value="client_review">
                                Client Review
                              </option>
                            </select>
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">Status Date</label>
                            <input
                              type="date"
                              className="form-control"
                              name="statisticanStatusDate"
                              value={formData.statisticanStatusDate}
                              onChange={(e) =>
                                handleStatisticanChange(
                                  index,
                                  "statisticanStatusDate",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name-small-sta">
                              Statistician Project Duration
                            </label>
                            <input
                              type="date"
                              className="form-control"
                              name="statisticanprojectduration"
                              value={formData.statisticanProjectDuration}
                              onChange={(e) =>
                                handleStatisticanChange(
                                  index,
                                  "statisticanprojectduration",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 col-lg pt-2">
                            <label className="statis-name">Comment Box</label>
                            <textarea
                              className="form-control"
                              name="statistican_comment"
                              value={formData.statistican_comment}
                              onChange={(e) =>
                                handleStatisticanChange(
                                  index,
                                  "statistican_comment",
                                  e.target.value
                                )
                              }
                              placeholder="Enter your comment here..."
                            />
                          </div>

                          {index === 0 && (
                            <div className="col-12 col-md-6 col-lg-1 pt-4">
                              <button
                                type="button"
                                className="save-form-add mt-1"
                                onClick={handleAddStatisticanField}
                              >
                                Add +
                              </button>
                            </div>
                          )}

                          {index > 0 && (
                            <div className="col-12 col-md-6 col-lg-1 mt-4">
                              <button
                                type="button"
                                className="save-form-del mt-1"
                                onClick={() =>
                                  handleDeleteStatisticanField(index)
                                }
                              >
                                Delete
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </>
                  )}

                  {showJournal && (
                    <>
                      {journalFields.map((formData, index) => (
                        <div
                          key={index}
                          className="row w-100 pt-2 d-flex flex-wrap"
                        >
                          <div className="col-12 col-md-6 col-lg-3 pt-2">
                            <label className="statis-name">Journal</label>
                            <input
                              type="text"
                              className="form-control"
                              name="journal"
                              value={formData.journal}
                              onChange={(e) =>
                                handleJournalChange(
                                  index,
                                  "journal",
                                  e.target.value
                                )
                              }
                              
                            />
                            {/* <select
                              className={`form-select ${
                                formData.error ? "error" : ""
                              }`}
                              name="journal"
                              value={formData.journal}
                              onChange={(e) =>
                                handleJournalChange(
                                  index,
                                  "journal",
                                  e.target.value
                                )
                              }
                            >
                              <option value="" disabled>
                                Select Journal
                              </option>
                              {journal.map((journal) => (
                                <option key={journal.id} value={journal.id}>
                                  {journal.name.charAt(0).toUpperCase() +
                                    journal.name.slice(1)}
                                </option>
                              ))}
                            </select> */}
                          </div>

                          <div className="col-12 col-md-6 col-lg-3 pt-2">
                            <label className="statis-name">Assigned Date</label>
                            <input
                              type="date"
                              className="form-control"
                              name="journalAssignedDate"
                              value={formData.journalAssignedDate}
                              onChange={(e) =>
                                handleJournalChange(
                                  index,
                                  "journalAssignedDate",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          {/* <div className="col-12 col-md-6 col-lg-3 pt-2">
                            <label className="statis-name">
                              {" "}
                              Journal Status
                            </label>
                            <select
                              className="form-select"
                              name="journalStatus"
                              value={formData.journalStatus}
                              onChange={(e) =>
                                handleJournalChange(
                                  index,
                                  "journalStatus",
                                  e.target.value
                                )
                              }
                            >
                              <option value="" disabled selected>
                                Select Status
                              </option>
                              <option value="submit_to_journal">
                                Sumbit to Journal
                              </option>
                              <option value="pending_author">
                                Pending Author
                              </option>
                              <option value="submitted">Submitted</option>
                              <option value="rejected">Rejected</option>
                              <option value="resubmission">Resubmission</option>
                              <option value="reviewer_comments">
                                Reviewer Comments
                              </option>
                              <option value="published">Published</option>
                              <option value="withdrawal">Withdrawal</option>
                            </select>
                          </div>

                          <div className="col-12 col-md-6 col-lg-3 pt-2">
                            <label className="statis-name">Status Date</label>
                            <input
                              type="date"
                              className="form-control"
                              name="journalStatusDate"
                              value={formData.journalStatusDate}
                              onChange={(e) =>
                                handleJournalChange(
                                  index,
                                  "journalStatusDate",
                                  e.target.value
                                )
                              }
                            />
                          </div> */}

                          <div className="col-12 col-md-6 col-lg-3 pt-2">
                            <label className="statis-name">
                              Journal Project Duration
                            </label>
                            <input
                              type="date"
                              className="form-control"
                              name="journalprojectduration"
                              value={formData.journalProjectDuration}
                              onChange={(e) =>
                                handleJournalChange(
                                  index,
                                  "journalprojectduration",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 col-lg-3 pt-2">
                            <label className="statis-name">
                              Type of Article
                            </label>
                            <select
                              className="form-select"
                              name="typeofarticle"
                              value={formData.type_of_article}
                              onChange={(e) =>
                                handleJournalChange(
                                  index,
                                  "type_of_article",
                                  e.target.value
                                )
                              }
                            >
                              <option value="" disabled selected>
                                Type of Article{" "}
                              </option>
                              <option value="original_research_article">
                                Original Research Article
                              </option>
                              <option value="case_report">Case Report</option>
                              <option value="case_series">Case Series</option>
                              <option value="systematic_review">
                                Systematic Review
                              </option>
                              <option value="comprehensive_review">
                                Comprehensive Review
                              </option>
                            </select>{" "}
                          </div>

                          <div className="col-12 col-md-6 col-lg-3 pt-3 ">
                            <label className="statis-name">
                              Quick Review / Normal Review
                            </label>

                            <div className="d-flex">
                              <div className="form-check mx-2">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  id="quickReview"
                                  name="review" // Shared name for radio buttons
                                  value="quickReview"
                                  checked={formData.review === "quickReview"}
                                  onChange={(e) =>
                                    handleJournalChange(
                                      index,
                                      "review",
                                      e.target.value
                                    )
                                  }
                                />
                                <label
                                  className="label-public-name"
                                  htmlFor="quickReview"
                                >
                                  Quick Review
                                </label>
                              </div>

                              <div className="form-check mx-2">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  id="normalReview"
                                  name="review" // Shared name for radio buttons
                                  value="normalReview"
                                  checked={formData.review === "normalReview"}
                                  onChange={(e) =>
                                    handleJournalChange(
                                      index,
                                      "review",
                                      e.target.value
                                    )
                                  }
                                />
                                <label
                                  className="label-public-name"
                                  htmlFor="normalReview"
                                >
                                  Normal Review
                                </label>
                              </div>
                            </div>
                          </div>

                          <div className="col-12 col-md-6 col-lg-3 pt-2">
                            <label className="statis-name">Comment Box</label>
                            <textarea
                              className="form-control"
                              name="journal_comment"
                              value={formData.journal_comment}
                              onChange={(e) =>
                                handleJournalChange(
                                  index,
                                  "journal_comment",
                                  e.target.value
                                )
                              }
                              placeholder="Enter your comment here..."
                            />
                          </div>

                          {/* {index === 0 && (
                            <div className="col-12 col-md-6 col-lg-1 ">
                              <button
                                type="button"
                                className="save-form-add mt-1"
                                onClick={handleAddJournalField}
                              >
                                Add +
                              </button>
                            </div>
                          )}

                          {index > 0 && (
                            <div className="col-12 col-md-6 col-lg-1 ">
                              <button
                                type="button"
                                className="save-form-del mt-1"
                                onClick={() => handleDeleteJournalField(index)}
                              >
                                Delete
                              </button>
                            </div>
                          )} */}
                        </div>
                      ))}
                    </>
                  )}

                  <div className="row">
                    <div className="col-12 col-md-4 pt-4">
                      <label className="client-name-pop ">Comment Box</label>
                      {/* <input className=" command-box" /> */}
                      <RichEditor
                        setFormData={setFormData}
                        formData={formData}
                      />
                    </div>
                  </div>
                  <div className="col-md-12 float-start px-3 mt-4 ">
                    <label className="client-name-pop ">Payment</label>
                  </div>

                  <div className="row  ">
                    {paymentFields.map((field, index) => (
                      <div key={index} className="row  align-items-center">
                        <div className="col-12 col-md-3">
                          <label className="statis-name">{`Payment ${
                            index + 1
                          }`}</label>
                          <input
                            type="number"
                            className={`form-control ${
                              errors[`amount_${index}`] ? "error" : ""
                            }`}
                            value={field.amount}
                            onChange={(e) => {
                              handlePaymentChange(
                                index,
                                "amount",
                                e.target.value
                              );
                              if (errors[`amount_${index}`]) {
                                setErrors((prevErrors) => {
                                  const updatedErrors = { ...prevErrors };
                                  delete updatedErrors[`amount_${index}`];
                                  return updatedErrors;
                                });
                              }
                            }}
                          />
                        </div>

                        <div className="col-12 col-md-3">
                          <label className="statis-name">Payment Date</label>
                          <input
                            type="date"
                            className={`form-control ${
                              errors[`date_${index}`] ? "error" : ""
                            }`}
                            value={field.date}
                            onChange={(e) => {
                              handlePaymentChange(
                                index,
                                "date",
                                e.target.value
                              );
                              if (errors[`date_${index}`]) {
                                setErrors((prevErrors) => {
                                  const updatedErrors = { ...prevErrors };
                                  delete updatedErrors[`date_${index}`];
                                  return updatedErrors;
                                });
                              }
                            }}
                          />
                        </div>

                        {index === 0 && (
                          <div className="col-12 col-md-3 d-flex justify-content-start align-items-center mt-4">
                            <button
                              type="button"
                              className="save-form-add mt-1"
                              onClick={handleAddFieldpayment}
                            >
                              Add +
                            </button>
                          </div>
                        )}

                        {index > 0 && (
                          <div className="col-12 col-md-3 d-flex justify-content-start align-items-center mt-4">
                            <button
                              type="button"
                              className="save-form-del mt-1"
                              onClick={() => handlePaymentRemoveField(index)}
                            >
                              Delete
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="row mt-2 pt-2 ">
                    <div className="col-12 col-md-3 px-3  col-md">
                      <label className="statis-name">Payment Status</label>
                      <select
                        className={`form-select ${
                          errors.payment_status ? "error" : ""
                        }`}
                        name="payment_status"
                        onChange={(e) => {
                          handleFormChange(e);
                          if (errors.payment_status) {
                            setErrors((prevErrors) => {
                              const updatedErrors = { ...prevErrors };
                              delete updatedErrors.payment_status;
                              return updatedErrors;
                            });
                          }
                        }}
                        value={formData.payment_status}
                      >
                        <option value="" disabled selected>
                          Payment Status
                        </option>
                        <option value="advance_pending">Advance Pending</option>
                        <option value="partial_payment_pending">
                          Partial payment pending
                        </option>
                        <option value="final_payment_pending">
                          Final payment pending
                        </option>
                      </select>
                    </div>
                  </div>

                  <div className="col-12 d-flex justify-content-end  pt-5 py-5 gap-3 ">
                    <Link to="/entry-process">
                      <button className="save-form">Back</button>
                    </Link>
                    <button
                      onClick={handleSubmit}
                      type="submit"
                      className="save-form-save"
                    >
                      Save
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div>
          <Footer></Footer>
        </div>
      </section>
    </>
  );
}

export default Enterprocess_form;
