import React, { useState, useEffect, useCallback } from "react";
import "../assests/css/payment_form.css";
import Sider from "../components/Sider";
import Header from "../components/Header.js";
import { Link } from "react-router-dom";
import Breadcrumbs from "../routes/Breadcrumbs.js";
import axios from "axios";
import { API_URL } from "../config.js";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import Swal from "sweetalert2";
import { Capitalize } from "../campsCase.js";
import { useRef } from "react";
import { PiCloudArrowUpLight } from "react-icons/pi";
import { RiDeleteBin6Line } from "react-icons/ri";
import { AiOutlineClose } from "react-icons/ai";

import PDF from "../assests/images/pdf.svg";
import Excel from "../assests/images/excel.svg";
import Word from "../assests/images/word.svg";
import Image from "../assests/images/image.svg";
import Loader from "../components/Loader.js";

function Payment_form() {
  const navigate = useNavigate();
  const location = useLocation();
  const today = new Date().toISOString().split("T")[0];

  const { rowId } = location.state || {};

  const [showDatas, setShowData] = useState({});

  useEffect(() => {
    if (rowId) {
      fetchShowData(rowId);
    }
  }, [rowId]);

  const fetchShowData = async (rowId) => {
    // console.log("check rowId", rowId);
    try {
      const responseShow = await axios.get(
        `${API_URL}/api/payment_processes/view/${rowId}`
      );

      const fetchData = responseShow.data;

      // console.log("fetchData :", fetchData);
      setShowData(responseShow.data);
      setPaymentIdData(responseShow.data.id);
      setProjecttile(fetchData.project_data.id);
      setBudget(fetchData.project_data.budget);
      setProjectId(fetchData.project_data.project_id);
      setProjectId(fetchData.project_data.project_id);
      setClientname(fetchData.project_data?.client_name || "-");
      setInstitution(fetchData.project_data?.institute_info?.name);
      setDepartment(fetchData.project_data?.department_info?.name);
      setProfession(fetchData.project_data?.profession_info?.name);
      setFormData((prevFormData) => ({
        ...prevFormData,
        payment_status: fetchData.payment_status || "",
        reference_number: fetchData.reference_number || "",
        discount: fetchData.discounts || "",
      }));

      const referenceFiles = Array.isArray(fetchData.reference_number_file)
        ? fetchData.reference_number_file
        : fetchData.reference_number_file
        ? [fetchData.reference_number_file] // Wrap in array if it's a single string
        : []; // Fallback to empty array if it's null or undefined

      // Process each file
      const dynamicFiles = referenceFiles.map((file, index) => {
        // Check if file is valid before attempting to split
        if (!file) {
          console.warn(`Skipping invalid file at index ${index}`);
          return null; // Skip invalid files
        }

        const fileType = file.split(".").pop(); // Get file extension
        const relativePath = file.replace(/\\/g, "/"); // Normalize path for URLs

        return {
          img: getFileIcon(fileType), // Function to get the corresponding file icon
          type: fileType,
          fileName: file.split("/").pop(), // Extract the file name
          url: `${API_URL}/payment_screenshots/${relativePath}`, // Construct the file URL
          id: index, // Assign a unique ID (index here since no specific ID is provided)
        };
      });

      // Update state with new files while avoiding duplicates
      setFiles((prevFiles) => {
        const newFiles = dynamicFiles.filter(
          (newFile) =>
            !prevFiles.some((existingFile) => existingFile.id === newFile.id)
        );
        return [...prevFiles, ...newFiles];
      });
      // console.log("fetchData.payment_data :", fetchData.payment_data);
      setPaymentFields(fetchData.payment_data);

      const project_data = fetchData.project_data;
      const writerData = fetchData?.payment_w_emp_data || [];
      const fallbackWriterData = project_data.writer_data || [];

      // Process both data sources and combine them
      const writerStatusDetails = [
        // Process payment_w_emp_data first
        ...writerData.map((user) => ({
          writerName: user.employee_id || "",
          paymentAmount: user.payment || "",
          paymentDate: user.payment_date || "",
          paymentStatus: user.status || "",
        })),

        // Then add fallback data for freelancers that aren't in payment_w_emp_data
        ...fallbackWriterData
          .filter(
            (user) =>
              user.user_date?.employee_type === "freelancers" &&
              !writerData.some((w) => w.employee_id === user.assign_user)
          )
          .map((user) => ({
            writerName: user.assign_user || "",
            paymentAmount: "",
            paymentDate: "",
            paymentStatus: "",
          })),
      ];

      const reviewerData = fetchData?.payment_r_emp_data || [];
      const fallbackReviewerData = project_data.reviewer_data || [];

      // Process both data sources and combine them
      const reviewerStatusDetails = [
        // Process payment_w_emp_data first
        ...reviewerData.map((user) => ({
          reviewerName: user.employee_id || "",
          reviewerPayment: user.payment || "",
          reviewerPaymentDate: user.payment_date || "",
          reviewerPaymentStatus: user.status || "",
        })),

        // Then add fallback data for freelancers that aren't in payment_w_emp_data
        ...fallbackReviewerData
          .filter(
            (user) =>
              user.user_date?.employee_type === "freelancers" &&
              !reviewerData.some((w) => w.employee_id === user.assign_user)
          )
          .map((user) => ({
            reviewerName: user.assign_user || "",
            paymentAmount: "",
            paymentDate: "",
            paymentStatus: "",
          })),
      ];

      const statisticanData = fetchData?.payment_s_emp_data || [];

      let statisticanStatusDetails = [];

      if (statisticanData.length > 0) {
        statisticanStatusDetails = statisticanData.map((user) => {
          return {
            statisticanName: user.employee_id || "",
            statisticanPayment: user.payment || "",
            statisticanPaymentDate: user.payment_date || "",
            statisticanPaymentStatus: user.status || "",
          };
        });
      } else {
        const fallbackStatisticanData = project_data.statistican_data || [];

        const freelancerStatisticanData = fallbackStatisticanData.filter(
          (user) => user.user_date?.employee_type === "freelancers"
        );

        statisticanStatusDetails = freelancerStatisticanData.map((user) => {
          return {
            statisticanName: user.assign_user || "",
            statisticanPayment: "",
            statisticanPaymentDate: "",
            statisticanPaymentStatus: "",
          };
        });
      }

      const journalData = fetchData?.payment_j_emp_data || [];

      let journalStatusDetails = [];

      if (journalData.length > 0) {
        journalStatusDetails = journalData.map((user) => {
          return {
            journalName: user.employee_id || "",
            journalPayment: user.payment || "",
            journalPaymentDate: user.payment_date || "",
            journalPaymentStatus: user.status || "",
          };
        });
      } else {
        const fallbackjournalData = project_data.journal_data || [];
        // console.log("text", fallbackjournalData);
        const freelancerjournalData = fallbackjournalData.filter(
          (user) => user.user_date?.employee_type === "full_time"
        );

        journalStatusDetails = fallbackjournalData.map((a) => {
          return {
            journalName: a.assign_user || "",
            journalPayment: "",
            journalPaymentDate: "",
            journalPaymentStatus: "",
          };
        });
      }
      // console.log('text',journalStatusDetails);
      setWriterDetails(writerStatusDetails);
      setReviewerDetails(reviewerStatusDetails);
      setStatisticanDetails(statisticanStatusDetails);
      setJournalDetails(journalStatusDetails);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const [showFields, setShowFields] = useState(false);
  const [showWriter, setShowWriter] = useState(false);
  const [showReviewer, setShowReviewer] = useState(false);
  const [showVendor, setShowVendor] = useState(false);
  const [showjournal, setShowJournal] = useState(false);
  const [payment_id, setPaymentIdData] = useState({});

  const handleReviewerChange = (e, index) => {
    const { name, value } = e.target;
    const updatedDetails = [...reviewerDetails];
    updatedDetails[index] = {
      ...updatedDetails[index],
      [name]: value,
    };
    setReviewerDetails(updatedDetails);
  };
  //multipleuser

  //multiple user

  const [writerDetails, setWriterDetails] = useState([
    {
      writerName: "",
      paymentAmount: "",
      paymentDate: "",
      paymentStatus: "",
    },
  ]);

  // console.log("writerDetails :", writerDetails);

  const [reviewerDetails, setReviewerDetails] = useState([
    {
      reviewerName: "",
      reviewerPayment: "",
      reviewerPaymentDate: "",
      reviewerPaymentStatus: "",
    },
  ]);

  // console.log("check reviewerDetails :", reviewerDetails);

  const [statisticanDetails, setStatisticanDetails] = useState([
    {
      statisticanName: "",
      statisticanPayment: "",
      statisticanPaymentDate: "",
      statisticanPaymentStatus: "",
    },
  ]);

  const [journalDetails, setJournalDetails] = useState([
    {
      journalName: "",
      journalPayment: "",
      journalPaymentDate: "",
      journalPaymentStatus: "",
    },
  ]);

  // console.log("journalDetails :", journalDetails);

  const handleWriterChange = (e, index) => {
    const { name, value } = e.target;
    const updatedDetails = [...writerDetails];
    updatedDetails[index] = {
      ...updatedDetails[index],
      [name]: value,
    };
    setWriterDetails(updatedDetails);
  };

  const handleStatisticanChange = (e, index) => {
    const { name, value } = e.target;
    const updatedDetails = [...statisticanDetails];
    updatedDetails[index] = {
      ...updatedDetails[index],
      [name]: value,
    };
    setStatisticanDetails(updatedDetails);
  };

  const handleJournalChange = (e, index) => {
    const { name, value } = e.target;
    const updatedDetails = [...journalDetails];
    updatedDetails[index] = {
      ...updatedDetails[index],
      [name]: value,
    };
    setJournalDetails(updatedDetails);
  };

  const handleWriterClick = () => {
    setShowWriter(!showWriter);
  };

  const handleReviewerClick = () => {
    setShowReviewer(!showReviewer);
  };

  const handleStatisticanClick = () => {
    setShowVendor(!showVendor);
  };

  const handleJournalClick = () => {
    setShowJournal(!showjournal);
  };

  const [date, setDate] = useState("");

  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  useEffect(() => {
    setDate(getTodayDate());
  }, []);

  const [paymentFields, setPaymentFields] = useState([]);
  // console.log("paymentFields :", paymentFields);
  // const handleAddField = () => {
  //   const newField = { payment: "", payment_date: "" }; // Default values for new field
  //   setPaymentFields([...paymentFields, newField]);
  // };
  const handleAddField = () => {
    const validationErrors = validateFormFiles();

    if (Object.keys(validationErrors).length === 0) {
      setPaymentFields((prevPaymentFields) => [
        ...prevPaymentFields,
        {
          amount: "",
          date: "",
          reference_number: "",
          payment_type: "",
          reference_number_file: "",
          id: prevPaymentFields.id + 1,
        },
      ]);
    } else {
      setErrors(validationErrors);
    }
  };
  const validateFormFiles = () => {
    const validationErrors = {};

    paymentFields.forEach((field, index) => {
      if (!field.payment) {
        validationErrors[`payment_${index}`] = "Payment is required";
      }
      if (!field.payment_date) {
        validationErrors[`payment_date_${index}`] = "Payment date is required";
      }
    });

    return validationErrors;
  };

  const handleRemoveField = async (index, id) => {
    // Show a SweetAlert confirmation dialog
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to delete this payment?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "Cancel",
    });

    // If user confirms, proceed with deletion
    if (result.isConfirmed) {
      try {
        // Check if the field has an `id` (exists in the database)
        if (id) {
          // await axios.delete(
          //   `${API_URL}/api/payment_processes/payment_delete/${id}`
          // );
          await axios.delete(
            `${API_URL}/api/payment_processes/payment_delete/${id}`,
            {
              params: {
                created_by: createdby,
                project_id: project_id,
              },
            }
          );
        }

        // Remove the field from the frontend state
        setPaymentFields((prevFields) =>
          prevFields.filter((_, i) => i !== index)
        );

        // Show a success message after deletion
        Swal.fire("Deleted!", "The payment field has been deleted.", "success");
      } catch (error) {
        console.error("Error deleting payment field", error);
        // Show error message if deletion fails
        Swal.fire(
          "Error!",
          "There was an issue deleting the payment field.",
          "error"
        );
      }
    } else {
      // If user cancels, you can show a cancellation message or do nothing
      Swal.fire("Cancelled", "Your payment field is safe :)", "info");
    }
  };

  const handleChange = (index, field, value) => {
    if (index >= 0 && index < paymentFields.length) {
      const updatedFields = [...paymentFields];

      updatedFields[index][field] = value;
      setPaymentFields(updatedFields);
    } else {
      console.error("Invalid index:", index);
    }
  };

  // const handleFileChange = (index, e) => {
  //   const newFiles = [...paymentFields];
  //   newFiles[index].reference_number_file = e.target.files;
  //   setPaymentFields(newFiles);
  // };

  const handleFileChange = (index, e) => {
    const newFiles = [...paymentFields];
    newFiles[index].reference_number_file = e.target.files[0]; // single file or null
    setPaymentFields(newFiles);
  };

  const handleFileDelete = (index) => {
    const newFiles = [...paymentFields];
    newFiles[index].file = null;
    setPaymentFields(newFiles);
  };

  // const handleFileChange = useCallback((e) => {
  //   const file = e.target.files[0];
  //   console.log("Selected file:", file);

  //   setFormData((prevData) => ({
  //     ...prevData,
  //     file, // Update file in formData
  //   }));
  // }, []);

  // const fileInputRef = useRef(null);
  // const handleFileDelete = useCallback(() => {
  //   setFormData((prevData) => ({
  //     ...prevData,
  //     file: null, // Clear file from formData
  //   }));

  //   // Clear validation error for reference_number
  //   setErrors((prevErrors) => {
  //     const updatedErrors = { ...prevErrors };
  //     delete updatedErrors.reference_number;
  //     return updatedErrors;
  //   });

  //   // Reset the file input field using the ref
  //   if (fileInputRef.current) {
  //     fileInputRef.current.value = "";
  //   }
  // }, []);

  const [projectTitles, setProjectTitles] = useState([]);
  const [projectTitleVal, setProjecttile] = useState([]);
  const [projectBudget, setBudget] = useState([]);
  const [projectId, setProjectId] = useState([]);
  const [project_id, setProjectDId] = useState("");
  const [isReadOnly, setIsReadOnly] = React.useState(true);
  const [clientname, setClientname] = useState("");

  const [profession, setProfession] = useState("");
  const [department, setDepartment] = useState("");
  const [institute, setInstitution] = useState("");
  console.log("clientname", clientname);
  const [checkboxes, setCheckboxes] = useState({
    writer: false,
    reviewer: false,
    statistican: false,
    journal: false,
  });

  const handlefetchDetails = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/projecttitlelist`
      );
      // console.log('response :',response);
      if (response.status === 200) {
        const projectTitleArray = response.data;
        setProjectTitles(projectTitleArray);
      } else {
        console.error("Error fetching project titles:", response.statusText);
      }
    } catch (error) {
      console.error("Submission error:", error);
    }
  };

  const handleSelectChange = async (event) => {
    const selectedId = event.target.value;

    setProjecttile(selectedId);
    setFormData((prevState) => ({
      ...prevState,
      projectTitleVal: selectedId,
    }));

    if (selectedId) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        projectTitleVal: "",
      }));
    }

    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/project-view-data/${selectedId}`
      );
      // console.log("response :", response);
      if (response.status === 200) {
        setBudget(
          new Intl.NumberFormat("en-IN").format(response.data.budget || "-")
        );
        setProjectId(response.data.project_id);
        setProjectDId(response.data.id);
        setClientname(response.data?.client_name);
        setInstitution(response.data?.institute_info.name);
        setDepartment(response.data?.department?.name);
        setProfession(response.data?.profession?.name);
        const writerId =
          response.data.writer?.employee_type === "freelancers"
            ? response.data.writer.id
            : "";

        const reviewerId =
          response.data.reviewer?.employee_type === "freelancers"
            ? response.data.reviewer.id
            : "";

        const statisticanId =
          response.data.statistican?.employee_type === "freelancers"
            ? response.data.statistican.id
            : "";

        const journalId =
          response.data.journal?.employee_type === "freelancers"
            ? response.data.journal.id
            : "";

        setFormData((prevFormData) => ({
          ...prevFormData,
          writer: writerId,
          reviewer: reviewerId,
          statistican: statisticanId,
          journal: journalId,
        }));
        // setFormData((prevFormData) => ({
        //   ...prevFormData,
        //   writer: response.data.writer || '',
        //   reviewer: response.data.reviewer || '',
        //   statistican: response.data.statistican || '',
        //   journal: response.data.journal || ''
        // }));

        const newCheckboxes = {
          writer:
            response.data.writer !== null &&
            response.data.writer.employee_type === "freelancers",
          reviewer:
            response.data.reviewer !== null &&
            response.data.reviewer.employee_type === "freelancers",
          statistican:
            response.data.statistican !== null &&
            response.data.statistican.employee_type === "freelancers",
          journal:
            response.data.journal !== null &&
            response.data.journal.employee_type === "freelancers",
        };

        setCheckboxes(newCheckboxes);

        // Update visibility states based on checkbox states
        setShowWriter(newCheckboxes.writer);
        setShowReviewer(newCheckboxes.reviewer);
        setShowVendor(newCheckboxes.statistican); // Assuming 'statistican' maps to 'vendor'
        setShowJournal(newCheckboxes.journal);
      }
    } catch (error) {
      console.error("Error fetching details:", error);
    }
  };

  useEffect(() => {
    handlefetchDetails(); // Fetch data on component mount
  }, []);

  const [errors, setErrors] = useState({});

  const [formData, setFormData] = useState({
    payment_status: "",
    writer_payment: "",
    writer: "",
    reviewer: "",
    statistican: "",
    journal: "",
    discount: "",
    reference_number: "",
    writer_payment_date: getTodayDate() || "",
    reviewer_payment: "",
    reviewer_payment_date: getTodayDate() || "",
    statistican_payment: "",
    statistican_payment_date: getTodayDate() || "",
    journal_payment: "",
    journal_payment_date: getTodayDate() || "",
    reference_number: "", // Add reference_number
    reference_number_file: "", // Add file
    writer_payment_status: "",
    reviwer_payment_status: "",
    statistican_payment_status: "",
    journal_payment_status: "",
  });

  const [isFormValid, setIsFormValid] = useState(true);

  const validateForm = () => {
    let formErrors = {};
    let isValid = true;

    // Validate payment fields
    paymentFields.forEach((paymentField, index) => {
      // if (!paymentField.payment || paymentField.payment <= 0) {
      //   formErrors[`payment_${index}`] = "Payment must be greater than 0";
      //   isValid = false;
      // }
      // if (!paymentField.payment_date) {
      //   formErrors[`payment_date_${index}`] = "Payment date is required";
      //   isValid = false;
      // }
    });

    if (!formData.payment_status) {
      formErrors.payment_status = "Payment status is required.";
      isValid = false;
    }

    // Validate reference_number or file
    if (formData.payment_status !== "advance_pending") {
      if (!formData.reference_number && !formData.reference_number_file) {
        formErrors.reference_number =
          "Please add a reference number or upload a screenshot.";
        isValid = false;
      }
    }

    return isValid ? {} : formErrors;
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validateForm();

    // if (Object.keys(validationErrors).length > 0) {
    //   console.log("Error :",validationErrors);
    //   setErrors(validationErrors);
    //   return;
    // }

    const formattedWriterDatas = writerDetails.some(
      (writer) => writer.writerName
    )
      ? writerDetails.map((writer) => ({
          writerName: writer.writerName || "",
          paymentAmount: writer.paymentAmount || "",
          paymentDate: writer.paymentDate,
          paymentStatus: writer.paymentStatus || "",
        }))
      : [];

    const formattedReviewerDatas = reviewerDetails.some(
      (writer) => writer.reviewerName
    )
      ? reviewerDetails.map((writer) => ({
          reviewerName: writer.reviewerName || "",
          reviewerPayment: writer.reviewerPayment || "",
          reviewerPaymentDate: writer.reviewerPaymentDate,
          reviewerPaymentStatus: writer.reviewerPaymentStatus || "",
        }))
      : [];

    const formattedstatisDatas = statisticanDetails.some(
      (writer) => writer.statisticanName
    )
      ? statisticanDetails.map((writer) => ({
          statisticanName: writer.statisticanName || "",
          statisticanPayment: writer.statisticanPayment || "",
          statisticanPaymentDate: writer.statisticanPaymentDate,
          statisticanPaymentStatus: writer.statisticanPaymentStatus || "",
        }))
      : [];

    const formattedjournalDatas = journalDetails.some(
      (writer) => writer.journalName
    )
      ? journalDetails.map((writer) => ({
          journalName: writer.journalName || "",
          journalPayment: writer.journalPayment || "",
          journalPaymentDate: writer.journalPaymentDate,
          journalPaymentStatus: writer.journalPaymentStatus || "",
        }))
      : [];

    const backendFormData = {
      id: paymentFields.id,
      payment_id: payment_id,
      project_id: projectTitleVal,
      payment_status: formData.payment_status,
      reference_number: paymentFields.map((item) => item.reference_number),
      reference_number_file: paymentFields.map(
        (item) => item.reference_number_file
      ),
      created_by: createdby,
      discount: formData.discount,
      payment_details: paymentFields,
      writerPay: formattedWriterDatas,
      reviewerPay: formattedReviewerDatas,
      statisticanPay: formattedstatisDatas,
      journalPay: formattedjournalDatas,
    };
    // console.log("backendFormData :", backendFormData);
    // return;

    document.getElementById("global-loader").style.display = "flex";
    setTimeout(async () => {
      try {
        const response = await axios.post(
          `${API_URL}/api/payment_processes/update/${payment_id}`,
          backendFormData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );

        // console.log("responseUpdate :", response);

        if (response.status === 200 || response.status === 201) {
          Swal.fire({
            title: "Success!",
            text: "Project update successfully.",
            icon: "success",
            confirmButtonText: "OK",
          });
          // navigate("/entry-process");
        } else {
          console.error("Error occurred:", response.statusText);
        }
      } catch (error) {
        Swal.fire({
          title: "Error!",
          text: "Something went wrong while creating the entry.",
          icon: "error",
          confirmButtonText: "OK",
        });
      } finally {
        document.getElementById("global-loader").style.display = "none";
      }
    }, 500);
  };

  const currentDate = new Date().toISOString().split("T")[0];

  const [writter, setWritter] = useState([]);
  const [reviewer, setReviewer] = useState([]);
  const [statistical, setStatistical] = useState([]);
  const [journal, setJournal] = useState([]);

  useEffect(() => {
    // Fetch data from the API when the component mounts
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${API_URL}/api/entry_process/getEmployeeName`
        );
        const data = response.data;

        // Update the state with the received data
        if (data) {
          setWritter(data.writer || []);
          setReviewer(data.reviewer || []);
          setStatistical(data.statistican || []);
          setJournal(data.journal || []);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  //view file

  // file showing

  const [files, setFiles] = useState([]);

  const getFileIcon = (type) => {
    // Define file format groups
    const imageFormats = ["jpg", "png", "gif", "jpeg", "svg", "PNG"];
    const excelFormats = ["xlsx", "xls", "csv"];
    const wordFormats = ["docx", "doc", "word"];

    if (imageFormats.includes(type)) {
      return <img src={Image} className="img-view" alt="Image" />;
    }

    if (excelFormats.includes(type)) {
      return <img src={Excel} className="img-view" alt="Excel" />;
    }

    if (wordFormats.includes(type)) {
      return <img src={Word} className="img-view" alt="Word" />;
    }

    if (type === "pdf") {
      return <img src={PDF} className="img-view" alt="PDF" />;
    }

    return null;
  };

  return (
    <>
      <section className="container">
        <div className="row mt-4">
          {/* <div className=" col-1 d-flex justify-content-center">
            <Sider></Sider>
          </div> */}
          <div className="col-12">
            <div className="col-12">
              <Header></Header>
            </div>

            <div className="col-11 wapper w-100 mt-3 ">
              <div className="pt-2 px-2 d-none d-md-block">
                <Breadcrumbs></Breadcrumbs>
              </div>

              <div className="row w-100 mt-2 pt-3   px-3 ">
                <div className="col-12 col-md ">
                  <label className="statis-name">Project ID</label>
                  <select
                    className="form-control1"
                    // onChange={handleSelectChange}
                    disabled={isReadOnly}
                    value={projectTitleVal}
                  >
                    <option value="" readOnly={isReadOnly} disabled selected>
                      Select Payment Title
                    </option>
                    {projectTitles.map((project) => (
                      <option key={project.id} value={project.id}>
                        {Capitalize(project.project_id)}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="col-12 col-md">
                  <label className="statis-name">Budget</label>
                  <input
                    type="text"
                    className="form-control1 px-2"
                    placeholder="Enter Project ID"
                    readOnly={isReadOnly}
                    value={`₹${projectBudget}`}
                    onChange={(e) => {
                      const value = e.target.value.replace("₹", ""); // Remove ₹ if user types it
                      setBudget(value);
                    }}
                  />
                </div>
                <div className="col-12 col-md">
                  <label className="statis-name">client Name</label>
                  <input
                    type="text"
                    className="form-control1 px-2"
                    placeholder="Enter client name"
                    readOnly={isReadOnly}
                    value={clientname}
                    onChange={(e) => setProjectId(e.target.value)}
                  />
                </div>

                <div className="col-12 col-md">
                  <label className="statis-name">Institute</label>
                  <input
                    type="text"
                    className="form-control1 px-2"
                    placeholder="Enter institute"
                    readOnly={isReadOnly}
                    value={institute}
                    onChange={(e) => setProjectId(e.target.value)}
                  />
                </div>
                <div className="col-12 col-md">
                  <label className="statis-name">Department</label>
                  <input
                    type="text"
                    className="form-control1 px-2"
                    placeholder="Enter department"
                    readOnly={isReadOnly}
                    value={department}
                    onChange={(e) => setProjectId(e.target.value)}
                  />
                </div>
                <div className="col-12 col-md">
                  <label className="statis-name">Profession</label>
                  <input
                    type="text"
                    className="form-control1 px-2"
                    placeholder="Enter profession"
                    readOnly={isReadOnly}
                    value={profession}
                    onChange={(e) => setProjectId(e.target.value)}
                  />
                </div>
              </div>
              <div className="row mt-2 pt-2 px-3">
                {paymentFields.map((field, index) => (
                  <div key={index} className="row mt-2 align-items-center">
                    {/* Payment Amount */}
                    <div className="col-12 col-md-2">
                      <label className="statis-name">{`Payment ${
                        index + 1
                      }`}</label>
                      <input
                        type="number"
                        className={`form-control ${
                          errors[`payment_${index}`] ? "error" : ""
                        }`}
                        value={field.payment}
                        onChange={(e) =>
                          handleChange(index, "payment", e.target.value)
                        }
                      />
                    </div>

                    {/* Payment Date */}
                    {/* <div className="col-12 col-md-2">
                      <label className="statis-name">Payment Date</label>
                      <input
                        type="date"
                        className={`form-control ${
                          errors[`date_${index}`] ? "error" : ""
                        }`}
                        value={field.payment_date}
                        onChange={(e) =>
                          handleChange(index, "payment_date", e.target.value)
                        }
                      />
                    </div> */}
                    <div className="col-12 col-md-2">
                      <label className="statis-name">Payment Date</label>
                      <input
                        type="date"
                        className={`form-control ${
                          errors[`date_${index}`] ? "error" : ""
                        }`}
                        // value={field.payment_date || today}
                        value={today}
                        onChange={(e) =>
                          handleChange(index, "payment_date", e.target.value)
                        }
                      />
                    </div>

                    {/* Payment status */}
                    <div className="col-12 col-md-2">
                      <label className="statis-name">Payment Status</label>
                      <input
                        type="text"
                        className={`form-control1 ${
                          errors[`date_${index}`] ? "error" : ""
                        }`}
                        value={Capitalize(field.payment_type)}
                        disabled
                      />
                    </div>

                    {/* Reference Number (Per Payment) */}
                    <div className="col-12 col-md-2">
                      <label className="statis-name">Reference No.</label>
                      <input
                        type="text"
                        className={`form-control ${
                          errors[`reference_${index}`] ? "is-invalid" : ""
                        }`}
                        value={field.reference_number || ""}
                        onChange={(e) => {
                          handleChange(
                            index,
                            "reference_number",
                            e.target.value
                          );
                          if (errors[`reference_${index}`]) {
                            setErrors((prev) => ({
                              ...prev,
                              [`reference_${index}`]: "",
                            }));
                          }
                        }}
                      />
                      {errors[`reference_${index}`] && (
                        <div className="invalid-feedback">
                          {errors[`reference_${index}`]}
                        </div>
                      )}
                    </div>

                    {/* File Upload (Per Payment) */}
                    <div className="col-12 col-md-2">
                      <label className="statis-name">File</label>
                      <div
                        className={`form-control d-flex justify-content-end`}
                      >
                        <input
                          type="file"
                          accept=".pdf,.jpg,.png"
                          className={`file-upload-input ${
                            errors.reference_number_file ? "is-invalid" : ""
                          }`}
                          onChange={(e) => handleFileChange(index, e)} // Modify handleFileChange to accept index
                        />
                        {field.file ? (
                          <RiDeleteBin6Line
                            className="file-del-icon"
                            onClick={() => handleFileDelete(index)} // Modify handleFileDelete to accept index
                          />
                        ) : (
                          <label className="file-icon">
                            <PiCloudArrowUpLight />
                          </label>
                        )}
                      </div>
                    </div>

                    {/* Add/Delete Buttons */}
                    {index === 0 ? (
                      <div className="col-12 col-md-2 d-flex align-items-center mt-4">
                        <button
                          type="button"
                          className="save-form-add mt-1"
                          onClick={() => handleAddField(field.id)}
                        >
                          Add +
                        </button>
                      </div>
                    ) : (
                      <div className="col-12 col-md-2 d-flex align-items-center mt-4">
                        <button
                          type="button"
                          className="save-form-del mt-1"
                          onClick={() => handleRemoveField(index)}
                        >
                          Delete
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div className="row mt-2 pt-2 px-3">
                <div className="col-12 col-md-3 px-3  col-md">
                  <label className="statis-name">Payment Status</label>
                  <select
                    className={`form-select ${
                      errors.payment_status ? "error" : ""
                    }`}
                    name="payment_status"
                    // onChange={handleFormChange}
                    onChange={(e) => {
                      handleFormChange(e);

                      // Clear validation error for payment_status
                      if (errors.payment_status) {
                        setErrors((prevErrors) => {
                          const updatedErrors = { ...prevErrors };
                          delete updatedErrors.payment_status;
                          return updatedErrors;
                        });
                      }
                    }}
                    value={formData.payment_status}
                  >
                    <option value="" disabled selected>
                      Payment Status
                    </option>
                    <option value="completed">Completed</option>
                    <option value="advance_pending">Advance Pending</option>
                    <option value="partial_payment_pending">
                      Partial payment pending
                    </option>
                    <option value="final_payment_pending">
                      Final payment pending
                    </option>
                    <option value="advance_received">Advance received</option>
                    <option value="partial_payment_received">
                      Partial payment received
                    </option>
                    {/* <option value="balance_to_pay">Balance to pay </option>
                    <option value="presentation">Presentation</option>
                    <option value="partial_payment_done">
                      Partial payment done
                    </option>
                    <option value="full_payment_done">Full payment done</option>
                    <option value="advance_payment_done">
                      Advance payment done{" "}
                    </option> */}
                  </select>
                </div>
                <div className="col-12 col-md-3">
                  <label className="statis-name">Discounts</label>
                  <input
                    type="text"
                    className={`form-control`}
                    name="discount"
                    value={formData.discount}
                    // onChange={handleFormChange}
                    onChange={(e) => {
                      handleFormChange(e);
                    }}
                  />
                </div>
              </div>
              {/*  update document view */}
              <div className="container mt-4">
                <div className="row g-2">
                  {files.map((file, index) => (
                    <div className="col-2" key={index}>
                      <div className="view-files pt-3">
                        <div>
                          <div className="text-center">
                            {getFileIcon(file.type)}
                          </div>
                          <h5 className="text-center mt-2 file-title-card">
                            {Capitalize(file.title)}
                          </h5>
                          <div className="d-flex justify-content-center">
                            <button
                              className="mt-1 file-view-button"
                              onClick={() => window.open(file.url, "_blank")}
                            >
                              View
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {writerDetails.some((writer) => writer.writerName) &&
                writerDetails
                  .filter((writer) => writer.writerName) // Filter only non-empty writerName
                  .map((writer, index) => (
                    <div className="row pt-2 px-3 ">
                      <div className="col-12 col-md-3">
                        <label className="statis-name">Writer Name</label>
                        <select
                          className="form-control2"
                          name="writerName"
                          value={writer.writerName}
                          disabled={isReadOnly}
                        >
                          <option value="" disabled selected>
                            Select writer
                          </option>
                          {writter.map((writer, index) => (
                            <option key={writer.id} value={writer.id}>
                              {/* {writer.name} */}
                              {writer.name.charAt(0).toUpperCase() +
                                writer.name.slice(1)}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="col-12 col-md-3">
                        <label className="statis-name"> Writer Payment</label>
                        <input
                          type="number"
                          className={`form-control`}
                          name="paymentAmount"
                          value={writer.paymentAmount}
                          onChange={(e) => handleWriterChange(e, index)}
                        />
                      </div>
                      <div className="col-12 col-md-3">
                        <label className="statis-name">
                          {" "}
                          Writer Payment Date
                        </label>
                        <input
                          type="date"
                          className="form-control "
                          id="dateInput"
                          name="paymentDate"
                          value={writer.paymentDate}
                          onChange={(e) => handleWriterChange(e, index)}
                        />
                      </div>
                      <div className="col-12 col-md-3">
                        <label className="statis-name">Payment Status</label>
                        <select
                          className={`form-select`}
                          name="paymentStatus"
                          onChange={(e) => handleWriterChange(e, index)}
                          value={writer.paymentStatus}
                        >
                          <option value="" disabled selected>
                            Payment Status
                          </option>
                          <option value="paid">Paid</option>
                          <option value="pending">UnPaid</option>
                        </select>
                      </div>
                    </div>
                  ))}
              {reviewerDetails.some((user) => user.reviewerName) &&
                reviewerDetails
                  .filter((user) => user.reviewerName) // Filter only non-empty reviewerName
                  .map((user, index) => (
                    <div className="row pt-2 px-3">
                      <div className="col-12 col-md-3">
                        <label className="statis-name"> Reviewer Name</label>
                        <select
                          className="form-control2"
                          name="reviewerName"
                          value={user.reviewerName || ""}
                          disabled={isReadOnly}
                        >
                          <option value="" disabled selected>
                            Select reviewer
                          </option>
                          {reviewer.map((writer, index) => (
                            <option key={writer.id} value={writer.id}>
                              {/* {writer.name} */}
                              {writer.name.charAt(0).toUpperCase() +
                                writer.name.slice(1)}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="col-12 col-md-3">
                        <label className="statis-name"> Reviewer Payment</label>
                        <input
                          type="number"
                          className={`form-control`}
                          name="reviewerPayment"
                          value={user.reviewerPayment}
                          onChange={(e) => handleReviewerChange(e, index)}
                        />
                      </div>
                      <div className="col-12 col-md-3">
                        <label className="statis-name">
                          Reviewer Payment Date
                        </label>
                        <input
                          type="date"
                          className="form-control "
                          id="dateInput"
                          name="reviewerPaymentDate"
                          value={user.reviewerPaymentDate}
                          onChange={(e) => handleReviewerChange(e, index)}
                        />
                      </div>
                      <div className="col-12 col-md-3">
                        <label className="statis-name">Payment Status</label>
                        <select
                          className={`form-select`}
                          name="reviewerPaymentStatus"
                          onChange={(e) => handleReviewerChange(e, index)}
                          value={user.reviewerPaymentStatus}
                        >
                          <option value="" disabled selected>
                            Payment Status
                          </option>
                          <option value="paid">Paid</option>
                          <option value="pending">UnPaid</option>
                        </select>
                      </div>
                    </div>
                  ))}

              {statisticanDetails.some((user) => user.statisticanName) &&
                statisticanDetails
                  .filter((user) => user.statisticanName) // Filter only non-empty statisticanName
                  .map((user, index) => (
                    <div className="row pt-2 px-3">
                      <div className="col-12 col-md-3">
                        <label className="statis-name">Statistican Name</label>
                        <select
                          className="form-control2"
                          name="statisticanName"
                          value={user.statisticanName || ""}
                          disabled={isReadOnly}
                        >
                          <option value="" disabled selected>
                            Select statistican
                          </option>
                          {statistical.map((writer, index) => (
                            <option key={writer.id} value={writer.id}>
                              {/* {writer.name} */}
                              {writer.name.charAt(0).toUpperCase() +
                                writer.name.slice(1)}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="col-12 col-md-3">
                        <label className="statis-name">
                          Statistican Payment
                        </label>
                        <input
                          type="number"
                          className={`form-control`}
                          name="statisticanPayment"
                          value={user.statisticanPayment}
                          onChange={(e) => handleStatisticanChange(e, index)}
                        />
                      </div>
                      <div className="col-12 col-md-3">
                        <label className="statis-name">
                          Statistican Payment Date
                        </label>
                        <input
                          type="date"
                          className="form-control "
                          id="dateInput"
                          name="statisticanPaymentDate"
                          value={user.statisticanPaymentDate}
                          onChange={(e) => handleStatisticanChange(e, index)}
                        />
                      </div>
                      <div className="col-12 col-md-3">
                        <label className="statis-name">Payment Status</label>
                        <select
                          className={`form-select`}
                          name="statisticanPaymentStatus"
                          onChange={(e) => handleStatisticanChange(e, index)}
                          value={user.statisticanPaymentStatus}
                        >
                          <option value="" disabled selected>
                            Payment Status
                          </option>
                          <option value="paid">Paid</option>
                          <option value="pending">UnPaid</option>
                        </select>
                      </div>
                    </div>
                  ))}

              {journalDetails.some((user) => user.journalName) &&
                journalDetails
                  .filter((user) => user.journalName) // Filter only non-empty journalName
                  .map((user, index) => (
                    <div className="row pt-2 px-3">
                      <div className="col-12 col-md-3">
                        <label className="statis-name">Journal Name</label>
                        <input
                          className="form-control2"
                          name="journalName"
                          value={user.journalName || ""}
                          disabled={isReadOnly}
                        />
                        {/* <select
                          className="form-control2"
                          name="journalName"
                          value={user.journalName || ""}
                          disabled={isReadOnly}
                        >
                          <option value="" disabled selected>
                            Select journal
                          </option>
                          {statistical.map((writer, index) => (
                            <option key={writer.id} value={writer.id}>
                              {writer.name} 
                              {writer.name.charAt(0).toUpperCase() +
                                writer.name.slice(1)}
                            </option>
                          ))}
                        </select> */}
                      </div>
                      <div className="col-12 col-md-3">
                        <label className="statis-name">Journal Payment</label>
                        <input
                          type="number"
                          className={`form-control`}
                          name="journalPayment"
                          value={user.journalPayment}
                          onChange={(e) => handleJournalChange(e, index)}
                        />
                      </div>
                      <div className="col-12 col-md-3">
                        <label className="statis-name">
                          Journal Payment Date
                        </label>
                        <input
                          type="date"
                          className="form-control "
                          id="dateInput"
                          name="journalPaymentDate"
                          value={user.journalPaymentDate}
                          onChange={(e) => handleJournalChange(e, index)}
                        />
                      </div>
                      <div className="col-12 col-md-3">
                        <label className="statis-name">Payment Status</label>
                        <select
                          className={`form-select`}
                          name="journalPaymentStatus"
                          onChange={(e) => handleJournalChange(e, index)}
                          value={user.journalPaymentStatus}
                        >
                          <option value="" disabled selected>
                            Payment Status
                          </option>
                          <option value="paid">Paid</option>
                          <option value="pending">UnPaid</option>
                        </select>
                      </div>
                    </div>
                  ))}

              <div className="col-12  d-flex justify-content-end py-5 px-1 gap-3   ">
                <Link to="/entry-process">
                  <button type="submit" className="save-form">
                    Back
                  </button>
                </Link>
                <button
                  onClick={handleSubmit}
                  type="submit"
                  className="save-form-save"
                >
                  Update
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Payment_form;
