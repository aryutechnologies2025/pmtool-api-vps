import React, { useState, useEffect, useCallback } from "react";
import "../assests/css/payment_form.css";
import Sider from "../components/Sider";
import Header from "../components/Header.js";
import { Link } from "react-router-dom";
import Breadcrumbs from "../routes/Breadcrumbs.js";
import axios from "axios";
import { API_URL } from "../config.js";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import Swal from "sweetalert2";
import { Capitalize } from "../campsCase.js";
import { useRef } from "react";
import { PiCloudArrowUpLight } from "react-icons/pi";
import { RiDeleteBin6Line } from "react-icons/ri";
import { AiOutlineClose } from "react-icons/ai";

import PDF from "../assests/images/pdf.svg";
import Excel from "../assests/images/excel.svg";
import Word from "../assests/images/word.svg";
import Image from "../assests/images/image.svg";

function Payment_form() {
  const navigate = useNavigate();
  const location = useLocation();

  const { rowId } = location.state || {};

  const [showDatas, setShowData] = useState({});

  useEffect(() => {
    if (rowId) {
      fetchShowData(rowId);
    }
  }, [rowId]);

  const fetchShowData = async (id) => {
    try {
      const responseShow = await axios.get(
        `${API_URL}/api/payment_processes/view/${id}`
      );

      const fetchData = responseShow.data;
      setShowData(responseShow.data);
      setPaymentIdData(responseShow.data.id);
      setProjecttile(fetchData.project_data.id);
      setBudget(fetchData.project_data.budget);
      setProjectId(fetchData.project_data.project_id);
      setProjectId(fetchData.project_data.project_id);
      setFormData((prevFormData) => ({
        ...prevFormData,
        writer: fetchData.project_data.writer || "",
        reviewer: fetchData.project_data.reviewer || "",
        statistican: fetchData.project_data.statistican || "",
        journal: fetchData.project_data.journal || "",
        payment_status: fetchData.payment_status || "",
        writer_payment: fetchData.writer_payment || "",
        writer_payment_date: fetchData.writer_payment_date || "",
        reviewer_payment: fetchData.reviewer_payment || "",
        reviewer_payment_date: fetchData.reviewer_payment_date || "",
        statistican_payment: fetchData.statistican_payment || "",
        statistican_payment_date: fetchData.statistican_payment_date || "",
        journal_payment: fetchData.journal_payment || "",
        reference_number: fetchData.reference_number || "",
        journal_payment_date: fetchData.journal_payment_date || "",
      }));

      const referenceFiles = Array.isArray(fetchData.reference_number_file)
        ? fetchData.reference_number_file
        : fetchData.reference_number_file
          ? [fetchData.reference_number_file] // Wrap in array if it's a single string
          : []; // Fallback to empty array if it's null or undefined


      // Process each file
      const dynamicFiles = referenceFiles.map((file, index) => {

        // Check if file is valid before attempting to split
        if (!file) {
          console.warn(`Skipping invalid file at index ${index}`);
          return null; // Skip invalid files
        }

        const fileType = file.split('.').pop(); // Get file extension
        const relativePath = file.replace(/\\/g, '/'); // Normalize path for URLs

        return {
          img: getFileIcon(fileType), // Function to get the corresponding file icon
          type: fileType,
          fileName: file.split('/').pop(), // Extract the file name
          url: `${API_URL}/payment_screenshots/${relativePath}`, // Construct the file URL
          id: index, // Assign a unique ID (index here since no specific ID is provided)
        };
      });

      // Update state with new files while avoiding duplicates
      setFiles((prevFiles) => {
        const newFiles = dynamicFiles.filter((newFile) =>
          !prevFiles.some((existingFile) => existingFile.id === newFile.id)
        );
        return [...prevFiles, ...newFiles];
      });

      setPaymentFields(fetchData.payment_data);

      const newCheckboxes = {
        writer: fetchData.writer_payment !== null,
        reviewer: fetchData.reviewer_payment !== null,
        statistican: fetchData.statistican_payment !== null,
        journal: fetchData.journal_payment !== null,
      };

      setCheckboxes(newCheckboxes);
      setShowWriter(newCheckboxes.writer);
      setShowReviewer(newCheckboxes.reviewer);
      setShowVendor(newCheckboxes.statistican); // Assuming 'statistican' maps to 'vendor'
      setShowJournal(newCheckboxes.journal);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const [showFields, setShowFields] = useState(false);
  const [showWriter, setShowWriter] = useState(false);
  const [showReviewer, setShowReviewer] = useState(false);
  const [showVendor, setShowVendor] = useState(false);
  const [showjournal, setShowJournal] = useState(false);
  const [payment_id, setPaymentIdData] = useState({});

  const handleWriterClick = () => {
    setShowWriter(!showWriter);
  };

  const handleReviewerClick = () => {
    setShowReviewer(!showReviewer);
  };

  const handleStatisticanClick = () => {
    setShowVendor(!showVendor);
  };

  const handleJournalClick = () => {
    setShowJournal(!showjournal);
  };

  const [date, setDate] = useState("");

  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  useEffect(() => {
    setDate(getTodayDate());
  }, []);

  const [paymentFields, setPaymentFields] = useState([]);

  // const handleAddField = () => {
  //   const newField = { payment: "", payment_date: "" }; // Default values for new field
  //   setPaymentFields([...paymentFields, newField]);
  // };
  const handleAddField = () => {
    const validationErrors = validateFormFiles();

    if (Object.keys(validationErrors).length === 0) {
      setPaymentFields((prevPaymentFields) => [
        ...prevPaymentFields,
        { amount: "", date: "" },
      ]);
    } else {
      setErrors(validationErrors);
    }
  };
  const validateFormFiles = () => {
    const validationErrors = {};

    paymentFields.forEach((field, index) => {
      if (!field.payment) {
        validationErrors[`payment_${index}`] = "Payment is required";
      }
      if (!field.payment_date) {
        validationErrors[`payment_date_${index}`] = "Payment date is required";
      }
    });

    return validationErrors;
  };

  const handleRemoveField = async (index, id) => {
    // Show a SweetAlert confirmation dialog
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to delete this payment?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "Cancel",
    });

    // If user confirms, proceed with deletion
    if (result.isConfirmed) {
      try {
        // Check if the field has an `id` (exists in the database)
        if (id) {
          await axios.delete(
            `${API_URL}/api/payment_processes/payment_delete/${id}`
          );
        }

        // Remove the field from the frontend state
        setPaymentFields((prevFields) =>
          prevFields.filter((_, i) => i !== index)
        );

        // Show a success message after deletion
        Swal.fire("Deleted!", "The payment field has been deleted.", "success");
      } catch (error) {
        console.error("Error deleting payment field", error);
        // Show error message if deletion fails
        Swal.fire(
          "Error!",
          "There was an issue deleting the payment field.",
          "error"
        );
      }
    } else {
      // If user cancels, you can show a cancellation message or do nothing
      Swal.fire("Cancelled", "Your payment field is safe :)", "info");
    }
  };

  const handleChange = (index, field, value) => {
    if (index >= 0 && index < paymentFields.length) {
      const updatedFields = [...paymentFields];

      updatedFields[index][field] = value;
      setPaymentFields(updatedFields);
    } else {
      console.error("Invalid index:", index);
    }
  };

  const handleFileChange = useCallback((e) => {
    const file = e.target.files[0];
    console.log("Selected file:", file);

    setFormData((prevData) => ({
      ...prevData,
      file, // Update file in formData
    }));
  }, []);

  const fileInputRef = useRef(null);
  const handleFileDelete = useCallback(() => {
    setFormData((prevData) => ({
      ...prevData,
      file: null, // Clear file from formData
    }));

    // Clear validation error for reference_number
    setErrors((prevErrors) => {
      const updatedErrors = { ...prevErrors };
      delete updatedErrors.reference_number;
      return updatedErrors;
    });

    // Reset the file input field using the ref
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  }, []);

  const [projectTitles, setProjectTitles] = useState([]);
  const [projectTitleVal, setProjecttile] = useState([]);
  const [projectBudget, setBudget] = useState([]);
  const [projectId, setProjectId] = useState([]);
  const [isReadOnly, setIsReadOnly] = React.useState(true);

  const [checkboxes, setCheckboxes] = useState({
    writer: false,
    reviewer: false,
    statistican: false,
    journal: false,
  });

  const handlefetchDetails = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/projecttitle`
      );

      if (response.status === 200) {
        const projectTitleArray = response.data;
        setProjectTitles(projectTitleArray);
      } else {
        console.error("Error fetching project titles:", response.statusText);
      }
    } catch (error) {
      console.error("Submission error:", error);
    }
  };

  const handleSelectChange = async (event) => {
    const selectedId = event.target.value;

    setProjecttile(selectedId);
    setFormData((prevState) => ({
      ...prevState,
      projectTitleVal: selectedId,
    }));

    if (selectedId) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        projectTitleVal: "",
      }));
    }

    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/project-view-data/${selectedId}`
      );
      if (response.status === 200) {
        setBudget(response.data.budget);
        setProjectId(response.data.project_id);
        const writerId =
          response.data.writer?.employee_type === "freelancers"
            ? response.data.writer.id
            : "";

        const reviewerId =
          response.data.reviewer?.employee_type === "freelancers"
            ? response.data.reviewer.id
            : "";

        const statisticanId =
          response.data.statistican?.employee_type === "freelancers"
            ? response.data.statistican.id
            : "";

        const journalId =
          response.data.journal?.employee_type === "freelancers"
            ? response.data.journal.id
            : "";

        setFormData((prevFormData) => ({
          ...prevFormData,
          writer: writerId,
          reviewer: reviewerId,
          statistican: statisticanId,
          journal: journalId,
        }));
        // setFormData((prevFormData) => ({
        //   ...prevFormData,
        //   writer: response.data.writer || '',
        //   reviewer: response.data.reviewer || '',
        //   statistican: response.data.statistican || '',
        //   journal: response.data.journal || ''
        // }));

        const newCheckboxes = {
          writer:
            response.data.writer !== null &&
            response.data.writer.employee_type === "freelancers",
          reviewer:
            response.data.reviewer !== null &&
            response.data.reviewer.employee_type === "freelancers",
          statistican:
            response.data.statistican !== null &&
            response.data.statistican.employee_type === "freelancers",
          journal:
            response.data.journal !== null &&
            response.data.journal.employee_type === "freelancers",
        };        

        setCheckboxes(newCheckboxes);

        // Update visibility states based on checkbox states
        setShowWriter(newCheckboxes.writer);
        setShowReviewer(newCheckboxes.reviewer);
        setShowVendor(newCheckboxes.statistican); // Assuming 'statistican' maps to 'vendor'
        setShowJournal(newCheckboxes.journal);
      }
    } catch (error) {
      console.error("Error fetching details:", error);
    }
  };

  useEffect(() => {
    handlefetchDetails(); // Fetch data on component mount
  }, []);

  const [errors, setErrors] = useState({});

  const [formData, setFormData] = useState({
    payment_status: "",
    writer_payment: "",
    writer: "",
    reviewer: "",
    statistican: "",
    journal: "",
    reference_number: "",
    writer_payment_date: getTodayDate() || "",
    reviewer_payment: "",
    reviewer_payment_date: getTodayDate() || "",
    statistican_payment: "",
    statistican_payment_date: getTodayDate() || "",
    journal_payment: "",
    journal_payment_date: getTodayDate() || "",
    reference_number: "", // Add reference_number
    file: null, // Add file
  });

  const [isFormValid, setIsFormValid] = useState(true);

  const validateForm = () => {
    let formErrors = {};
    let isValid = true;

    // Validate payment fields
    paymentFields.forEach((paymentField, index) => {
      if (!paymentField.payment || paymentField.payment <= 0) {
        formErrors[`payment_${index}`] = "Payment must be greater than 0";
        isValid = false;
      }

      if (!paymentField.payment_date) {
        formErrors[`payment_date_${index}`] = "Payment date is required";
        isValid = false;
      }
    });
    setErrors(formErrors);
    setIsFormValid(isValid);
    return isValid;
  };



  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();

    if (isValid) {
      console.log("Form submitted successfully with data:", paymentFields);
    } else {
      console.log("Form is invalid. Please check the errors.");
    }

    // Map state values to backend keys
    const backendFormData = {
      payment_id: payment_id,
      project_id: projectTitleVal,
      payment_status: formData.payment_status,
      writer_payment: formData.writer_payment,
      writer_payment_date: formData.writer_payment_date,
      reviewer_payment: formData.reviewer_payment,
      reviewer_payment_date: formData.reviewer_payment_date,
      statistican_payment: formData.statistican_payment,
      statistican_payment_date: formData.statistican_payment_date,
      journal_payment: formData.journal_payment,
      journal_payment_date: formData.journal_payment_date,
      reference_number: formData.reference_number,
      reference_number_file: formData.file,
      created_by: createdby,
      payment_details: paymentFields, // Ensure this matches backend format
    };
    try {
      const response = await axios.post(
        `${API_URL}/api/payment_processes/update/${payment_id}`,
        backendFormData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      if (response.status === 200 || response.status === 201) {
        navigate("/entry-process");
      } else {
        console.error("Error occurred:", response.statusText);
      }
    } catch (error) {
      console.error("Submission error:", error);
    }
  };

  const currentDate = new Date().toISOString().split("T")[0];


  const [writter, setWritter] = useState([]);
  const [reviewer, setReviewer] = useState([]);
  const [statistical, setStatistical] = useState([]);
  const [journal, setJournal] = useState([]);


  useEffect(() => {
    // Fetch data from the API when the component mounts
    const fetchData = async () => {
      try {
        const response = await axios.get(`${API_URL}/api/entry_process/getEmployeeName`);
        const data = response.data;

        // Update the state with the received data
        if (data) {
          setWritter(data.writer || []);
          setReviewer(data.reviewer || []);
          setStatistical(data.statistican || []);
          setJournal(data.journal || []);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  //view file

  // file showing

  const [files, setFiles] = useState([]);

  const getFileIcon = (type) => {
    // Define file format groups
    const imageFormats = ["jpg", "png", "gif", "jpeg", "svg", "PNG"];
    const excelFormats = ["xlsx", "xls", "csv"];
    const wordFormats = ["docx", "doc", "word"];

    if (imageFormats.includes(type)) {
      return <img src={Image} className="img-view" alt="Image" />;
    }

    if (excelFormats.includes(type)) {
      return <img src={Excel} className="img-view" alt="Excel" />;
    }

    if (wordFormats.includes(type)) {
      return <img src={Word} className="img-view" alt="Word" />;
    }

    if (type === "pdf") {
      return <img src={PDF} className="img-view" alt="PDF" />;
    }

    return null;
  };

  return (
    <>
      <section className="container">
        <div className="row mt-4">
          {/* <div className=" col-1 d-flex justify-content-center">
            <Sider></Sider>
          </div> */}
          <div className="col-12">
            <div className="col-12">
              <Header></Header>
            </div>

            <div className="col-11 wapper w-100 mt-3 ">
              <div className="pt-2 px-2 d-none d-md-block">
                <Breadcrumbs></Breadcrumbs>
              </div>


              <div className="row w-100 mt-2 pt-3   px-3 ">
                <div className="col-12 col-md ">
                  <label className="statis-name">Project ID</label>
                  <select
                    className="form-control "
                    onChange={handleSelectChange}
                    value={projectTitleVal}
                  >
                    <option value="" disabled selected>
                      Select Payment Title
                    </option>
                    {projectTitles.map((project) => (
                      <option key={project.id} value={project.id}>
                        {Capitalize(project.project_id)}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="col-12 col-md">
                  <label className="statis-name">Budget</label>
                  <input
                    type="text"
                    className="form-control1 px-2"
                    placeholder="Enter Project ID"
                    readOnly={isReadOnly}
                    value={projectBudget}
                    onChange={(e) => setBudget(e.target.value)}
                  />
                </div>
                <div className="col-12 col-md">
                  <label className="statis-name">Project ID</label>
                  <input
                    type="text"
                    className="form-control1 px-2"
                    placeholder="Enter Project ID"
                    readOnly={isReadOnly}
                    value={projectId}
                    onChange={(e) => setProjectId(e.target.value)}
                  />
                </div>
              </div>
              <div className="row mt-2 pt-2 px-3">
                {paymentFields.map((field, index) => (
                  <div key={index} className="row mt-2 align-items-center">
                    <div className="col-12 col-md-3">
                      <label className="statis-name">{`Payment ${index + 1
                        }`}</label>
                      <input
                        type="number"
                        className={`form-control ${errors[`payment_${index}`] ? "error" : ""}`}  // Apply error class if there's an error

                        value={field.payment}
                        // onChange={(e) =>
                        //   handleChange(index, "payment", e.target.value)
                        // }

                        onChange={(e) => {
                          handleChange(index, "payment", e.target.value);

                          // Clear validation error for this field if it exists
                          if (errors[`payment_${index}`]) {
                            setErrors((prevErrors) => {
                              const updatedErrors = { ...prevErrors };
                              delete updatedErrors[`payment_${index}`];
                              return updatedErrors;
                            });
                          }
                        }}
                      />
                    </div>
                    <div className="col-12 col-md-3">
                      <label className="statis-name">Payment Date</label>
                      <input
                        type="date"
                        className={`form-control ${errors[`payment_date_${index}`] ? "error" : ""}`}  // Apply error class if there's an error

                        value={field.payment_date}
                        // onChange={(e) =>
                        //   handleChange(index, "payment_date", e.target.value)
                        // }
                        onChange={(e) => {
                          handleChange(index, "payment_date", e.target.value);

                          // Clear validation error for this field if it exists
                          if (errors[`date_${index}`]) {
                            setErrors((prevErrors) => {
                              const updatedErrors = { ...prevErrors };
                              delete updatedErrors[`payment_date_${index}`];
                              return updatedErrors;
                            });
                          }
                        }}
                      />
                    </div>

                    {/* Add Button only for the first row */}
                    {index === 0 && (
                      <div className="col-12 col-md-3 d-flex justify-content-start align-items-center mt-4">
                        <button
                          type="button"
                          className="save-form-add mt-1"
                          onClick={handleAddField}
                        >
                          Add +
                        </button>
                      </div>
                    )}

                    {/* Delete Button for all rows except the first */}
                    {index > 0 && (
                      <div className="col-12 col-md-3 d-flex justify-content-start align-items-center mt-4">
                        <button
                          type="button"
                          className="save-form-del mt-1"
                          onClick={() => handleRemoveField(index, field.id)}
                        >
                          Delete
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>


              <div className="row mt-2 px-3">
                <div className="col-12 col-md-4 px-3  col-md">
                  <label className="statis-name">Payment Status</label>
                  <select
                    className="form-control"
                    name="payment_status"
                    onChange={handleFormChange}
                    value={formData.payment_status}
                  >
                    <option value="" disabled selected>
                      Payment Status
                    </option>
                    <option value="completed">Completed</option>
                    <option value="balance">Balance to pay </option>
                    <option value="partial">Partial payment done</option>
                    <option value="full payment">Full payment done</option>
                    <option value="Advance payment">
                      Advance payment done{" "}
                    </option>
                  </select>
                </div>
                <div className="col-12 col-md-3 px-3 col-md">
                  <label className="statis-name">Payment Reference Number</label>
                  <input
                    type="text"
                    className={`form-control ${errors.reference_number ? "is-invalid" : ""}`}
                    name="reference_number"
                    value={formData.reference_number}
                    // onChange={handleFormChange}
                    onChange={(e) => {
                      handleFormChange(e);

                      // Clear validation error for payment_status
                      if (errors.reference_number) {
                        setErrors((prevErrors) => {
                          const updatedErrors = { ...prevErrors };
                          delete updatedErrors.reference_number;
                          return updatedErrors;
                        });
                      }
                    }}
                  />
                  {errors.reference_number && (
                    <div className="invalid-feedback d-flex justify-content-between">{errors.reference_number}</div>
                  )}
                </div>
                <span className="col-1 mt-4">(or)</span>

                <div className="col-12 col-md-3">
                  <label className="statis-name">File</label>
                  <div
                    className={`form-control d-flex justify-content-end`}
                  >
                    <input
                      type="file"
                      accept="file/*"
                      ref={fileInputRef}
                      className={`file-upload-input ${errors.reference_number ? "is-invalid" : ""}`}
                      // onChange={(e) => handleFileChange(index, e)}
                      onChange={(e) => {
                        handleFileChange(e);
                        // Clear validation error for reference_number if file is uploaded
                        if (errors.reference_number) {
                          setErrors((prevErrors) => {
                            const updatedErrors = { ...prevErrors };
                            delete updatedErrors.reference_number;
                            return updatedErrors;
                          });
                        }
                      }}
                    />
                    {formData.file && (
                      <RiDeleteBin6Line
                        className="file-del-icon"
                        onClick={handleFileDelete}
                      />
                    )}
                    {!formData.file && (
                      <label className="file-icon">
                        <PiCloudArrowUpLight />
                      </label>
                    )}
                  </div>
                  {errors.reference_number && (
                    <div className="invalid-feedback">{errors.reference_number}</div>
                  )}
                </div>
                {/*  update document view */}
                <div className="container mt-4">
                  <div className="row g-2">
                    {files.map((file, index) => (
                      <div className="col-2" key={index}>
                        <div className="view-files pt-3">
                          <div>
                            {/* <AiOutlineClose
                              className="file-cancel-icon"
                              onClick={() => handleDelete(index, file.id)}
                            /> */}
                            <div className="text-center">
                              {getFileIcon(file.type)}
                            </div>
                            <h5 className="text-center mt-2 file-title-card">
                              {Capitalize(file.title)}
                            </h5>
                            <div className="d-flex justify-content-center">
                              <button className="mt-1 file-view-button"
                                onClick={() => window.open(file.url, '_blank')}
                              >
                                View
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>


              </div>


              {/* <div className=" gap-3 px-4 d-flex  flex-wrap pt-4">
                  {checkboxes.writer && (
                    <div className=" ">
                      <input
                        type="checkbox"
                        id="writer"
                        checked={checkboxes.writer}
                        onClick={handleWriterClick}
                      />
                      <label className="statis-name1 " htmlFor="writer">
                        Writer
                      </label>
                    </div>
                  )}
                  {checkboxes.reviewer && (
                    <div className=" ">
                      <input
                        type="checkbox"
                        id="reviewer"
                        checked={checkboxes.reviewer}
                        onClick={handleReviewerClick}
                      />
                      <label className="statis-name1" htmlFor="reviewer">
                        Reviewer
                      </label>
                    </div>
                  )}
                  {checkboxes.statistican && (
                    <div className=" ">
                      <input
                        type="checkbox"
                        id="vendor"
                        checked={checkboxes.statistican}
                        onClick={handleStatisticanClick}
                      />
                      <label className="statis-name1" htmlFor="vendor">
                        Statistican
                      </label>
                    </div>
                  )}
                  {checkboxes.journal && (
                    <div className="">
                      <input
                        type="checkbox"
                        id="jounel"
                        checked={checkboxes.journal}
                        onClick={handleJournalClick}
                      />
                      <label className="statis-name1" htmlFor="jounel">
                        Journal{" "}
                      </label>
                    </div>
                  )}
                </div> */}

              {showWriter && (
                <div className="row pt-2 px-3">
                  <div className="col-12 col-md-4">
                    <label className="statis-name"> Writer Name</label>
                    <select
                      className="form-control1"
                      name="writer"
                      value={formData.writer}
                      disabled={isReadOnly}
                    >
                      <option value="" disabled selected>
                        Select writer
                      </option>
                      {writter.map((writer, index) => (
                        <option key={writer.id} value={writer.id}>
                          {/* {writer.name} */}
                          {writer.name.charAt(0).toUpperCase() + writer.name.slice(1)}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-12 col-md-4">

                    <label className="statis-name"> Writer Payment</label>
                    <input
                      type="number"
                      className="form-control mt-2"
                      name="writer_payment"
                      value={formData.writer_payment}
                      // onChange={handleFormChange}
                      onChange={(e) => {
                        handleFormChange(e);

                        // Clear validation error for payment_status
                        if (errors.writer_payment) {
                          setErrors((prevErrors) => {
                            const updatedErrors = { ...prevErrors };
                            delete updatedErrors.writer_payment;
                            return updatedErrors;
                          });
                        }
                      }}
                    />
                  </div>
                  <div className="col-12 col-md-4">
                    <label className="statis-name">
                      {" "}
                      Writer Payment Date
                    </label>
                    <input
                      type="date"
                      className="form-control mt-2"
                      id="dateInput"
                      name="writer_payment_date"
                      value={formData.writer_payment_date}
                      onChange={handleFormChange}
                    // onChange={(e) => setDate(e.target.value)}
                    />
                  </div>
                </div>
              )}
              {showReviewer && (
                <div className="row pt-2 px-3">
                  <div className="col-12 col-md-4">
                    <label className="statis-name"> Reviewer Name</label>
                    <select
                      className="form-control1"
                      name="writer"
                      value={formData.reviewer || ""}
                      disabled={isReadOnly}
                    >
                      <option value="" disabled selected>
                        Select reviewer
                      </option>
                      {reviewer.map((writer, index) => (
                        <option key={writer.id} value={writer.id}>
                          {/* {writer.name} */}
                          {writer.name.charAt(0).toUpperCase() + writer.name.slice(1)}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-12 col-md-4">
                    <label className="statis-name"> Reviewer Payment</label>
                    <input
                      type="number"
                      className="form-control mt-2"
                      name="reviewer_payment"
                      value={formData.reviewer_payment}
                      // onChange={handleFormChange}
                      onChange={(e) => {
                        handleFormChange(e);

                        // Clear validation error for payment_status
                        if (errors.reviewer_payment) {
                          setErrors((prevErrors) => {
                            const updatedErrors = { ...prevErrors };
                            delete updatedErrors.reviewer_payment;
                            return updatedErrors;
                          });
                        }
                      }}
                    />
                  </div>
                  <div className="col-12 col-md-4">
                    <label className="statis-name">
                      Reviewer Payment Date
                    </label>
                    <input
                      type="date"
                      className="form-control mt-2"
                      id="dateInput"
                      name="reviewer_payment_date"
                      value={formData.reviewer_payment_date}
                      onChange={handleFormChange}
                    />
                  </div>
                </div>
              )}
              {showVendor && (
                <div className="row pt-2 px-3">
                  <div className="col-12 col-md-4">
                    <label className="statis-name">Statistican Name</label>
                    <select
                      className="form-control1"
                      name="writer"
                      value={formData.statistican || ""}
                      disabled={isReadOnly}
                    >
                      <option value="" disabled selected>
                        Select statistican
                      </option>
                      {statistical.map((writer, index) => (
                        <option key={writer.id} value={writer.id}>
                          {/* {writer.name} */}
                          {writer.name.charAt(0).toUpperCase() + writer.name.slice(1)}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-12 col-md-4">
                    <label className="statis-name">Statistican Payment</label>
                    <input
                      type="number"
                      className="form-control mt-2"
                      name="statistican_payment"
                      value={formData.statistican_payment}
                      // onChange={handleFormChange}
                      onChange={(e) => {
                        handleFormChange(e);

                        // Clear validation error for payment_status
                        if (errors.statistican_payment) {
                          setErrors((prevErrors) => {
                            const updatedErrors = { ...prevErrors };
                            delete updatedErrors.statistican_payment;
                            return updatedErrors;
                          });
                        }
                      }}
                    />
                  </div>
                  <div className="col-12 col-md-4">
                    <label className="statis-name">
                      Statistican Payment Date
                    </label>
                    <input
                      type="date"
                      className="form-control mt-2"
                      id="dateInput"
                      name="statistican_payment_date"
                      value={formData.statistican_payment_date}
                      onChange={handleFormChange}
                    />
                  </div>
                </div>
              )}
              {showjournal && (
                <div className="row pt-2 px-3">
                  <div className="col-12 col-md-4">
                    <label className="statis-name">Journal Name</label>
                    <select
                      className="form-control1"
                      name="writer"
                      value={formData.journal || ""}
                      disabled={isReadOnly}
                    >
                      <option value="" disabled selected>
                        Select journal
                      </option>
                      {journal.map((writer, index) => (
                        <option key={writer.id} value={writer.id}>
                          {/* {writer.name} */}
                          {writer.name.charAt(0).toUpperCase() + writer.name.slice(1)}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-12 col-md-4">
                    <label className="statis-name">Journal</label>
                    <input
                      type="number"
                      className="form-control mt-2"
                      name="journal_payment"
                      value={formData.journal_payment}
                      // onChange={handleFormChange}
                      onChange={(e) => {
                        handleFormChange(e);

                        // Clear validation error for payment_status
                        if (errors.journal_payment) {
                          setErrors((prevErrors) => {
                            const updatedErrors = { ...prevErrors };
                            delete updatedErrors.journal_payment;
                            return updatedErrors;
                          });
                        }
                      }}
                    />
                  </div>
                  <div className="col-12 col-md-4">
                    <label className="statis-name">Jounel Payment Date</label>
                    <input
                      type="date"
                      className="form-control mt-2"
                      id="dateInput"
                      name="journal_payment_date"
                      value={formData.journal_payment_date}
                      onChange={handleFormChange}
                    />
                  </div>
                </div>
              )}

              <div className="col-12  d-flex justify-content-end py-5 px-1 gap-3   ">
                <Link to="/entry-process">
                  <button type="submit" className="save-form">
                    Back
                  </button>
                </Link>
                <button
                  onClick={handleSubmit}
                  type="submit"
                  className="save-form-save"
                >
                  Update
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Payment_form;
