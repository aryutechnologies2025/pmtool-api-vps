import React, { useState, useEffect, useCallback } from "react";
import "../assests/css/payment_form.css";
import Sider from "../components/Sider";
import Header from "../components/Header.js";
import { Link } from "react-router-dom";
import Breadcrumbs from "../routes/Breadcrumbs.js";
import axios from "axios";
import { API_URL } from "../config.js";
import { useNavigate } from "react-router-dom";
import { Capitalize } from "../campsCase.js";
import { PiCloudArrowUpLight } from "react-icons/pi";
import { RiDeleteBin6Line } from "react-icons/ri";
import { useRef } from "react";
import Loader from "../components/Loader.js";
import Swal from "sweetalert2";
import Select from "react-select";

function Payment_form() {
  const navigate = useNavigate();

  const [showFields, setShowFields] = useState(false);
  const [showWriter, setShowWriter] = useState(false);
  const [showReviewer, setShowReviewer] = useState(false);
  const [showVendor, setShowVendor] = useState(false);
  const [showjournal, setShowJournal] = useState(false);

  const handleWriterClick = () => {
    setShowWriter(!showWriter);
  };

  const handleReviewerClick = () => {
    setShowReviewer(!showReviewer);
  };

  const handleStatisticanClick = () => {
    setShowVendor(!showVendor);
  };

  const handleJournalClick = () => {
    setShowJournal(!showjournal);
  };

  const [date, setDate] = useState("");

  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  useEffect(() => {
    setDate(getTodayDate());
  }, []);

  const [paymentFields, setPaymentFields] = useState([
    { amount: "", date: "" },
  ]);

  const validateFormFiles = () => {
    const validationErrors = {};

    // Validate payment fields
    paymentFields.forEach((paymentField, index) => {
      if (!paymentField.amount) {
        validationErrors[`amount_${index}`] = "Amount is required";
      }
      if (!paymentField.date) {
        validationErrors[`date_${index}`] = "Date is required";
      }
    });

    return validationErrors;
  };
  const handleAddField = () => {
    const validationErrors = validateFormFiles();

    if (Object.keys(validationErrors).length === 0) {
      setPaymentFields((prevPaymentFields) => [
        ...prevPaymentFields,
        { amount: "", date: "" },
      ]);
    } else {
      setErrors(validationErrors);
    }
  };

  const handleRemoveField = (index) => {
    setPaymentFields(paymentFields.filter((_, i) => i !== index));
  };


  const handleChange = (index, field, value) => {
    const updatedFields = [...paymentFields];
    updatedFields[index][field] = value;
    setPaymentFields(updatedFields);
  };

  const handleFileChange = useCallback((e) => {
    const file = e.target.files[0];
    setFormData((prevData) => ({
      ...prevData,
      file, // Update file in formData
    }));
  }, []);

  const fileInputRef = useRef(null);
  const handleFileDelete = useCallback(() => {
    setFormData((prevData) => ({
      ...prevData,
      file: null, // Clear file from formData
    }));

    // Clear validation error for reference_number
    setErrors((prevErrors) => {
      const updatedErrors = { ...prevErrors };
      delete updatedErrors.reference_number;
      return updatedErrors;
    });

    // Reset the file input field using the ref
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  }, []);

  const [projectTitles, setProjectTitles] = useState([]);
  const [projectTitleVal, setProjecttile] = useState([]);
  const [projectBudget, setBudget] = useState([]);
  const [projectId, setProjectId] = useState([]);
  const [clientname, setClientname] = useState("");
  const [profession, setProfession] = useState("");
  const [department, setDepartment] = useState("");
  const [institute, setInstitution] = useState("");


  const [isReadOnly, setIsReadOnly] = React.useState(true);

  const [checkboxes, setCheckboxes] = useState({
    writer: false,
    reviewer: false,
    statistican: false,
    journal: false,
  });

  const handlefetchDetails = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/projecttitle`
      );

      if (response.status === 200) {
        const projectTitleArray = response.data;
        setProjectTitles(projectTitleArray);
      } else {
        console.error("Error fetching project titles:", response.statusText);
      }
    } catch (error) {
      console.error("Submission error:", error);
    }
  };

  const handleSelectChange = async (selectedOption) => {
    if (!selectedOption) return;

    const selectedId = selectedOption.value; // Correct way to access value

    setProjecttile(selectedId);
    setFormData((prevState) => ({
      ...prevState,
      projectTitleVal: selectedId,
    }));

    if (selectedId) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        projectTitleVal: "",
      }));
    }

    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/project-view-data/${selectedId}`
      );

      if (response.status === 200) {
        setBudget(response.data.budget || "-");
        setProjectId(response.data.project_id);
        setClientname(response.data?.client_name || "-");
        setInstitution(response.data?.institute?.name);
        setDepartment(response.data?.department?.name);
        setProfession(response.data?.profession?.name);
        console.log(response.data.project_id);
        
        const fetchData = response.data;
        const writerData = fetchData.writer_data || [];

        // Filter writers who are freelancers
        const freelancerWriterData = writerData.filter(user => user.user_date.employee_type === 'freelancers');

        const writerStatusDetails = freelancerWriterData.map((user, index) => {
          return {
            writerName: user.assign_user || "",
            paymentAmount: "",
            paymentDate: "",
            paymentStatus: "",
          };
        });

        const reviewerData = fetchData.reviewer_data || [];

        
        // Filter writers who are freelancers
        const freelancerReviewerData = reviewerData.filter(user => user.user_date.employee_type === 'freelancers');


        const reviewerStatusDetails = freelancerReviewerData.map((user, index) => {
          return {
            reviewerName: user.assign_user || "",
            reviewerPayment: "",
            reviewerPaymentDate: "",
            reviewerPaymentStatus: "",
          };
        });

        const statisticanData = fetchData.statistican_data || [];


        const freelancerStatisticanData = statisticanData.filter(user => user.user_date.employee_type === 'freelancers');


        const statisticanStatusDetails = freelancerStatisticanData.map((user, index) => {
          return {
            statisticanName: user.assign_user || "",
            statisticanPayment: "",
            statisticanPaymentDate: "",
            statisticanPaymentStatus: "",
          };
        });

        setWriterDetails(writerStatusDetails);
        setReviewerDetails(reviewerStatusDetails);
        setStatisticanDetails(statisticanStatusDetails);

      }
    } catch (error) {
      console.error("Error fetching details:", error);
    }
  };

  useEffect(() => {
    handlefetchDetails(); // Fetch data on component mount
  }, []);

  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    projectTitleVal: "",
    amount: "",
    payment_status: "",
    writer: "",
    reviewer: "",
    statistican: "",
    journal: "",
    discount: "",
    writer_payment: "",
    writer_payment_date: getTodayDate() || "",
    reviewer_payment: "",
    reviewer_payment_date: getTodayDate() || "",
    statistican_payment: "",
    statistican_payment_date: getTodayDate() || "",
    journal_payment: "",
    journal_payment_date: getTodayDate() || "",
    reference_number: "", // Add reference_number
    file: null, // Add file
    writer_payment_status: "",
    reviwer_payment_status: "",
    statistican_payment_status: "",
    journal_payment_status: "",
  });

  const validateForm = () => {
    let formErrors = {};
    let isValid = true;

    // Check for required fields
    if (!formData.projectTitleVal) {
      formErrors.projectTitleVal = "Project title is required.";
      isValid = false;
    }
    if (!paymentFields.some((field) => field.amount)) {
      formErrors.amount = "Amount is required.";
      isValid = false;
    }
    paymentFields.forEach((paymentField, index) => {
      if (!paymentField.amount || paymentField.amount <= 0) {
        formErrors[`amount_${index}`] = "Amount must be greater than 0";
      }

      if (!paymentField.date) {
        formErrors[`date_${index}`] = "Date is required";
      }
    });

    if (!formData.payment_status) {
      formErrors.payment_status = "Payment status is required.";
      isValid = false;
    }

    // Validate reference_number or file
    if (formData.payment_status !== 'advance_pending') {
      if (!formData.reference_number && !formData.file) {
        formErrors.reference_number =
          "Please add a reference number or upload a screenshot.";
        isValid = false;
      }
    }

    setErrors(formErrors);
    return isValid;
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleReviewerChange = (e, index) => {
    const { name, value } = e.target;
    const updatedDetails = [...reviewerDetails];
    updatedDetails[index] = {
      ...updatedDetails[index],
      [name]: value,
    };
    setReviewerDetails(updatedDetails);
  };
  const handleWriterChange = (e, index) => {
    const { name, value } = e.target;
    const updatedDetails = [...writerDetails];
    updatedDetails[index] = {
      ...updatedDetails[index],
      [name]: value,
    };
    setWriterDetails(updatedDetails);
  };

  const handleStatisticanChange = (e, index) => {
    const { name, value } = e.target;
    const updatedDetails = [...statisticanDetails];
    updatedDetails[index] = {
      ...updatedDetails[index],
      [name]: value,
    };
    setStatisticanDetails(updatedDetails);
  };

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();

    if (!isValid) {
      return;
    }

    // Map state values to backend keys

    const formattedWriterDatas = writerDetails.some(writer => writer.writerName)
      ? writerDetails.map(writer => ({
        writerName: writer.writerName || "",
        paymentAmount: writer.paymentAmount || "",
        paymentDate: writer.paymentDate,
        paymentStatus: writer.paymentStatus || "",
      }))
      : [];

    const formattedReviewerDatas = reviewerDetails.some(writer => writer.reviewerName)
      ? reviewerDetails.map(writer => ({
        reviewerName: writer.reviewerName || "",
        reviewerPayment: writer.reviewerPayment || "",
        reviewerPaymentDate: writer.reviewerPaymentDate,
        reviewerPaymentStatus: writer.reviewerPaymentStatus || "",
      }))
      : [];

    const formattedstatisDatas = statisticanDetails.some(writer => writer.statisticanName)
      ? statisticanDetails.map(writer => ({
        statisticanName: writer.statisticanName || "",
        statisticanPayment: writer.statisticanPayment || "",
        statisticanPaymentDate: writer.statisticanPaymentDate,
        statisticanPaymentStatus: writer.statisticanPaymentStatus || "",
      }))
      : [];

    const backendFormData = {
      project_id: projectTitleVal,
      payment_status: formData.payment_status,
      reference_number: formData.reference_number,
      reference_number_file: formData.file,
      created_by: createdby,
      payment_details: paymentFields,
      discount: formData.discount,
      writerPay: formattedWriterDatas,
      reviewerPay: formattedReviewerDatas,
      statisticanPay: formattedstatisDatas
    };

    document.getElementById("global-loader").style.display = "flex";
    setTimeout(async () => {
      try {
        const response = await axios.post(
          `${API_URL}/api/payment_processes/payments`,
          backendFormData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );

        if (response.status === 200 || response.status === 201) {
          Swal.fire({
            title: "Success!",
            text: "Payment added successfully.",
            icon: "success",
            confirmButtonText: "OK",
          })
          navigate("/entry-process");
        } else {
          console.error("Error occurred:", response.statusText);
        }
      } catch (error) {
        Swal.fire({
          title: "Error!",
          text: "Something went wrong while added payment.",
          icon: "error",
          confirmButtonText: "OK",
        });
      } finally {
        document.getElementById("global-loader").style.display = "none";
      }
    }, 500);
  };

  const currentDate = new Date().toISOString().split("T")[0];

  const [writter, setWritter] = useState([]);
  const [reviewer, setReviewer] = useState([]);
  const [statistical, setStatistical] = useState([]);
  const [journal, setJournal] = useState([]);

  //multiple user

  const [writerDetails, setWriterDetails] = useState([
    {
      writerName: "",
      paymentAmount: "",
      paymentDate: "",
      paymentStatus: "",
    }
  ]);

  const [reviewerDetails, setReviewerDetails] = useState([
    {
      reviewerName: "",
      reviewerPayment: "",
      reviewerPaymentDate: "",
      reviewerPaymentStatus: "",
    }
  ]);

  const [statisticanDetails, setStatisticanDetails] = useState([
    {
      statisticanName: "",
      statisticanPayment: "",
      statisticanPaymentDate: "",
      statisticanPaymentStatus: "",
    }
  ]);

  useEffect(() => {
    // Fetch data from the API when the component mounts
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${API_URL}/api/entry_process/getEmployeeName`
        );
        const data = response.data;

        // Update the state with the received data
        if (data) {
          setWritter(data.writer || []);
          setReviewer(data.reviewer || []);
          setStatistical(data.statistican || []);
          setJournal(data.journal || []);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const options = projectTitles.map((project) => ({
    value: project.id,
    label: project.project_id,
  }));

  return (
    <>
      <section className="container">
        <div className=" row mt-4 ">
          {/* <div className=" col-1 d-flex justify-content-center">
            <Sider></Sider>
          </div> */}
          <div className="col-12  ">
            <div className="col-12">
              <Header></Header>
            </div>

            <div className="col-11  pt-1 wapper w-100 mt-3 ">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className=" col-12 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>

              <form>
                <div className="row w-100 mt-2 pt-3   px-3 ">
                  <div className="col-12 col-md ">
                    <label className="statis-name">Project ID</label>
                    <Select
                      options={options}
                      onChange={handleSelectChange}
                      placeholder="Select Payment Title"
                      isSearchable
                    />
                  </div>
                  <div className="col-12 col-md">
                    <label className="statis-name">Budget</label>
                    <input
                      type="text"
                      className="form-control1 px-2"
                      placeholder="Enter Project ID"
                      readOnly={isReadOnly}
                      value={projectBudget}
                      onChange={(e) => setBudget(e.target.value)}
                    />
                  </div>
                  <div className="col-12 col-md">
                    <label className="statis-name">client Name</label>
                    <input
                      type="text"
                      className="form-control1 px-2"
                      placeholder="Enter client name"
                      readOnly={isReadOnly}
                      value={clientname}
                      onChange={(e) => setProjectId(e.target.value)}
                    />
                  </div>

                  <div className="col-12 col-md">
                    <label className="statis-name">Institute</label>
                    <input
                      type="text"
                      className="form-control1 px-2"
                      placeholder="Enter institute"
                      readOnly={isReadOnly}
                      value={institute}
                      onChange={(e) => setProjectId(e.target.value)}
                    />
                  </div>
                  <div className="col-12 col-md">
                    <label className="statis-name">Department</label>
                    <input
                      type="text"
                      className="form-control1 px-2"
                      placeholder="Enter department"
                      readOnly={isReadOnly}
                      value={department}
                      onChange={(e) => setProjectId(e.target.value)}
                    />
                  </div>
                  <div className="col-12 col-md">
                    <label className="statis-name">Profession</label>
                    <input
                      type="text"
                      className="form-control1 px-2"
                      placeholder="Enter profession"
                      readOnly={isReadOnly}
                      value={profession}
                      onChange={(e) => setProjectId(e.target.value)}
                    />
                  </div>
                </div>
                <div className="row mt-2 pt-2 px-3">
                  {paymentFields.map((field, index) => (
                    <div key={index} className="row mt-2 align-items-center">
                      <div className="col-12 col-md-3">
                        <label className="statis-name">{`Payment ${index + 1
                          }`}</label>
                        <input
                          type="number"
                          className={`form-control ${errors[`amount_${index}`] ? "error" : ""
                            }`}
                          value={field.amount}
                          onChange={(e) => {
                            handleChange(index, "amount", e.target.value);
                            if (errors[`amount_${index}`]) {
                              setErrors((prevErrors) => {
                                const updatedErrors = { ...prevErrors };
                                delete updatedErrors[`amount_${index}`];
                                return updatedErrors;
                              });
                            }
                          }}
                        />
                      </div>

                      <div className="col-12 col-md-3">
                        <label className="statis-name">Payment Date</label>
                        <input
                          type="date"
                          className={`form-control ${errors[`date_${index}`] ? "error" : ""
                            }`}
                          value={field.date}
                          onChange={(e) => {
                            handleChange(index, "date", e.target.value);
                            if (errors[`date_${index}`]) {
                              setErrors((prevErrors) => {
                                const updatedErrors = { ...prevErrors };
                                delete updatedErrors[`date_${index}`];
                                return updatedErrors;
                              });
                            }
                          }}
                        />
                      </div>
                      {index === 0 && (
                        <div className="col-12 col-md-3 d-flex justify-content-start align-items-center mt-4">
                          <button
                            type="button"
                            className="save-form-add mt-1"
                            onClick={handleAddField}
                          >
                            Add +
                          </button>
                        </div>
                      )}
                      {index > 0 && (
                        <div className="col-12 col-md-3 d-flex justify-content-start align-items-center mt-4">
                          <button
                            type="button"
                            className="save-form-del mt-1"
                            onClick={() => handleRemoveField(index)}
                          >
                            Delete
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                <div className="row mt-2 pt-2 px-3">
                  <div className="col-12 col-md-3 px-3  col-md">
                    <label className="statis-name">Payment Status</label>
                    <select
                      className={`form-select ${errors.payment_status ? "error" : ""
                        }`}
                      name="payment_status"
                      onChange={(e) => {
                        handleFormChange(e);
                        if (errors.payment_status) {
                          setErrors((prevErrors) => {
                            const updatedErrors = { ...prevErrors };
                            delete updatedErrors.payment_status;
                            return updatedErrors;
                          });
                        }
                      }}
                      value={formData.payment_status}
                    >
                      <option value="" disabled selected>
                        Payment Status
                      </option>
                      <option value="completed">Completed</option>
                      <option value="advance_pending">Advance Pending</option>
                      <option value="partial_payment_pending">
                        Partial payment pending
                      </option>
                      <option value="payment_pending">Payment pending</option>
                    </select>
                  </div>

                  <div className="col-12 col-md-3">
                    <label className="statis-name">Discounts</label>
                    <input
                      type="text"
                      className={`form-control`}
                      name="discount"
                      value={formData.discount}
                      onChange={(e) => {
                        handleFormChange(e);

                      }}
                    />
                  </div>

                  <div className="col-12 col-md-3 px-2 mt-0 col-md ">
                    <label className="statis-name">
                      Payment Reference Number
                    </label>
                    <input
                      type="text"
                      className={`form-control ${errors.reference_number ? "is-invalid" : ""
                        }`}
                      name="reference_number"
                      value={formData.reference_number}
                      onChange={(e) => {
                        handleFormChange(e);
                        if (errors.reference_number) {
                          setErrors((prevErrors) => {
                            const updatedErrors = { ...prevErrors };
                            delete updatedErrors.reference_number;
                            return updatedErrors;
                          });
                        }
                      }}
                    />
                  </div>
                  <div className="col-auto pt-4 text-center">
                    <div className="or-divider mt-2">(or)</div>
                  </div>
                  <div className="col-12 col-md-3 ">
                    <label className="statis-name">File</label>
                    <div className={`form-control d-flex justify-content-end`}>
                      <input
                        type="file"
                        accept="file/*"
                        ref={fileInputRef}
                        className={`file-upload-input ${errors.reference_number ? "is-invalid" : ""
                          }`}
                        // onChange={(e) => handleFileChange(index, e)}
                        onChange={(e) => {
                          handleFileChange(e);
                          // Clear validation error for reference_number if file is uploaded
                          if (errors.reference_number) {
                            setErrors((prevErrors) => {
                              const updatedErrors = { ...prevErrors };
                              delete updatedErrors.reference_number;
                              return updatedErrors;
                            });
                          }
                        }}
                      />
                      {formData.file && (
                        <RiDeleteBin6Line
                          className="file-del-icon"
                          onClick={handleFileDelete}
                        />
                      )}
                      {!formData.file && (
                        <label className="file-icon">
                          <PiCloudArrowUpLight />
                        </label>
                      )}
                    </div>
                    {errors.reference_number && (
                      <div className="invalid-feedback">
                        {errors.reference_number}
                      </div>
                    )}
                  </div>
                  {errors.reference_number && (
                    <span className="error-text d-flex justify-content-center p-0 m-0">
                      {errors.reference_number}
                    </span>
                  )}
                </div>

                {writerDetails.filter(writer => writer.writerName).length > 0 &&
                  writerDetails
                    .filter(writer => writer.writerName) // Filter only non-empty writerName
                    .map((writer, index) => (
                      <div className="row pt-2 px-3 ">
                        <div className="col-12 col-md-3">
                          <label className="statis-name">Writer Name</label>
                          <select
                            className="form-control2"
                            name="writerName"
                            value={writer.writerName}
                            disabled={isReadOnly}
                          >
                            <option value="" disabled selected>
                              Select writer
                            </option>
                            {writter.map((writer, index) => (
                              <option key={writer.id} value={writer.id}>
                                {/* {writer.name} */}
                                {writer.name.charAt(0).toUpperCase() +
                                  writer.name.slice(1)}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="col-12 col-md-3">
                          <label className="statis-name"> Writer Payment</label>
                          <input
                            type="number"
                            className={`form-control`}
                            name="paymentAmount"
                            value={writer.paymentAmount}
                            onChange={(e) => handleWriterChange(e, index)}
                          />
                        </div>
                        <div className="col-12 col-md-3">
                          <label className="statis-name">
                            {" "}
                            Writer Payment Date
                          </label>
                          <input
                            type="date"
                            className="form-control "
                            id="dateInput"
                            name="paymentDate"
                            value={writer.paymentDate}
                            onChange={(e) => handleWriterChange(e, index)}
                          />
                        </div>
                        <div className="col-12 col-md-3">
                          <label className="statis-name">Payment Status</label>
                          <select
                            className={`form-select`}
                            name="paymentStatus"
                            onChange={(e) => handleWriterChange(e, index)}
                            value={writer.paymentStatus}
                          >
                            <option value="" disabled selected>
                              Payment Status
                            </option>
                            <option value="pending">Pending Payment</option>
                            <option value="paid">Paid Payemnt</option>
                          </select>
                        </div>
                      </div>
                    ))}
                {reviewerDetails.filter(user => user.reviewerName).length > 0 &&
                  reviewerDetails
                    .filter(user => user.reviewerName) // Filter only non-empty writerName
                    .map((user, index) => (
                      <div className="row pt-2 px-3">
                        <div className="col-12 col-md-3">
                          <label className="statis-name"> Reviewer Name</label>
                          <select
                            className="form-control2"
                            name="reviewerName"
                            value={user.reviewerName || ""}
                            disabled={isReadOnly}
                          >
                            <option value="" disabled selected>
                              Select reviewer
                            </option>
                            {reviewer.map((writer, index) => (
                              <option key={writer.id} value={writer.id}>
                                {/* {writer.name} */}
                                {writer.name.charAt(0).toUpperCase() +
                                  writer.name.slice(1)}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="col-12 col-md-3">
                          <label className="statis-name"> Reviewer Payment</label>
                          <input
                            type="number"
                            className={`form-control`}
                            name="reviewerPayment"
                            value={user.reviewerPayment}
                            onChange={(e) => handleReviewerChange(e, index)}
                          />
                        </div>
                        <div className="col-12 col-md-3">
                          <label className="statis-name">
                            Reviewer Payment Date
                          </label>
                          <input
                            type="date"
                            className="form-control "
                            id="dateInput"
                            name="reviewerPaymentDate"
                            value={user.reviewerPaymentDate}
                            onChange={(e) => handleReviewerChange(e, index)}
                          />
                        </div>
                        <div className="col-12 col-md-3">
                          <label className="statis-name">Payment Status</label>
                          <select
                            className={`form-select`}
                            name="reviewerPaymentStatus"
                            onChange={(e) => handleReviewerChange(e, index)}
                            value={user.reviewerPaymentStatus}
                          >
                            <option value="" disabled selected>
                              Payment Status
                            </option>
                            <option value="pending">Pending Payment</option>
                            <option value="paid">Paid Payemnt</option>
                          </select>
                        </div>
                      </div>
                    ))}
                {statisticanDetails.filter(user => user.statisticanName).length > 0 &&
                  reviewerDetails
                    .filter(user => user.statisticanName) // Filter only non-empty writerName
                    .map((user, index) => (
                      <div className="row pt-2 px-3">
                        <div className="col-12 col-md-3">
                          <label className="statis-name">Statistican Name</label>
                          <select
                            className="form-control2"
                            name="statisticanName"
                            value={user.statisticanName || ""}
                            disabled={isReadOnly}
                            autoComplete="off"
                          >
                            <option value="" disabled selected>
                              Select statistican
                            </option>
                            {statistical.map((writer, index) => (
                              <option key={writer.id} value={writer.id}>
                                {/* {writer.name} */}
                                {writer.name.charAt(0).toUpperCase() +
                                  writer.name.slice(1)}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="col-12 col-md-3">
                          <label className="statis-name">Statistican Payment</label>
                          <input
                            type="number"
                            className={`form-control`}
                            name="statisticanPayment"
                            value={user.statisticanPayment}
                            onChange={(e) => handleStatisticanChange(e, index)}
                          />
                        </div>
                        <div className="col-12 col-md-3">
                          <label className="statis-name">
                            Statistican Payment Date
                          </label>
                          <input
                            type="date"
                            className="form-control "
                            id="dateInput"
                            name="statisticanPaymentDate"
                            value={user.statisticanPaymentDate}
                            onChange={(e) => handleStatisticanChange(e, index)}
                          />
                        </div>
                        <div className="col-12 col-md-3">
                          <label className="statis-name">Payment Status</label>
                          <select
                            className={`form-select`}
                            name="statisticanPaymentStatus"
                            onChange={(e) => handleStatisticanChange(e, index)}
                            value={user.statisticanPaymentStatus}
                          >
                            <option value="" disabled selected>
                              Payment Status
                            </option>
                            <option value="pending">Pending Payment</option>
                            <option value="paid">Paid Payemnt</option>
                          </select>
                        </div>
                      </div>
                    ))}
                <div className="col-12  d-flex justify-content-end py-5 px-1 gap-3   ">
                  <Link to="/entry-process">
                    <button type="submit" className="save-form">
                      Back
                    </button>
                  </Link>
                  <button
                    onClick={handleSubmit}
                    type="submit"
                    className="save-form-save"
                  >
                    Save
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Payment_form;