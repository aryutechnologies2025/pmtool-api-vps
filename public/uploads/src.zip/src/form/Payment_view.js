

import React, { useState, useEffect } from "react";
import Header from "../components/Header.js";
import Breadcrumbs from "../routes/Breadcrumbs";
import Footer from "../components/Footer";
import axios from "axios";
import { useLocation } from "react-router-dom";
import { API_URL } from "../config.js";
import { Link } from "react-router-dom";

function Payment_view() {
  const location = useLocation();
  const rowId = location.state?.rowId || null;

  const [showDatas, setShowData] = useState({});
  const [isReadOnly, setIsReadOnly] = useState(true);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (rowId) {
      fetchShowData(rowId);
    } else {
      setError("No row ID provided.");
      setLoading(false);
    }
  }, [rowId]);

  const fetchShowData = async (id) => {
    try {
      setLoading(true);
      const responseShow = await axios.get(
        `${API_URL}/api/payment_processes/view/${id}`
      );
      setShowData(responseShow.data);
    } catch (err) {
      console.error("Error fetching data", err);
      setError("Failed to fetch payment details. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const toggleEdit = () => setIsReadOnly((prev) => !prev);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  const {
    payment_data,
    payment_status,
    writer_payment,
    writer_payment_date,
    reviewer_payment,
    reviewer_payment_date,
    statistican_payment,
    statistican_payment_date,
    journal_payment,
    journal_payment_date,
  } = showDatas;
  

  return (
    <>
      
      <section className="container">
        <div className="row mt-4">
          <div className="col-12">
            <Header />
          </div>

          <div className="col-11 mt-3 wapper w-100 pb-5">
            <div className="pt-2 px-2 d-none d-md-block">
              <Breadcrumbs />
            </div>

            <div className="row ">
              <div className="col-md-4 float-start pt-2">
                <label className="statis-name">Project Title</label>
                <input
                  type="text"
                  className="form-control1"
                  value={showDatas?.project_data?.title || ""}
                  readOnly={isReadOnly}
                />
              </div>
              <div className="col-md-4 float-start pt-2">
                <label className="statis-name">Budget</label>
                <input
                  type="text"
                  className="form-control1"
                  value={showDatas?.project_data?.budget || ""}
                  readOnly={isReadOnly}
                />
              </div>
              <div className="col-md-4 float-start pt-2">
                <label className="statis-name">Project ID</label>
                <input
                  type="text"
                  className="form-control1"
                  value={showDatas?.project_data?.project_id || ""}
                  readOnly={isReadOnly}
                />
              </div>

              {/* Payment Data */}
              {payment_data?.length > 0 ? (
                payment_data.map((payment, index) => (
                  <div className="row mt-2" key={payment.id}>
                    <div className="col-md-4">
                      <label className="statis-name ">
                        Payment {index + 1}
                      </label>
                      <input
                        type="text"
                        className="form-control1"
                        value={payment.payment || ""}
                        readOnly={isReadOnly}
                      />
                    </div>
                    <div className="col-md-4">
                      <label className="statis-name">
                        Payment Date {index + 1}
                      </label>
                      <input
                        type="text"
                        className="form-control1"
                        value={payment.payment_date || ""}
                        readOnly={isReadOnly}
                      />
                    </div>
                  </div>
                ))
              ) : (
                <p>No payment data available</p>
              )}

              <div className="row">
                <div className="col-md-4 float-start pt-3">
                  <label className="statis-name">Payment Status</label>
                  <input
                    type="text"
                    className="form-control1"
                    value={payment_status || ""}
                    readOnly={isReadOnly}
                  />
                </div>
              </div>

              {/* Payment Details */}
              {[
                {
                  label1: "Writer Name",
                  label: "Writer Payment",
                  value: writer_payment,
                  value: writer_payment,
                  date: writer_payment_date,
                  writername: showDatas?.project_data?.writer.employee_name
                },
                {
                  label1: "Reviewer Name",
                  label: "Reviewer Payment",
                  value: reviewer_payment,
                  date: reviewer_payment_date,
                  writername: showDatas?.project_data?.reviewer.employee_name
                },
                {
                  label1: "Statistican Name",
                  label: "Statistican Payment",
                  value: statistican_payment,
                  date: statistican_payment_date,
                  writername: showDatas?.project_data?.statistican.employee_name
                },
                {
                  label1: "Journal Name",
                  label: "Journal Payment",
                  value: journal_payment,
                  date: journal_payment_date,
                  writername: showDatas?.project_data?.journal.employee_name
                },
              ].map((item, index) => (
                <div className="row mt-2" key={index}>
                   <div className="col-md-4">
                    <label className="statis-name">{item.label1}</label>
                    <input
                      type="text"
                      className="form-control1"
                      value={item.writername || ""} 
                      readOnly={isReadOnly}
                    />
                  </div>
                  <div className="col-md-4">
                    <label className="statis-name">{item.label}</label>
                    <input
                      type="text"
                      className="form-control1"
                      value={item.value || ""}
                      readOnly={isReadOnly}
                    />
                  </div>
                  <div className="col-md-4">
                    <label className="statis-name">{item.label} Date</label>
                    <input
                      type="text"
                      className="form-control1"
                      value={item.date || ""}
                      readOnly={isReadOnly}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="col-12 d-flex justify-content-end mt-5">
              <Link to="/paymentstatus">
                <button type="submit" className="save-form">
                  Back
                </button>
              </Link>
            </div>
          </div>
        </div>

        <Footer />
      </section>
    </>
  );
}

export default Payment_view;
