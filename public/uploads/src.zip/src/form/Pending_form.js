import React, { useState, useEffect } from "react";
import "../assests/css/payment_form.css";
import Sider from "../components/Sider";
import Header from "../components/Header.js";
import { Link } from "react-router-dom";
import Breadcrumbs from "../routes/Breadcrumbs.js";
import { useLocation } from 'react-router-dom';
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import axios from "axios";

function Pending_form() {
  const location = useLocation();

  const { rowId } = location.state || {};
 useEffect(() => {
    fetchPendingData();
  }, []);

  const [pendingData, setPendingData] = useState([]);

  const fetchPendingData = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/entry_process/getPendingList/${rowId}`);

      const responsedata = response.data.data

      setPendingData(responsedata);

    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const [formData, setFormData] = useState({
    myFee: "",

    writerPendingDays: "",
    reviewerPendingDays: "",
    projectPendingDays: "",
    writerDueDate: getTodayDate() || "",
    reviewerDueDate: getTodayDate() || "",
  });

  // State to store validation errors
  const [errors, setErrors] = useState({});

  // Handle input changes
  const handleChangepending = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // Validate form before submission
  const validateForm = () => {
    let formErrors = {};

    if (!formData.myFee) formErrors.myFee = "Fee is required";
    if (!formData.projectId) formErrors.projectId = "Project ID is required";
    if (!formData.clientName) formErrors.clientName = "Client Name is required";
    if (!formData.profession) formErrors.profession = "Profession is required";
    if (!formData.writerPendingDays)
      formErrors.writerPendingDays = "Writer Pending Days is required";
    if (!formData.reviewerPendingDays)
      formErrors.reviewerPendingDays = "Reviewer Pending Days is required";
    if (!formData.projectPendingDays)
      formErrors.projectPendingDays = "Project Pending Days is required";
    if (!formData.writerDueDate) formErrors.writerDueDate = "Writer Due Date is required";
    if (!formData.reviewerDueDate) formErrors.reviewerDueDate = "Reviewer Due Date is required";

    setErrors(formErrors);
    return Object.keys(formErrors).length === 0;
  };

  // Handle form submission
  const handleSubmitpending = (e) => {
    e.preventDefault();

    // If form is valid, process the data
    if (validateForm()) {
      console.log("Form data submitted:", formData);
    }
  };
  const [isReadOnly, setIsReadOnly] = React.useState(true);
  return (
    <>


      <section className="main">
        <div className="row mt-4 w-100">
          {/* <div className="col-1 d-flex justify-content-center">
            <Sider />
          </div> */}
          <div className="col-11  ">

            <div className="col-12">
              <Header></Header>
            </div>


            <div className="col-12 wapper w-100 mt-3">
              <div className="pt-2 px-2 d-none d-md-block"><Breadcrumbs></Breadcrumbs></div>

              <form onSubmit={handleSubmitpending}>
                <div className="row w-100 mt-2 mx-1 p-3">

                  <div className="col-md-4 float-start pt-4 ">
                    <h5 className="statis-name ">ID</h5>
                    <input
                      type="text"
                      className={`form-control1`}
                      name="myFee"
                      value={pendingData.project_id}
                      readOnly={isReadOnly}
                    />
                  </div>

                  <div className="col-md-4 float-start pt-4 ">
                    <h5 className="statis-name ">Writer Pending Days</h5>
                    <input
                      className={` form-control1`}
                      name="writerPendingDays"
                      value={pendingData.writer_days_count}
                      readOnly={isReadOnly}
                    />



                  </div>

                  <div className="col-md-4 float-start pt-4 ">
                    <h5 className="statis-name ">Reviewer Pending Days</h5>
                    <input
                      className={` form-control1`}
                      name="reviewerPendingDays"
                      value={pendingData.reviewer_days_count}

                      readOnly={isReadOnly}
                    />



                  </div>

                  <div className="col-md-4 float-start pt-4 ">
                    <h5 className="statis-name ">Project Pending Days</h5>
                    <input
                      className={` form-control1`}
                      name="projectPendingDays"
                      value={pendingData.project_delay_count}
                      onChange={handleChangepending}

                    />



                  </div>

                  <div className="col-md-4 float-start pt-4 ">
                    <h5 className="statis-name ">Writer Payment Due Date</h5>
                    <input
                      type="text"
                      className={`form-control1`}
                      // value={pendingData.writerPaymentDueDate}
                      value={pendingData.writerPaymentDueDate ? pendingData.writerPaymentDueDate : ""}

                    />
                  </div>

                  <div className="col-md-4 float-start pt-4 ">
                    <h5 className="statis-name ">Reviewer Payment Due Date</h5>
                    <input
                      type="text"
                      className={`form-control1`}
                      name="reviewerDueDate"
                      // value={pendingData.reviewerPaymentDueD}
                      value={pendingData.reviewerPaymentDueD ? pendingData.reviewerPaymentDueD : ""}

                    />
                  </div>
                </div>

                <div className="col-md-12 d-flex justify-content-end mt-5  px-5 py-5 gap-3">
                  <Link to="/entry-process"><button className="save-form">
                    Back
                  </button></Link>
                  {/* <button type="submit" className="save-form ">
                    Save
                  </button> */}

                </div>
              </form>
            </div>
          </div>
        </div>
        \
      </section>
    </>
  );
}

export default Pending_form;
