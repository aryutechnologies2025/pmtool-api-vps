import React, { useState, useEffect } from "react";
import "../assests/css/payment_form.css";
import Sider from "../components/Sider.js";
import Header from "../components/Header.js";
import { Link } from "react-router-dom";
import Breadcrumbs from "../routes/Breadcrumbs.js";
import { useLocation } from "react-router-dom";
import axios from "axios";
import { API_URL } from "../config.js";
import { BASE_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import { useNavigate } from "react-router-dom";

import { CapitalizeCase } from "../capsUnderCase.js";
import PDF from "../assests/images/pdf.svg";
import Sav from "../assests/images/sav-file-format.png";

import Excel from "../assests/images/excel.svg";
import ppt from "../assests/images/ppt.svg";
import Word from "../assests/images/word.svg";
import Image from "../assests/images/image.svg";
import Footer from "../components/Footer";
import { getDateFormate } from "../dateFormate.js";
import { VscEye } from "react-icons/vsc";
import Tooltip from "@mui/material/Tooltip";
import Loader from "../components/Loader.js";
import {
  FaFilePdf,
  FaFileWord,
  FaFileExcel,
  FaFileImage,
} from "react-icons/fa";
import { formatIndianCurrency } from "../AmountFormet.js";

function Process_details() {
  const location = useLocation();
  const { rowId } = location.state || {};

  const roleName = localStorage.getItem("medicsroleName");
  const roleNum =localStorage.getItem("medocsrolename")
  console.log("roleName :", roleNum);
  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;

  const [formData, setFormData] = useState({
    myFee: "",
    writerPendingDays: "",
    reviewerPendingDays: "",
    projectPendingDays: "",
    writerDueDate: "",
    reviewerDueDate: "",
    entrydate: getDateFormate() || "",
    typeofwork: "",
    projectid: "",
    clientName: "",
    profession: "",
    title: "",
    institute: "",
    contactNo: "",
    department: "",
    email: "",
    discount: "",
    hierarchy: "",
    writer: "",
    writerDate: getDateFormate() || "",
    writerStatus: "",
    writerStatusDate: getDateFormate() || "",
    reviwer: "",
    reviwerAssignedDate: getDateFormate() || "",
    reviwerStatus: "",
    reviwerStatusdate: getDateFormate() || "",
    statistican: "",
    statisticanDate: getDateFormate() || "",
    statisticanStatus: "",
    statisticanStatusDate: getDateFormate() || "",
    journal: "",
    journalDate: getDateFormate() || "",
    journalStatus: "",
    journalStatusDate: getDateFormate() || "",
    duration: "",
    reviwerduration: "",
    statisticanduration: "",
    journalduration: "",
    processStatus: "",
    budget: "",
    journaldurationUnit: "",
    writerdurationUnit: "",
    reviwerdurationUnit: "",
    statisticandurationUnit: "",
    commandbox: "",
    processStatusDate: getDateFormate() || "",
    else_project_manager: false,
    payment_status: "",
    reference_number: "",
    project_duration: "",
    writer_comment: "",
    reviewer_comment: "",
    statistican_comment: "",
    journal_comment: "",
  });
  console.log("alldata:", formData);

  // State to store validation errors
  const [errors, setErrors] = useState({});

  // Handle input changes
  const handleChangepending = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  const [isReadOnly, setIsReadOnly] = React.useState(true);
  const [customId, setCustomId] = useState("");

  // Validate form before submission
  const validateForm = () => {
    let formErrors = {};

    if (!formData.myFee) formErrors.myFee = "Fee is required";
    if (!formData.projectId) formErrors.projectId = "Project ID is required";
    if (!formData.clientName) formErrors.clientName = "Client Name is required";
    if (!formData.profession) formErrors.profession = "Profession is required";
    if (!formData.writerPendingDays)
      formErrors.writerPendingDays = "Writer Pending Days is required";
    if (!formData.reviewerPendingDays)
      formErrors.reviewerPendingDays = "Reviewer Pending Days is required";
    if (!formData.projectPendingDays)
      formErrors.projectPendingDays = "Project Pending Days is required";
    if (!formData.writerDueDate)
      formErrors.writerDueDate = "Writer Due Date is required";
    if (!formData.reviewerDueDate)
      formErrors.reviewerDueDate = "Reviewer Due Date is required";

    setErrors(formErrors);
    return Object.keys(formErrors).length === 0;
  };

  // Handle form submission
  useEffect(() => {
    if (rowId) {
      fetchShowData(rowId);
      fetchPendingData(rowId);
    }
  }, [rowId]);

  const [checkboxes, setCheckboxes] = useState({
    writer: false,
    reviewer: false,
    statistican: false,
    journal: false,
  });

  const [writter, setWritter] = useState([]);
  const [reviewer, setReviewer] = useState([]);
  const [statistical, setStatistical] = useState([]);
  const [journal, setJournal] = useState([]);

  useEffect(() => {
    // Fetch data from the API when the component mounts
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${API_URL}/api/entry_process/getEmployeeName`
        );
        const data = response.data;

        // Update the state with the received data
        if (data) {
          setWritter(data.writer || []);
          setReviewer(data.reviewer || []);
          setStatistical(data.statistican || []);
          setJournal(data.journal || []);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);
  const navigate = useNavigate();

  const handleEditClick = (id) => {
    navigate("/entry-process/entryprocess-update-form", {
      state: { rowId: id },
    });
  };

  const handlePaymentClick = (id) => {
    navigate("/entry-process/payment-edit-form", {
      state: { rowId: id },
    });
  };

  const [paymentData, setPaymentData] = useState([]);
  // console.log('paymentData :',paymentData)
  const [selecteddocuments, setSelectedDocument] = useState([]);
  const [projectcomments, setProjectcomments] = useState([]);
  const [projectDatails, setProjectDetais] = useState([]);

  console.log("all Response:", projectDatails);

  const removeEmptyTags = (html) => {
    const div = document.createElement("div");
    div.innerHTML = html;

    // Loop through all child elements and remove empty tags
    const elements = div.querySelectorAll("*");
    elements.forEach((element) => {
      if (!element.innerHTML.trim()) {
        element.remove(); // Remove empty elements
      }
    });

    return div.innerHTML;
  };
  const [mail_status, setMailData] = useState([]);
  console.log("mail_status :", mail_status);
  const emailStatus = mail_status?.project_entry_email || "";
  const isSent = emailStatus.startsWith("Send");

  const fetchShowData = async (id) => {
    try {
      const responseShow = await axios.get(
        `${API_URL}/api/entry_process/view/${id}?createdBy=${createdby}`
      );
      const fetchData = responseShow.data;
      // console.log("fetchData :", fetchData);
      setFormData((prevFormData) => ({
        ...prevFormData,
        entrydate: fetchData.entry_date || "",
        title: fetchData.title || "",
        typeofwork: fetchData.type_of_work || "",
        projectid: fetchData.project_id || "",
        clientName: fetchData.client_name || "",
        email: fetchData.email || "",
        contactNo: fetchData.contact_number || "",
        institute: fetchData.institute?.name || "",
        department: fetchData.department?.name || "",
        profession: fetchData.profession?.name || "",
        budget: fetchData.budget || "",
        processStatus: fetchData.process_status || "",
        processStatusDate: fetchData.process_date || "",
        hierarchy: fetchData.hierarchy_level || "",
        else_project_manager: fetchData.else_project_manager || "",
        commandbox: fetchData.comment_box || "",
        project_duration: fetchData.projectduration || "",
        payment_status: fetchData.payment_process?.payment_status || "",
        writer_payment: fetchData.payment_process?.writer_payment || "",
        writer_payment_date:
          fetchData.payment_process?.writer_payment_date || "",
        reviewer_payment: fetchData.payment_process?.reviewer_payment || "",
        reviewer_payment_date:
          fetchData.payment_process?.reviewer_payment_date || "",
        statistican_payment:
          fetchData.payment_process?.statistican_payment || "",
        statistican_payment_date:
          fetchData.payment_process?.statistican_payment_date || "",
        journal_payment: fetchData.payment_process?.journal_payment || "",
        journal_payment_date:
          fetchData.payment_process?.journal_payment_date || "",
        reference_number:
          fetchData.payment_process?.payment_data
            ?.map((item) => item.reference_number)
            .join(", ") || "",
        discount: fetchData.payment_process?.discounts || "",
      }));

      setProjectDetais(fetchData);

      setProjectcomments(fetchData?.projectcomment || []);

      const projectmailstatus = fetchData?.project_mail_status || [];

      // Initialize formData with default values
      const formData1 = {
        project_entry_email: "Not Send",
        project_status_email: "Not Send",
        project_payment_status: "Not Send",
        advance_payment: "Not Send",
        partial_payment: "Not Send",
        final_payment: "Not Send",
      };

      // Populate formData with actual values if they exist
      projectmailstatus.forEach((mail) => {
        const statusText =
          // <span
          //   style={{
          //     color: mail.status === "success" ? "green" : "red",
          //     fontWeight: "bold",
          //   }}
          // >
          //   {mail.status === "success"
          //     ? `Send (${mail.created_date})`
          //     : "Not Send"}
          // </span>

          // style={{
          //   color: mail.status === "success" ? "green" : "red",
          //   fontWeight: "bold",
          // }};

          mail.status === "success"
            ? `Send (${mail.created_date})`
            : "Not Send";

        if (mail.mail_type === "project_entry_email") {
          formData1.project_entry_email = statusText;
        }
        if (mail.mail_type === "project_status_email") {
          formData1.project_status_email = statusText;
        }
        if (mail.mail_type === "project_payment_status_email") {
          formData1.project_payment_status = statusText;
        }
        if (mail.mail_type === "advance_payment") {
          formData1.advance_payment = statusText;
        }
        if (mail.mail_type === "partial_payment") {
          formData1.partial_payment = statusText;
        }
        if (mail.mail_type === "final_payment") {
          formData1.final_payment = statusText;
        }
      });

      setMailData(formData1);

      setSelectedDocument((fetchData?.documents_title || []).join(", "));
      const paymentProcess = fetchData?.payment_process || {};
      // console.log("paymentProcess :", paymentProcess);
      const referenceFiles = paymentProcess.payment_data;
      console.log("referenceFiles :", referenceFiles);
      const dynamicFiles1 = referenceFiles?.map((file, index) => {
        if (!file) {
          console.warn(`Skipping invalid file at index ${index}`);
          return null;
        }
        const fileType = file.reference_number_file?.split(".").pop();
        const relativePath = file.reference_number_file?.replace(/\\/g, "/");

        return {
          img: getFileIcon(fileType),
          type: fileType,
          fileName: file.reference_number_file?.split("/").pop(),
          url: `${API_URL}/payment_screenshots/${relativePath}`,
          id: index,
        };
      });

      // Update state with new files while avoiding duplicates
      // setFiles1((prevFiles) => {
      //   const newFiles = dynamicFiles1.filter(
      //     (newFile) =>
      //       !prevFiles.some((existingFile) => existingFile.id === newFile.id)
      //   );
      //   return [...prevFiles, ...newFiles];
      // });
      setFiles1(dynamicFiles1);
      setPaymentData(paymentProcess.payment_data || []);
      setCustomId(fetchData.project_id);
      const dynamicFiles = fetchData.documents.flatMap((doc) => {
        return doc.file.map((file) => {
          const fileType = file.file.split(".").pop(); // Extract file extension
          const relativePath = file.file.replace(/\\/g, "/"); // Handle backslashes

          // // Parse the select_document JSON string into an array
          // const documentTitles = JSON.parse(doc.select_document);
          // const title = documentTitles.join(", ");
          // setSelectedDocument(title);

          return {
            title: file.original_name.split("/").pop() || "Untitled Document", // Use document title or default
            img: getFileIcon(fileType), // Get corresponding file icon
            type: fileType, // File type/extension
            fileName: file.original_name.split("/").pop(), // Extract filename
            url: `${API_URL}/uploads/${relativePath}`, // Construct file URL
          };
        });
      });

      setFiles((prevFiles) => {
        const newFiles = dynamicFiles.filter(
          (newFile) =>
            !prevFiles.some((existingFile) => existingFile.id === newFile.id)
        );
        return [...prevFiles, ...newFiles];
      });
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const [pendingData, setPendingData] = useState([]);

  console.log("checvk mail:", mail_status);

  const fetchPendingData = async (id) => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/getPendingList/${id}`
      );
      const responsedata = response.data.data;
      // console.log("responsedata :", responsedata);
      setPendingData(responsedata);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  const [files, setFiles] = useState([]);

  const [files1, setFiles1] = useState([]);

  const getFileIcon = (type) => {
    // Define file format groups
    const imageFormats = ["jpg", "png", "gif", "jpeg", "svg", "PNG"];
    const excelFormats = ["xlsx", "xls", "csv"];
    const wordFormats = ["docx", "doc", "word", "txt"];
    const pptFormats = ["ppt", "pptx"];
    const SavFormats = ["sav"];

    if (imageFormats.includes(type)) {
      return <img src={Image} className="img-view" alt="Image" />;
    }
    if (SavFormats.includes(type)) {
      return <img src={Sav} className="img-view" alt="Image" />;
    }

    if (excelFormats.includes(type)) {
      return <img src={Excel} className="img-view" alt="Excel" />;
    }

    if (wordFormats.includes(type)) {
      return <img src={Word} className="img-view" alt="Word" />;
    }

    if (pptFormats.includes(type)) {
      return <img src={ppt} className="img-view" alt="Word" />;
    }

    if (type === "pdf") {
      return <img src={PDF} className="img-view" alt="PDF" />;
    }

    return null;
  };

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }

  return (
    <>
      <section className="container">
        <div className="row mt-4">
          {/* <div className="col-1 d-flex justify-content-center">
            <Sider />
          </div> */}
          <div className="col-12">
            <div className="col-12">
              <Header></Header>
            </div>

            <div className="col-12 pt-1 wapper w-100 mt-3">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className=" col-12 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>
              <div className="row w-100 mt-0 px-3">
                <div className="col-12  d-flex flex-wrap justify-content-between">
                  <div className="col-12 col-md-4 d-flex flex-column ">
                    <div className="col-md-12 float-start  ">
                      <label className="heading-entr mx-2 ">
                        Enter Details
                      </label>
                    </div>

                    <div className="col-md-12 float-start pt-2 d-flex  ">
                      <div className=" statis-name-details">Entry Date</div>
                      <div className="view-details-data">
                        : {getDateFormate(formData.entrydate)}
                      </div>
                    </div>
                    <div className="col-md-12 float-start pt-2 d-flex">
                      <div className=" statis-name-details">Title</div>
                      <span className="view-dot mx-1">:</span>
                      <div className="view-details-data">
                        {CapitalizeCase(formData.title)}
                      </div>
                    </div>
                    <div className="col-md-12 float-start pt-2 d-flex ">
                      <div className=" statis-name-details">Type Of work</div>
                      <div className="view-details-data">
                        : {CapitalizeCase(formData.typeofwork)}
                      </div>
                    </div>
                    <div className="col-md-12 float-start pt-2 d-flex ">
                      <div className=" statis-name-details">Project ID</div>
                      <div className="view-details-data">
                        : {CapitalizeCase(customId)}
                      </div>
                    </div>

                    <div className="col-md-12 float-start pt-2 d-flex ">
                      <div className=" statis-name-details">
                        Project Requirement
                      </div>
                      <span className="view-dot mx-1">:</span>
                      <div className="view-details-data">
                        {CapitalizeCaseU(selecteddocuments)}
                      </div>
                    </div>
                  </div>
                  {roleNum !== "14" && (
                    <div className="col-12 col-md-8 d-flex flex-column">
                      <div className="col-md-12 float-start px-2 ">
                        <label className="heading-entr ">
                          Client Informations
                        </label>
                      </div>
                      <div className="row">
                        <div className="col-6">
                          <div className="col-12 col-md-12 float-start pt-2 d-flex  ">
                            <div className=" statis-name-details">
                              Client Name
                            </div>
                            <div className="view-details-data">
                              : Dr.{CapitalizeCase(formData.clientName)}
                            </div>
                          </div>
                          <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                            <div className="statis-name-details  ">
                              Email ID
                            </div>
                            <span className="view-dot mx-1">:</span>
                            <div className="view-details-data">
                              {formData.email}
                            </div>
                          </div>
                          <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                            <div className="statis-name-details  ">
                              Contact No
                            </div>
                            <span className="view-dot mx-1">:</span>
                            <div className="view-details-data">
                              {formData.contactNo}
                            </div>
                          </div>

                          <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                            <div className="statis-name-details ">
                              Institute
                            </div>
                            <span className="view-dot mx-1">:</span>

                            <div className="view-details-data">
                              {formData.institute}
                            </div>
                          </div>

                          <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                            <div className="statis-name-details  ">
                              Department
                            </div>
                            <span className="view-dot mx-1">:</span>

                            <div className="view-details-data">
                              {formData.department}
                            </div>
                          </div>
                          <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                            <div className="statis-name-details ">
                              Profession
                            </div>
                            <span className="view-dot mx-1">:</span>

                            <div className="view-details-data">
                              {formData.profession}
                            </div>
                          </div>
                        </div>
                        <div className="col-12 col-md-6">
                          <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                            <div className="statis-name-details ">Budget</div>

                            <div className="view-details-data">
                              : {formatIndianCurrency(formData.budget || 0)}
                            </div>
                          </div>

                          <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                            <div className="statis-name-details  ">
                              Process Status
                            </div>

                            <div className="view-details-data">
                              : {CapitalizeCase(formData.processStatus)}
                            </div>
                          </div>
                          <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                            <div className="statis-name-details ">
                              Process Status Date
                            </div>

                            <div className="view-details-data">
                              : {getDateFormate(formData.processStatusDate)}
                            </div>
                          </div>
                          <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                            <div className="statis-name-details ">
                              Project Completion
                            </div>

                            <div className="view-details-data">
                              : {getDateFormate(formData.project_duration)}
                            </div>
                          </div>

                          <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                            <div className="statis-name-details ">
                              Hierarchical
                            </div>

                            <div className="view-details-data">
                              : {CapitalizeCase(formData.hierarchy)}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="">
                  <div className="d-flex">
                    <div className="heading-view-details mx-2 mt-2">
                      Uploaded Files :
                    </div>
                    <div className="d-flex gap-2 flex-wrap p-1 px-2 ">
                      {files.map((file, index) => (
                        <div className="images-box-all-view " key={index}>
                          <div className=" view-files-view p-2 text-center">
                            {/* <div className="   file-title-card">
                            {CapitalizeCase(file.title)}
                          </div> */}
                            <Tooltip title="View">
                              <div
                                className="  "
                                onClick={() => window.open(file.url, "_blank")}
                              >
                                {getFileIcon(file.type)}

                                {/* <VscEye /> */}
                              </div>
                            </Tooltip>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className=" px-3 pt-1">
                  <label className="heading-entr mx-1">Comments :</label>
                  <div className="">
                    {projectcomments.map((comment, index) => (
                      <div
                        key={index}
                        className="pt-2 comments-background-color p-1 mb-1"
                      >
                        <div>
                          <div className="view-names1-command ">
                            {comment.created_by_user?.employee_name}:
                            <span className="mx-2">
                              <span
                                dangerouslySetInnerHTML={{
                                  __html: removeEmptyTags(
                                    CapitalizeCaseU(comment.commend_box || "")
                                      .replace(/<p>/g, "<span>")
                                      .replace(/<\/p>/g, "</span>")
                                  ),
                                }}
                              />
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {projectDatails?.writer_data &&
                  projectDatails.writer_data.length > 0 && (
                    <div className="col-12  pt-1">
                      <label className="heading-entr mx-2">
                        Writer Informations
                      </label>
                      <div className="d-flex flex-wrap">
                        {projectDatails.writer_data.map((writer, index) => (
                          <>
                            <div className="pb-3">
                              <div className="  pt-2  d-flex">
                                <label className="statis-name-details">
                                  Name
                                </label>
                                <div className="view-details-data">
                                  : {writer.user_date?.employee_name}
                                </div>
                              </div>

                              <div className="d-flex pt-2">
                                <label className="statis-name-details">
                                  Assigned Date
                                </label>

                                <div className="view-details-data">
                                  : {getDateFormate(writer.assign_date)}
                                </div>
                              </div>

                              <div className="d-flex  pt-2">
                                <label className="statis-name-details">
                                  Status
                                </label>

                                <div className="view-details-data">
                                  : {CapitalizeCase(writer.status)}
                                </div>
                              </div>
                              <div className="d-flex   pt-2">
                                <label className="statis-name-details">
                                  Status Date
                                </label>

                                <div className="view-details-data">
                                  : {getDateFormate(writer.status_date) || ""}
                                </div>
                              </div>
                              <div className="d-flex  pt-2">
                                <label className="statis-name-details">
                                  Project Duration
                                </label>

                                <div className="view-details-data">
                                  : {getDateFormate(writer.project_duration)}
                                </div>
                              </div>
                              <div className="d-flex  pt-2">
                                <label className="statis-name-details">
                                  Comments
                                </label>
                                <div className="view-details-data">
                                  : {CapitalizeCase(writer.comments || "")}
                                </div>
                              </div>
                            </div>
                          </>
                        ))}
                      </div>
                    </div>
                  )}

                {projectDatails?.reviewer_data &&
                  projectDatails.reviewer_data.length > 0 && (
                    <div className="col-12  pt-1">
                      <label className="heading-entr mx-2">
                        Reviewer Informations
                      </label>
                      <div className="d-flex flex-wrap">
                        {projectDatails.reviewer_data.map((writer, index) => (
                          <div className="pb-3">
                            <div className=" d-flex pt-2">
                              <label className="statis-name-details">
                                Name
                              </label>

                              <div className="view-details-data">
                                : {writer.user_date?.employee_name}
                              </div>
                            </div>

                            <div className="d-flex  pt-2">
                              <label className="statis-name-details">
                                Assigned Date
                              </label>

                              <div className="view-details-data">
                                : {getDateFormate(writer.assign_date)}
                              </div>
                            </div>

                            <div className="d-flex  pt-2">
                              <label className="statis-name-details">
                                Status
                              </label>

                              <div className="view-details-data">
                                : {CapitalizeCase(writer.status)}
                              </div>
                            </div>
                            <div className="d-flex   pt-2">
                              <label className="statis-name-details">
                                Status Date
                              </label>
                              <div className="view-details-data">
                                : {getDateFormate(writer.status_date)}
                              </div>
                            </div>
                            <div className="d-flex  pt-2">
                              <label className="statis-name-details">
                                Project Duration
                              </label>
                              <div className="view-details-data">
                                : {getDateFormate(writer.project_duration)}
                              </div>
                            </div>
                            <div className="d-flex  pt-2">
                              <label className="statis-name-details">
                                Comments
                              </label>

                              <div className="view-details-data">
                                : {CapitalizeCase(writer.comments)}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                {projectDatails?.statistican_data &&
                  projectDatails.statistican_data.length > 0 && (
                    <div className="col-12  pt-1">
                      <label className="heading-entr mx-2">
                        Statistician Informations
                      </label>
                      <div className="d-flex flex-wrap">
                        {projectDatails.statistican_data.map(
                          (writer, index) => (
                            <div className="pb-3">
                              <div className="d-flex pt-2">
                                <label className="statis-name-details">
                                  Name
                                </label>
                                <div className="view-details-data">
                                  : {writer.user_date?.employee_name}
                                </div>
                              </div>

                              <div className="d-flex  pt-2">
                                <label className="statis-name-details ">
                                  Assigned Date
                                </label>
                                <div className="view-details-data">
                                  : {getDateFormate(writer.assign_date)}
                                </div>
                              </div>

                              <div className="d-flex pt-2">
                                <label className="statis-name-details  ">
                                  Status
                                </label>
                                <div className="view-details-data">
                                  : {CapitalizeCase(writer.status)}
                                </div>
                              </div>
                              <div className="d-flex   pt-2">
                                <label className="statis-name-details">
                                  Status Date
                                </label>

                                <div className="view-details-data">
                                  : {getDateFormate(writer.status_date)}
                                </div>
                              </div>
                              <div className="d-flex  pt-2">
                                <div className="statis-name-details">
                                  Project Duration
                                </div>
                                <div className="view-details-data">
                                  : {getDateFormate(writer.project_duration)}
                                </div>
                              </div>
                              <div className="d-flex  pt-2">
                                <label className="statis-name-details">
                                  Comments
                                </label>

                                <div className="view-details-data">
                                  : {CapitalizeCase(writer.comments)}
                                </div>
                              </div>
                            </div>
                          )
                        )}
                      </div>
                    </div>
                  )}

                {projectDatails?.journal_data &&
                  projectDatails.journal_data.length > 0 && (
                    <div className="col-6  pt-1">
                      <label className="heading-entr mx-2">
                        Journal Informations
                      </label>
                      {projectDatails.journal_data.map((journal, index) => (
                        <>
                          <div className="d-flex pt-2">
                            <label className="statis-name-details">Name</label>
                            <div className="view-details-data">
                              : {journal.assign_user}
                            </div>
                          </div>

                          <div className="d-flex  pt-2">
                            <label className="statis-name-details ">
                              Assigned Date
                            </label>
                            <div className="view-details-data">
                              : {getDateFormate(journal.assign_date)}
                            </div>
                          </div>

                          {/* <div className="d-flex pt-2">
                            <label className="statis-name-details  ">
                              Status
                            </label>
                            <div className="view-details-data">
                              : {CapitalizeCase(journal.status)}
                            </div>
                          </div>
                          <div className="d-flex   pt-2">
                            <label className="statis-name-details">
                              Status Date
                            </label>

                            <div className="view-details-data">
                              : {getDateFormate(journal.status_date)}
                            </div>
                          </div> */}
                          <div className="d-flex  pt-2">
                            <div className="statis-name-details">
                              Project Duration
                            </div>
                            <div className="view-details-data">
                              : {getDateFormate(journal.project_duration)}
                            </div>
                          </div>
                          <div className="d-flex  pt-2">
                            <label className="statis-name-details">
                              Comments
                            </label>

                            <div className="view-details-data">
                              : {CapitalizeCase(journal.comments || "-")}
                            </div>
                          </div>
                          <div className="d-flex  pt-2">
                            <label className="statis-name-details">
                              Status
                            </label>

                            <div className="view-details-data">
                              : {CapitalizeCase(journal.status || "-")}
                            </div>
                          </div>
                          <div className="d-flex  pt-2">
                            <label className="statis-name-details">
                              Type Of Article
                            </label>

                            <div className="view-details-data">
                              : {CapitalizeCase(journal.type_of_article || "-")}
                            </div>
                          </div>
                          <div className="d-flex  pt-2">
                            <label className="statis-name-details">
                              Review
                            </label>

                            <div className="view-details-data">
                              : {CapitalizeCase(journal.review || "-")}
                            </div>
                          </div>
                        </>
                      ))}
                    </div>
                  )}

                <div className="col-12">
                  <label className="heading-entr mt-1 px-2 ">PENDING</label>
                </div>
                <div className="col-12">
                  <div className="col-md-6 d-flex pt-2">
                    <label className="statis-name-details ">
                      Writer Delay Days
                    </label>
                    <div className="view-details-data">
                      : {pendingData.writer_days_count || "0"}
                    </div>
                  </div>

                  <div className="col-md-6 d-flex  pt-2">
                    <label className="statis-name-details ">
                      Reviewer Delay Days
                    </label>
                    {/* <input
                    type="text"
                    className="form-control1"
                    value={pendingData.reviewer_days_count}
                    readOnly={isReadOnly}
                  /> */}
                    <div className="view-details-data">
                      : {pendingData.reviewer_days_count || "0"}
                    </div>
                  </div>

                  <div className="col-md-6 d-flex pt-2">
                    <label className="statis-name-details ">
                      Statistician Delay Days
                    </label>
                    {/* <input
                    type="text"
                    className="form-control1"
                    value={pendingData.statistican_days_count}
                    readOnly={isReadOnly}
                  /> */}
                    <div className="view-details-data">
                      : {pendingData.statistican_days_count || "0"}
                    </div>
                  </div>

                  <div className="col-md-6 d-flex pt-2">
                    <label className="statis-name-details  ">
                      Project Delay Days
                    </label>
                    {/* <input
                    type="text"
                    className="form-control1"
                    value={pendingData.project_delay_count}
                    readOnly={isReadOnly}
                  /> */}
                    <div className="view-details-data">
                      : {pendingData.project_delay_count || "0"}
                    </div>
                  </div>
                  {roleNum !== "14" && (
                    <>
                      <div className="col-md-6 d-flex pt-2">
                        <label className="statis-name-details">
                          Writer Payment Due Date
                        </label>
                        {/* <input
                    type="email"
                    className="form-control1"
                    readOnly={isReadOnly}
                    value={
                      pendingData.writerPaymentDueDate
                        ? getDateFormate(pendingData.writerPaymentDueDate)
                        : ""
                    }
                  /> */}
                        <div className="view-details-data">
                          :{" "}
                          {pendingData.writerPaymentDueDate
                            ? getDateFormate(pendingData.writerPaymentDueDate)
                            : "0"}
                        </div>
                      </div>

                      <div className="col-md-6 d-flex pt-2">
                        <label className="statis-name-details ">
                          Reviewer Payment Due Date
                        </label>
                        <div className="view-details-data">
                          :{" "}
                          {pendingData.reviewerPaymentDueD
                            ? getDateFormate(pendingData.reviewerPaymentDueD)
                            : "0"}
                        </div>
                      </div>
                    </>
                  )}
                </div>

                {roleNum !== "14" && (
                  <div className="col-12">
                    <label className="heading-entr mx-2  mt-3 ">
                      PAYMENT STATUS
                    </label>
                  </div>
                )}

                {/* {paymentData.length > 0 && ( */}
                {roleNum !== "14" && (
                  <div className="col-12">
                    <div className=" col-md-6 d-flex pt-2  ">
                      <label className="statis-name-details ">
                        Payment Status
                      </label>
                      {/* <input
                      type="text"
                      className="form-control1"
                      value={CapitalizeCase(formData?.payment_status || "")}
                      readOnly={isReadOnly}
                    /> */}
                      <div className="view-details-data">
                        : {CapitalizeCase(formData?.payment_status || "-")}
                      </div>
                    </div>

                    <div className=" col-md-6 d-flex pt-2  ">
                      <label className="statis-name-details ">Discounts</label>

                      <div className="view-details-data">
                        : {CapitalizeCase(formData?.discount || "-")}
                      </div>
                    </div>
                    {/* <div className="col-6 d-flex pt-2">
                      <label className="statis-name-details">
                        Payment Reference Number
                      </label>
                     
                      <div className="view-details-data-num">
                        : {CapitalizeCaseU(formData?.reference_number || "-")}
                      </div>
                    </div> */}

                    {/*  update document view */}
                    <div className="col-6 d-flex ">
                      
                        <div className="statis-name-details  mt-2">
                          Reference Number File 
                        </div>
                        :<div className=" view-details-data-num d-flex gap-2 flex-wrap pt-1 px-2">
                          {files1.map((file, index) => (
                            <div className="images-box-all-view" key={index}>
                              <div className=" ">
                                <div>
                                  {/* <div className="text-center">
                                {getFileIcon(file.type)}
                              </div> */}
                                  {/* <h5 className="text-center mt-2 file-title-card">
                                {Capitalize(file.title)}
                              </h5> */}

                                  <div
                                    title="view"
                                    onClick={() =>
                                      window.open(file.url, "_blank")
                                    }
                                  >
                                    {getFileIcon(file.type)}
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                     
                    </div>
                  </div>
                )}
                {/* )} */}
                {roleNum !== "14" && (
                  <>
                    {formData.writer_payment && (
                      <div className="">
                        <div className="col-md-6 d-flex pt-2 ">
                          <label className="statis-name-details  ">
                            Writer Payment
                          </label>
                          {/* <input
                        type="text"
                        className="form-control1"
                        value={formData.writer_payment}
                        readOnly={isReadOnly}
                      /> */}
                          <div className="view-details-data">
                            : {formData.writer_payment}
                          </div>
                        </div>
                        <div className="col-md-6 d-flex pt-2 ">
                          <label className="statis-name-details">
                            Writer Payment Date
                          </label>
                          {/* <input
                        type="email"
                        className="form-control1"
                        value={getDateFormate(formData.writer_payment_date)}
                        readOnly={isReadOnly}
                      /> */}
                          <div className="view-details-data">
                            : {getDateFormate(formData.writer_payment_date)}
                          </div>
                        </div>
                      </div>
                    )}
                    {formData.reviewer_payment && (
                      <div className="">
                        <div className="col-md-6 d-flex pt-2 ">
                          <label className="statis-name-details">
                            Reviewer Payment
                          </label>
                          {/* <input
                        type="text"
                        className="form-control1"
                        value={formData.reviewer_payment}
                        readOnly={isReadOnly}
                      /> */}
                          <div className="view-details-data">
                            : {formData.reviewer_payment}
                          </div>
                        </div>
                        <div className="col-md-6 d-flex pt-2 ">
                          <label className="statis-name-details">
                            Reviewer Payment Date
                          </label>
                          {/* <input
                        type="email"
                        className="form-control1"
                        value={getDateFormate(formData.reviewer_payment_date)}
                        readOnly={isReadOnly}
                      /> */}
                          <div className="view-details-data">
                            : {getDateFormate(formData.reviewer_payment_date)}
                          </div>
                        </div>
                      </div>
                    )}
                    {formData.statistican_payment && (
                      <div className="">
                        <div className="col-md-6 d-flex  pt-2 ">
                          <label className="statis-name-details  ">
                            Statistican Payment
                          </label>
                          {/* <input
                        type="text"
                        className="form-control1"
                        value={formData.statistican_payment}
                        readOnly={isReadOnly}
                      /> */}
                          <div className="view-details-data">
                            : {formData.statistican_payment}
                          </div>
                        </div>
                        <div className="col-md-6 d-flex  pt-2 ">
                          <label className="statis-name-details">
                            Statistican Payment Date
                          </label>
                          {/* <input
                        type="email"
                        className="form-control1"
                        value={getDateFormate(
                          formData.statistican_payment_date
                        )}
                        readOnly={isReadOnly}
                      /> */}
                          <div className="view-details-data">
                            :{" "}
                            {getDateFormate(formData.statistican_payment_date)}
                          </div>
                        </div>
                      </div>
                    )}
                    {formData.journal_payment && (
                      <div className="">
                        <div className="col-md-6  d-flex pt-2 ">
                          <label className="statis-name-details  ">
                            Journal Payment
                          </label>
                          {/* <input
                        type="text"
                        className="form-control1"
                        value={formData.journal_payment}
                        readOnly={isReadOnly}
                      /> */}
                          <div className="view-details-data">
                            :{formData.journal_payment}
                          </div>
                        </div>
                        <div className="col-md-4  pt-2 ">
                          <label className="statis-name-details">
                            Journal Payment Date
                          </label>
                          {/* <input
                        type="email"
                        className="form-control1"
                        value={getDateFormate(formData.journal_payment_date)}
                        readOnly={isReadOnly}
                      /> */}
                          <div className="view-details-data">
                            : {getDateFormate(formData.journal_payment_date)}
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}
 {roleNum !== "14" && (
<>
                <div className="">
                  {paymentData.length > 0 &&
                    paymentData.map((payment, index) => (
                      <div key={index} className="col-md-6 d-flex pt-2">
                        <label className="statis-name-details">
                          {`Payment-${index + 1} `}
                        </label>
                        {/* <input
                          type="text"
                          className="form-control1"
                          value={`Amount: ${payment.payment}`}
                          readOnly
                        /> */}

                        <div className="view-details-data ">
                          <span className="view-dot">:</span>
                          {payment.payment !== "0" ? (
                            <>
                              <span className="fw-bold mx-1">
                                {formatIndianCurrency(payment.payment)} -
                              </span>
                              {getDateFormate(payment.payment_date)}
                             
                            </>
                          ) : (
                            <span> -</span> // or null if you want to show nothing
                          )}
                        </div>
                      </div>
                    ))}
                </div>
                <div className="">
                  {paymentData.length > 0 &&
                    paymentData.map((payment, index) => (
                      <div key={index} className="col-md-6 d-flex pt-2">
                        <label className="statis-name-details">
                          {`Reference No -${index + 1} `}
                        </label>
                        {/* <input
                          type="text"
                          className="form-control1"
                          value={`Amount: ${payment.payment}`}
                          readOnly
                        /> */}

                        <div className="view-details-data ">
                          <span className="view-dot">:</span>
                          {payment.payment !== "0" ? (
                            <>
                             
                          
                              <span className="fw-bold mx-1">
                                {(payment.reference_number)} -
                              </span>
                              {getDateFormate(payment.payment_date)}
                            </>
                          ) : (
                            <span> -</span> // or null if you want to show nothing
                          )}
                        </div>
                      </div>
                    ))}
                </div>
 
                {projectDatails?.employee_payment_detail &&
                  projectDatails.employee_payment_detail.length > 0 && (
                    <div className="col-12  pt-1">
                      <label className="heading-entr mx-2">
                        Freelancer Payment
                      </label>
                      <div className="d-flex flex-wrap">
                        {projectDatails.employee_payment_detail.map(
                          (freepay, index) => (
                            <>
                              <div className="pb-3">
                                <div className="  pt-2  d-flex">
                                  <label className="statis-name-details">
                                    Name
                                  </label>
                                  <div className="view-details-data">
                                    : {freepay.user_date?.employee_name}
                                  </div>
                                </div>
                                {/* <div className="d-flex  pt-2">
                                  <label className="statis-name-details">
                                    
                                  </label>

                                  <div className="view-details-data">
                                    : {CapitalizeCase(freepay.type)}
                                  </div>
                                </div> */}

                                <div className="d-flex pt-2">
                                  <label className="statis-name-details">
                                    Payment
                                  </label>

                                  <div className="view-details-data">
                                    : {formatIndianCurrency(freepay.payment)}
                                  </div>
                                </div>

                                <div className="d-flex  pt-2">
                                  <label className="statis-name-details">
                                    Status
                                  </label>

                                  <div className="view-details-data">
                                    : {CapitalizeCase(freepay.status)}
                                  </div>
                                </div>
                                <div className="d-flex  pt-2">
                                  <label className="statis-name-details">
                                    Payment Date
                                  </label>

                                  <div className="view-details-data">
                                    : {getDateFormate(freepay.payment_date)}
                                  </div>
                                </div>
                              </div>
                            </>
                          )
                        )}
                      </div>
                    </div>
                  )}

                {projectDatails?.journal_payment_details &&
                  projectDatails.journal_payment_details.length > 0 && (
                    <div className="col-12  pt-1">
                      <label className="heading-entr mx-2">
                        Journal Payment Details
                      </label>
                      <div className="d-flex flex-wrap">
                        {projectDatails.journal_payment_details.map(
                          (journalpay, index) => (
                            <>
                              <div className="pb-3">
                                {/* <div className="  pt-2  d-flex">
                                  <label className="statis-name-details">
                                    Name
                                  </label>
                                  <div className="view-details-data">
                                    : {journalpay.user_date?.employee_name}
                                  </div>
                                </div> */}
                                {/* <div className="d-flex  pt-2">
                                  <label className="statis-name-details">
                                    
                                  </label>

                                  <div className="view-details-data">
                                    : {CapitalizeCase(journalpay.type)}
                                  </div>
                                </div> */}

                                <div className="d-flex pt-2">
                                  <label className="statis-name-details">
                                    Payment
                                  </label>

                                  <div className="view-details-data">
                                    : {formatIndianCurrency(journalpay.payment)}
                                  </div>
                                </div>

                                <div className="d-flex  pt-2">
                                  <label className="statis-name-details">
                                    Status
                                  </label>

                                  <div className="view-details-data">
                                    : {CapitalizeCase(journalpay.status || "-")}
                                  </div>
                                </div>
                                <div className="d-flex  pt-2">
                                  <label className="statis-name-details">
                                    Payment Date
                                  </label>

                                  <div className="view-details-data">
                                    : {getDateFormate(journalpay.payment_date)}
                                  </div>
                                </div>
                              </div>
                            </>
                          )
                        )}
                      </div>
                    </div>
                  )}
</>
                    )}
                {roleNum !== "14" && roleName !== "SME" && (
                  <>
                    <div className="col-12">
                      <label className="heading-entr mx-2  mt-3 ">
                        Mail Notification Status
                      </label>
                    </div>

                    <div className="col-12">
                      <div className=" col-md-6 d-flex pt-2  ">
                        <label className="statis-name-details ">
                          Project entry email
                        </label>
                        <div className="view-details-data">
                          :{" "}
                          <span
                            className={`status-text ${
                              mail_status?.project_entry_email?.startsWith(
                                "Send"
                              )
                                ? "success"
                                : "failed"
                            }`}
                          >
                            {CapitalizeCase(mail_status?.project_entry_email)}
                          </span>
                        </div>
                      </div>
                      <div className="col-12">
                        <div className=" col-md-6 d-flex pt-2  ">
                          <label className="statis-name-details ">
                            Project status email
                          </label>
                          <div className="view-details-data">
                            :{" "}
                            <span
                              className={`status-text ${
                                mail_status?.project_status_email?.startsWith(
                                  "Send"
                                )
                                  ? "success"
                                  : "failed"
                              }`}
                            >
                              {CapitalizeCase(
                                mail_status?.project_status_email
                              )}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* <div className="col-12">
                        <div className=" col-md-6 d-flex pt-2  ">
                          <label className="statis-name-details ">
                            Project payment status email
                          </label>
                          <div className="view-details-data">
                            :  <span
                              className={`status-text ${
                                mail_status?.project_payment_status.startsWith(
                                  "Send"
                                )
                                  ? "success"
                                  : "failed"
                              }`}
                            >
                              {CapitalizeCase(
                                mail_status?.project_payment_status
                              )}
                            </span>
                          </div>
                        </div>
                      </div> */}
                      <div className="col-12">
                        <div className=" col-md-6 d-flex pt-2  ">
                          <label className="statis-name-details ">
                            Advance
                          </label>
                          <div className="view-details-data">
                            :{" "}
                            <span
                              className={`status-text ${
                                mail_status?.advance_payment?.startsWith("Send")
                                  ? "success"
                                  : "failed"
                              }`}
                            >
                              {CapitalizeCase(mail_status?.advance_payment)}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="col-12">
                        <div className=" col-md-6 d-flex pt-2  ">
                          <label className="statis-name-details ">
                            Partial Payment
                          </label>
                          <div className="view-details-data">
                            :{" "}
                            <span
                              className={`status-text ${
                                mail_status?.partial_payment?.startsWith("Send")
                                  ? "success"
                                  : "failed"
                              }`}
                            >
                              {CapitalizeCase(mail_status?.partial_payment)}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="col-12">
                        <div className=" col-md-6 d-flex pt-2  ">
                          <label className="statis-name-details ">
                            Final Payment
                          </label>
                          <div className="view-details-data">
                            :{" "}
                            <span
                              className={`status-text ${
                                mail_status?.final_payment?.startsWith("Send")
                                  ? "success"
                                  : "failed"
                              }`}
                            >
                              {CapitalizeCase(mail_status?.final_payment)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </>
                )}
                
            

                {/* sme only */}
                {roleName === "SME" && (
                  <>
                    <div className="col-12">
                      <label className="heading-entr mx-2  mt-3 ">
                        Mail Notification Status
                      </label>
                    </div>
                    <div className="col-12">
                      <div className=" col-md-6 d-flex pt-2  ">
                        <label className="statis-name-details ">
                          Project status email
                        </label>
                        <div className="view-details-data">
                          :{" "}
                          <span
                            className={`status-text ${
                              mail_status?.project_status_email?.startsWith(
                                "Send"
                              )
                                ? "success"
                                : "failed"
                            }`}
                          >
                            {CapitalizeCase(mail_status?.project_status_email)}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="col-12">
                      <div className=" col-md-6 d-flex pt-2  ">
                        <label className="statis-name-details ">
                          Project payment status email
                        </label>
                        <div className="view-details-data">
                          :{" "}
                          <span
                            className={`status-text ${
                              mail_status?.project_payment_status?.startsWith(
                                "Send"
                              )
                                ? "success"
                                : "failed"
                            }`}
                          >
                            {CapitalizeCase(
                              mail_status?.project_payment_status
                            )}
                          </span>
                        </div>
                      </div>
                    </div>
                  </>
                )}
                <div className="col-md-12 d-flex justify-content-end float-start pt-5 gap-3 ">
                  {(roleName === "Project Manager" || roleName === "Admin") && (
                    <button
                      type="submit"
                      onClick={() => handlePaymentClick(rowId)}
                      className="save-form-save"
                    >
                      Payment Update
                    </button>
                  )}
                  {roleName === "13" ||
                    ((roleName === "Admin" ||
                      roleName === "Project Manager") && (
                      <>
                        <button
                          className="save-form"
                          onClick={() => navigate("/entry-process")}
                        >
                          Back
                        </button>
                      </>
                    ))}

                  {roleName !== "Project Manager" && roleName !== "Admin" && (
                    <>
                      <button
                        className="save-form"
                        onClick={() => navigate(-1)}
                      >
                        Back
                      </button>
                    </>
                  )}

                  {(roleName === "Project Manager" || roleName === "Admin") && (
                    <button
                      type="submit"
                      onClick={() => handleEditClick(rowId)}
                      className="save-form-save"
                    >
                      Edit
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div>
          <Footer />
        </div>
      </section>
    </>
  );
}

export default Process_details;
