import React, { useState, useEffect, useCallback, useRef } from "react";
import "../assests/css/enter_form.css";
import Tooltip from "@mui/material/Tooltip";

import Sider from "../components/Sider.js";
import Header from "../components/Header.js";
import { Link } from "react-router-dom";
// import Enterprocesshead from "../enterprocess/Enterprocesshead.js";
import { PiCloudArrowUpLight } from "react-icons/pi";
import { RiDeleteBin6Line } from "react-icons/ri";
import RichEditor from "../components/RichEditor.jsx";
import Breadcrumbs from "../routes/Breadcrumbs";
import axios from "axios";
import { API_URL } from "../config.js";
import { BASE_URL } from "../config.js";
import Swal from "sweetalert2";
import Loader from "../components/Loader.js";

import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { Capitalize } from "../campsCase.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import { AiOutlineClose } from "react-icons/ai";
import PDF from "../assests/images/pdf.svg";

import Excel from "../assests/images/excel.svg";
import Sav from "../assests/images/sav-file-format.png";

import Word from "../assests/images/word.svg";
import Image from "../assests/images/image.svg";
import { TbRefreshAlert } from "react-icons/tb";
import { MdDriveFileRenameOutline } from "react-icons/md";
import { cssHooks } from "jquery";
import { IoMdRefreshCircle } from "react-icons/io";
import Footer from "../components/Footer";
import { VscEye } from "react-icons/vsc";
import { MdOutlineCancel } from "react-icons/md";

import { getTotalDuration } from "../utils/projectDurations";

function Enterprocess_form() {
  const navigate = useNavigate();
  const location = useLocation();
  const [loading, setLoading] = useState(true);
  const queryParams = new URLSearchParams(location.search);

  const rowId = location.state?.rowId || queryParams.get("id");

  console.log("rowId :", rowId);
  const rolename = localStorage.getItem("medocsrolename") || "Admin";

  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const [formFields, setFormFields] = useState([
    { specificOption: "", file: null, fileName: "" },
  ]);

  const [projectdate, setEntryDate] = useState(new Date());
  const [typeofwork, setTypeofwork] = useState("");

  const getEndDate = (selectedOptions, type_of_work) => {
    const { total, statistician, writer, reviewer, journal } = getTotalDuration(
      selectedOptions,
      type_of_work
    );
    console.log("durations :", total, statistician, writer, reviewer, journal);
    const formatDate = (days) => {
      if (!projectdate || isNaN(new Date(projectdate))) {
        return new Date().toISOString().split("T")[0];
      }

      const date = new Date(projectdate);
      date.setDate(date.getDate() + days);
      return date.toISOString().split("T")[0]; // Format YYYY-MM-DD
    };

    return {
      project_duration:
        total > 0 ? formatDate(total) : new Date().toISOString().split("T")[0],
      writer_project_duration:
        writer > 0
          ? formatDate(writer)
          : new Date().toISOString().split("T")[0],
      reviewer_project_duration:
        reviewer > 0
          ? formatDate(reviewer)
          : new Date().toISOString().split("T")[0],
      statistician_project_duration:
        statistician > 0
          ? formatDate(statistician)
          : new Date().toISOString().split("T")[0],
      journal_project_duration:
        journal > 0
          ? formatDate(journal)
          : new Date().toISOString().split("T")[0],
    };
  };

  const selectedOptions = formFields[0]?.specificOption || [];
  const typeOfWork = typeofwork;

  const durations = getTotalDuration(selectedOptions, typeOfWork);

  // console.log("check data duration", durations);

  // useEffect(() => {
  //   if (!Array.isArray(selectedOptions)) return; // Prevent unnecessary updates

  //   const durations = getEndDate(selectedOptions, typeofwork); // Pass type_of_work

  //   setFormData((prevData) => ({
  //     ...prevData,
  //     project_duration: durations.project_duration,
  //     writerprojectduration: durations.writer_project_duration,
  //     reviewerProjectDuration: durations.reviewer_project_duration,
  //     statisticanprojectduration: durations.statistician_project_duration,
  //     journalprojectduration: durations.journal_project_duration,
  //   }));

  //   setWriterFields((prevFields) =>
  //     prevFields.map((field, index) =>
  //       index === 0
  //         ? {
  //             ...field,
  //             writerprojectduration: durations.writer_project_duration,
  //           }
  //         : field
  //     )
  //   );

  //   setReviewerFields((prevFields) =>
  //     prevFields.map((field, index) =>
  //       index === 0
  //         ? {
  //             ...field,
  //             reviewerProjectDuration: durations.reviewer_project_duration,
  //           }
  //         : field
  //     )
  //   );

  //   setStatisticanFields((prevFields) =>
  //     prevFields.map((field, index) =>
  //       index === 0
  //         ? {
  //             ...field,
  //             statisticanProjectDuration:
  //               durations.statistician_project_duration,
  //           }
  //         : field
  //     )
  //   );

  //   setJournalFields((prevFields) =>
  //     prevFields.map((field, index) =>
  //       index === 0
  //         ? {
  //             ...field,
  //             journalProjectDuration: durations.journal_project_duration,
  //           }
  //         : field
  //     )
  //   );
  // }, [selectedOptions, typeOfWork]);

  const [formData, setFormData] = useState({
    entrydate: getTodayDate() || "",
    typeofwork: "",
    projectid: "",
    clientName: "",
    profession: "",
    title: "",
    institute: "",
    contactNo: "",
    department: "",
    email: "",
    hierarchy: "",
    duration: "",
    processStatus: "",
    budget: "",
    commandbox: "",
    processStatusDate: getTodayDate() || "",
    else_project_manager: false,
    project_duration: "",
    writerprojectduration: "",
    reviewerProjectDuration: "",
    statisticanprojectduration: "",
    journalprojectduration: "",
    // writer_comment: "",
    // reviewer_comment: "",
    // statistican_comment: "",
    // journal_comment: "",
    payment_status: "",
    typeofarticle: "",
    journalStatus: "",
    review: "",
  });

  const [errors, setErrors] = useState({});
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });

    if (name === "entrydate") {
      setEntryDate(value);
    }
    setErrors((prevErrors) => {
      const { [name]: removedError, ...rest } = prevErrors;
      return rest;
    });
  };
  // current
  const [formErrors, setFormErrors] = useState({});

  // Validate form before submission
  const validateForm = () => {
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    const phoneNumberRegex = /^[+]?[0-9]{10,15}$/;

    let formErrors = {};
    // if (!formData.project_duration) formErrors.project_duration = "Completion date is required";
    if (!formData.entrydate) formErrors.entrydate = "EntryDate is required";
    if (!typeofwork) formErrors.typeofwork = "typeofwork is required";
    // if (!formData.projectid) formErrors.projectid = "Project ID is // required";
    if (!formData.clientName) formErrors.clientName = "Client Name is required";
    if (!formData.profession) formErrors.profession = "Profession is required";
    if (!formData.department) formErrors.department = "Department is required";

    if (!formData.institute) formErrors.institute = "Institute is required";

    // if (!formData.title) formErrors.title = "Title is required";
    if (!formData.email == "") {
      if (!emailRegex.test(formData.email)) {
        formErrors.email = "Invalid email format";
      }
    }

    if (!formData.contactNo == "") {
      if (!phoneNumberRegex.test(formData.contactNo)) {
        formErrors.contactNo =
          "Invalid phone number. It must be between 10-15 digits.";
      }
    }
    if (!formData.hierarchy) formErrors.hierarchy = "hierarchy is required";

    const hasValidPayment = (paymentFields || []).some(
      (field) =>
        String(field.payment).trim() !== "" &&
        String(field.payment_date).trim() !== ""
    );
    if (hasValidPayment && !formData.payment_status) {
      formErrors.payment_status = "Payment status is required.";
    }

    return formErrors;
  };

  //  profession.........................................................>
  const [currentChoice, setCurrentChoice] = useState(""); // Stores selected option
  const [query, setQuery] = useState(""); // Stores search query
  const [dropdownItems, setProfessions] = useState([]); // Static list of options
  const [isDropdownVisible, setDropdownVisible] = useState(false); // Tracks dropdown visibility

  const filteredItems = dropdownItems.filter((item) =>
    item.name.toLowerCase().includes(query.toLowerCase())
  );

  // const handleSelectItem = (id, name) => {
  //   setCurrentChoice({ id, name });
  //   setDropdownVisible(false); // Close dropdown after selection
  // };
  const handleSelectItem = (id, name) => {
    setCurrentChoice({ id, name });
    setFormData({
      ...formData,
      profession: id,
    });
    setErrors({
      ...errors,
      profession: "",
    });
    setQuery("");
    setDropdownVisible(false);
  };

  const toggleDropmenu = () => {
    setDropdownVisible((prev) => !prev); // Toggle dropdown visibility
    setListExpanded(false);
    setIsDropdownOpen(false);
  };

  // institute...................................................=>
  const [selectedOption, setSelectedOption] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [optionsinstitute, setIntitutes] = useState([]);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const filteredOptions = optionsinstitute.filter((institute) =>
    institute.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSelectOption = (id, name) => {
    setSelectedOption({ id, name });
    setIsDropdownOpen(false);
  };

  const toggleDropdowninstitue = () => {
    setIsDropdownOpen((prev) => !prev);
    setDropdownVisible(false);
  };

  // department........................................................>
  const [chosenOption, setChosenOption] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [availableOptions, setDepartments] = useState([]);
  const [isListExpanded, setListExpanded] = useState(false);

  const filtereddepOptions = availableOptions.filter((option) =>
    option.name.toLowerCase().includes(searchInput.toLowerCase())
  );

  const handledepOptionSelect = (id, name) => {
    setChosenOption({ id, name });
    setListExpanded(false); // Close dropdown after selection
  };

  const toggleList = () => {
    setListExpanded((prev) => !prev); // Toggle dropdown visibility
    setDropdownVisible(false);
    setIsDropdownOpen(false);
  };

  const [showWriter, setShowWriter] = useState(false);
  const [showReviewer, setShowReviewer] = useState(false);
  const [showStatistican, setShowStatistican] = useState(false);
  const [showJournal, setShowJournal] = useState(false);
  console.log("showWriter", showWriter);
  const [showProject, setShowProject] = useState(false);
  const handleWriterClick = () => {
    // Toggle the writer checkbox state
    setCheckboxes((prevCheckboxes) => {
      const newWriterState = !prevCheckboxes.writer; // Corrected variable name

      // If the checkbox is being unchecked, clear the form values
      if (!newWriterState) {
        setFormData((prevData) => ({
          ...prevData,
          writer: "",
          writerStatus: "",
          // writerdurationUnit: "",
          writerprojectduration: "",
          // durationInput: "",
        }));

        setWriterFields([
          {
            writer: "",
            writerDate: getTodayDate() || "",
            writerStatus: "to_do",
            writerStatusDate: getTodayDate() || "",
            writerprojectduration:
              formData.writerprojectduration || getTodayDate(),
            writer_comment: "",
            error: false,
          },
        ]);
      }

      return {
        ...prevCheckboxes,
        writer: newWriterState, // Update the writer state
      };
    });

    // Toggle the `showWriter` state
    setShowWriter((prevShowWriter) => !prevShowWriter); // Corrected variable name
  };

  const handleStatisticanClick = () => {
    // Toggle the statistican checkbox state
    setCheckboxes((prevCheckboxes) => {
      const newStatisticanState = !prevCheckboxes.statistican; // Determine the new state for statistican

      // If the checkbox is being unchecked, clear the form values
      if (!newStatisticanState) {
        setFormData((prevData) => ({
          ...prevData,
          statistican: "",
          statisticanStatus: "",
          statisticanprojectduration: "",
          // statisticandurationUnit: "",
        }));

        setStatisticanFields([
          {
            statistican: "",
            statisticanAssignedDate: getTodayDate() || "",
            statisticanStatus: "to_do",
            statisticanStatusDate: getTodayDate() || "",
            statisticanProjectDuration:
              formData.statisticanprojectduration || getTodayDate(),
            statistican_comment: "",
            error: false,
          },
        ]);
      }

      return {
        ...prevCheckboxes,
        statistican: newStatisticanState, // Update the statistican state
      };
    });

    // Toggle the visibility of the statistican section
    setShowStatistican((prevShowStatistican) => !prevShowStatistican);
  };

  const handleReviewerClick = () => {
    // Toggle the reviewer checkbox state
    setCheckboxes((prevCheckboxes) => {
      const newReviewerState = !prevCheckboxes.reviewer;

      // If the checkbox is being unchecked, clear the form values
      if (!newReviewerState) {
        setFormData((prevData) => ({
          ...prevData,
          reviwer: "",
          reviwerStatus: "",
          reviewerProjectDuration: "",
          // reviwerdurationUnit: "",
        }));

        setReviewerFields([
          {
            reviewer: "",
            reviewerAssignedDate: getTodayDate() || "",
            reviewerStatus: "to_do",
            reviewerStatusDate: getTodayDate() || "",
            reviewerProjectDuration:
              formData.reviewerProjectDuration || getTodayDate(),
            reviewer_comment: "",
            error: false,
          },
        ]);
      }

      return {
        ...prevCheckboxes,
        reviewer: newReviewerState,
      };
    });

    // Toggle the `showReviewer` state
    setShowReviewer((prevShowReviewer) => !prevShowReviewer);
  };

  const [journalFields, setJournalFields] = useState([
    {
      journalid: "",
      journal: "",
      journalAssignedDate: getTodayDate() || "",
      journalStatus: "",
      journalStatusDate: getTodayDate() || "",
      journalProjectDuration: formData.journalprojectduration || getTodayDate(),
      journal_comment: "",
      typeofarticle: "",
      review: "",
      error: false,
    },
  ]);

  console.log("journalFields :", journalFields);

  const handleJournalClick = () => {
    // Toggle the checkbox state for `journal`
    setCheckboxes((prevCheckboxes) => {
      const newJournalState = !prevCheckboxes.journal; // Determine the new state for the journal checkbox

      // If the checkbox is being unchecked, clear the form values
      if (!newJournalState) {
        setFormData((prevData) => ({
          ...prevData,
          journal: "",
          journalStatus: "",
          journalprojectduration: "",
          // journaldurationUnit: "",
        }));

        setJournalFields([
          {
            journal: "",
            journalAssignedDate: getTodayDate() || "",
            journalStatus: "",
            journalStatusDate: getTodayDate() || "",
            journalProjectDuration:
              formData.journalprojectduration || getTodayDate(),
            journal_comment: "",
            type_of_article: "",
            review: "",
            error: false,
          },
        ]);
      }
      console.log("check journal", newJournalState);

      return {
        ...prevCheckboxes,
        journal: newJournalState, // Update the journal checkbox state
      };
    });

    // Toggle the visibility of the journal section
    setShowJournal((prevShowJournal) => !prevShowJournal);
  };

  const handleProjectClick = (e) => {
    const isChecked = e.target.checked;

    // Update the checkbox value in the formData
    setFormData((prevData) => ({
      ...prevData,
      else_project_manager: isChecked,
    }));

    // Only toggle reviewer and other states if the checkbox is unchecked
    if (!isChecked) {
      // setShowReviewer(false);

      setCheckboxes({
        writer: false,
        reviewer: false,
        statistican: false,
        journal: false,
      });

      // Clear reviewer-related data
      setFormData((prevData) => ({
        ...prevData,
        reviwer: "",
        reviwerStatus: "",
        // reviwerdurationInput: "",
        reviewerProjectDuration: "",
      }));

      if (showReviewer) {
        setShowReviewer(false);
        setFormData((prevData) => ({
          ...prevData,
          reviwer: "",
          reviwerStatus: "",
          // reviwerdurationInput: "",
          reviewerProjectDuration: "",
        }));
      }

      if (showStatistican) {
        setShowStatistican(false);

        setFormData((prevData) => ({
          ...prevData,
          statistican: "",
          statisticanStatus: "",
          // statisticandurationInput: "",
          statisticanprojectduration: "",
        }));
      }

      if (showWriter) {
        setShowWriter(false);

        setFormData((prevData) => ({
          ...prevData,
          writer: "",
          writerStatus: "",
          // writerdurationUnit: "",
          writerprojectduration: "",
          // durationInput: "",
        }));
      }

      if (showJournal) {
        setShowJournal(false);
        setFormData((prevData) => ({
          ...prevData,
          journal: "",
          journalStatus: "",
          journalprojectduration: "",
          // journaldurationUnit: "",
        }));
      }
    }
  };

  // const handleJournalClick = () => {
  //   // Toggle the checkbox state for `journal`
  //   setCheckboxes((prevCheckboxes) => {
  //     const newJournalState = !prevCheckboxes.journal; // Determine the new state for the journal checkbox

  //     // If the checkbox is being unchecked, clear the form values
  //     if (!newJournalState) {
  //       setFormData((prevData) => ({
  //         ...prevData,
  //         journal: "",
  //         journalStatus: "",
  //         journalprojectduration: "",
  //         // journaldurationUnit: "",
  //       }));
  //     }

  //     return {
  //       ...prevCheckboxes,
  //       journal: newJournalState, // Update the journal checkbox state
  //     };
  //   });

  //   // Toggle the visibility of the journal section
  //   setShowJournal((prevShowJournal) => !prevShowJournal);
  // };

  const optionsMapping = {
    statistics: [
      { value: "sample_size", label: "Sample Size" },
      { value: "paper_statistics", label: "Paper Statistics" },
      {
        value: "thesis_statistics_with_text",
        label: "Thesis Statistics - With Text",
      },
      {
        value: "thesis_statistics_without_text",
        label: "Thesis Statistics - Without Text",
      },
    ],
    manuscript: [
      { value: "writing", label: "Writing" },
      { value: "with_statistics", label: "With Statistics" },
      { value: "with_publication", label: "With Publication" },
    ],
    thesis: [
      // {
      //   value: "supporting_thesis_with_ms",
      //   label: "Supporting Thesis with MS",
      // },
      // {
      //   value: "supporting_thesis_without_ms",
      //   label: "Supporting Thesis without MS",
      // },
      { value: "supporting_thesis_part1", label: "Supporting Thesis Part - 1" },
      { value: "supporting_thesis_part2", label: "Supporting Thesis Part - 2" },
      {
        value: "supporting_thesis_part_with_ms",
        label: "Supporting Thesis Part - With MS",
      },
      {
        value: "supporting_thesis_part_without_ms",
        label: "Supporting Thesis Part - Without MS",
      },
      { value: "thesis_reviewing", label: "Thesis Reviewing" },
    ],
    presentation: [
      { value: "conference_presentation", label: "Conference Presentation" },
      { value: "with_statistics", label: "With Statistics" },
      { value: "poster_presentation", label: "Poster Presentation" },
    ],
    others: [],
  };

  const handleSpecificChange = (e, index) => {
    const { name, value } = e.target;
    setFormFields((prevFormFields) => {
      const updatedFormFields = [...prevFormFields];
      updatedFormFields[index][name] = value;
      return updatedFormFields;
    });

    // Remove validation error for this specific field if it exists
    const updatedErrors = { ...errors };
    delete updatedErrors[`specificOption_${index}`];
    setErrors(updatedErrors);
  };

  const handleFileChange = useCallback((index, e) => {
    const files = Array.from(e.target.files);

    setFormFields((prevFormFields) => {
      const updatedFormFields = [...prevFormFields];
      updatedFormFields[index].file = [
        ...(updatedFormFields[index].file || []), // Ensure it's an array
        ...files,
      ];
      return updatedFormFields;
    });
  }, []);

  // Handle file delete
  const handleFileDelete = useCallback((index) => {
    setFormFields((prevFormFields) => {
      const updatedFormFields = [...prevFormFields];
      updatedFormFields[index].file = null;
      return updatedFormFields;
    });
  }, []);

  // Handle adding a new field
  const handleAddField = useCallback(() => {
    setFormFields((prevFormFields) => [
      ...prevFormFields,
      { specificOption: "", file: null, fileName: "" },
    ]);
  }, []);

  // Handle delete field
  const handleDeleteField = useCallback((index) => {
    setFormFields((prevFormFields) =>
      prevFormFields.filter((_, i) => i !== index)
    );
  }, []);

  const handleChangeselect = (e, index) => {
    const { name, value } = e.target;
    setFormFields((prevFormFields) => {
      const updatedFormFields = [...prevFormFields];
      updatedFormFields[index][name] = value;
      return updatedFormFields;
    });
  };

  const [isDropdowncheck, setIsDropdowncheck] = useState(false);

  const toggleDropcheck = () => {
    setIsDropdowncheck((prev) => !prev);
  };

  //Institiue list

  const fetchRoles = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/institutions`
      );

      setIntitutes(response.data);
    } catch (err) {
      console.log("Failed to fetch roles.");
    }
  };

  const fetchDepartments = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/departments`
      );
      setDepartments(response.data);
    } catch (err) {
      console.log("Failed to fetch roles.");
    }
  };

  const fetchProfession = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/professions`
      );

      setProfessions(response.data);
    } catch (err) {
      console.log("Failed to fetch roles.");
    }
  };

  useEffect(() => {
    fetchRoles();
    fetchDepartments();
    fetchProfession();
  }, []);

  // file showing

  // Function to handle the file deletion
  const handleDelete = async (index, documentId) => {
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to delete this documents?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      try {
        const response = await fetch(
          `${API_URL}/api/entry_process/document-delete/${documentId}?createdby=${createdby}`,
          {
            method: "DELETE",
            headers: {
              "Content-Type": "application/json",
            },
          }
        );

        // Check if the delete operation was successful
        if (response.ok) {
          const updatedFiles = files.filter((_, i) => i !== index);
          setFiles(updatedFiles);
        } else {
          // Handle error response
          const errorData = await response.json();
          console.error("Error deleting document:", errorData.message);
        }
      } catch (error) {
        console.error("Error deleting document:", error.message);
      }
    } else {
      Swal.fire("Cancelled", "Your document is safe :)", "info");
    }
  };

  const [files, setFiles] = useState([]);

  const getFileIcon = (type) => {
    // Define file format groups
    const imageFormats = ["jpg", "png", "gif", "jpeg", "svg", "txt"];
    const excelFormats = ["xlsx", "xls", "csv"];
    const wordFormats = ["docx", "doc", "word"];
    const SavFormats = ["sav"];

    if (imageFormats.includes(type)) {
      return <img src={Image} className="img-view" alt="Image" />;
    }
    if (SavFormats.includes(type)) {
      return <img src={Sav} className="img-view" alt="Image" />;
    }

    if (excelFormats.includes(type)) {
      return <img src={Excel} className="img-view" alt="Excel" />;
    }

    if (wordFormats.includes(type)) {
      return <img src={Word} className="img-view" alt="Word" />;
    }

    if (type === "pdf") {
      return <img src={PDF} className="img-view" alt="PDF" />;
    }

    return null;
  };

  //project id

  const [commentval, setCommentBox] = useState(""); // State to store content

  const handleCommentChange = (newContent) => {
    setCommentBox(newContent); // Set the updated content from the editor
  };

  // Handle Type of Work Change
  const [customId, setCustomId] = useState("");

  const handleTypeOfWorkChange = async (e) => {
    const selectedType = e.target.value;
    setTypeofwork(selectedType);

    try {
      const response = await axios.post(`${API_URL}/api/customId`, {
        type_of_work: selectedType,
      });
      const customId = response.data.custom_id;
      setCustomId(customId);
      setFormData((prev) => ({ ...prev, project_id: customId }));
    } catch (error) {
      console.error("Error generating custom ID:", error);
    }
  };

  const [writter, setWritter] = useState([]);
  const [reviewer, setReviewer] = useState([]);
  const [statistical, setStatistical] = useState([]);
  const [journal, setJournal] = useState([]);
  const [projectcomments, setProjectcomments] = useState([]);

  //payment update

  const handleRemoveField = async (index, id) => {
    // Show a SweetAlert confirmation dialog
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to delete this payment?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      try {
        if (id) {
          await axios.delete(
            `${API_URL}/api/payment_processes/payment_delete/${id}`,
            {
              params: {
                created_by: createdby,
                project_id: rowId,
              },
            }
          );
        }

        // Remove the field from the frontend state
        setPaymentFields((prevFields) =>
          prevFields.filter((_, i) => i !== index)
        );

        // Show a success message after deletion
        Swal.fire("Deleted!", "The payment field has been deleted.", "success");
      } catch (error) {
        console.error("Error deleting payment field", error);
        // Show error message if deletion fails
        Swal.fire(
          "Error!",
          "There was an issue deleting the payment field.",
          "error"
        );
      }
    } else {
      // If user cancels, you can show a cancellation message or do nothing
      Swal.fire("Cancelled", "Your payment field is safe :)", "info");
    }
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // const handlePaymentChange = (index, field, value) => {
  //   if (index >= 0 && index < paymentFields.length) {
  //     const updatedFields = [...paymentFields];

  //     updatedFields[index][field] = value;
  //     setPaymentFields(updatedFields);
  //   } else {
  //     console.error("Invalid index:", index);
  //   }
  // };
  const validateFormFiles = () => {
    const validationErrors = {};

    // Ensure `paymentFields` is properly initialized
    if (!Array.isArray(paymentFields) || paymentFields === undefined) {
      console.error(
        "Error: `paymentFields` is not an array or undefined",
        paymentFields
      );
      setPaymentFields([{ payment: "", payment_date: "" }]);
      return {
        payment_0: "Payment is required",
        payment_date_0: "Payment date is required",
      };
    }

    // Ensure at least one default payment field
    if (paymentFields.length === 0) {
      setPaymentFields([{ payment: "", payment_date: "" }]);
      validationErrors[`payment_0`] = "Payment is required";
      validationErrors[`payment_date_0`] = "Payment date is required";
      return validationErrors;
    }

    // Field-wise validation (without resetting user input)
    paymentFields.forEach((field, index) => {
      if (!field.payment) {
        validationErrors[`payment_${index}`] = "Payment is required";
      }
      if (!field.payment_date) {
        validationErrors[`payment_date_${index}`] = "Payment date is required";
      }
    });

    return validationErrors;
  };

  const handlePaymentChange = (index, field, value) => {
    const updatedFields = Array.isArray(paymentFields)
      ? [...paymentFields]
      : [];
    updatedFields[index] = { ...updatedFields[index], [field]: value };
    setPaymentFields(updatedFields);
  };

  const handleAddFieldpayment = () => {
    const validationErrors = validateFormFiles(paymentFields || []);

    if (Object.keys(validationErrors).length === 0) {
      setPaymentFields((prevPaymentFields) => [
        ...(prevPaymentFields || []),
        { amount: "", date: "" },
      ]);
    } else {
      setErrors(validationErrors);
    }
  };

  // const handlePaymentChange = (index, field, value) => {
  //   const updatedFields = [...paymentFields];
  //   updatedFields[index][field] = value;
  //   setPaymentFields(updatedFields);
  // };
  //payment end

  useEffect(() => {
    fetchData();
    if (rowId) {
      fetchShowData(rowId);
    }
  }, [rowId]);

  const [checkboxes, setCheckboxes] = useState({
    writer: false,
    reviewer: false,
    statistican: false,
    journal: false,
  });
  const [selecteddocuments, setSelectedDocument] = useState([]);

  // console.log('check accountsdata', selecteddocuments);

  const [paymentFields, setPaymentFields] = useState([
    { payment: "", payment_date: "" },
  ]);
  const [payment_id, setPaymentId] = useState("");

  // useEffect(() => {
  //   if (paymentFields.length === 0) {
  //     setPaymentFields([{ payment: "", payment_date: "" }]);
  //   }
  // }, [paymentFields]);

  const fetchShowData = async (id) => {
    try {
      const responseShow = await axios.get(
        `${API_URL}/api/entry_process/view/${id}?createdBy=${createdby}`
      );
      const fetchData = responseShow.data;

      setFormData((prevFormData) => ({
        ...prevFormData,
        entrydate: fetchData.entry_date || "",
        title: fetchData.title || "",
        // typeofwork: fetchData.type_of_work || '',
        projectid: fetchData.project_id || "",
        clientName: fetchData.client_name || "",
        email: fetchData.email || "",
        contactNo: fetchData.contact_number || "",
        institute: fetchData.institute?.id || "",
        department: fetchData.department?.id || "",
        profession: fetchData.profession?.id || "",
        budget: fetchData.budget || "",
        processStatus: fetchData.process_status || "",
        processStatusDate: fetchData.process_date || "",
        hierarchy: fetchData.hierarchy_level || "",
        project_duration: fetchData.projectduration || "",

        // else_project_manager: fetchData.else_project_manager || false,
        // commandbox: fetchData.comment_box || "",
        payment_status: fetchData.payment_process?.payment_status || "",
      }));

      setPaymentId(fetchData.payment_process?.id);
      setPaymentFields(fetchData.payment_process?.payment_data);
      setSelectedDocument((fetchData?.documents_title || []).join(", "));
      setProjectcomments(fetchData?.projectcomment || []);

      setFormData((prevFormData) => ({
        ...prevFormData,
        else_project_manager:
          fetchData.else_project_manager === "false"
            ? false
            : Boolean(fetchData.else_project_manager),
      }));
      setCustomId(fetchData.project_id);
      setTypeofwork(fetchData.type_of_work);

      const newCheckboxes = {
        writer: fetchData.writer_data.length > 0, // Check if writer_data is not empty
        reviewer: fetchData.reviewer_data.length > 0, // Check if reviewer_data is not empty
        statistican: fetchData.statistican_data.length > 0, // Check if statistican_data is not
        // empty
        journal: fetchData.journal_data.length > 0, // Check if journal_data is not
      };

      setCheckboxes(newCheckboxes);
      setShowWriter(newCheckboxes.writer);
      setShowReviewer(newCheckboxes.reviewer);
      setShowStatistican(newCheckboxes.statistican);
      setShowJournal(newCheckboxes.journal);

      if (
        fetchData?.documents_title &&
        Array.isArray(fetchData?.documents_title)
      ) {
        const specificOption = fetchData?.documents_title; // Keep it as an array
        setFormFields([{ specificOption, file: null, fileName: "" }]);
      } else {
        setFormFields([{ specificOption: [], file: null, fileName: "" }]); // Ensure it's an empty array
      }

      // console.log('fetchData.documents', fetchData?.documents_title);
      const dynamicFiles = fetchData.documents.flatMap((doc) => {
        return doc.file.map((file) => {
          const fileType = file.file.split(".").pop();
          const relativePath = file.file.replace(/\\/g, "/");
          return {
            title: file.original_name.split("/").pop() || "Untitled Document",
            img: getFileIcon(fileType),
            type: fileType,
            fileName: file.original_name.split("/").pop(),
            url: `${BASE_URL}uploads/${relativePath}`,
            id: file.id,
          };
        });
      });

      const selectedOptions = formFields[0].specificOption;

      const hasWriting = selectedOptions.includes("writing");
      const hasWithStatistics = selectedOptions.includes("with_statistics");

      setFiles((prevFiles) => {
        const newFiles = dynamicFiles.filter(
          (newFile) =>
            !prevFiles.some((existingFile) => existingFile.id === newFile.id)
        );
        return [...prevFiles, ...newFiles];
      });

      setSelectedOption({
        id: fetchData.institute?.id || "",
        name: fetchData.institute?.name || "Institute",
      });

      setChosenOption({
        id: fetchData.department?.id || "",
        name: fetchData.department?.name || "Department",
      });

      setCurrentChoice({
        id: fetchData.profession?.id || "",
        name: fetchData.profession?.name || "Profession",
      });

      //multiple writer
      const writerData = fetchData.writer_data || [];

      const formattedWriterData =
        writerData.length === 0
          ? [
              {
                writerid: "",
                writer: "",
                writerDate: getTodayDate() || "",
                writerStatus: "to_do",
                writerStatusDate: getTodayDate() || "",
                writerprojectduration: getTodayDate(),
                writer_comment: "",
                error: false,
              },
            ]
          : writerData.map((writer) => ({
              writerid: writer.id,
              writer: writer.assign_user,
              writerDate: writer.assign_date,
              writerStatus: writer.status,
              writerStatusDate: writer.status_date,
              writerprojectduration: writer.project_duration,
              writer_comment: writer.comments,
              error: false,
            }));
      setWriterFields(formattedWriterData);

      const reviewerData = fetchData.reviewer_data || [];

      const formattedRevierwerData =
        reviewerData.length === 0
          ? [
              {
                reviewerid: "",
                reviewer: "",
                reviewerAssignedDate: getTodayDate() || "",
                reviewerStatus: "to_do",
                reviewerStatusDate: getTodayDate() || "",
                reviewerProjectDuration: getTodayDate(),
                reviewer_comment: "",
                error: false,
              },
            ]
          : reviewerData.map((reviewer) => ({
              reviewerid: reviewer.id,
              reviewer: reviewer.assign_user,
              reviewerAssignedDate: reviewer.assign_date,
              reviewerStatus: reviewer.status,
              reviewerStatusDate: reviewer.status_date,
              reviewerProjectDuration: reviewer.project_duration,
              reviewer_comment: reviewer.comments,
              error: false,
            }));
      setReviewerFields(formattedRevierwerData);

      const statisticanData = fetchData.statistican_data || [];

      const formattedStatisticanData =
        statisticanData.length === 0
          ? [
              {
                statisticanid: "",
                statistican: "",
                statisticanAssignedDate: getTodayDate() || "",
                statisticanStatus: "to_do",
                statisticanStatusDate: getTodayDate() || "",
                statisticanProjectDuration: getTodayDate(),
                statistican_comment: "",
                error: false,
              },
            ]
          : statisticanData.map((statistican) => ({
              statisticanid: statistican.id,
              statistican: statistican.assign_user,
              statisticanAssignedDate: statistican.assign_date,
              statisticanStatus: statistican.status,
              statisticanStatusDate: statistican.status_date,
              statisticanProjectDuration: statistican.project_duration,
              statistican_comment: statistican.comments,
              error: false,
            }));
      setStatisticanFields(formattedStatisticanData);

      const journalData = fetchData.journal_data || [];

      const formattedJournalData =
        journalData.length === 0
          ? [
              {
                journalid: "",
                journal: "",
                journalAssignedDate: getTodayDate() || "",
                journalStatus: "",
                journalStatusDate: getTodayDate() || "",
                journalProjectDuration: getTodayDate(),
                journal_comment: "",
                typeofarticle: "",
                review: "",
                error: false,
              },
            ]
          : journalData.map((journal) => ({
              journalid: journal.id,
              journal: journal.assign_user,
              journalAssignedDate: journal.assign_date,
              journalStatus: journal.status
                ? journal.status
                : "",
              journalStatusDate: journal.status_date
                ? journal.status_date
                : getTodayDate(),
              journalProjectDuration: journal.project_duration,
              journal_comment: journal.comments,
              typeofarticle: journal.type_of_article,
              review: journal.review,
              error: false,
            }));
      setJournalFields(formattedJournalData);
      setLoading(false);
      // console.log("check journalData", journalData);
    } catch (error) {
      setLoading(false);
      console.error("Error fetching data", error);
    }
  };

  const fetchData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/getEmployeeName`
      );
      const data = response.data;
      console.log("data :", data);
      // Update the state with the received data
      if (data) {
        setWritter(data.writer || []);
        setReviewer(data.reviewer || []);
        setStatistical(data.statistican || []);
        setJournal(data.journal || []);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  // ... your other code ...

  const [writerFields, setWriterFields] = useState([
    {
      writerid: "",
      writer: "",
      writerDate: getTodayDate() || "",
      writerStatus: "to_do",
      writerStatusDate: getTodayDate() || "",
      writerprojectduration: formData.writerprojectduration || getTodayDate(),
      writer_comment: "",
      error: false,
    },
  ]);

  // This will log the initial state and any subsequent changes
  useEffect(() => {
    console.log("writerFields updated:", writerFields);
  }, [writerFields]); // This effect runs whenever writerFields changes

  const handlewriterChange = (index, field, value) => {
    const updatedFields = [...writerFields];
    updatedFields[index][field] = value;
    setWriterFields(updatedFields);

    if (field === "writer" && value) {
      updatedFields[index].error = false;
    }

    const durations = getEndDate(selectedOptions, typeofwork); // Pass type_of_work

    setFormData((prevData) => ({
      ...prevData,
      writerprojectduration: durations.writer_project_duration,
    }));

    setWriterFields((prevFields) =>
      prevFields.map((field, index) =>
        index === 0
          ? {
              ...field,
              writerprojectduration: durations.writer_project_duration,
            }
          : field
      )
    );
  };

  const handleAddWriterField = () => {
    const lastEntry = writerFields[writerFields.length - 1];
    const durations = getEndDate(selectedOptions, typeofwork);
    if (!lastEntry.writer) {
      const updatedFields = [...writerFields];
      updatedFields[writerFields.length - 1].error = true;
      setWriterFields(updatedFields);
      return;
    }

    setWriterFields((prevFields) => [
      ...prevFields,
      {
        writerid: "",
        writer: "",
        writerDate: getTodayDate() || "",
        writerStatus: "to_do",
        writerStatusDate: getTodayDate() || "",
        writerprojectduration:
          durations.writer_project_duration || getTodayDate(),
        writer_comment: "",
        error: false,
      },
    ]);
  };

  // const handleDeleteWriterField = async (index, writerId) => {
  //   Swal.fire({
  //     title: "Are you sure?",
  //     text: "This action will permanently delete the writer!",
  //     icon: "warning",
  //     showCancelButton: true,
  //     confirmButtonColor: "#d33",
  //     cancelButtonColor: "#3085d6",
  //     confirmButtonText: "Yes, delete it!",
  //     cancelButtonText: "Cancel",
  //   }).then(async (result) => {
  //     if (result.isConfirmed) {
  //       try {
  //         const response = await fetch(
  //           `${API_URL}/api/entry_process/project_assign_delete/${writerId}`,
  //           {
  //             method: "DELETE",
  //           }
  //         );

  //         if (response.ok) {
  //           // Remove the writer from the state after successful deletion
  //           const updatedFields = writerFields.filter((_, i) => i !== index);
  //           setWriterFields(updatedFields);

  //           Swal.fire("Deleted!", "The writer has been deleted.", "success");
  //         } else {
  //           Swal.fire("Error!", "Failed to delete the writer.", "error");
  //         }
  //       } catch (error) {
  //         console.error("Error deleting writer:", error);
  //         Swal.fire("Error!", "Something went wrong.", "error");
  //       }
  //     }
  //   });
  // };

  // reviwer

  const handleDeleteWriterField = (index) => {
    const updatedFields = writerFields.filter((_, i) => i !== index);
    setWriterFields(updatedFields);
  };

  const [reviewerFields, setReviewerFields] = useState([
    {
      reviewerid: "",
      reviewer: "",
      reviewerAssignedDate: getTodayDate() || "",
      reviewerStatus: "to_do",
      reviewerStatusDate: getTodayDate() || "",
      reviewerProjectDuration:
        formData.reviewerProjectDuration || getTodayDate(),
      reviewer_comment: "",
      error: false,
    },
  ]);

  const handleReviewerChange = (index, field, value) => {
    const updatedFields = [...reviewerFields];
    updatedFields[index][field] = value;
    setReviewerFields(updatedFields);

    if (field === "reviewer" && value) {
      updatedFields[index].error = false;
    }

    const durations = getEndDate(selectedOptions, typeofwork); // Pass type_of_work

    setFormData((prevData) => ({
      ...prevData,
      project_duration: durations.project_duration,
      writerprojectduration: durations.writer_project_duration,
      reviewerProjectDuration: durations.reviewer_project_duration,
      statisticanprojectduration: durations.statistician_project_duration,
      journalprojectduration: durations.journal_project_duration,
    }));

    setReviewerFields((prevFields) =>
      prevFields.map((field, index) =>
        index === 0
          ? {
              ...field,
              reviewerProjectDuration: durations.reviewer_project_duration,
            }
          : field
      )
    );
  };

  const handleAddReviewerField = () => {
    const lastEntry = reviewerFields[reviewerFields.length - 1];
    const durations = getEndDate(selectedOptions, typeofwork);
    if (!lastEntry.reviewer) {
      const updatedFields = [...reviewerFields];
      updatedFields[reviewerFields.length - 1].error = true;
      setReviewerFields(updatedFields);
      return;
    }

    setReviewerFields([
      ...reviewerFields,
      {
        reviewerid: "",
        reviewer: "",
        reviewerAssignedDate: getTodayDate() || "",
        reviewerStatus: "to_do",
        reviewerStatusDate: getTodayDate() || "",
        reviewerProjectDuration:
          durations.reviewerProjectDuration || getTodayDate(),
        reviewer_comment: "",
      },
    ]);
  };
  // const handleDeleteReviewerField = async (index, reviewerid) => {
  //   Swal.fire({
  //     title: "Are you sure?",
  //     text: "This action will permanently delete the reviewer!",
  //     icon: "warning",
  //     showCancelButton: true,
  //     confirmButtonColor: "#d33",
  //     cancelButtonColor: "#3085d6",
  //     confirmButtonText: "Yes, delete it!",
  //     cancelButtonText: "Cancel",
  //   }).then(async (result) => {
  //     if (result.isConfirmed) {
  //       try {
  //         const response = await fetch(
  //           `${API_URL}/api/entry_process/project_assign_delete/${reviewerid}`,
  //           {
  //             method: "DELETE",
  //           }
  //         );

  //         if (response.ok) {
  //           // Remove the item from state after successful deletion
  //           const updatedFields = reviewerFields.filter((_, i) => i !== index);
  //           setReviewerFields(updatedFields);

  //           Swal.fire("Deleted!", "The reviewer has been deleted.", "success");
  //         } else {
  //           Swal.fire("Error!", "Failed to delete the reviewer.", "error");
  //         }
  //       } catch (error) {
  //         console.error("Error deleting reviewer:", error);
  //         Swal.fire("Error!", "Something went wrong.", "error");
  //       }
  //     }
  //   });
  // };

  // statistican
  const handleDeleteReviewerField = (index) => {
    const updatedFields = reviewerFields.filter((_, i) => i !== index);
    setReviewerFields(updatedFields);
  };

  const [statisticanFields, setStatisticanFields] = useState([
    {
      statisticanid: "",
      statistican: "",
      statisticanAssignedDate: getTodayDate() || "",
      statisticanStatus: "to_do",
      statisticanStatusDate: getTodayDate() || "",
      statisticanProjectDuration:
        formData.statisticanprojectduration || getTodayDate(),
      statistican_comment: "",
      error: false,
    },
  ]);

  const handleStatisticanChange = (index, field, value) => {
    const updatedFields = [...statisticanFields];
    updatedFields[index][field] = value;
    setStatisticanFields(updatedFields);

    if (field === "statistican" && value) {
      updatedFields[index].error = false;
    }

    const durations = getEndDate(selectedOptions, typeofwork); // Pass type_of_work

    setFormData((prevData) => ({
      ...prevData,
      project_duration: durations.project_duration,
      writerprojectduration: durations.writer_project_duration,
      reviewerProjectDuration: durations.reviewer_project_duration,
      statisticanprojectduration: durations.statistician_project_duration,
      journalprojectduration: durations.journal_project_duration,
    }));

    setStatisticanFields((prevFields) =>
      prevFields.map((field, index) =>
        index === 0
          ? {
              ...field,
              statisticanProjectDuration:
                durations.statistician_project_duration,
            }
          : field
      )
    );
  };

  const handleAddStatisticanField = () => {
    const lastEntry = statisticanFields[statisticanFields.length - 1];
    const durations = getEndDate(selectedOptions, typeofwork);
    if (!lastEntry.statistican) {
      const updatedFields = [...statisticanFields];
      updatedFields[statisticanFields.length - 1].error = true;
      setStatisticanFields(updatedFields);
      return;
    }

    setStatisticanFields([
      ...statisticanFields,
      {
        statisticanid: "",
        statistican: "",
        statisticanAssignedDate: getTodayDate() || "",
        statisticanStatus: "to_do",
        statisticanStatusDate: getTodayDate() || "",
        statisticanProjectDuration:
          durations.statisticanprojectduration || getTodayDate(),
        statistican_comment: "",
      },
    ]);
  };

  const handleDeleteStatisticanField = (index) => {
    const updatedFields = statisticanFields.filter((_, i) => i !== index);
    setStatisticanFields(updatedFields);
  };

  // const handleDeleteStatisticanField = async (index, statisticianId) => {
  //   Swal.fire({
  //     title: "Are you sure?",
  //     text: "This action will permanently delete the statistician!",
  //     icon: "warning",
  //     showCancelButton: true,
  //     confirmButtonColor: "#d33",
  //     cancelButtonColor: "#3085d6",
  //     confirmButtonText: "Yes, delete it!",
  //     cancelButtonText: "Cancel",
  //   }).then(async (result) => {
  //     if (result.isConfirmed) {
  //       try {
  //         const response = await fetch(
  //           `${API_URL}/api/entry_process/project_assign_delete/${statisticianId}`,
  //           {
  //             method: "DELETE",
  //           }
  //         );

  //         if (response.ok) {
  //           // Remove the statistician from the state after successful deletion
  //           const updatedFields = statisticanFields.filter(
  //             (_, i) => i !== index
  //           );
  //           setStatisticanFields(updatedFields);

  //           Swal.fire(
  //             "Deleted!",
  //             "The statistician has been deleted.",
  //             "success"
  //           );
  //         } else {
  //           Swal.fire("Error!", "Failed to delete the statistician.", "error");
  //         }
  //       } catch (error) {
  //         console.error("Error deleting statistician:", error);
  //         Swal.fire("Error!", "Something went wrong.", "error");
  //       }
  //     }
  //   });
  // };

  //journal

  const handleJournalChange = (index, field, value) => {
    const updatedFields = [...journalFields];
    updatedFields[index][field] = value;
    setJournalFields(updatedFields);

    if (field === "journal" && value) {
      updatedFields[index].error = false;
    }

    const durations = getEndDate(selectedOptions, typeofwork); // Pass type_of_work

    setFormData((prevData) => ({
      ...prevData,
      project_duration: durations.project_duration,
      writerprojectduration: durations.writer_project_duration,
      reviewerProjectDuration: durations.reviewer_project_duration,
      statisticanprojectduration: durations.statistician_project_duration,
      journalprojectduration: durations.journal_project_duration,
    }));

    setJournalFields((prevFields) =>
      prevFields.map((field, index) =>
        index === 0
          ? {
              ...field,
              journalProjectDuration: durations.journal_project_duration,
            }
          : field
      )
    );
  };

  const handleAddJournalField = () => {
    const lastEntry = journalFields[journalFields.length - 1];

    if (!lastEntry.journal) {
      const updatedFields = [...journalFields];
      updatedFields[journalFields.length - 1].error = true;
      setJournalFields(updatedFields);
      return;
    }

    setJournalFields([
      ...journalFields,
      {
        journalid: "",
        journal: "",
        journalAssignedDate: getTodayDate() || "",
        journalStatus: "",
        journalStatusDate: getTodayDate() || "",
        journalProjectDuration:
          formData.journalprojectduration || getTodayDate(),
        journal_comment: "",
        typeofarticle: "",
        review: "",
        error: false,
      },
    ]);
  };
  const handleDeleteJournalField = (index) => {
    const updatedFields = journalFields.filter((_, i) => i !== index);
    setJournalFields(updatedFields);
  };

  //end

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;
  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    if (showWriter || showReviewer || showStatistican || showJournal) {
      if (Object.keys(validationErrors).length > 0) {
        setErrors(validationErrors);
        return;
      }
    }

    const formattedWriterDatas = writerFields.some((writer) => writer.writer)
      ? writerFields.map((writer) => ({
          writerid: writer.writerid,
          writer: writer.writer,
          writerDate: writer.writerDate,
          writerStatus: writer.writerStatus,
          writerStatusDate: writer.writerStatusDate,
          writerprojectduration: writer.writerprojectduration,
          writer_comment: writer.writer_comment,
          error: writer.error,
        }))
      : [];

    const formattedReviewerDatas = reviewerFields.some(
      (reviewer) => reviewer.reviewer
    )
      ? reviewerFields.map((reviewer) => ({
          reviewerid: reviewer.reviewerid,
          reviewer: reviewer.reviewer,
          reviewerAssignedDate: reviewer.reviewerAssignedDate,
          reviewerStatus: reviewer.reviewerStatus,
          reviewerStatusDate: reviewer.reviewerStatusDate,
          reviewerProjectDuration: reviewer.reviewerProjectDuration,
          reviewer_comment: reviewer.reviewer_comment,
          error: reviewer.error,
        }))
      : [];

    const formattedStatisticanDatas = statisticanFields.some(
      (statistican) => statistican.statistican
    )
      ? statisticanFields.map((statistican) => ({
          statisticanid: statistican.statisticanid,
          statistican: statistican.statistican,
          statisticanAssignedDate: statistican.statisticanAssignedDate,
          statisticanStatus: statistican.statisticanStatus,
          statisticanStatusDate: statistican.statisticanStatusDate,
          statisticanProjectDuration: statistican.statisticanProjectDuration,
          statistican_comment: statistican.statistican_comment,
          error: statistican.error,
        }))
      : [];

    const formattedJournalDatas = journalFields.some(
      (journal) => journal.journal
    )
      ? journalFields.map((journal) => ({
          journalid: journal.journalid,
          journal: journal.journal,
          journalAssignedDate: journal.journalAssignedDate,
          journalStatus: journal.journalStatus,
          journalStatusDate: journal.journalStatusDate,
          journalProjectDuration: journal.journalProjectDuration,
          journal_comment: journal.journal_comment,
          type_of_article: journal.typeofarticle,
          review: journal.review,
          error: journal.error,
        }))
      : [];

    console.log("formattedJournalDatas", formattedJournalDatas);

    const backendFormData = {
      entry_date: formData.entrydate,
      title: formData.title,
      type_of_work: typeofwork,
      project_id: customId,
      client_name: formData.clientName,
      email: formData.email,
      contact_number: formData.contactNo,
      institute: formData.institute,
      department: formData.department,
      profession: formData.profession,
      budget: formData.budget,
      process_status: formData.processStatus,
      process_date: formData.processStatusDate,
      hierarchy_level: formData.hierarchy,
      comment_box: commentval || "",
      else_project_manager: formData.else_project_manager,
      entryprocess_documents: formFields.filter(
        (field) => field.specificOption || field.file
      ),
      created_by: createdby,
      comment_box: formData.commandbox,
      project_duration: formData.project_duration,
      writer: formattedWriterDatas,
      reviewer: formattedReviewerDatas,
      statistican: formattedStatisticanDatas,
      journal: formattedJournalDatas,
      payment_details: paymentFields,
      payment_id: payment_id,
      payment_status: formData.payment_status,
    };

    console.log("check backendFormData", backendFormData);

    document.getElementById("global-loader").style.display = "flex";

    setTimeout(async () => {
      try {
        const response = await axios.post(
          `${API_URL}/api/entry_process/update/${rowId}`,
          backendFormData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );

        if (response.status === 200 || response.status === 201) {
          // Navigate to the "entry-process" route
          Swal.fire({
            icon: "success",
            title: "Success!",
            text: "Your form has been updated successfully.",
            confirmButtonText: "OK",
          });
          // navigate("/entry-process/process-view-details");
          navigate("/entry-process/process-view-details", {
            state: { rowId },
          });
        } else {
          console.error("Error occurred:", response.statusText);
        }
      } catch (error) {
        console.error("Submission error:", error);
      } finally {
        document.getElementById("global-loader").style.display = "none";
      }
    }, 500);
  };

  // rename popup
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [currentFileId, setCurrentFileId] = useState(null);
  const [newFileName, setNewFileName] = useState("");
  const [originalFileName, setNewFileOrgName] = useState("");

  // Toggle the popup and store file id and file name
  const togglePopup = (fileid = null, filename = "") => {
    const nameWithoutExtension =
      filename.substring(0, filename.lastIndexOf(".")) || filename;

    setIsPopupOpen((prevState) => !prevState); // Toggle the popup
    setCurrentFileId(fileid || null); // Set the file ID
    setNewFileName(nameWithoutExtension || ""); // Set the file name
    setNewFileOrgName(filename || "");
  };

  // Handle input change
  const handleInputChange = (e) => {
    setNewFileName(e.target.value); // Update state as user types
  };

  // Handle save button click
  const handleSave = async (e) => {
    e.preventDefault();
    const extension = originalFileName.split(".").pop();
    try {
      const response = await axios.post(
        `${API_URL}/api/entry_process/document-rename/${currentFileId}`,
        {
          name: newFileName,
          filename: newFileName,
          extension: extension,
        }
      );

      setIsPopupOpen(false);
      const updatedFiles = files.map((file) =>
        file.id === currentFileId ? { ...file, title: newFileName } : file
      );
      setFiles(updatedFiles);
    } catch (error) {
      console.error("Error while renaming file:", error);
    }
  };
  // select file

  const dropselectRef = useRef(null);
  const handleClickOutsideselect = (event) => {
    if (
      isDropdowncheck &&
      dropselectRef.current &&
      !dropselectRef.current.contains(event.target)
    ) {
      setIsDropdowncheck(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutsideselect);
    return () => {
      document.removeEventListener("mousedown", handleClickOutsideselect);
    };
  }, [isDropdowncheck]);

  // institute use ref
  const dropdownRef = useRef(null);

  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setIsDropdownOpen(false); // Close dropdown when clicking outside
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);
  //  department ref

  const dropdepRef = useRef(null);

  const handleClickdep = (event) => {
    if (
      isListExpanded &&
      dropdepRef.current &&
      !dropdepRef.current.contains(event.target)
    ) {
      setListExpanded(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickdep);
    return () => {
      document.removeEventListener("mousedown", handleClickdep);
    };
  }, [isListExpanded]);

  // profession

  const dropprofRef = useRef(null);
  const handleClickprof = (event) => {
    if (
      isDropdownVisible &&
      dropprofRef.current &&
      !dropprofRef.current.contains(event.target)
    ) {
      setDropdownVisible(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickprof);
    return () => {
      document.removeEventListener("mousedown", handleClickprof);
    };
  }, [isDropdownVisible]);

  // list of delete

  const handlelistfileDelete = (fieldIndex, fileIndex) => {
    setFormFields((prevFields) => {
      const updatedFields = [...prevFields];
      updatedFields[fieldIndex].file = updatedFields[fieldIndex].file.filter(
        (_, idx) => idx !== fileIndex
      );
      return updatedFields;
    });
  };

  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const handlePopupVisible = () => {
    setIsPopupVisible((prev) => !prev);
  };
  const handleCancel = () => {
    setIsPopupVisible(false);
  };
  // enter click
  useEffect(() => {
    const listener = (event) => {
      if (event.code === "Enter" || event.code === "NumpadEnter") {
        console.log("Enter key was pressed. Run your function.");
        event.preventDefault();
        // callMyFunction();
      }
    };
    document.addEventListener("keydown", listener);
    return () => {
      document.removeEventListener("keydown", listener);
    };
  }, []);

  // useEffect(() => {
  //   const timer = setTimeout(() => {
  //     setLoading(false);
  //   }, 1000);

  //   return () => clearTimeout(timer);
  // }, []);

  // if (loading) {
  //   return <Loader />;
  // }

  const removeEmptyTags = (html) => {
    const div = document.createElement("div");
    div.innerHTML = html;

    const elements = div.querySelectorAll("*");
    elements.forEach((element) => {
      if (!element.innerHTML.trim()) {
        element.remove(); // Remove empty elements
      }
    });

    return div.innerHTML;
  };

  return (
    <>
      <section className="container">
        <div className="row mt-4">
          {/* <div className=" col-1 d-flex justify-content-center">
            <Sider></Sider>
          </div> */}
          <div className="col-12">
            <div className="col-12">
              <Header></Header>
            </div>

            <div className="col-12 pt-1  wapper w-100 mt-3  ">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className=" col-12 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>
              {loading ? (
                <Loader />
              ) : (
                <div className="row w-100 mt-0 px-3 ">
                  {rolename !== "14" && rolename !== "28" && (
                    <>
                      <div className="col-12  d-flex flex-wrap justify-content-between">
                        <div className="col-12 col-md-4 d-flex flex-column">
                          <div className="col-md-12 float-start  ">
                            <label className="client-name-pop mx-2 ">
                              Enter Details
                            </label>
                          </div>
                          <div className="col-12 col-md-8 pt-4   ">
                            <label className="statis-name  mx-2">
                              Entry Date
                            </label>
                            <input
                              type="date"
                              className={`form-control ${
                                errors.entryDateType ? "error" : ""
                              }`}
                              name="entrydate"
                              value={formData.entrydate}
                              onChange={handleChange}
                              // // required
                            />
                          </div>

                          <div className="col-12 col-md-8 pt-2  float-start ">
                            <label className="statis-name">Type of Work</label>
                            <select
                              className={`form-select`}
                              name="typeofwork"
                              value={typeofwork}
                              onChange={handleTypeOfWorkChange}
                              // // required
                            >
                              <option value="" disabled>
                                Select an option
                              </option>
                              <option value="statistics">Statistics</option>
                              <option value="manuscript">Manuscript</option>
                              <option value="thesis">Thesis</option>
                              {/* <option value="presentation">Presentation</option> */}
                              <option value="others">Others</option>
                            </select>
                          </div>

                          <div className="col-12 col-md-8 pt-2  float-start  ">
                            <label className="statis-name ">Project ID</label>
                            <input
                              className={`form-control`}
                              name="project_id"
                              id="project_id"
                              value={Capitalize(customId)}
                              placeholder="Enter the Project Id"
                              onChange={handleChange}
                              // // required
                            />
                          </div>

                          <div className=" col-12 col-md-8 pt-2  float-start  ">
                            <label className="statis-name ">Title</label>
                            <input
                              type="text"
                              className={`form-control`}
                              name="title"
                              placeholder="Enter the Title"
                              value={Capitalize(formData.title)}
                              onChange={handleChange}
                              // // required
                            />
                          </div>

                          {formFields.map((formData, index) => (
                            <div className="mt-2" key={index}>
                              <div className="col-12 col-md-8">
                                {index === 0 && (
                                  <>
                                    <label className="statis-name">
                                      Project Requirement
                                    </label>
                                    {typeofwork === "others" ? (
                                      <input
                                        type="text"
                                        className={`form-control ${
                                          errors[`specificOption_${index}`]
                                            ? "error"
                                            : ""
                                        }`}
                                        name="specificOption"
                                        value={formData.specificOption}
                                        onChange={(e) => {
                                          handleSpecificChange(e, index);
                                          // Remove validation error for this specific field
                                          const updatedErrors = { ...errors };
                                          delete updatedErrors[
                                            `specificOption_${index}`
                                          ];
                                          setErrors(updatedErrors); // Assuming setErrors is your function to manage errors state
                                        }}
                                        placeholder="Enter Others Option"
                                        // required
                                      />
                                    ) : (
                                      <div
                                        ref={dropselectRef}
                                        className={`dropdown-container position-relative ${
                                          isDropdowncheck ? "open" : ""
                                        } ${
                                          errors[`specificOption_${index}`]
                                            ? "error"
                                            : ""
                                        }`}
                                      >
                                        <div
                                          className="form-select"
                                          tabIndex={0} // Makes it focusable
                                          onClick={toggleDropcheck}
                                          onKeyDown={(e) => {
                                            if (
                                              e.key === "Enter" ||
                                              e.key === "Tab"
                                            ) {
                                              e.preventDefault();
                                              setIsDropdowncheck(true);
                                              setTimeout(() => {
                                                document
                                                  .querySelector(
                                                    ".dropdown-list label:first-child input"
                                                  )
                                                  ?.focus();
                                              }, 0);
                                            }
                                          }}
                                        >
                                          {formData.specificOption?.length > 0
                                            ? formData.specificOption.join(", ")
                                            : "Select specific options"}
                                        </div>

                                        {isDropdowncheck && (
                                          <div className="dropdown-list">
                                            {optionsMapping[typeofwork]?.map(
                                              (option) => (
                                                <label
                                                  key={option.value}
                                                  className="checkbox-label"
                                                >
                                                  <input
                                                    type="checkbox"
                                                    value={option.value}
                                                    checked={
                                                      formData.specificOption?.includes(
                                                        option.value
                                                      ) || false
                                                    }
                                                    tabIndex={0}
                                                    onChange={(e) => {
                                                      const updatedSelections =
                                                        e.target.checked
                                                          ? [
                                                              ...(formData.specificOption ||
                                                                []),
                                                              option.value,
                                                            ]
                                                          : formData.specificOption.filter(
                                                              (val) =>
                                                                val !==
                                                                option.value
                                                            );

                                                      handleSpecificChange(
                                                        {
                                                          target: {
                                                            name: "specificOption",
                                                            value:
                                                              updatedSelections,
                                                          },
                                                        },
                                                        index
                                                      );

                                                      // Remove validation error for this field
                                                      const updatedErrors = {
                                                        ...errors,
                                                      };
                                                      delete updatedErrors[
                                                        `specificOption_${index}`
                                                      ];
                                                      setErrors(updatedErrors);
                                                    }}
                                                    onKeyDown={(e) => {
                                                      if (
                                                        e.key === "Enter" ||
                                                        e.key === " "
                                                      ) {
                                                        e.preventDefault();
                                                        e.target.click(); // Select the option
                                                      } else if (
                                                        e.key === "ArrowDown"
                                                      ) {
                                                        e.preventDefault();
                                                        e.target.parentElement.nextElementSibling
                                                          ?.querySelector(
                                                            "input"
                                                          )
                                                          ?.focus();
                                                      } else if (
                                                        e.key === "ArrowUp"
                                                      ) {
                                                        e.preventDefault();
                                                        e.target.parentElement.previousElementSibling
                                                          ?.querySelector(
                                                            "input"
                                                          )
                                                          ?.focus();
                                                      } else if (
                                                        e.key === "Tab"
                                                      ) {
                                                        if (
                                                          !e.target
                                                            .parentElement
                                                            .nextElementSibling
                                                        ) {
                                                          setIsDropdowncheck(
                                                            false
                                                          ); // Close dropdown on last option
                                                        }
                                                      }
                                                    }}
                                                  />
                                                  {option.label}
                                                </label>
                                              )
                                            )}
                                          </div>
                                        )}
                                      </div>
                                    )}
                                  </>
                                )}
                              </div>

                              <div className="col-12 col-md-8 mt-1">
                                <label className="statis-name">File</label>
                                <div
                                  className={`form-control d-flex justify-content-end ${
                                    errors[`file_${index}`] ? "error" : ""
                                  }`}
                                >
                                  <input
                                    type="file"
                                    accept="file/*"
                                    multiple
                                    // onChange={(e) => handleFileChange(index, e)}
                                    onChange={(e) => {
                                      handleFileChange(index, e);
                                      // Remove validation error for this file field
                                      const updatedErrors = { ...errors };
                                      delete updatedErrors[`file_${index}`];
                                      setErrors(updatedErrors); // Assuming setErrors is your function to manage errors state
                                      e.target.value = null;
                                    }}
                                    className="file-upload-input"
                                  />
                                  {formData.file && (
                                    <RiDeleteBin6Line
                                      className="file-del-icon"
                                      onClick={() => handleFileDelete(index)}
                                    />
                                  )}
                                  {!formData.file && (
                                    <label className="file-icon">
                                      <PiCloudArrowUpLight />
                                    </label>
                                  )}
                                </div>

                                {/* {errors[index]?.file && (
                                            <p className="text-danger">{errors[index].file}</p>
                                          )} */}
                              </div>
                              {formFields[index].file &&
                                formFields[index].file.length > 0 && (
                                  <div className="px-1 col-12 ">
                                    {formFields[index].file.map(
                                      (file, fileIndex) => (
                                        <div>
                                          <MdOutlineCancel
                                            className="cancel-list  mx-1"
                                            onClick={() =>
                                              handlelistfileDelete(
                                                index,
                                                fileIndex
                                              )
                                            }
                                          />
                                          {file.name}
                                        </div>
                                      )
                                    )}
                                  </div>
                                )}

                              <div className="col d-flex justify-content-start  mt-2">
                                {/* {index === 0 && (
                            <button
                              type="button"
                              className="save-form-add mt-1"
                              onClick={handleAddField}
                            >
                              Add +
                            </button>
                          )} */}
                                {index !== 0 && (
                                  <button
                                    type="button"
                                    className="save-form-del mt-1"
                                    onClick={() => handleDeleteField(index)}
                                  >
                                    Delete
                                  </button>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="col-12 col-md-8 d-flex flex-column ">
                          <div className="col-md-12 float-start">
                            <label className="client-name-pop">
                              Client Information
                            </label>
                          </div>
                          <div className=" row mt-4">
                            <div className="col-6">
                              <div className="col-12 col-md-10 float-start  ">
                                <label className="statis-name ">
                                  Client Name
                                </label>
                                <input
                                  type="text"
                                  className={`form-control  ${
                                    errors.clientName ? "error" : ""
                                  }`}
                                  name="clientName"
                                  placeholder="Enter the name"
                                  autoComplete="off"
                                  value={Capitalize(formData.clientName)}
                                  onChange={handleChange}
                                  // // required
                                />
                              </div>
                              <div className="col-12 col-md-10 float-start pt-2">
                                <label className="statis-name  ">
                                  Email ID
                                </label>

                                <input
                                  type="email"
                                  className={`form-control ${
                                    errors.email ? "error" : ""
                                  }`}
                                  name="email"
                                  placeholder="Enter the Email"
                                  autoComplete="off"
                                  value={formData.email}
                                  onChange={(e) => {
                                    handleChange(e);
                                    // if (e.key !== 'Tab') {
                                    validateForm(e.target.value);
                                    // }
                                  }}
                                  onBlur={(e) => {
                                    setFormErrors((prevErrors) => ({
                                      ...prevErrors,
                                      email: "",
                                    }));
                                  }}
                                />
                                {formErrors.email && (
                                  <div className="error-text">
                                    {formErrors.email}
                                  </div>
                                )}
                              </div>

                              <div className="col-12 col-md-10 float-start pt-2">
                                <label className="statis-name  ">
                                  Contact No
                                </label>
                                <input
                                  type="number"
                                  className={`form-control ${
                                    errors.contactNo ? "error" : ""
                                  }`}
                                  placeholder="Enter the Contact No"
                                  name="contactNo"
                                  value={formData.contactNo}
                                  autoComplete="off"
                                  onChange={(e) => {
                                    handleChange(e); // Update form data
                                    validateForm(e.target.value);
                                  }}
                                  onBlur={(e) => {
                                    setFormErrors((prevErrors) => ({
                                      ...prevErrors,
                                      contactNo: "",
                                    }));
                                  }}
                                />
                                {formErrors.contactNo && (
                                  <div className="error-text">
                                    {formErrors.contactNo}
                                  </div>
                                )}
                              </div>
                              <div className="col-12 col-md-10 float-start pt-2">
                                <label className="statis-name ">
                                  Institute
                                </label>
                                <div className="d-flex  gap-2">
                                  <div
                                    className="dropdown-container position-relative"
                                    ref={dropdownRef}
                                  >
                                    <input
                                      type="text"
                                      className={`form-control dropdown-search-header ${
                                        errors.institute ? "error" : ""
                                      }`}
                                      placeholder="Search Institute..."
                                      value={
                                        searchQuery || selectedOption.name || ""
                                      }
                                      onChange={(e) => {
                                        const value = e.target.value;
                                        if (value === "") {
                                          setSelectedOption({}); // Clear selected option on empty input
                                        }
                                        setSearchQuery(value);
                                        setIsDropdownOpen(true); // Open dropdown on typing
                                      }}
                                      onClick={toggleDropdowninstitue}
                                      onKeyDown={(e) => {
                                        if (
                                          e.key === "Enter" ||
                                          e.key === "Tab"
                                        ) {
                                          e.preventDefault();
                                          setIsDropdownOpen(true);
                                          setTimeout(() => {
                                            document
                                              .querySelector(
                                                ".dropdown-option:first-child"
                                              )
                                              ?.focus();
                                          }, 0);
                                        } else if (e.key === "ArrowDown") {
                                          e.preventDefault();
                                          document
                                            .querySelector(
                                              ".dropdown-option:first-child"
                                            )
                                            ?.focus();
                                        }
                                      }}
                                      tabIndex={0} // Make input focusable via Tab
                                      onBlur={(e) => {
                                        if (
                                          !dropdownRef.current.contains(
                                            e.relatedTarget
                                          )
                                        ) {
                                          setIsDropdownOpen(false);
                                        }
                                      }}
                                    />

                                    {isDropdownOpen && (
                                      <div className="dropdown position-absolute">
                                        <div className="dropdown-options">
                                          {filteredOptions.length > 0 ? (
                                            filteredOptions.map(
                                              (option, index) => (
                                                <div
                                                  key={option.id}
                                                  className="dropdown-option"
                                                  tabIndex={0} // Make dropdown options focusable
                                                  onClick={() => {
                                                    handleSelectOption(
                                                      option.id,
                                                      option.name
                                                    );
                                                    setFormData({
                                                      ...formData,
                                                      institute: option.id,
                                                    });
                                                    setErrors({
                                                      ...errors,
                                                      institute: "",
                                                    });
                                                    setSearchQuery("");
                                                    setIsDropdownOpen(false);
                                                    setTimeout(() => {
                                                      document.activeElement.nextElementSibling?.focus(); // Move to next input field
                                                    }, 0);
                                                  }}
                                                  onKeyDown={(e) => {
                                                    if (e.key === "Enter") {
                                                      e.preventDefault();
                                                      handleSelectOption(
                                                        option.id,
                                                        option.name
                                                      );
                                                      setFormData({
                                                        ...formData,
                                                        institute: option.id,
                                                      });
                                                      setErrors({
                                                        ...errors,
                                                        institute: "",
                                                      });
                                                      setSearchQuery("");
                                                      setIsDropdownOpen(false);
                                                      setTimeout(() => {
                                                        document.activeElement.nextElementSibling?.focus(); // Move to next input field
                                                      }, 0);
                                                    } else if (
                                                      e.key === "ArrowDown"
                                                    ) {
                                                      e.preventDefault();
                                                      e.target.nextElementSibling?.focus();
                                                    } else if (
                                                      e.key === "ArrowUp"
                                                    ) {
                                                      e.preventDefault();
                                                      e.target.previousElementSibling?.focus();
                                                    } else if (
                                                      e.key === "Tab"
                                                    ) {
                                                      if (
                                                        !e.target
                                                          .nextElementSibling
                                                      ) {
                                                        setIsDropdownOpen(
                                                          false
                                                        );
                                                        setTimeout(() => {
                                                          document.activeElement.nextElementSibling?.focus(); // Move to next input field
                                                        }, 0);
                                                      }
                                                    }
                                                  }}
                                                >
                                                  {option.name}
                                                </div>
                                              )
                                            )
                                          ) : (
                                            <div
                                              className="dropdown-no-options"
                                              tabIndex={0}
                                            >
                                              No options found
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    )}
                                  </div>

                                  <div className="">
                                    <Tooltip title="Refresh">
                                      <IoMdRefreshCircle
                                        className="mt-0 refe-button"
                                        onClick={fetchRoles}
                                        title="Refresh Institute"
                                      />
                                    </Tooltip>
                                  </div>
                                </div>

                                <Link to="/modula-institution" target="_blank">
                                  <span className="mx-1">Add Institute</span>
                                </Link>
                              </div>

                              <div className="col-12 col-md-10 float-start pt-2">
                                <label className="statis-name  ">
                                  Department
                                </label>
                                <div className="d-flex gap-2 ">
                                  <div
                                    className="dropdown-container position-relative"
                                    ref={dropdepRef}
                                  >
                                    <input
                                      type="text"
                                      className={`form-control dropdown-search-header ${
                                        errors.department ? "error" : ""
                                      }`}
                                      placeholder="Search Department..."
                                      value={
                                        searchInput || chosenOption.name || ""
                                      }
                                      onChange={(e) => {
                                        const value = e.target.value;
                                        if (value === "") {
                                          setChosenOption({});
                                        }
                                        setSearchInput(value);
                                        setListExpanded(true); // Open dropdown when typing
                                      }}
                                      onClick={() => setListExpanded(true)}
                                      onKeyDown={(e) => {
                                        if (
                                          e.key === "Tab" ||
                                          e.key === "Enter"
                                        ) {
                                          e.preventDefault();
                                          setListExpanded(true);
                                          setTimeout(() => {
                                            document
                                              .querySelector(
                                                ".dropdown-option:first-child"
                                              )
                                              ?.focus();
                                          }, 0);
                                        } else if (e.key === "ArrowDown") {
                                          e.preventDefault();
                                          document
                                            .querySelector(
                                              ".dropdown-option:first-child"
                                            )
                                            ?.focus();
                                        }
                                      }}
                                      tabIndex={0}
                                      onBlur={(e) => {
                                        if (
                                          !dropdepRef.current.contains(
                                            e.relatedTarget
                                          )
                                        ) {
                                          setListExpanded(false);
                                        }
                                      }}
                                    />

                                    {isListExpanded && (
                                      <div className="dropdown position-absolute">
                                        <div className="dropdown-options">
                                          {filtereddepOptions.length > 0 ? (
                                            filtereddepOptions.map(
                                              (option, index) => (
                                                <div
                                                  key={option.id}
                                                  className="dropdown-option"
                                                  tabIndex={0} // Make dropdown options focusable
                                                  onClick={() => {
                                                    handledepOptionSelect(
                                                      option.id,
                                                      option.name
                                                    );
                                                    setFormData({
                                                      ...formData,
                                                      department: option.id,
                                                    });
                                                    setErrors({
                                                      ...errors,
                                                      department: "",
                                                    });
                                                    setSearchInput("");
                                                    setListExpanded(false);
                                                    setTimeout(() => {
                                                      document.activeElement.nextElementSibling?.focus(); // Move to next field
                                                    }, 0);
                                                  }}
                                                  onKeyDown={(e) => {
                                                    if (e.key === "Enter") {
                                                      e.preventDefault();
                                                      handledepOptionSelect(
                                                        option.id,
                                                        option.name
                                                      );
                                                      setFormData({
                                                        ...formData,
                                                        department: option.id,
                                                      });
                                                      setErrors({
                                                        ...errors,
                                                        department: "",
                                                      });
                                                      setSearchInput("");
                                                      setListExpanded(false);
                                                      setTimeout(() => {
                                                        document.activeElement.nextElementSibling?.focus();
                                                      }, 0);
                                                    } else if (
                                                      e.key === "ArrowDown"
                                                    ) {
                                                      e.preventDefault();
                                                      e.target.nextElementSibling?.focus();
                                                    } else if (
                                                      e.key === "ArrowUp"
                                                    ) {
                                                      e.preventDefault();
                                                      e.target.previousElementSibling?.focus();
                                                    } else if (
                                                      e.key === "Tab"
                                                    ) {
                                                      if (
                                                        !e.target
                                                          .nextElementSibling
                                                      ) {
                                                        setListExpanded(false);
                                                        setTimeout(() => {
                                                          document.activeElement.nextElementSibling?.focus();
                                                        }, 0);
                                                      }
                                                    }
                                                  }}
                                                >
                                                  {option.name}
                                                </div>
                                              )
                                            )
                                          ) : (
                                            <div
                                              className="dropdown-no-options"
                                              tabIndex={0}
                                            >
                                              No options found
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                  <div className="">
                                    <IoMdRefreshCircle
                                      className=" refe-button"
                                      onClick={fetchDepartments}
                                      title="Refresh Department"
                                    />
                                  </div>
                                </div>
                                <Link to="/modula-department" target="_blank">
                                  <span className="mx-1">Add Department</span>
                                </Link>
                              </div>
                              <div className=" col-12 col-md-10 float-start  pt-2">
                                <label className="statis-name ">
                                  Profession
                                </label>
                                {/* input */}
                                <div className="d-flex justify-content-between gap-2 ">
                                  <div
                                    className="dropdown-container position-relative"
                                    ref={dropprofRef}
                                  >
                                    <input
                                      type="text"
                                      className={`form-control dropdown-search-header ${
                                        errors.profession ? "error" : ""
                                      }`}
                                      placeholder="Search Profession..."
                                      value={query || currentChoice.name || ""}
                                      onChange={(e) => {
                                        const value = e.target.value;
                                        if (value === "") {
                                          setCurrentChoice({});
                                        }
                                        setQuery(value);
                                        setDropdownVisible(true); // Open dropdown when typing
                                      }}
                                      onClick={() => setDropdownVisible(true)}
                                      onKeyDown={(e) => {
                                        if (
                                          e.key === "Enter" ||
                                          e.key === "Tab"
                                        ) {
                                          e.preventDefault();
                                          setDropdownVisible(true);
                                          setTimeout(() => {
                                            document
                                              .querySelector(
                                                ".dropdown-option:first-child"
                                              )
                                              ?.focus();
                                          }, 0);
                                        } else if (e.key === "ArrowDown") {
                                          e.preventDefault();
                                          document
                                            .querySelector(
                                              ".dropdown-option:first-child"
                                            )
                                            ?.focus();
                                        }
                                      }}
                                      tabIndex={0}
                                      onBlur={(e) => {
                                        if (
                                          !dropprofRef.current.contains(
                                            e.relatedTarget
                                          )
                                        ) {
                                          setDropdownVisible(false);
                                        }
                                      }}
                                    />

                                    {isDropdownVisible && (
                                      <div className="dropdown position-absolute">
                                        <div className="dropdown-options">
                                          {filteredItems.length > 0 ? (
                                            filteredItems.map((item) => (
                                              <div
                                                key={item.id}
                                                className="dropdown-option"
                                                tabIndex={0}
                                                onClick={() => {
                                                  handleSelectItem(
                                                    item.id,
                                                    item.name
                                                  );
                                                  setFormData({
                                                    ...formData,
                                                    profession: item.id,
                                                  });
                                                  setErrors({
                                                    ...errors,
                                                    profession: "",
                                                  });
                                                  setQuery("");
                                                  setDropdownVisible(false);
                                                  setTimeout(() => {
                                                    document.activeElement.nextElementSibling?.focus(); // Move to next input field
                                                  }, 0);
                                                }}
                                                onKeyDown={(e) => {
                                                  if (e.key === "Enter") {
                                                    e.preventDefault();
                                                    handleSelectItem(
                                                      item.id,
                                                      item.name
                                                    );
                                                    setFormData({
                                                      ...formData,
                                                      profession: item.id,
                                                    });
                                                    setErrors({
                                                      ...errors,
                                                      profession: "",
                                                    });
                                                    setQuery("");
                                                    setDropdownVisible(false);
                                                    // document.querySelector(".dropdown-search-header")?.focus();
                                                  } else if (
                                                    e.key === "ArrowDown"
                                                  ) {
                                                    e.preventDefault();
                                                    e.target.nextElementSibling?.focus();
                                                  } else if (
                                                    e.key === "ArrowUp"
                                                  ) {
                                                    e.preventDefault();
                                                    e.target.previousElementSibling?.focus();
                                                  } else if (
                                                    e.key === "Escape"
                                                  ) {
                                                    setDropdownVisible(false);
                                                    // document.querySelector(".dropdown-search-header")?.focus();
                                                  }
                                                }}
                                              >
                                                {item.name}
                                              </div>
                                            ))
                                          ) : (
                                            <div
                                              className="dropdown-no-options"
                                              tabIndex={0}
                                            >
                                              No options found
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                  <div className="">
                                    <IoMdRefreshCircle
                                      className=" refe-button"
                                      onClick={fetchProfession}
                                      title="Refresh Profession"
                                    />
                                  </div>
                                </div>
                                <Link to="/modula-profession" target="_blank">
                                  <span className="mx-1">Add Profession</span>
                                </Link>
                              </div>
                            </div>
                            <div className="col-6">
                              <div className="col-12 col-md-10 float-start ">
                                <label className="statis-name ">Budget</label>
                                <input
                                  type="number"
                                  className={`form-control ${
                                    errors.budget ? "error" : ""
                                  }`}
                                  placeholder="Enter Budget"
                                  // name="contactNo"
                                  name="budget"
                                  value={formData.budget}
                                  onChange={handleChange}
                                  // // required
                                />
                              </div>

                              <div className="col-12 col-md-10 float-start  pt-2 ">
                                <label className="statis-name ">
                                  Process Status
                                </label>
                                <select
                                  className={`form-select  ${
                                    errors.processStatus ? "error" : ""
                                  }`}
                                  name="processStatus"
                                  value={formData.processStatus}
                                  onChange={handleChange}
                                  // // required
                                >
                                  <option value="" disabled selected>
                                    Select Process status
                                  </option>
                                  <option value="not_assigned">
                                    Not Assigned
                                  </option>
                                  <option value="pending_author">
                                    Pending - Author
                                  </option>
                                  <option value="completed">Completed</option>
                                  <option value="withdrawal">Withdrawn</option>
                                  <option value="in_progress">
                                    In Progress
                                  </option>
                                  <option value="client_review">
                                    Client Review
                                  </option>
                                </select>
                              </div>

                              <div className="col-12 col-md-10 float-start pt-2 ">
                                <label className="statis-name ">
                                  Process Status Date
                                </label>
                                <input
                                  type="date"
                                  className={`form-control ${
                                    errors.processStatusDate ? "error" : ""
                                  }`}
                                  name="processStatusDate"
                                  value={formData.processStatusDate}
                                  onChange={handleChange}
                                  // // required
                                />
                              </div>
                              <div className="col-12 col-md-10 float-start pt-2 ">
                                <label className="statis-name ">
                                  Project Completion Date
                                </label>
                                <input
                                  type="date"
                                  className={`form-control ${
                                    errors.project_duration ? "error" : ""
                                  }`}
                                  placeholder="Enter Duration"
                                  name="project_duration"
                                  value={formData.project_duration}
                                  // min={new Date().toISOString().split("T")[0]}
                                  onChange={(e) => {
                                    handleChange(e);
                                    if (errors.budget) {
                                      setErrors((prevErrors) => ({
                                        ...prevErrors,
                                        project_duration: "",
                                      }));
                                    }
                                  }}
                                  required
                                />
                              </div>

                              <div className="col-12 col-md-10 float-start pt-2 ">
                                <label className="statis-name ">
                                  Hierarchy Level
                                </label>
                                <select
                                  className={`form-select ${
                                    errors.hierarchy ? "error" : ""
                                  } ${
                                    formData.hierarchy === "urgent_important"
                                      ? "hierarchy-red"
                                      : formData.hierarchy ===
                                        "important_not_urgent"
                                      ? "hierarchy-yellow"
                                      : formData.hierarchy ===
                                        "urgent_not_important"
                                      ? "hierarchy-orange"
                                      : formData.hierarchy ===
                                        "not_urgent_not_important"
                                      ? "hierarchy-green"
                                      : ""
                                  }`}
                                  name="hierarchy"
                                  value={formData.hierarchy}
                                  onChange={handleChange}
                                  // // required
                                  aria-label="Priority hierarchy"
                                >
                                  <option value="" disabled>
                                    Select an option
                                  </option>
                                  <option value="urgent_important">
                                    Urgent/Important
                                  </option>
                                  <option value="important_not_urgent">
                                    Important/Not Urgent
                                  </option>
                                  <option value="urgent_not_important">
                                    Urgent/Not Important
                                  </option>
                                  <option value="not_urgent_not_important">
                                    Not Urgent/Not Important
                                  </option>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className=" col-12 col-md-8 pt-2  float-start  ">
                        <label className="statis-name ">
                          Project Requirement
                        </label>
                        <div className="px-2">
                          {CapitalizeCaseU(selecteddocuments)}
                        </div>
                      </div>

                      {/*  update document view */}
                      <div className=" mt-4">
                        <label className="statis-name ">Uploaded Files</label>
                        <div className="row g-1">
                          {files.map((file, index) => (
                            <div className="col-2" key={index}>
                              <div className="view-files  p-1">
                                <div>
                                  <AiOutlineClose
                                    className="file-cancel-icon"
                                    onClick={() => handleDelete(index, file.id)}
                                  />
                                  {/* <div className="text-center">
                                {getFileIcon(file.type)}
                              </div> */}
                                  <div className="d-flex justify-content-center gap-1 mt-3">
                                    <h5 className="text-center mt-2 file-title-card">
                                      {Capitalize(file.title)}
                                    </h5>
                                    <Tooltip title="Rename">
                                      <div
                                        className=""
                                        onClick={() =>
                                          togglePopup(file.id, file.title)
                                        }
                                      >
                                        <MdDriveFileRenameOutline className="icon-rename" />
                                      </div>
                                    </Tooltip>

                                    <Tooltip title="View">
                                      <button
                                        className="file-view-button1 mt-1"
                                        onClick={() =>
                                          window.open(file.url, "_blank")
                                        }
                                      >
                                        <VscEye />
                                      </button>
                                    </Tooltip>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}

                          {isPopupOpen && (
                            <div className="modal-container-view position-fixed">
                              <div className="modal-box">
                                <div className="d-flex justify-content-end">
                                  <span
                                    className="modal-close "
                                    onClick={() => togglePopup()}
                                  >
                                    &times;
                                  </span>
                                </div>
                                <div className="modal-body">
                                  <input
                                    type="text"
                                    className="form-control1"
                                    placeholder="Enter File Name"
                                    value={newFileName}
                                    onChange={handleInputChange}
                                  />
                                  <div className="d-flex justify-content-center mt-3">
                                    <button
                                      className="mt-2 file-view-button"
                                      onClick={handleSave}
                                    >
                                      Save
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </>
                  )}

                  <div class="row p-4">
                    <div className="col d-flex gap-1">
                      <input
                        type="checkbox"
                        id="project"
                        onClick={handleProjectClick}
                        checked={formData.else_project_manager}
                        className=""
                        disabled={formData.processStatus === "not_assigned"}
                      />
                      <label className="statis-name1 " htmlFor="project">
                        Assign Process.
                      </label>
                    </div>
                  </div>
                  {formData.else_project_manager && (
                    <>
                      <div className="gap-3 px-4 d-flex  flex-wrap">
                        {/* {['manuscript', 'thesis', 'presentation', 'others'].includes(typeofwork) && ( */}
                        <div>
                          <input
                            type="checkbox"
                            id="writer"
                            checked={checkboxes.writer}
                            // disabled={durations.writer <= 0}
                            onClick={handleWriterClick}
                          />
                          <label className="statis-name1 " htmlFor="writer">
                            Writer
                          </label>
                        </div>
                        {/* )} */}
                        {/* {['manuscript', 'thesis', 'presentation', 'others'].includes(typeofwork) && ( */}
                        <div>
                          <input
                            type="checkbox"
                            id="reviewer"
                            checked={checkboxes.reviewer}
                            // disabled={durations.reviewer <= 0}
                            onClick={handleReviewerClick}
                          />
                          <label className="statis-name1" htmlFor="reviewer">
                            Reviewer
                          </label>
                        </div>
                        {/* )} */}
                        {/* {['statistics', 'others'].includes(typeofwork) && ( */}
                        <div>
                          <input
                            type="checkbox"
                            id="statistican"
                            checked={checkboxes.statistican}
                            // disabled={durations.statistician <= 0}
                            onClick={handleStatisticanClick}
                          />
                          <label className="statis-name1" htmlFor="statistican">
                            Statistician
                          </label>
                        </div>
                        {/* )} */}
                        {rolename !== "14" && (
                          <div>
                            <input
                              type="checkbox"
                              id="journal"
                              checked={checkboxes.journal}
                              // disabled={durations.journal <= 0}
                              onClick={handleJournalClick}
                            />
                            <label className="statis-name1" htmlFor="journal">
                              Journal
                            </label>
                          </div>
                        )}
                      </div>
                    </>
                  )}

                  {showWriter && (
                    <>
                      {writerFields.map((formData, index) => (
                        <div
                          key={index}
                          className="row w-100 pt-2 d-flex flex-wrap"
                        >
                          <div className="col-12 col-md-6 text-field pt-1">
                            <label className="statis-name">Writer</label>
                            <select
                              className={`form-select ${
                                formData.error ? "error" : ""
                              }`}
                              name="writer"
                              required
                              value={formData.writer}
                              onChange={(e) =>
                                handlewriterChange(
                                  index,
                                  "writer",
                                  e.target.value
                                )
                              }
                            >
                              <option value="" disabled>
                                Select writer
                              </option>
                              {writter.map((writer) => (
                                <option key={writer.id} value={writer.id}>
                                  {writer.name.charAt(0).toUpperCase() +
                                    writer.name.slice(1)}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name">
                              Writer Assigned Date
                            </label>
                            <input
                              type="date"
                              className={`form-control ${
                                errors.writerDate ? "error" : ""
                              }`}
                              name="writerDate"
                              value={formData.writerDate}
                              onChange={(e) =>
                                handlewriterChange(
                                  index,
                                  "writerDate",
                                  e.target.value
                                )
                              }
                              required
                            />
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name">Writer Status</label>
                            <select
                              // className={`form-select ${
                              //   errors.writerStatus ? "error" : ""
                              // }`}
                              className="form-select"
                              name="writerStatus"
                              value={formData.writerStatus}
                              onChange={(e) =>
                                handlewriterChange(
                                  index,
                                  "writerStatus",
                                  e.target.value
                                )
                              }
                               disabled={
                                
                                rolename === "14" 
                                
                              }
                              required
                            >
                              <option value="to_do">To do</option>
                              <option value="plag_correction">
                                Plag correction
                              </option>
                              <option value="correction">Correction</option>
                            </select>
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name">
                              Writer Status Date
                            </label>
                            <input
                              type="date"
                              className={`form-control ${
                                errors.writerStatusDate ? "error" : ""
                              }`}
                              name="writerStatusDate"
                              value={formData.writerStatusDate}
                              onChange={(e) =>
                                handlewriterChange(
                                  index,
                                  "writerStatusDate",
                                  e.target.value
                                )
                              }
                              required
                            />
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name">
                              Writer Project Duration
                            </label>
                            <input
                              type="date"
                              className="form-control"
                              // className={`form-control ${errors.writerprojectduration ? "error" : ""}`}
                              name="writerprojectduration"
                              value={formData.writerprojectduration}
                              onChange={(e) =>
                                handlewriterChange(
                                  index,
                                  "writerprojectduration",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name">Comment Box</label>
                            <textarea
                              className="form-control"
                              name="writer_comment"
                              placeholder="Enter your comment here..."
                              value={formData.writer_comment}
                              onChange={(e) =>
                                handlewriterChange(
                                  index,
                                  "writer_comment",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          {index === 0 && (
                            <div className="col-12 col-md-6 col-lg-1 pt-4">
                              <button
                                type="button"
                                className="save-form-add mt-1"
                                onClick={handleAddWriterField}
                              >
                                Add +
                              </button>
                            </div>
                          )}

                          {index > 0 && (
                            <div className="col-12 col-md-6 col-lg-1 mt-4">
                              <button
                                type="button"
                                className="save-form-del mt-1"
                                onClick={() => handleDeleteWriterField(index)}
                              >
                                Delete
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </>
                  )}

                  {showReviewer && (
                    <>
                      {reviewerFields.map((formData, index) => (
                        <div
                          key={index}
                          className="row w-100 pt-2 d-flex flex-wrap"
                        >
                          <div className="col-12 col-md-6 pt-1 text-field">
                            <label className="statis-name">Reviewer</label>
                            <select
                              className={`form-select ${
                                formData.error ? "error" : ""
                              }`}
                              name="reviewer"
                              value={formData.reviewer}
                              onChange={(e) =>
                                handleReviewerChange(
                                  index,
                                  "reviewer",
                                  e.target.value
                                )
                              }
                            >
                              <option value="" disabled>
                                Select Reviewer
                              </option>
                              {reviewer.map((reviewer) => (
                                <option key={reviewer.id} value={reviewer.id}>
                                  {reviewer.name.charAt(0).toUpperCase() +
                                    reviewer.name.slice(1)}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name">
                              Reviewer Assigned Date
                            </label>
                            <input
                              type="date"
                              className="form-control"
                              name="reviewerAssignedDate"
                              value={formData.reviewerAssignedDate}
                              onChange={(e) =>
                                handleReviewerChange(
                                  index,
                                  "reviewerAssignedDate",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name">
                              Reviewer Status
                            </label>
                            <select
                              className="form-select"
                              name="reviewerStatus"
                              value={formData.reviewerStatus}
                              onChange={(e) =>
                                handleReviewerChange(
                                  index,
                                  "reviewerStatus",
                                  e.target.value
                                )
                              }
                               disabled={
                                
                                rolename === "14" 
                                
                              }
                            >
                              <option value="to_do">To do</option>
                              <option value="plag_correction">
                                Plag correction
                              </option>
                              <option value="correction">Correction</option>
                            </select>
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name">
                              Reviewer Status Date
                            </label>
                            <input
                              type="date"
                              className="form-control"
                              name="reviewerStatusDate"
                              value={formData.reviewerStatusDate}
                              onChange={(e) =>
                                handleReviewerChange(
                                  index,
                                  "reviewerStatusDate",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name-small">
                              Reviewer Project Duration
                            </label>
                            <input
                              type="date"
                              className="form-control"
                              name="reviewerProjectDuration"
                              // value={formData.reviewerProjectduration}
                              value={formData.reviewerProjectDuration}
                              onChange={(e) =>
                                handleReviewerChange(
                                  index,
                                  "reviewerProjectDuration",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name">Comment Box</label>
                            <textarea
                              className="form-control"
                              name="reviewer_comment"
                              value={formData.reviewer_comment}
                              onChange={(e) =>
                                handleReviewerChange(
                                  index,
                                  "reviewer_comment",
                                  e.target.value
                                )
                              }
                              placeholder="Enter your comment here..."
                            />
                          </div>

                          {index === 0 && (
                            <div className="col-12 col-md-6 col-lg-1 pt-4">
                              <button
                                type="button"
                                className="save-form-add mt-1"
                                onClick={handleAddReviewerField}
                              >
                                Add +
                              </button>
                            </div>
                          )}

                          {index > 0 && (
                            <div className="col-12 col-md-6 col-lg-1 mt-4">
                              <button
                                type="button"
                                className="save-form-del mt-1"
                                onClick={() => handleDeleteReviewerField(index)}
                              >
                                Delete
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </>
                  )}

                  {showStatistican && (
                    <>
                      {statisticanFields.map((formData, index) => (
                        <div
                          key={index}
                          className="row w-100 pt-2 d-flex flex-wrap"
                        >
                          <div className="col-12 col-md-6 text-field pt-1">
                            <label className="statis-name">Statistician</label>
                            <select
                              className={`form-select ${
                                formData.error ? "error" : ""
                              }`}
                              name="statistican"
                              value={formData.statistican}
                              onChange={(e) =>
                                handleStatisticanChange(
                                  index,
                                  "statistican",
                                  e.target.value
                                )
                              }
                            >
                              <option value="" disabled>
                                Select Statistician
                              </option>
                              {statistical.map((statistican) => (
                                <option
                                  key={statistican.id}
                                  value={statistican.id}
                                >
                                  {statistican.name.charAt(0).toUpperCase() +
                                    statistican.name.slice(1)}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name">Assigned Date</label>
                            <input
                              type="date"
                              className="form-control"
                              name="statisticanAssignedDate"
                              value={formData.statisticanAssignedDate}
                              onChange={(e) =>
                                handleStatisticanChange(
                                  index,
                                  "statisticanAssignedDate",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name">Status</label>
                            <select
                              className="form-select"
                              name="statisticanStatus"
                              value={formData.statisticanStatus}
                              onChange={(e) =>
                                handleStatisticanChange(
                                  index,
                                  "statisticanStatus",
                                  e.target.value
                                )
                              }
                              disabled={
                                
                                rolename === "14" 
                                
                              }
                            >
                              <option value="to_do">To do</option>
                              <option value="correction">Correction</option>
                              <option value="client_review">
                                Client Review
                              </option>
                            </select>
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name">Status Date</label>
                            <input
                              type="date"
                              className="form-control"
                              name="statisticanStatusDate"
                              value={formData.statisticanStatusDate}
                              onChange={(e) =>
                                handleStatisticanChange(
                                  index,
                                  "statisticanStatusDate",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name-small-sta">
                              Statistician Project Duration
                            </label>
                            <input
                              type="date"
                              className="form-control"
                              name="statisticanProjectDuration"
                              value={formData.statisticanProjectDuration}
                              onChange={(e) =>
                                handleStatisticanChange(
                                  index,
                                  "statisticanProjectDuration",
                                  e.target.value
                                )
                              }
                            />
                          </div>

                          <div className="col-12 col-md-6 text-field pt-2">
                            <label className="statis-name">Comment Box</label>
                            <textarea
                              className="form-control"
                              name="statistican_comment"
                              value={formData.statistican_comment}
                              onChange={(e) =>
                                handleStatisticanChange(
                                  index,
                                  "statistican_comment",
                                  e.target.value
                                )
                              }
                              placeholder="Enter your comment here..."
                            />
                          </div>

                          {index === 0 && (
                            <div className="col-12 col-md-6 col-lg-1 pt-4">
                              <button
                                type="button"
                                className="save-form-add mt-1"
                                onClick={handleAddStatisticanField}
                              >
                                Add +
                              </button>
                            </div>
                          )}

                          {index > 0 && (
                            <div className="col-12 col-md-6 col-lg-1 mt-4">
                              <button
                                type="button"
                                className="save-form-del mt-1"
                                onClick={() =>
                                  handleDeleteStatisticanField(index)
                                }
                              >
                                Delete
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </>
                  )}

                  {showJournal && (
                    <>
                      {journalFields.map((formData, index) => (
                        <div
                          key={index}
                          className="row w-100 pt-2 d-flex flex-wrap"
                        >
                          <div className="col-12 col-md-6 col-lg-3 pt-2">
                            <label className="statis-name">Journal</label>
                            <input
                              type="text"
                              className="form-control"
                              name="journal"
                              value={formData.journal}
                              onChange={(e) =>
                                handleJournalChange(
                                  index,
                                  "journal",
                                  e.target.value
                                )
                              }
                              disabled={["14"].includes(rolename)}
                              defaultValue=""
                            />
                          </div>

                          <div className="col-12 col-md-6 col-lg-3 pt-2">
                            <label className="statis-name">Assigned Date</label>
                            <input
                              type="date"
                              className="form-control"
                              name="journalAssignedDate"
                              value={formData.journalAssignedDate}
                              onChange={(e) =>
                                handleJournalChange(
                                  index,
                                  "journalAssignedDate",
                                  e.target.value
                                )
                              }
                              disabled={["14"].includes(rolename)}
                              defaultValue=""
                            />
                          </div>

                          {/* <div className="col-12 col-md-6 col-lg-3 pt-2">
                          <label className="statis-name">Status</label>
                          <select
                            className="form-select"
                            name="journalStatus"
                            value={formData.journalStatus}
                            onChange={(e) =>
                              handleJournalChange(
                                index,
                                "journalStatus",
                                e.target.value
                              )
                            }
                          >
                          
                            <option value="">
                              Select Status
                            </option>
                            <option value="submit_to_journal">
                              Waiting for Submission
                            </option>
                            <option value="peer_review">Peer Review</option>
                            <option value="pending_author">
                              Pending Author
                            </option>
                            <option value="submitted">Submitted</option>
                            <option value="rejected">Rejected</option>
                            <option value="resubmission">Resubmission</option>
                            <option value="reviewer_comments">
                              Reviewer Comments
                            </option>
                            <option value="published">Published</option>
                            <option value="withdrawal">Withdrawn</option>
                          </select>
                        </div> */}

                          {/* <div className="col-12 col-md-6 col-lg-3 pt-2">
                          <label className="statis-name">Status Date</label>
                          <input
                            type="date"
                            className="form-control"
                            name="journalStatusDate"
                            value={formData.journalStatusDate}
                            onChange={(e) =>
                              handleJournalChange(
                                index,
                                "journalStatusDate",
                                e.target.value
                              )
                            }
                          />
                        </div> */}

                          <div className="col-12 col-md-6 col-lg-3 pt-2">
                            <label className="statis-name">
                              Journal Project Duration
                            </label>
                            <input
                              type="date"
                              className="form-control"
                              name="journalProjectDuration"
                              value={formData.journalProjectDuration}
                              onChange={(e) =>
                                handleJournalChange(
                                  index,
                                  "journalProjectDuration",
                                  e.target.value
                                )
                              }
                              disabled={["14"].includes(rolename)}
                              defaultValue=""
                            />
                          </div>

                          <div className="col-12 col-md-6 col-lg-3 pt-2">
                            <label className="statis-name">
                              Type of Article
                            </label>
                            <select
                              className="form-select"
                              name="typeofarticle"
                              value={formData.typeofarticle}
                              onChange={(e) =>
                                handleJournalChange(
                                  index,
                                  "typeofarticle",
                                  e.target.value
                                )
                              }
                              disabled={["14"].includes(rolename)}
                              defaultValue=""
                            >
                              <option value="" disabled selected>
                                Type of Article{" "}
                              </option>
                              <option value="original_research_article">
                                Original Research Article
                              </option>
                              <option value="case_report">Case Report</option>
                              <option value="case_series">Case Series</option>
                              <option value="systematic_review">
                                Systematic Review
                              </option>
                              <option value="comprehensive_review">
                                Comprehensive Review
                              </option>
                            </select>{" "}
                          </div>

                          <div className="col-12 col-md-6 col-lg-3 pt-3 ">
                            <label className="statis-name">
                              Quick Review / Normal Review
                            </label>

                            <div className="d-flex">
                              <div className="form-check mx-2">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  id="quickReview"
                                  name="review" // Shared name for radio buttons
                                  value="quickReview"
                                  checked={formData.review === "quickReview"}
                                  onChange={(e) =>
                                    handleJournalChange(
                                      index,
                                      "review",
                                      e.target.value
                                    )
                                  }
                                  disabled={["14"].includes(rolename)}
                                  defaultValue=""
                                />
                                <label
                                  className="label-public-name"
                                  htmlFor="quickReview"
                                >
                                  Quick Review
                                </label>
                              </div>

                              <div className="form-check mx-2">
                                <input
                                  type="radio"
                                  className="form-check-input"
                                  id="normalReview"
                                  name="review" // Shared name for radio buttons
                                  value="normalReview"
                                  checked={formData.review === "normalReview"}
                                  onChange={(e) =>
                                    handleJournalChange(
                                      index,
                                      "review",
                                      e.target.value
                                    )
                                  }
                                  disabled={["14"].includes(rolename)}
                                  defaultValue=""
                                />
                                <label
                                  className="label-public-name"
                                  htmlFor="normalReview"
                                >
                                  Normal Review
                                </label>
                              </div>
                            </div>
                          </div>

                          <div className="col-12 col-md-6 col-lg-3 pt-2">
                            <label className="statis-name">Comment Box</label>
                            <textarea
                              className="form-control"
                              name="journal_comment"
                              value={formData.journal_comment}
                              onChange={(e) =>
                                handleJournalChange(
                                  index,
                                  "journal_comment",
                                  e.target.value
                                )
                              }
                              disabled={["14"].includes(rolename)}
                              defaultValue=""
                              placeholder="Enter your comment here..."
                            />
                          </div>

                          {/* {index === 0 && (
                          <div className="col-12 col-md-6 col-lg-1 pt-4">
                            <button
                              type="button"
                              className="save-form-add mt-1"
                              onClick={handleAddJournalField}
                            >
                              Add +
                            </button>
                          </div>
                        )} */}
                          {/* 
                        {index > 0 && (
                          <div className="col-12 col-md-6 col-lg-1 mt-4">
                            <button
                              type="button"
                              className="save-form-del mt-1"
                              onClick={() => handleDeleteStatisticanField(index, formData.statisticanid)}
                            >
                              Delete
                            </button>
                          </div>
                        )} */}
                        </div>
                      ))}
                    </>
                  )}

                  {rolename !== "14" && rolename !== "28" && (
                    <>
                      <div className="row">
                        <div className="col-12 col-md-4 pt-4">
                          <label className="client-name-pop">Comment Box</label>
                          {/* <input className=" command-box" /> */}
                          <RichEditor
                            setFormData={setFormData}
                            formData={formData}
                          />
                        </div>
                        <div className="col-12 col-md-6 mt-5 pt-1">
                          <button
                            className="view-commands-popup"
                            onClick={handlePopupVisible}
                          >
                            View Commands
                          </button>
                        </div>
                        {isPopupVisible && (
                          <div className="modal-container-view">
                            <div className="updateviewc">
                              <div className="d-flex justify-content-between align-items-center">
                                <span className="view-names1-command pt-1">
                                  Commands:
                                </span>
                                <span
                                  className="modal-close mb-0"
                                  onClick={handleCancel}
                                >
                                  &times;
                                </span>
                              </div>

                              <div className="modal-body">
                                {projectcomments.map((comment, index) => (
                                  <div
                                    key={index}
                                    className="view-project-title1 w-100"
                                  >
                                    <hr />
                                    <div className="d-flex gap-2 pt-2">
                                      <div className="view-names1-command">
                                        {comment.created_by_user?.employee_name}
                                      </div>
                                      <div className="created-min">
                                        {comment.created_date}
                                      </div>
                                    </div>
                                    <p
                                      className="view-project-title1 mt-2"
                                      dangerouslySetInnerHTML={{
                                        __html: removeEmptyTags(
                                          CapitalizeCaseU(
                                            comment.commend_box || ""
                                          )
                                        ),
                                      }}
                                    />
                                    <hr />
                                  </div>
                                ))}
                              </div>
                              <div className="modal-footer gap-2  ">
                                <button
                                  className="view-rej-command"
                                  onClick={handleCancel}
                                >
                                  close
                                </button>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="col-md-12 float-start px-3 mt-4 ">
                        <label className="client-name-pop ">Payment</label>
                      </div>

                      <div className="row ">
                        {!Array.isArray(paymentFields) ||
                        paymentFields.length === 0 ? (
                          // Ensure at least one form appears
                          <div className="row  align-items-center">
                            <div className="col-12 col-md-3">
                              <label className="statis-name">Payment 1</label>
                              <input
                                type="number"
                                className={`form-control ${
                                  errors[`amount`] ? "error" : ""
                                }`}
                                value={paymentFields?.[0]?.payment || ""}
                                onChange={(e) => {
                                  handlePaymentChange(
                                    0,
                                    "payment",
                                    e.target.value
                                  );

                                  if (errors[`amount`]) {
                                    setErrors((prevErrors) => {
                                      const updatedErrors = { ...prevErrors };
                                      delete updatedErrors[`amount`];
                                      return updatedErrors;
                                    });
                                  }
                                }}
                              />
                            </div>

                            <div className="col-12 col-md-3">
                              <label className="statis-name">
                                Payment Date
                              </label>
                              <input
                                type="date"
                                className={`form-control ${
                                  errors[`payment_date_0`] ? "error" : ""
                                }`}
                                value={paymentFields?.[0]?.payment_date || ""}
                                onChange={(e) => {
                                  handlePaymentChange(
                                    0,
                                    "payment_date",
                                    e.target.value
                                  );

                                  if (errors[`payment_date_0`]) {
                                    setErrors((prevErrors) => {
                                      const updatedErrors = { ...prevErrors };
                                      delete updatedErrors[`payment_date_0`];
                                      return updatedErrors;
                                    });
                                  }
                                }}
                              />
                            </div>

                            <div className="col-12 col-md-3 d-flex justify-content-start align-items-center mt-4">
                              <button
                                type="button"
                                className="save-form-add mt-1"
                                onClick={handleAddFieldpayment}
                              >
                                Add +
                              </button>
                            </div>
                          </div>
                        ) : (
                          paymentFields.map((field, index) => (
                            <div
                              key={field.id}
                              className="row mt-2 align-items-center"
                            >
                              <div className="col-12 col-md-3">
                                <label className="statis-name">{`Payment ${
                                  index + 1
                                }`}</label>
                                <input
                                  type="number"
                                  className={`form-control ${
                                    errors[`payment_${index}`] ? "error" : ""
                                  }`}
                                  value={
                                    field.payment === ""
                                      ? ""
                                      : Number(field.payment)
                                  }
                                  onChange={(e) => {
                                    const value =
                                      e.target.value === ""
                                        ? ""
                                        : Number(e.target.value); // Handle empty correctly
                                    handlePaymentChange(
                                      index,
                                      "payment",
                                      value
                                    );

                                    if (errors[`payment_${index}`]) {
                                      setErrors((prevErrors) => {
                                        const updatedErrors = { ...prevErrors };
                                        delete updatedErrors[
                                          `payment_${index}`
                                        ];
                                        return updatedErrors;
                                      });
                                    }
                                  }}
                                />
                              </div>

                              <div className="col-12 col-md-3">
                                <label className="statis-name">
                                  Payment Date
                                </label>
                                <input
                                  type="date"
                                  className={`form-control ${
                                    errors[`payment_date_${index}`]
                                      ? "error"
                                      : ""
                                  }`}
                                  value={field.payment_date || ""}
                                  onChange={(e) => {
                                    handlePaymentChange(
                                      index,
                                      "payment_date",
                                      e.target.value
                                    );

                                    if (errors[`payment_date_${index}`]) {
                                      setErrors((prevErrors) => {
                                        const updatedErrors = { ...prevErrors };
                                        delete updatedErrors[
                                          `payment_date_${index}`
                                        ];
                                        return updatedErrors;
                                      });
                                    }
                                  }}
                                />
                              </div>

                              {index === 0 && (
                                <div className="col-12 col-md-3 d-flex justify-content-start align-items-center mt-4">
                                  <button
                                    type="button"
                                    className="save-form-add mt-1"
                                    onClick={handleAddFieldpayment}
                                  >
                                    Add +
                                  </button>
                                </div>
                              )}

                              {index > 0 && (
                                <div className="col-12 col-md-3 d-flex justify-content-start align-items-center mt-4">
                                  <button
                                    type="button"
                                    className="save-form-del mt-1"
                                    onClick={() =>
                                      handleRemoveField(index, field.id)
                                    }
                                  >
                                    Delete
                                  </button>
                                </div>
                              )}
                            </div>
                          ))
                        )}
                      </div>

                      <div className="row mt-2 pt-2 ">
                        <div className="col-12 col-md-3 px-3  col-md">
                          <label className="statis-name">Payment Status</label>
                          <select
                            className={`form-select ${
                              errors.payment_status ? "error" : ""
                            }`}
                            name="payment_status"
                            onChange={(e) => {
                              handleFormChange(e);
                              if (errors.payment_status) {
                                setErrors((prevErrors) => {
                                  const updatedErrors = { ...prevErrors };
                                  delete updatedErrors.payment_status;
                                  return updatedErrors;
                                });
                              }
                            }}
                            value={formData.payment_status}
                          >
                            <option value="" disabled selected>
                              Payment Status
                            </option>
                            <option value="advance_pending">
                              Advance Pending
                            </option>
                            <option value="partial_payment_pending">
                              Partial payment pending
                            </option>
                            <option value="final_payment_pending">
                              Final payment pending
                            </option>
                          </select>
                        </div>
                      </div>
                    </>
                  )}

                  <div className="col-12 d-flex justify-content-end  pt-5 py-5 gap-3 ">
                    {rolename !== "14" && rolename !== "28" && (
                      <Link to="/entry-process">
                        <button className="save-form">Back</button>
                      </Link>
                    )}
                    <button
                      onClick={handleSubmit}
                      type="submit"
                      className="save-form-save"
                    >
                      Update
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        <div>
          <Footer></Footer>
        </div>
      </section>
    </>
  );
}

export default Enterprocess_form;
