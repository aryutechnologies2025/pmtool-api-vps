import React, { useState, useEffect } from "react";
import Header from "../components/Header.js";
import Breadcrumbs from "../routes/Breadcrumbs.js";
import DataTable from "datatables.net-react";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import axios from "axios";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import { VscGitStashPop } from "react-icons/vsc";
import Tooltip from "@mui/material/Tooltip";
import Loader from "../components/Loader.js";

// import { saveAs } from "file-saver";

// import Papa from "papaparse";

function Client_record() {
  const [data, setData] = useState([]);
  const [journaldata, setJournalData] = useState([]);

  const fetchData = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/reports/get-client-report`);
      
      setData(response.data.client_details);
      setJournalData(response.data.Journal_Publication_details);

      console.log(response.data);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);

  const columns = [
    { title: "S.no ",  data: null, 
      render: (data, type, row, meta) => meta.row + 1 },
    { title: "Client Name  ", data: "client_name" ,render: (data) => Capitalize(data),},
    { title: "Email Id", data: "email" },
    { title: "Contact", data: "contact" },
    { title: "institute ", data: "institute" },
    { title: "Department", data: "department" },
    { title: "Profession ", data: "profession" },
  ];
  const columns1 = [
    { title: "S.no ",  data: null, 
      render: (data, type, row, meta) => meta.row + 1 },
      { title: "Client Name  ", data: "client_name" ,render: (data) => Capitalize(data),},
    { title: "Email Id", data: "email" },
    { title: "Contact", data: "contact" },
    { title: "institute ", data: "institute" },
    { title: "Department", data: "department" },
    { title: "Profession ", data: "profession" },
  ];


   //exprt
    // const exportToCSV = () => {
    //   // Define custom headers and map them to data fields
    //   const headers = [
    //     { label: "Project ID", value: "project_id", transform: (data) => Capitalize(data || "-") },
    //     { label: "Entry Date", value: "entry_date", transform: (data) => getDateFormate(data || "-") },
    //     { label: "Department", value: "department", transform: (data) => data?.name ? Capitalize(data.name) : "-" },
    //     { label: "Institution", value: "institute", transform: (data) => data?.name ? Capitalize(data.name) : "-" },
    //     { label: "Client Name", value: "client_name", transform: (data) => Capitalize(data || "-") },
    //     { label: "Title", value: "title", transform: (data) => Capitalize(data || "-") },
    //     { label: "Process Status", value: "process_status", transform: (data) => CapitalizeCaseU(data || "-") },
    //     { label: "Type of Work", value: "type_of_work", transform: (data) => Capitalize(data || "-") },
    //     {
    //       label: "Assigned Date",
    //       value: "assigned_date",
    //       transform: (_, row) => {
    //         // Extracting assigned date from the available sources
    //         let assignedDate =
    //           row.writer_data?.[0]?.assign_date ||
    //           row.reviewer_data?.[0]?.assign_date ||
    //           row.statistican_data?.[0]?.assign_date ||
    //           "-";
        
    //         return assignedDate !== "-" ? getDateFormate(assignedDate) : "-";
    //       },
    //     },
    //     {
    //       label: "Duration",
    //       value: null,
    //       transform: (_, row) => {
    //         let duration = row.writer_data?.project_duration || "-";
    //         return duration !== "-" ? getDateFormate(duration) : "-";
    //       },
    //     },
    //     {
    //       label: "Pending Days",
    //       value: "pending_days",
    //       transform: (_, row) => {
    //         let pendingDays = row.writer_pending_days || row.reviewer_pending_days || row.statistican_pending_days || "-";
    //         return pendingDays;
    //       },
    //     },
    //   ];
    
    //   // Prepare data for CSV export
  
    
    //   // Convert data to CSV format using PapaParse
    //   const csv = Papa.unparse({
    //     fields: headers.map((header) => header.label), // Column names
    //     data: csvData,
    //   });
    
    //   // Create a Blob from the CSV string
    //   const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    
      
      
    //   // Use FileSaver to save the file
    //   saveAs(blob, fileName);
    // };
    
  
    const [loading, setLoading] = useState(true);

    useEffect(() => {
      const handleLoad = () => {
        setTimeout(() => {
          setLoading(false);
        }, 1000);
      };
  
      if (document.readyState === "complete") {
        handleLoad();
      } else {
        window.addEventListener("load", handleLoad);
      }
  
      return () => window.removeEventListener("load", handleLoad);
    }, []);
  
    if (loading) {
      return <Loader />;
    }

  return (
    <>
      <section className="container container d-flex flex-column justify-content-between min-vh-100">
        <div className="mt-4 w-100">
          <div className="col-12 ">
            <div className="col-12">
              <Header></Header>
            </div>
            <div className=" pt-1 mt-3 py-3 project-manage w-100 ">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className="col-12 col-md-6  px-3 pt-3">
                  <h1 className="heading-entr">Client Record </h1>
                </div>

                <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>

              <section className="pb-2 mt-2">
                <div className="d-flex justify-content-between">
                  <div className="heading-entr mt-1">From New project entry client details  </div>
                  <div className="text-center ">
                    <div className="d-flex justify-content-center gap-2">
                      <Tooltip title="Export">
                        <div className="add-icon">
                          <VscGitStashPop
                            className="add1-icon"
                            // onClick={exportToCSV}
                          />
                        </div>
                      </Tooltip>
                    </div>
                  </div>
                </div>
                <div>
                  <DataTable
                    id="example"
                    data={data}
                    columns={columns}
                    className="display"
                    options={{
                      scrollX: true,
                      select: true,
                      pageLength: 20, // Default number of rows per page
                      lengthMenu: [
                        [20, 30, 50],
                        [20, 30, 50],
                      ],
                      search: {
                        return: true, // Ensures search starts fresh
                      },
                    }}
                  />
                </div>
              </section>
            </div>

            <section className="  mt-2 project-manage w-100 py-3">
              <div className="col-12 pt-3 ">
                <h2 className="heading-entr">
                  Journal Publication From Author Form entry
                </h2>
              </div>
              <div className="">
              <DataTable
                    id="example"
                    data={journaldata}
                    columns={columns1}
                    className="display"
                    options={{
                      scrollX: true,
                      select: true,
                      pageLength: 20, // Default number of rows per page
                      lengthMenu: [
                        [20, 30, 50],
                        [20, 30, 50],
                      ],
                      search: {
                        return: true, // Ensures search starts fresh
                      },
                    }}
                  />
              </div> 
            </section>
          </div>
        </div>
      </section>
    </>
  );
}

export default Client_record;
