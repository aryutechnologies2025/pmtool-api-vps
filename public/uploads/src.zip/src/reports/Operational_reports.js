import React, { useState, useEffect } from "react";
import Header from "../components/Header.js";
import Breadcrumbs from "../routes/Breadcrumbs.js";
import DataTable from "datatables.net-react";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import axios from "axios";
import { API_URL } from "../config.js";
import Loader from "../components/Loader.js";
import { VscGitStashPop } from "react-icons/vsc";
import Tooltip from "@mui/material/Tooltip";
import Papa from "papaparse";
import { saveAs } from "file-saver";
import { Capitalize } from "../campsCase.js";


function Operational_reports() {
  const [data, setData] = useState([]);

  console.log("operations:", data);

  const fetchData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/operational-report/project-durations`
      );
      console.log("response :", response.data.data);
      // Transform the data to match the table structure
      const transformedData = Object.entries(response.data.data).map(
        ([projectId, projectData]) => ({
          projectId: projectId || "-",
          // workingTime:
          //   projectData.project_working_time &&
          //     projectData.project_working_time.length > 0
          //     ? projectData.project_working_time
          //     : "-",

          // workingTime:
          //   projectData.project_working_time &&
          //     Object.keys(projectData.project_working_time).length > 0
          //     ? Object.entries(projectData.project_working_time)
          //       .map(([key, value]) => {
          //         const capitalizedKey =
          //           key.charAt(0).toUpperCase() + key.slice(1);
          //         return `<strong>${capitalizedKey}</strong>: ${value}`;
          //       })
          //       .join("<br />")
          //     : "-",
workingTime:
  projectData.project_working_time &&
  Object.keys(projectData.project_working_time).length > 0
    ? `
      <div class="pwt-column">
        ${Object.entries(projectData.project_working_time)
          .map(([name, time]) => {
            const Name = name.charAt(0).toUpperCase() + name.slice(1);
            return `
              <div class="pwt-row">
                <div class="pwt-name">${Name}</div>
                <div class="pwt-time">${time}</div>
              </div>
            `;
          })
          .join("")}
      </div>
    `
    : "-",






          // waitingTime:
          //   projectData.project_waiting_time &&
          //   Object.keys(projectData.project_waiting_time).length > 0
          //     ? Object.entries(projectData.project_waiting_time)
          //         .map(([key, value]) => `${key}: ${value}`)

          //     : "-",

          // waitingTime:
          //   projectData.project_waiting_time &&
          //     Object.keys(projectData.project_waiting_time).length > 0
          //     ? Object.entries(projectData.project_waiting_time)
          //       .map(([key, value]) => {
          //         const capitalizedKey =
          //           key.charAt(0).toUpperCase() + key.slice(1);
          //         return `<strong>${capitalizedKey}</strong>: ${value}`;
          //       })
          //       .join("<br />")
          //     : "-",


          waitingTime:
  projectData.project_waiting_time &&
  Object.keys(projectData.project_waiting_time).length > 0
    ? `
      <div class="pwt-column">
        ${Object.entries(projectData.project_waiting_time)
          .map(([key, value]) => {
            const name = key.charAt(0).toUpperCase() + key.slice(1);
            return `
              <div class="pwt-row">
                <div class="pwt-name">${name}</div>
                <div class="pwt-time">${value}</div>
              </div>
            `;
          })
          .join("")}
      </div>
    `
    : "-",


          workDuration:
            projectData.project_work_duration &&
              projectData.project_work_duration.length > 0
              ? projectData.project_work_duration
              : "-",
          completionDuration:
            projectData.project_completion_duration &&
              projectData.project_completion_duration.length > 0
              ? projectData.project_completion_duration
              : "-",
        })
      );

      setData(transformedData);
      console.log("Operational_reports:", transformedData);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);

  const [emplyeename, setEmplyeename] = useState([]);
  // console.log("empname:", emplyeename);
  const [jounalstatus, setJournalStatus] = useState([]);
  // console.log("jounal:", jounalstatus);
  const fetchDatajounal = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/operational-report/operational-durations`
      );

      setEmplyeename(response.data);
      // const transformedData = Object.entries(response.data.data).map(
      //   ([projectId, projectData]) => ({
      //     projectId: projectId || "-",
      //     teamcoordinar:
      //       projectData.team_coordinator &&
      //         projectData.team_coordinator.length > 0
      //         ? projectData.team_coordinator.join(", ")
      //         : "-",
      //     statistican:
      //       projectData.statistican &&
      //         Object.keys(projectData.statistican).length > 0
      //         ? `${Object.keys(projectData.statistican)[0]
      //           .charAt(0)
      //           .toUpperCase() +
      //         Object.keys(projectData.statistican)[0].slice(1)
      //         }: ${Object.values(projectData.statistican)[0]}`
      //         : "-",
      //     writer:
      //       projectData.writer && projectData.writer.length > 0
      //         ? projectData.writer.join(", ")
      //         : "-",
      //     reviewer:
      //       projectData.reviewer && projectData.reviewer.length > 0
      //         ? projectData.reviewer.join(", ")
      //         : "-",
      //     sme:
      //       projectData.sme && projectData.sme.length > 0
      //         ? projectData.sme.join(", ")
      //         : "-",
      //     public:
      //       projectData.publication_manager &&
      //         projectData.publication_manager.length > 0
      //         ? projectData.publication_manager
      //         : "-",
      //     completionDuration:
      //       projectData.project_work_duration &&
      //         projectData.project_work_duration.length > 0
      //         ? projectData.project_work_duration
      //         : "-",
      //   })
      // );

//       const transformedData = Object.entries(response.data.data).map(
//   ([projectId, projectData]) => {
//     // --- STATISTICAL FORMAT (repeated for writer, reviewer, sme) ---
//     const statistican =
//       projectData.statistican &&
//       Object.keys(projectData.statistican).length > 0
//         ? `${Object.keys(projectData.statistican)[0].charAt(0).toUpperCase() +
//             Object.keys(projectData.statistican)[0].slice(1)
//           }: ${Object.values(projectData.statistican)[0]}`
//         : "-";

//     const writer =
//       projectData.writer &&
//       Object.keys(projectData.writer).length > 0
//         ? `${Object.keys(projectData.writer)[0].charAt(0).toUpperCase() +
//             Object.keys(projectData.writer)[0].slice(1)
//           }: ${Object.values(projectData.writer)[0]}`
//         : "-";

//     const reviewer =
//       projectData.reviewer &&
//       Object.keys(projectData.reviewer).length > 0
//         ? `${Object.keys(projectData.reviewer)[0].charAt(0).toUpperCase() +
//             Object.keys(projectData.reviewer)[0].slice(1)
//           }: ${Object.values(projectData.reviewer)[0]}`
//         : "-";

//     const sme =
//       projectData.sme &&
//       Object.keys(projectData.sme).length > 0
//         ? `${Object.keys(projectData.sme)[0].charAt(0).toUpperCase() +
//             Object.keys(projectData.sme)[0].slice(1)
//           }: ${Object.values(projectData.sme)[0]}`
//         : "-";

//     // --- FINAL RETURN ---
//     return {
//       projectId: projectId || "-",

//       teamcoordinar:
//         projectData.team_coordinator &&
//         projectData.team_coordinator.length > 0
//           ? projectData.team_coordinator.join(", ")
//           : "-",

//       statistican: statistican,
//       writer: writer,
//       reviewer: reviewer,
//       sme: sme,

//       public:
//         projectData.publication_manager &&
//         projectData.publication_manager.length > 0
//           ? projectData.publication_manager
//           : "-",

//       completionDuration:
//         projectData.project_work_duration &&
//         projectData.project_work_duration.length > 0
//           ? projectData.project_work_duration
//           : "-",
//     };
//   }
// );



const transformedData = Object.entries(response.data.data).map(
  ([projectId, projectData]) => {
    // --- FORMAT same for teamcoordinar, statistican, writer, reviewer, sme ---

    // const teamcoordinar =
    //   projectData.team_coordinator &&
    //   Object.keys(projectData.team_coordinator).length > 0
    //     ? `${Object.keys(projectData.team_coordinator)[0].charAt(0).toUpperCase() +
    //         Object.keys(projectData.team_coordinator)[0].slice(1)
    //       }: ${Object.values(projectData.team_coordinator)[0]}`
    //     : "-";


              const teamcoordinar =
  projectData.team_coordinator &&
  Object.keys(projectData.team_coordinator).length > 0
    ? `
      <div class="pwt-column">
        ${Object.entries(projectData.team_coordinator)
          .map(([key, value]) => {
            const name = key.charAt(0).toUpperCase() + key.slice(1);
            return `
              <div class="pwt-row">
                <div class="pwt-name">${name}</div>
                <div class="pwt-time">${value}</div>
              </div>
            `;
          })
          .join("")}
      </div>
    `
    : "-";
    

    // const statistican =
    //   projectData.statistican &&
    //   Object.keys(projectData.statistican).length > 0
    //     ? `${Object.keys(projectData.statistican)[0].charAt(0).toUpperCase() +
    //         Object.keys(projectData.statistican)[0].slice(1)
    //       }: ${Object.values(projectData.statistican)[0]}`
    //     : "-";

    // const writer =
    //   projectData.writer &&
    //   Object.keys(projectData.writer).length > 0
    //     ? `${Object.keys(projectData.writer)[0].charAt(0).toUpperCase() +
    //         Object.keys(projectData.writer)[0].slice(1)
    //       }: ${Object.values(projectData.writer)[0]}`
    //     : "-";

    // const reviewer =
    //   projectData.reviewer &&
    //   Object.keys(projectData.reviewer).length > 0
    //     ? `${Object.keys(projectData.reviewer)[0].charAt(0).toUpperCase() +
    //         Object.keys(projectData.reviewer)[0].slice(1)
    //       }: ${Object.values(projectData.reviewer)[0]}`
    //     : "-";

    // const sme =
    //   projectData.sme &&
    //   Object.keys(projectData.sme).length > 0
    //     ? `${Object.keys(projectData.sme)[0].charAt(0).toUpperCase() +
    //         Object.keys(projectData.sme)[0].slice(1)
    //       }: ${Object.values(projectData.sme)[0]}`
    //     : "-";
     const statistican =
  projectData.statistican &&
  Object.keys(projectData.statistican).length > 0
    ? `
      <div class="pwt-column">
        ${Object.entries(projectData.statistican)
          .map(([key, value]) => {
            const name = key.charAt(0).toUpperCase() + key.slice(1);
            return `
              <div class="pwt-row">
                <div class="pwt-name">${name}</div>
                <div class="pwt-time">${value}</div>
              </div>
            `;
          })
          .join("")}
      </div>
    `
    : "-";
    
     const writer =
  projectData.writer &&
  Object.keys(projectData.writer).length > 0
    ? `
      <div class="pwt-column">
        ${Object.entries(projectData.writer)
          .map(([key, value]) => {
            const name = key.charAt(0).toUpperCase() + key.slice(1);
            return `
              <div class="pwt-row">
                <div class="pwt-name">${name}</div>
                <div class="pwt-time">${value}</div>
              </div>
            `;
          })
          .join("")}
      </div>
    `
    : "-";
    
     const reviewer =
  projectData.reviewer &&
  Object.keys(projectData.reviewer).length > 0
    ? `
      <div class="pwt-column">
        ${Object.entries(projectData.reviewer)
          .map(([key, value]) => {
            const name = key.charAt(0).toUpperCase() + key.slice(1);
            return `
              <div class="pwt-row">
                <div class="pwt-name">${name}</div>
                <div class="pwt-time">${value}</div>
              </div>
            `;
          })
          .join("")}
      </div>
    `
    : "-";
    
     const sme =
  projectData.sme &&
  Object.keys(projectData.sme).length > 0
    ? `
      <div class="pwt-column">
        ${Object.entries(projectData.sme)
          .map(([key, value]) => {
            const name = key.charAt(0).toUpperCase() + key.slice(1);
            return `
              <div class="pwt-row">
                <div class="pwt-name">${name}</div>
                <div class="pwt-time">${value}</div>
              </div>
            `;
          })
          .join("")}
      </div>
    `
    : "-";
    

    // --- FINAL RETURN ---
    return {
      projectId: projectId || "-",

      teamcoordinar: teamcoordinar,
      statistican: statistican,
      writer: writer,
      reviewer: reviewer,
      sme: sme,

      public:
        projectData.publication_manager &&
        projectData.publication_manager.length > 0
          ? projectData.publication_manager
          : "-",

      completionDuration:
        projectData.project_work_duration &&
        projectData.project_work_duration.length > 0
          ? projectData.project_work_duration
          : "-",
    };
  }
);


      setJournalStatus(transformedData);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    fetchDatajounal();
  }, []);

  const columns = [
    {
      title: "Project ID",
      data: "projectId", render: Capitalize // Matches the key in transformedData
    },
    // {
    //   title: "Project Working Time (PWT)",
    //   data: "workingTime", 
    // },
{
  title: `
    <div class="pwt-header">
      <div class="pwt-header-title">Project Working Time (PWT)</div>
      <div class="pwt-header-row">
        <div class="pwt-header-name">Name</div>
        <div class="pwt-header-time">Time</div>
      </div>
    </div>
  `,
  data: "workingTime",
  orderable: false,
},



    {
      title: "Project Waiting Time (PWAT)",
      data: "waitingTime", 
    },
    {
      title: "Project Work Duration (PWD)",
      data: "workDuration", 
    },
    {
      title: "Project Completion Duration (PCD)",
      data: "completionDuration", 
    },
  ];
  const columns1 = [
    { title: "Projects ID  ", data: "projectId", render: Capitalize },
    // { title: "Team Coordinator ", data: "teamcoordinar" },
    {
  title: `
    <div class="pwt-header">
      <div class="pwt-header-title">Team Coordinator</div>
      <div class="pwt-header-row">
        <div class="pwt-header-name">Name</div>
        <div class="pwt-header-time">Time</div>
      </div>
    </div>
  `,
  data: "teamcoordinar",
  orderable: false,
},
    // { title: "Statistician ", data: "statistican" },
    // { title: "Writer", data: "writer" },
    // { title: "Reviewer", data: "reviewer" },
    // { title: "SME", data: "sme" },
     {
  title: `
    <div class="pwt-header">
      <div class="pwt-header-title">Statistician</div>
      <div class="pwt-header-row">
        <div class="pwt-header-name">Name</div>
        <div class="pwt-header-time">Time</div>
      </div>
    </div>
  `,
  data: "statistican",
  orderable: false,
},
 {
  title: `
    <div class="pwt-header">
      <div class="pwt-header-title">Writer</div>
      <div class="pwt-header-row">
        <div class="pwt-header-name">Name</div>
        <div class="pwt-header-time">Time</div>
      </div>
    </div>
  `,
  data: "writer",
  orderable: false,
},
 {
  title: `
    <div class="pwt-header">
      <div class="pwt-header-title">Reviewer</div>
      <div class="pwt-header-row">
        <div class="pwt-header-name">Name</div>
        <div class="pwt-header-time">Time</div>
      </div>
    </div>
  `,
  data: "reviewer",
  orderable: false,
},
 {
  title: `
    <div class="pwt-header">
      <div class="pwt-header-title">SME</div>
      <div class="pwt-header-row">
        <div class="pwt-header-name">Name</div>
        <div class="pwt-header-time">Time</div>
      </div>
    </div>
  `,
  data: "sme",
  orderable: false,
},
    { title: "Publication Manager", data: "public" },
    { title: "Total Duration ", data: "completionDuration" },
  ];

  const exportToCSV1 = () => {
    // Define export columns matching columns1
    const exportColumns = [
      { title: "Projects ID", key: "projectId" },
      { title: "Team Coordinator", key: "teamcoordinar" },
      { title: "Statistician", key: "statistican" },
      { title: "Writer", key: "writer" },
      { title: "Reviewer", key: "reviewer" },
      { title: "SME", key: "sme" },
      { title: "Publication Manager", key: "public" },
      { title: "Total Duration", key: "completionDuration" },
    ];

    // Prepare headers
    const headers = exportColumns.map((col) => col.title);

    // Prepare body rows
    const bodyData = jounalstatus.map((row) =>
      exportColumns.map((col) => row[col.key] ?? "-")
    );

    // Combine headers and data
    const csvData = [headers, ...bodyData];

    // Convert to CSV format
    const csv = Papa.unparse(csvData);

    // Create and download CSV file
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const formattedDate = new Date()
      .toLocaleDateString("en-GB")
      .replace(/\//g, "-");
    const fileName = `Operational_Duration_${formattedDate}.csv`;

    saveAs(blob, fileName);
  };

  const exportToCSV = () => {
    // Define export columns matching the duration-based columns
    const exportColumns = [
      { title: "Project ID", key: "projectId" },
      { title: "Project Working Time (PWT)", key: "workingTime" },
      { title: "Project Waiting Time (PWAT)", key: "waitingTime" },
      { title: "Project Work Duration (PWD)", key: "workDuration" },
      { title: "Project Completion Duration (PCD)", key: "completionDuration" },
    ];

    // Prepare headers
    const headers = exportColumns.map((col) => col.title);

    // Prepare body rows from the same `jounalstatus` or your relevant dataset
    const bodyData = data.map((row) =>
      exportColumns.map((col) => row[col.key] ?? "-")
    );

    // Combine headers and data
    const csvData = [headers, ...bodyData];

    // Convert to CSV format
    const csv = Papa.unparse(csvData);

    // Create and download CSV file
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const formattedDate = new Date()
      .toLocaleDateString("en-GB")
      .replace(/\//g, "-");
    const fileName = `Project_Durations_${formattedDate}.csv`;

    saveAs(blob, fileName);
  };

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }
  return (
    <>
      <section className="container container d-flex flex-column justify-content-between min-vh-100">
        <div className="mt-4 w-100">
          <div className="col-12 ">
            <div className="col-12">
              <Header></Header>
            </div>
            <div className=" pt-1 mt-3 py-3 project-manage w-100 ">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className="col-12 col-md-6  px-3 pt-3">
                  <h1 className="heading-entr">Operational Reports</h1>
                </div>

                <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>

              <section className="pb-2 mt-2">
                <div className="row ">
                  <div className="col-12 ">
                    <div className="d-flex justify-content-between">
                      <div className="heading-entr mt-1">Project Durations</div>
                      <div className="text-center ">
                        <div className="d-flex justify-content-center gap-2">
                          <Tooltip title="Export">
                            <div className="add-icon">
                              <VscGitStashPop
                                className="add1-icon"
                                onClick={exportToCSV}
                              />
                            </div>
                          </Tooltip>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div>
                  <DataTable
                    id="example"
                    data={data}
                    columns={columns}
                    className="display"
                    options={{
                      scrollX: true,
                      select: true,
                      pageLength: 20, // Default number of rows per page
                      lengthMenu: [
                        [20, 30, 50],
                        [20, 30, 50],
                      ],
                      order: [],
                      search: {
                        return: true, // Ensures search starts fresh
                      },
                    }}
                  />
                </div>
              </section>
            </div>

            <section className="  mt-2 project-manage w-100 py-3">
              <div className="col-12 pt-3 ">
                <div className="d-flex justify-content-between">
                  <div className="heading-entr mt-1">Operational Duration</div>
                  <div className="text-center ">
                    <div className="d-flex justify-content-center gap-2">
                      <Tooltip title="Export">
                        <div className="add-icon">
                          <VscGitStashPop
                            className="add1-icon"
                            onClick={exportToCSV1}
                          />
                        </div>
                      </Tooltip>
                    </div>
                  </div>
                </div>
              </div>
              <div className="">
                <DataTable
                  id="example"
                  data={jounalstatus}
                  columns={columns1}
                  className="display"
                  options={{
                    paging: true,
                    pageLength: 20,
                    lengthMenu: [
                      [20, 30, 50],
                      [20, 30, 50],
                    ],
                    order: [],
                    scrollX: true,
                  }}
                />
              </div>
            </section>
          </div>
        </div>
      </section>
    </>
  );
}

export default Operational_reports;
