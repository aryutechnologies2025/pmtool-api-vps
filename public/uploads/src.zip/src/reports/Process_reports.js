import React, { useState, useEffect } from "react";
import Header from "../components/Header.js";
import Breadcrumbs from "../routes/Breadcrumbs.js";
import DataTable from "datatables.net-react";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import axios from "axios";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import { VscGitStashPop } from "react-icons/vsc";
import Tooltip from "@mui/material/Tooltip";
import { render } from "@testing-library/react";
import { formatIndianCurrency } from "../AmountFormet.js";
import Papa from "papaparse";
import { saveAs } from "file-saver";
import Loader from "../components/Loader.js";


function Process_reports() {
  const [data, setData] = useState([]);
  const [pendingData, setPendingData] = useState([]);
  const [payment, setPayment] = useState([]);
  console.log('pendingData :',pendingData);
  console.log('payment :',payment);
  const fetchData = async () => {
    try {
      const [reportResponse, pendingResponse] = await Promise.all([
        axios.get(`${API_URL}/api/reports/get-report`),
        axios.get(`${API_URL}/api/reports/project-pending`)
      ]);
      
      setData(reportResponse.data.details);
      setPendingData(pendingResponse.data);
      
    } catch (error) {
      // ...
    }
  };
  useEffect(() => {
    fetchData();
  }, []);

  // total project pending

  const fetchDatapending = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/reports/get-project-payment`
      );
      setPayment(response.data.details);

      console.log("reposnsepending", response.data);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    fetchDatapending();
  }, []);

  const columns = [
    {
      title: "Type of project ",
      data: "type_of_work",
      render: (data) => Capitalize(data),
    },
    { title: "Total project Count  ", data: "total_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleProjectClick( '${row.type_of_work}')">${data}</span>`;
      }
     },
    {
      title: "Not Assigned",
      data: "not_assigned",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleproessClick('not_assigned', '${row.type_of_work}')">${data}</span>`;
      }
    },
    
    
    { title: "In progress ", data: "in_progress",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleproessClick('in_progress', '${row.type_of_work}')">${data}</span>`;
      }
     },
    { title: "Client Review ", data: "client_review",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleproessClick('client_review', '${row.type_of_work}')">${data}</span>`;
      }
     },
    { title: "Pending Author ", data: "pending_author",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleproessClick('pending_author', '${row.type_of_work}')">${data}</span>`;
      }
     },
    { title: "Completed", data: "completed",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleproessClick('completed', '${row.type_of_work}')">${data}</span>`;
      }
     },
    { title: "Withdrawn", data: "withdrawal",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleproessClick('withdrawal', '${row.type_of_work}')">${data}</span>`;
      }
     },
  ];
 const [emplyeename, setEmplyeename] = useState([]);
  console.log("empname:", emplyeename);
const[jounalstatus,setJournalStatus]=useState([]);
console.log("jounal:",jounalstatus)
  const fetchDatajounal = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/reports/journal-status`
      );
      
setEmplyeename(response.data)
      const flattenedToData = response.data.map((item) => {
        return {
          period: item.period,
          total:item.total,
          twoweek:item.two_weeks,
          twofourweek:item.two_four_weeks,
          fourweek:item.four_weeks,
          
        };
      });
      

      setJournalStatus(flattenedToData);
     
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    fetchDatajounal();
  }, []);
  const columns1 = [
    { title: "Type of project ", data: "type_of_work" },
    { title: "TC  ", data: "tc" },
    { title: "Pending - Statistics ", data: "pending_statistics" },
    { title: "Pending - Writer ", data: "pending_writer" },
    { title: "Pending - Reviewer", data: "pending_reviewer" },
    { title: "Pending - SME", data: "pending_sme" },
    { title: "Pending - Pub Manager", data: "pending_publication" },
    { title: "Pending - Author", data: "pending_author" },
  ];

  // payment
  const columns2 = [
    { title: "Type of project ", data: "type_of_project",render: (data) => Capitalize(data),
      
     },
    { title: "Total project Count  ", data: "total_project_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleProjectClick( '${row.type_of_project}')">${data}</span>`;
      }
     },
    { title: "Budget  ", data: "budget",
      render: (value) => formatIndianCurrency(Number(value) || 0)
     },
    { title: "Amount received", data: "amount_received",
      render: (value) => formatIndianCurrency(Number(value) || 0)
     },
    { title: "Amount Pending", data: "amount_pending",
      render: (value) => formatIndianCurrency(Number(value) || 0)
     },
    { title: "Journal Paid amount ", data: "Journal_paid_amount",
      render: (value) => formatIndianCurrency(Number(value) || 0)
     },
    { title: "Freelance paid  ", data: "Freelance_paid",
      render: (value) => formatIndianCurrency(Number(value) || 0)
     },
    { title: "Freelancer unpaid amount   ", data: "Freelance_unpaid",
      render: (value) => formatIndianCurrency(Number(value) || 0)
     },
  ];
  // jounal 
  const columns3 = [
    { title: "Period ", data: "period",
      render: (data) => Capitalize(data),
     },
    { title: "Total", data: "total" },
    { title: "<2 weeks  ", data: "twoweek" },
    { title: "2-4 weeks", data: "twofourweek" },
    { title: ">4 weeks", data: "fourweek" },
  ];

  window.handleproessClick = function(value1, value2) {
    console.log("Clicked value1:", value1);  // Logs the first value
    console.log("Clicked value2:", value2);  // Logs the second value
  
    // Set the first value in localStorage
    localStorage.setItem('procesStatus', value1);
  
    // Set the second value in localStorage
    localStorage.setItem('projectType', value2);
  
    // Open the new page in a new tab
    window.open('/projectlist', '_blank');
  };

  window. handleProjectClick = (projectType) => {
    // Store the projectType in localStorage
    localStorage.setItem('projectType', projectType);
  
    // Open the new tab with the projectlist URL
    window.open('/projectlist', '_blank', 'noopener,noreferrer');
  };
  
// total project export

  const exportToCSV = () => {
    // Define the column structure similar to the DataTable
    const exportColumns = [
      { title: "Type of Project", key: "type_of_work", format: Capitalize },
      { title: "Total Project Count", key: "total_count" },
      { title: "Not Assigned", key: "not_assigned" },
      { title: "In Progress", key: "in_progress" },
      { title: "Completed", key: "completed" },
      { title: "Withdrawn", key: "withdrawal" },
    ];
  
    // Prepare headers
    const headers = exportColumns.map(col => col.title);
  
    // Prepare body rows
    const bodyData = data.map(row =>
      exportColumns.map(col =>
        typeof col.format === "function" ? col.format(row[col.key]) : row[col.key] || "-"
      )
    );
  
    // Combine headers and data
    const csvData = [headers, ...bodyData];
  
    // Convert to CSV format
    const csv = Papa.unparse(csvData);
  
    // Create and download CSV file
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const formattedDate = new Date().toLocaleDateString("en-GB").replace(/\//g, "-");
    const fileName = `Total_Projects${formattedDate}.csv`;
  
    saveAs(blob, fileName);
  };
  

  const exportToCSV1 = () => {
    // Define export columns matching columns1
    const exportColumns = [
      { title: "Type of Project", key: "type_of_work", format: Capitalize },
      { title: "TC", key: "tc" },
      { title: "Pending - Statistics", key: "pending_statistics" },
      { title: "Pending - Writer", key: "pending_writer" },
      { title: "Pending - Reviewer", key: "pending_reviewer" },
      { title: "Pending - SME", key: "pending_sme" },
      { title: "Pending - Pub Manager", key: "pending_publication" },
      { title: "Pending - Author", key: "pending_author" },
    ];
  
    // Prepare headers
    const headers = exportColumns.map(col => col.title);
  
    // Prepare body rows
    const bodyData = pendingData.map(row =>
      exportColumns.map(col =>
        typeof col.format === "function" ? col.format(row[col.key]) : row[col.key] || "-"
      )
    );
  
    // Combine headers and data
    const csvData = [headers, ...bodyData];
  
    // Convert to CSV format
    const csv = Papa.unparse(csvData);
  
    // Create and download CSV file
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const formattedDate = new Date().toLocaleDateString("en-GB").replace(/\//g, "-");
    const fileName = `Total_Projects_Pending_${formattedDate}.csv`;
  
    saveAs(blob, fileName);
  };


  const exportToCSV2 = () => {
    // Define export columns matching columns2
    const exportColumns = [
      { title: "Type of Project", key: "type_of_project", format: Capitalize },
      { title: "Total Project Count", key: "total_project_count" },
      { title: "Budget", key: "budget" },
      { title: "Amount Received", key: "amount_received" },
      { title: "Amount Pending", key: "amount_pending" },
      { title: "Journal Paid Amount", key: "Journal_paid_amount" },
      { title: "Freelance Paid", key: "Freelance_paid" },
      { title: "Freelancer Unpaid Amount", key: "Freelance_unpaid" },
    ];
  
    // Prepare headers
    const headers = exportColumns.map(col => col.title);
  
    // Prepare body rows
    const bodyData = payment.map(row =>
      exportColumns.map(col =>
        typeof col.format === "function" ? col.format(row[col.key]) : row[col.key] || "-"
      )
    );
  
    // Combine headers and data
    const csvData = [headers, ...bodyData];
  
    // Convert to CSV format
    const csv = Papa.unparse(csvData);
  
    // Create and download CSV file
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const formattedDate = new Date().toLocaleDateString("en-GB").replace(/\//g, "-");
    const fileName = `Total_Projects_Payments_${formattedDate}.csv`;
  
    saveAs(blob, fileName);
  };
  
  const exportToCSV3 = () => {
    // Define export columns matching columns3
    const exportColumns = [
      { title: "Period", key: "period", format: Capitalize },
      { title: "Total", key: "total" },
      { title: "<2 Weeks", key: "twoweek" },
      { title: "2-4 Weeks", key: "twofourweek" },
      { title: ">4 Weeks", key: "fourweek" },
    ];
  
    // Prepare headers
    const headers = exportColumns.map(col => col.title);
  
    // Prepare body rows (assuming dataset is called `delayData`)
    const bodyData = jounalstatus.map(row =>
      exportColumns.map(col =>
        typeof col.format === "function" ? col.format(row[col.key]) : row[col.key] || "-"
      )
    );
  
    // Combine headers and data
    const csvData = [headers, ...bodyData];
  
    // Convert to CSV format
    const csv = Papa.unparse(csvData);
  
    // Create and download CSV file
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const formattedDate = new Date().toLocaleDateString("en-GB").replace(/\//g, "-");
    const fileName = `Journal_status${formattedDate}.csv`;
  
    saveAs(blob, fileName);
  };
  
  const Capitalize = (str) => str?.charAt(0).toUpperCase() + str?.slice(1).toLowerCase();

const formatIndianCurrency = (value) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
  }).format(value);
};
const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }
  return (
    <>
      <section className="container container d-flex flex-column justify-content-between min-vh-100">
        <div className="mt-4 w-100">
          <div className="col-12 ">
            <div className="col-12">
              <Header></Header>
            </div>
            <div className=" pt-1 mt-3 py-3 project-manage w-100 ">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className="col-12 col-md-6  px-3 pt-3">
                  <h1 className="heading-entr">Process Reports</h1>
                </div>

                <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>

              <section className="pb-2 mt-2">
                <div className="d-flex justify-content-between">
                  <div className="heading-entr mt-1">Total Projects </div>
                  <div className="text-center ">
                    <div className="d-flex justify-content-center gap-2">
                      <Tooltip title="Export">
                        <div className="add-icon">
                          <VscGitStashPop
                            className="add1-icon"
                            onClick={exportToCSV}
                          />
                        </div>
                      </Tooltip>
                    </div>
                  </div>
                </div>

                <div>
                  <DataTable
                    id="example"
                    data={data}
                    columns={columns}
                    className="display"
                    options={{
                      scrollX: true,
                      select: true,
                      pageLength: 20, // Default number of rows per page
                      lengthMenu: [
                        [20, 30, 50],
                        [20, 30, 50],
                      ],
                      search: {
                        return: true, // Ensures search starts fresh
                      },
                    }}
                  />
                </div>
              </section>
            </div>

            <section className="  mt-2 project-manage w-100 py-3">
              <div className="col-12 pt-3 ">
                <div className="d-flex justify-content-between">
                  <div className="heading-entr mt-1">Total Projects Pending </div>
                  <div className="text-center ">
                    <div className="d-flex justify-content-center gap-2">
                      <Tooltip title="Export">
                        <div className="add-icon">
                          <VscGitStashPop
                            className="add1-icon"
                            onClick={exportToCSV1}
                          />
                        </div>
                      </Tooltip>
                    </div>
                  </div>
                </div>
              </div>
              <div className="">
                <DataTable
                  id="example"
                  data={pendingData}
                  columns={columns1}
                  className="display"
                  options={{
                    paging: true,
                    pageLength: 20,
                    lengthMenu: [
                      [20, 30, 50],
                      [20, 30, 50],
                    ],
                    scrollX: true,
                  }}
                />
              </div>
            </section>

            <section className="  mt-2 project-manage w-100 py-3">
              <div className="col-12 pt-3 ">
              <div className="d-flex justify-content-between">
                  <div className="heading-entr mt-1">Total Projects Payments </div>
                  <div className="text-center ">
                    <div className="d-flex justify-content-center gap-2">
                      <Tooltip title="Export">
                        <div className="add-icon">
                          <VscGitStashPop
                            className="add1-icon"
                            onClick={exportToCSV2}
                          />
                        </div>
                      </Tooltip>
                    </div>
                  </div>
                </div>
              </div>
              <div className="">
                <DataTable
                  id="example"
                  data={payment}
                  columns={columns2}
                  className="display"
                  options={{
                    paging: true,
                    pageLength: 20,
                    lengthMenu: [
                      [20, 30, 50],
                      [20, 30, 50],
                    ],
                    scrollX: true,
                  }}
                />
              </div>
            </section>
            <section className="  mt-2 project-manage w-100 py-3">
              <div className="col-12 pt-3 ">
                <div className="d-flex justify-content-between">
                  <div className="heading-entr mt-1">Journal Status </div>
                  <div className="text-center ">
                    <div className="d-flex justify-content-center gap-2">
                      <Tooltip title="Export">
                        <div className="add-icon">
                          <VscGitStashPop
                            className="add1-icon"
                            onClick={exportToCSV3}
                          />
                        </div>
                      </Tooltip>
                    </div>
                  </div>
                </div>
              </div>
              <div className="">
                <DataTable
                  id="example"
                  data={jounalstatus}
                  columns={columns3}
                  className="display"
                  options={{
                    paging: true,
                    pageLength: 20,
                    lengthMenu: [
                      [20, 30, 50],
                      [20, 30, 50],
                    ],
                    scrollX: true,
                  }}
                />
              </div>
            </section>
          </div>
        </div>
      </section>
    </>
  );
}

export default Process_reports;
