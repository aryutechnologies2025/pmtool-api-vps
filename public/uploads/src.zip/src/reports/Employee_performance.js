import React, { useState, useEffect } from "react";
import Header from "../components/Header.js";
import Breadcrumbs from "../routes/Breadcrumbs.js";
import DataTable from "datatables.net-react";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import axios from "axios";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import Loader from "../components/Loader.js";

function Employee_performance() {
  const [data, setData] = useState([]);
  // console.log("alldata:", data);
  const [emplyeename, setEmplyeename] = useState([]);
  // console.log("empname:", emplyeename);

  const fetchData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/reports/employee-type-report`
      );
      setData(response.data);
      const flattenedToData = response.data.map((item) => {
        return {
          empstatus: item.created_by_users[0].name,
        };
      });
      // console.log("alldetails:", flattenedToData);

      setEmplyeename(flattenedToData);
      // setEmplyeename(response.data[0].created_by_users[0].name
      // )

      //       const employeeNames = response.data[0].created_by_users.map(user => user.name).join(', ');
      // setEmplyeename(employeeNames);

      // console.log(response.data);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);

  const [allempid, setallempid] = useState([]);
  console.log("empid:", allempid);

  const [fullemp, setFullemp] = useState([]);

  const [projectdetails, setProjectdetails] = useState([]);

  console.log("empdetails:", fullemp);

  const fetchDataemp = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/reports/employee-performance-report`,
        {
          params: {
            employee_id: allempid,
          },
        }
      );
      setFullemp(response.data);

      const flattenedToData = response.data.map((item) => {
        return {
          projectid: item.project_ids?.[0] || "-",
          writerduration:
            item.writer.normal?.map((e) => e.duration).join(", ") || "-",
          writercount: item.writer.corrections_count ?? "-",
          correctionduration:
            item.writer.corrections?.map((e) => e.duration).join(", ") || "-",
          plagcorrectioncount: item.writer.plag_corrections_count ?? "-",
          plagcorrectionduration:
            item.writer.plag_corrections?.map((e) => e.duration).join(", ") ||
            "-",

          // reviwer

          reviewerduration:
            item.reviewer.normal?.map((e) => e.duration).join(", ") || "-",
          reviewercount: item.reviewer.corrections_count ?? "-",
          reviewercorrectionduration:
            item.reviewer.corrections?.map((e) => e.duration).join(", ") || "-",
          reviewerplagcorrectioncount:
            item.reviewer.plag_corrections_count ?? "-",
          reviewerplagcorrectionduration:
            item.reviewer.plag_corrections?.map((e) => e.duration).join(", ") ||
            "-",
          totalduration: item.total_duration || "-",
        };
      });
      console.log("allprojectdetails:", flattenedToData);

      setProjectdetails(flattenedToData);

      console.log(response.data);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    if (allempid) {
      fetchDataemp(); // Fetch data when an employee is selected
    }
  }, [allempid]);

  const handleEmployeeChange = (e) => {
    setallempid(e.target.value);
  };

  // employess name
  const [empallname, setEmpallname] = useState([]);

  console.log("allnames:", empallname);
  const fetchdataallemp = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/getEmployeeNameReport`
      );
      setEmpallname(response.data);
      setallempid(response.data.map((emp) => emp.id));
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    fetchdataallemp();
  }, []);

  const columns = [
    { data: "projectid", render: Capitalize },
    { data: "writerduration" },
    { data: "writercount" },
    { data: "correctionduration" },
    { data: "plagcorrectioncount" },
    { data: "plagcorrectionduration" },
    // reviwer
    { data: "reviewerduration" },
    { data: "reviewercount" },
    { data: "reviewercorrectionduration" },
    { data: "reviewerplagcorrectioncount" },
    { data: "reviewerplagcorrectionduration" },
    { data: "totalduration" },
  ];
  const columns1 = [
    { title: "Employee Name   ", data: "employee_name" },
    {
      title: "Work Type ",
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
                 <div class="d-flex justify-content-center ">
                   <div class="table-row-width"><div>Writing</div></div>
       
        </div>
                 
               `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
                <div class="d-flex justify-content-center ">
                   <div class="table-row-width"><div>Reviewing</div></div>
       
        </div>
                 
               `;
        }

        if (positions.includes("11")) {
          tableContent += `
                  <div class="d-flex justify-content-center">
                   <div class="table-row-width"><div>statistician</div></div>
     
        </div>
               `;
        }

        if (positions.includes("10")) {
          tableContent += `
                  <div class="d-flex justify-content-center ">
                   <div class="table-row-width"><div>Journal</div></div>
     
        </div>
               `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },

    {
      title: "Count",
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
                  <div class="d-flex justify-content-center ">
                    
         <div class="mx-2">${writerCount}</div>
         </div>
                  
                `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider-final"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
                 <div class="d-flex justify-content-center">
                 
         <div class="mx-2">${reviewerCount}</div>
         </div>
                  
                `;
        }

        if (positions.includes("11")) {
          tableContent += `
                   <div class="d-flex justify-content-center">
                 
         <div class="mx-2">${statisticianCount}</div>
         </div>
                `;
        }

        if (positions.includes("10")) {
          tableContent += `
                   <div class="d-flex justify-content-center">
                 
         <div class="mx-2">${journalCount}</div>
         </div>
                `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    //   {
    //     title: "Total Duration ",
    //     data: null,
    //     render: (data, type, row) => {
    //       let positions = row.position.split(",").map((pos) => pos.trim());

    //       let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
    //       let reviewerCount = positions.includes("8")
    //         ? row.reviewer_count || 0
    //         : 0;
    //       let journalCount = positions.includes("10")
    //         ? row.journal_count || 0
    //         : 0;
    //       let
    //       total_duration
    //        = positions.includes("11")
    //         ? row.statistican_count || 0
    //         : 0;

    //       let tableContent = `<table class="nested-table">`;

    //       if (positions.includes("7")) {
    //         tableContent += `
    //           <div class="d-flex justify-content-center ">

    //  <div class="mx-2">${
    //   total_duration
    //   }</div>
    //  </div>

    //         `;
    //       }
    //       if (positions.includes("7") && positions.includes("8")) {
    //         tableContent += `<div class="row-divider"></div>`;
    //       }
    //       if (positions.includes("8")) {
    //         tableContent += `
    //          <div class="d-flex justify-content-center">

    //  <div class="mx-2">${
    //   total_duration
    //   }</div>
    //  </div>

    //         `;
    //       }

    //       if (positions.includes("11")) {
    //         tableContent += `
    //            <div class="d-flex justify-content-center">

    //  <div class="mx-2">${
    //   total_duration
    //   }</div>
    //  </div>
    //         `;
    //       }

    //       if (positions.includes("10")) {
    //         tableContent += `
    //            <div class="d-flex justify-content-center">

    //  <div class="mx-2">${
    //   total_duration
    //   }</div>
    //  </div>
    //         `;
    //       }

    //       tableContent += `</table>`;

    //       return tableContent;
    //     },
    //   },
    {
      title: "Total Duration ",
      data: "total_duration",
    },

    // {
    //   title: "Avg. Range  per project",
    //   data: null,
    //   render: function (data, type, row) {
    //     return `
    //           <div class="d-flex justify-content-center">
    //             <div class="table-row-width"><div>20</div></div>
    //           </div>
    //           <div class="row-divider-final"></div>
    //           <div class="d-flex justify-content-center">
    //             <div class="table-row-width"><div>2</div></div>
    //           </div>
    //         `;
    //   },
    // },
  ];

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }
  return (
    <>
      <section className="container container d-flex flex-column justify-content-between min-vh-100">
        <div className="mt-4 w-100">
          <div className="col-12 ">
            <div className="col-12">
              <Header></Header>
            </div>
            <div className=" pt-1 mt-3 py-3 project-manage w-100 ">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className="col-12 col-md-6  px-3 pt-3">
                  <h1 className="heading-entr">Employee Performance </h1>
                </div>

                <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>

              <section className="pb-2 mt-2">
                <div className="row ">
                  <div className="col-12 ">
                    {/* <h className="heading-entr">Project Durations </h> */}
                  </div>
                </div>
                <div>
                  <DataTable
                    data={projectdetails}
                    columns={columns}
                    className="display"
                    options={{
                      order: [],
                    }}
                  >
                    <thead>
                      <tr>
                        <th colSpan="2" className="payment-table">
                          <label className="statis-name">Employee Name</label>

                          <select
                            className="form-select2"
                            onChange={handleEmployeeChange}
                            value={allempid}
                          >
                            <option value="">Select Employee</option>
                            {empallname.map((empname) => (
                              <option key={empname.id} value={empname.id}>
                                {empname.name + " (" + empname.role + ")"}
                              </option>
                            ))}
                          </select>
                        </th>
                        <th colSpan="10" className="payment-table">
                          <div class="d-flex mb-2">
                            <div class="table-row-width-final">
                              <div>Manuscript writing Average Range: </div>
                            </div>
                          </div>
                          <div class="row-divider-final"></div>
                          <div class="d-flex mt-2 mb-2">
                            <div class="table-row-width-final">
                              <div>Thesis Writing Average Range: </div>
                            </div>
                          </div>
                          <div class="row-divider-final"></div>
                          <div class="d-flex mt-2">
                            <div class="table-row-width-final">
                              <div>Reviewing Average Range:</div>
                            </div>
                          </div>
                        </th>
                      </tr>
                      <tr>
                        <th className="payment-table">Project ID</th>
                        <th className="payment-table">Writing</th>
                        <th className="payment-table">Correction</th>
                        <th className="payment-table">Correction Timing</th>
                        <th className="payment-table">Plag Correction</th>
                        <th className="payment-table">
                          Plag Correction Timing
                        </th>
                        <th className="payment-table">Reviewing</th>
                        <th className="payment-table">Correction</th>
                        <th className="payment-table">Correction Timing </th>
                        <th className="payment-table">Plag Correction </th>
                        <th className="payment-table">
                          Plag Correction Timing{" "}
                        </th>
                        <th className="payment-table">Total Timing </th>
                      </tr>
                      <tr>
                        <th></th>
                        <th>Ongoing Status to Completed Status Time</th>
                        <th>Count</th>
                        <th>Ongoing to Completed</th>
                        <th>Count</th>
                        <th>Ongoing to Completed</th>
                        <th>Ongoing to Completed</th>
                        <th>Count</th>

                        <th>Ongoing to Completed</th>
                        <th>Count</th>
                        <th>Ongoing to Completed</th>
                        <th>Total Timing </th>
                      </tr>
                    </thead>
                  </DataTable>
                </div>
              </section>
            </div>

            <section className="  mt-2 project-manage w-100 py-3">
              <div className="col-12 pt-3 ">
                {/* <h2 className="heading-entr">Operational Duration</h2> */}
              </div>
              <div className="">
                <DataTable
                  id="example"
                  data={data}
                  columns={columns1}
                  className="display"
                  options={{
                    paging: true,
                    pageLength: 20,
                    lengthMenu: [
                      [20, 30, 50],
                      [20, 30, 50],
                    ],
                    scrollX: true,
                  }}
                />
              </div>
            </section>
          </div>
        </div>
      </section>
    </>
  );
}

export default Employee_performance;
