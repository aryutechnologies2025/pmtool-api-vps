import React, { useState, useEffect } from "react";
import Header from "../components/Header.js";
import Breadcrumbs from "../routes/Breadcrumbs.js";
import DataTable from "datatables.net-react";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import axios from "axios";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import { VscGitStashPop } from "react-icons/vsc";
import Tooltip from "@mui/material/Tooltip";
import Papa from 'papaparse';
import { saveAs } from 'file-saver';
import Loader from "../components/Loader.js";



function Client_analysis() {
  const [data, setData] = useState([]);
  const [institute, setIntitute] = useState([]);
  const [profession, setProfession] = useState([]);

  // department
  const fetchData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/reports/get-department-report`
      );
      setData(response.data.department_report);

      console.log("department report", response.data);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  // instution
  const fetchDatainstitute = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/reports/get-institute-report`
      );
      setIntitute(response.data.institute_report);

      console.log("institute report", response.data);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    fetchDatainstitute();
  }, []);

  // profession

  const fetchDataprofession = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/reports/get-profession-report`
      );
      setProfession(response.data.profession_report);

      console.log("profession report", response.data);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    fetchDataprofession();
  }, []);

// department
  window.handledepClick = function(value1) {
    console.log("Clicked value1:", value1);  // Logs the first value
  
    localStorage.setItem('departmentstatus', value1);
  
  
    window.open('/projectlist', '_blank');
  };

  window.handledepallClick = function(value1, value2) {
    console.log("Clicked value1:", value1);  // Logs the first value
    console.log("Clicked value2:", value2);  // Logs the second value
  
    localStorage.setItem('departmentstatus', value1);
  
    localStorage.setItem('projectType', value2);
  
    window.open('/projectlist', '_blank');
  };

  // instution

  window.handleinstClick = function(value1) {
    console.log("Clicked value1:", value1);  // Logs the first value
  
    localStorage.setItem('instutionstatus', value1);
  
  
    window.open('/projectlist', '_blank');
  };

  window.handleinstallClick = function(value1, value2) {
    console.log("Clicked value1:", value1);  // Logs the first value
    console.log("Clicked value2:", value2);  // Logs the second value
  
    localStorage.setItem('instutionstatus', value1);
  
    localStorage.setItem('projectType', value2);
  
    window.open('/projectlist', '_blank');
  };

  // profession

  window.handleprofClick = function(value1) {
    console.log("Clicked value1:", value1);  // Logs the first value
  
    localStorage.setItem('professionstatus', value1);
  
  
    window.open('/projectlist', '_blank');
  };

  window.handleprofallClick = function(value1, value2) {
    console.log("Clicked value1:", value1);  // Logs the first value
    console.log("Clicked value2:", value2);  // Logs the second value
  
    localStorage.setItem('professionstatus', value1);
  
    localStorage.setItem('projectType', value2);
  
    window.open('/projectlist', '_blank');
  };

  // department
  const columns = [
    {
      title: "Departments  ",
      data: "department_name",
      render: (data) => Capitalize(data),
    },
    { title: "Total Count ", data: "total_count",
      render: function (data, type, row, meta) {
              return `<span class="my-clickable-span" onclick="handledepClick( '${row.department_name}')">${data}</span>`;
            }
     },
    { title: "Statistics ", data: "statistics_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handledepallClick( '${row.department_name}','statistics')">${data}</span>`;
      }
},
     
    { title: "Manuscript ", data: "manuscript_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handledepallClick( '${row.department_name}','manuscript')">${data}</span>`;
      }
     },
    { title: "Thesis ", data: "thesis_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handledepallClick( '${row.department_name}','thesis')">${data}</span>`;
      }
     },
    { title: "Others ", data: "others_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handledepallClick( '${row.department_name}','others')">${data}</span>`;
      }
     },
    { title: "Publication ", data: "publication_count" },
  ];
  const exportToCSV = () => {
    const columns = [
      { title: "Departments", data: "department_name", render: Capitalize },
      { title: "Total Count", data: "total_count" },
      { title: "Statistics", data: "statistics_count" },
      { title: "Manuscript", data: "manuscript_count" },
      { title: "Thesis", data: "thesis_count" },
      { title: "Others", data: "others_count" },
      { title: "Publication", data: "publication_count" },
    ];
  
    // Prepare CSV data with headers
    const csv = Papa.unparse({
      fields: columns.map((col) => col.title),
      data: data.map((row) => {
        return columns.map((col) => {
          const value = row[col.data] || "-";
          return col.render ? col.render(value) : value;
        });
      }),
    });
  
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  
    const currentDate = new Date();
    const formattedCurrentDate = currentDate.toISOString().split("T")[0];
    const fileName = `report_Department_${formattedCurrentDate}.csv`;
  
    saveAs(blob, fileName);
  };
  
  
  // instute
  const columns1 = [
    {
      title: "Institute   ",
      data: "institute_name",
      render: (data) => Capitalize(data),
    },
    { title: "Total Count ", data: "total_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleinstClick( '${row.institute_name}')">${data}</span>`;
      }
},
    
    { title: "Statistics ", data: "statistics_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleinstallClick( '${row.institute_name}','statistics')">${data}</span>`;
      }
     },
    { title: "Manuscript ", data: "manuscript_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleinstallClick( '${row.institute_name}','manuscript')">${data}</span>`;
      }
     },
    { title: "Thesis ", data: "thesis_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleinstallClick( '${row.institute_name}','thesis')">${data}</span>`;
      }
     },
    { title: "Others ", data: "others_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleinstallClick( '${row.institute_name}','others')">${data}</span>`;
      }
     },
    { title: "Publication ", data: "publication_count" },
  ];
  const exportToCSV1 = () => {
    const columns1 = [
      {
        title: "Institute   ",
        data: "institute_name",
        render: (data) => Capitalize(data),
      },
      { title: "Total Count ", data: "total_count" },
      { title: "Statistics ", data: "statistics_count" },
      { title: "Manuscript ", data: "manuscript_count" },
      { title: "Thesis ", data: "thesis_count" },
      { title: "Others ", data: "others_count" },
      { title: "Publication ", data: "publication_count" },
    ];
  
    try {
      const csv = Papa.unparse({
        fields: columns1.map((col) => col.title),
        data: institute.map((row) =>
          columns1.map((col) => {
            const value = row[col.data];
            return col.render ? col.render(value || "-") : value || "-";
          })
        ),
      });
  
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const formattedDate = new Date().toLocaleDateString("en-GB").replace(/\//g, "-");
      const fileName = `report_institute_${formattedDate}.csv`;
  
      saveAs(blob, fileName);
    } catch (error) {
      console.error("Error exporting CSV:", error);
      alert("Failed to export CSV. Please try again.");
    }
  };
  
  // profession
  const columns2 = [
    { title: "Profession   ", data: "profession_name",render: (data) => Capitalize(data), },
    { title: "Total Count ", data: "total_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleprofClick( '${row.profession_name}')">${data}</span>`;
      }
},
    
    { title: "Statistics ", data: "statistics_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleprofallClick( '${row.profession_name}','statistics')">${data}</span>`;
      }
     },
    { title: "Manuscript ", data: "manuscript_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleprofallClick( '${row.profession_name}','manuscript')">${data}</span>`;
      }
     },
    { title: "Thesis ", data: "thesis_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleprofallClick( '${row.profession_name}','thesis')">${data}</span>`;
      }
     },
    { title: "Others ", data: "others_count",
      render: function (data, type, row, meta) {
        return `<span class="my-clickable-span" onclick="handleprofallClick( '${row.profession_name}','others')">${data}</span>`;
      }
     },
    { title: "Publication ", data: "publication_count" },
  ];
  const exportToCSV2 = () => {
    const columns2 = [
      { title: "Profession   ", data: "profession_name",render: (data) => Capitalize(data), },
      { title: "Total Count ", data: "total_count" },
      { title: "Statistics ", data: "statistics_count" },
      { title: "Manuscript ", data: "manuscript_count" },
      { title: "Thesis ", data: "thesis_count" },
      { title: "Others ", data: "others_count" },
      { title: "Publication ", data: "publication_count" },
    ];
  
    try {
      const csv = Papa.unparse({
        fields: columns2.map((col) => col.title),
        data: profession.map((row) =>
          columns2.map((col) => {
            const value = row[col.data];
            return col.render ? col.render(value || "-") : value || "-";
          })
        ),
      });
  
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const formattedDate = new Date().toLocaleDateString("en-GB").replace(/\//g, "-");
      const fileName = `report_profession_${formattedDate}.csv`;
  
      saveAs(blob, fileName);
    } catch (error) {
      console.error("Error exporting CSV:", error);
      alert("Failed to export CSV. Please try again.");
    }
  };
  


  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }  

  return (
    <>
      <section className="container container d-flex flex-column justify-content-between min-vh-100">
        <div className="mt-4 w-100">
          <div className="col-12 ">
            <div className="col-12">
              <Header></Header>
            </div>
            <div className=" pt-1 mt-3 py-3 project-manage w-100 ">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className="col-12 col-md-6  px-3 pt-3">
                  <h1 className="heading-entr"> Client analysis</h1>
                </div>

                <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>

              <section className="pb-2 mt-2">
                <div className="d-flex justify-content-between">
                  <div className="heading-entr mt-1">Department Report </div>
                  <div className="text-center ">
                    <div className="d-flex justify-content-center gap-2">
                      <Tooltip title="Export">
                        <div className="add-icon">
                          <VscGitStashPop
                            className="add1-icon"
                            onClick={exportToCSV}
                          />
                        </div>
                      </Tooltip>
                    </div>
                  </div>
                </div>
                <div>
                  <DataTable
                    id="example"
                    data={data}
                    columns={columns}
                    className="display"
                    options={{
                      scrollX: true,
                      select: true,
                      pageLength: 20, // Default number of rows per page
                      lengthMenu: [
                        [20, 30, 50],
                        [20, 30, 50],
                      ],
                      search: {
                        return: true, // Ensures search starts fresh
                      },
                    }}
                  />
                </div>
              </section>
            </div>

            <section className="  mt-2 project-manage w-100 py-3">
              <div className="d-flex justify-content-between">
                <div className="heading-entr mt-1">Institute Report </div>
                <div className="text-center ">
                  <div className="d-flex justify-content-center gap-2">
                    <Tooltip title="Export">
                      <div className="add-icon">
                        <VscGitStashPop
                          className="add1-icon"
                          onClick={exportToCSV1}
                        />
                      </div>
                    </Tooltip>
                  </div>
                </div>
              </div>
              <div className="">
                <DataTable
                  id="example"
                  data={institute}
                  columns={columns1}
                  className="display"
                  options={{
                    paging: true,
                    pageLength: 20,
                    lengthMenu: [
                      [20, 30, 50],
                      [20, 30, 50],
                    ],
                    scrollX: true,
                  }}
                />
              </div>
            </section>

            <section className="  mt-2 project-manage w-100 py-3">
            <div className="d-flex justify-content-between">
                <div className="heading-entr mt-1">Profession Report  </div>
                <div className="text-center ">
                  <div className="d-flex justify-content-center gap-2">
                    <Tooltip title="Export">
                      <div className="add-icon">
                        <VscGitStashPop
                          className="add1-icon"
                          onClick={exportToCSV2}
                        />
                      </div>
                    </Tooltip>
                  </div>
                </div>
              </div>
              <div className="">
                <DataTable
                  id="example"
                  data={profession}
                  columns={columns2}
                  className="display"
                  options={{
                    paging: true,
                    pageLength: 20,
                    lengthMenu: [
                      [20, 30, 50],
                      [20, 30, 50],
                    ],
                    scrollX: true,
                  }}
                />
              </div>
            </section>
          </div>
        </div>
      </section>
    </>
  );
}

export default Client_analysis;
