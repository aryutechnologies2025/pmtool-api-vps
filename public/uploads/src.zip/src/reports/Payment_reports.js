import React, { useState, useEffect } from "react";
import Header from "../components/Header.js";
import Breadcrumbs from "../routes/Breadcrumbs.js";
import { Table } from "react-bootstrap";
import DataTable from "datatables.net-react";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import axios from "axios";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import { VscGitStashPop } from "react-icons/vsc";
import Tooltip from "@mui/material/Tooltip";
import Papa from "papaparse";
import { saveAs } from "file-saver";
import { useNavigate } from "react-router-dom";
import { formatIndianCurrency } from "../AmountFormet.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import Loader from "../components/Loader.js";


const Payment_reports = () => {
  const [data, setData] = useState([]);
  const [totalyear, settotalYear] = useState([]);
  const [year, setYear] = useState([]);

    const [loading, setLoading] = useState(true);


  // year

  const fetchData = async () => {
           setLoading(true);

    try {
      const response = await axios.get(
        `${API_URL}/api/reports/get-yearly-report`
      );
      const allMonthsData = response.data.flatMap((value) => value.months);
      const yearTotal = response.data.flatMap((value) => value.yearly_total);
      const yearAccount = response.data.flatMap((value) => value.year);

      setData(allMonthsData);
      settotalYear(yearTotal);
      setYear(yearAccount);
      console.log("year:", yearAccount);
      console.log("tota year:", yearTotal);
      console.log("months table", response.data);
      console.log("months table", response.data[0].months);
       setLoading(false);

    } catch (error) {
      console.error("error fetching data", error);

    }finally {
    setLoading(false);  
  }
  };
  useEffect(() => {
    fetchData();
  }, []);

  console.log(year);

  const exportToCSV = () => {
    // Prepare headers
    const headers = [
      ["Yearly Process Comparison"], // Title

      [
        "Months",
        ...year.flatMap(() => [
          "Total Count",
          "Budget",
          "Writers Reviewers Payment",
          "Journals Payment",
          "Office emp salary",
        ]),
      ], // Dynamic year headers
    ];

    // Prepare body data
    const bodyData = data.map((row) => [
      row.month,
      ...year.flatMap(() => [
        row.total_count || "-",
        row.total_budget || "-",
        row.writer_reviewer_payment || "-",
        row.journal_payment || "-",
        row.office_emp_salary || "-",
      ]),
    ]);

    // Prepare footer data (Total Year values)
    const footerData = totalyear.map((row) => [
      row.total_year.split("_").map(Capitalize).join(" "),
      row.total_count || "-",
      row.total_budget || "-",
      row.writer_reviewer_payment || "-",
      row.journal_payment || "-",
      row.office_emp_salary || "-",
    ]);

    // Combine all data
    const csvData = [...headers, ...bodyData, ...footerData];

    // Convert to CSV format
    const csv = Papa.unparse(csvData);

    // Create and download CSV file
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const formattedDate = new Date()
      .toLocaleDateString("en-GB")
      .replace(/\//g, "-");
    const fileName = `Yearly_Process_Comparison_${formattedDate}.csv`;

    saveAs(blob, fileName);
  };

  // year income
  const [income, setIncome] = useState([]);
  const [incometotal, setIncometotal] = useState([]);
  const [incomeyear, setIncomeyear] = useState([]);

  const fetchDatayear = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/reports/get-yearly-income`
      );

      const allincomedata = response.data.flatMap((value) => value.data);
      const allyear = response.data.flatMap((value) => value.total_data);
      const allincomeyear = response.data.flatMap((value) => value.year);

      setIncome(allincomedata);
      setIncometotal(allyear);
      setIncomeyear(allincomeyear);
 setLoading(false);

      console.log("income:", response.data);
    } catch (error) {
      console.error("error fetching data", error);
            setLoading(false);

    }
  };
  useEffect(() => {
    fetchDatayear();
  }, []);

  const navigate = useNavigate();

  // const handleProjectClick = (projectType) => {
  //   navigate('/projectlist', { state: { projectType } });
  // };

  const handleProjectClick = (projectType) => {
    // Store the projectType in localStorage
    localStorage.setItem("projectType", projectType);

    // Open the new tab with the projectlist URL
    window.open("/projectlist", "_blank", "noopener,noreferrer");
  };

  // const columns1 = [
  //   { data: "id" },
  //   { data: "id" },
  //   { data: "id" },
  //   { data: "id" },
  //   { data: "id" },
  //   { data: "id" },
  //   { data: "id" },
  //   { data: "id" },

  //   { data: "id" },
  //   { data: "id" },
  //   { data: "id" },
  //   { data: "id" },
  //   { data: "id" },

  // ];

  const [totalall, setToatalyear] = useState([]);
  console.log("totallyear:", totalall);

  const fetchDataall = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        `${API_URL}/api/reports/get-total-payment
`
      );
      setToatalyear(response.data);

      // const allincomedata = response.data.flatMap((value) => value.data);
      // const allyear = response.data.flatMap((value) => value.total_data);
      // const allincomeyear = response.data.flatMap((value) => value.year);

      // setIncome(allincomedata);
      // setIncometotal(allyear);
      // setIncomeyear(allincomeyear);

      console.log("income:", response.data);
       setLoading(false);

    } catch (error) {
      console.error("error fetching data", error);
            setLoading(false);

    }
  };
  useEffect(() => {
    fetchDataall();
  }, []);
  const columns2 = [
    { title: "Year   ", data: "Year" },
    { title: "Total Project", data: "Total_Project" },
    { title: "Budget ", data: "Budget",
      render: (data) => {
        const formattedData = formatIndianCurrency(Math.abs(data)); // Ensure no negative sign

        return formattedData.charAt(0).toUpperCase() + formattedData.slice(1);
      },
     },
    { title: "Expense ", data: "Expense",
      render: (data) => {
        const formattedData = formatIndianCurrency(Math.abs(data)); // Ensure no negative sign

        return formattedData.charAt(0).toUpperCase() + formattedData.slice(1);
      },
     },
    { title: "Total received amount ", data: "Total_Received_Amount",
      render: (data) => {
        const formattedData = formatIndianCurrency(Math.abs(data)); // Ensure no negative sign

        return formattedData.charAt(0).toUpperCase() + formattedData.slice(1);
      },
     },
    {
      title: "Income ",
      data: "Income",
      render: (data) => {
        const formattedData = formatIndianCurrency(Math.abs(data)); // Ensure no negative sign

        return formattedData.charAt(0).toUpperCase() + formattedData.slice(1);
      },
    },
    {
      title: "Income ",
      data: "Income_percentage",
      render: (data) => {
        const formattedData = CapitalizeCaseU(Math.abs(data).toString()); // Ensure no negative sign

        return `${formattedData}%`; // Capitalized result
      },
    },
  ];


  // useEffect(() => {
  //   const handleLoad = () => {
  //     setTimeout(() => {
  //       setLoading(false);
  //     }, 1000);
  //   };

  //   if (document.readyState === "complete") {
  //     handleLoad();
  //   } else {
  //     window.addEventListener("load", handleLoad);
  //   }

  //   return () => window.removeEventListener("load", handleLoad);
  // }, []);

  // if (loading) {
  //   return <Loader />;
  // }
  return (
    <>
      <section className="container container d-flex flex-column justify-content-between min-vh-100">
         {loading ? (
        <Loader />
      ) : (
        <>
        <div className="mt-4 w-100">
          <div className="col-12 ">
            <div className="col-12">
              <Header></Header>
            </div>
            <div className=" pt-1 mt-3 py-3 project-manage w-100 ">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className="col-12 col-md-6  px-3 pt-3">
                  <h1 className="heading-entr">Payment report </h1>
                </div>

                <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>

              <div>
                <div className="d-flex justify-content-between">
                  <div className="heading-entr mt-1">
                    Yearly Process Comparison
                  </div>
                  <div className="text-center ">
                    <div className="d-flex justify-content-center gap-2 mx-2">
                      <Tooltip title="Export">
                        <div className="add-icon">
                          <VscGitStashPop
                            className="add1-icon"
                            onClick={exportToCSV}
                          />
                        </div>
                      </Tooltip>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-12 mt-2 table-responsive  table-wrapper-scroll-y my-custom-scrollbar  ">
                <table className="table-head">
                  <thead className="">
                    <tr className="payment-table">
                      <th colSpan={year.length * 5 + 1}>
                        Yearly Process Comparison
                      </th>
                    </tr>
                    <tr className="payment-table">
                      <th rowSpan="2" className="fw-bold">
                        Months
                      </th>
                      {year.map((row, index) => (
                        <th colSpan="5" key={index} className="fw-bold">
                          {row}
                        </th>
                      ))}
                    </tr>
                    <tr className="payment-table">
                      <th>Total Count</th>
                      <th>Budget</th>
                      <th>Writers Reviewers Payment</th>
                      <th>Journals Payment</th>
                      <th>Office emp salary</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.map((row, index) => (
                      <tr key={index}>
                        <td className="payment-head fw-bold">{row.month}</td>
                        <td>{row.total_count}</td>
                        <td>
                          &#8377;{row.total_budget.toLocaleString("en-IN")}
                        </td>
                        <td>
                          &#8377;
                          {row.writer_reviewer_payment.toLocaleString("en-IN")}
                        </td>
                        <td>
                          &#8377;{row.journal_payment.toLocaleString("en-IN")}
                        </td>
                        <td>
                          &#8377;
                          {row.office_emp_salary?.toLocaleString("en-IN") ??
                            "0"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    {totalyear.map((row, index) => (
                      <tr key={index}>
                        <td className="fw-bold payment-head">
                          {row.total_year.split("_").map(Capitalize).join(" ")}
                        </td>
                        <td className="fw-bold">{row.total_count}</td>
                        <td className="fw-bold">
                          &#8377;{row.total_budget.toLocaleString("en-IN")}
                        </td>
                        <td className="fw-bold">
                          &#8377;
                          {row.writer_reviewer_payment.toLocaleString("en-IN")}
                        </td>
                        <td className="fw-bold">
                          &#8377;{row.journal_payment.toLocaleString("en-IN")}
                        </td>
                        <td className="fw-bold">
                          &#8377;{row.office_emp_salary.toLocaleString("en-IN")}
                        </td>
                      </tr>
                    ))}
                  </tfoot>
                </table>
              </div>
            </div>

            <section className="  mt-2 project-manage w-100 py-3">
              <div>
                <div className="d-flex justify-content-between">
                  <div className="heading-entr mt-1">Yearly Income</div>
                  <div className="text-center ">
                    <div className="d-flex justify-content-center gap-2 mx-2">
                      <Tooltip title="Export">
                        <div className="add-icon">
                          <VscGitStashPop
                            className="add1-icon"
                            // onClick={exportToCSV}
                          />
                        </div>
                      </Tooltip>
                    </div>
                  </div>
                </div>
              </div>
              <div className="">
                <div className="col-12 mt-2 table-responsive  table-wrapper-scroll-y my-custom-scrollbar  ">
                  <table className="table-head">
                    <thead className="">
                      <tr className="payment-table">
                        <th rowSpan="2" className="fw-bold">
                          Year
                        </th>
                        {incomeyear.map((row, index) => (
                          <th colSpan="4" key={index} className="fw-bold">
                            {row}
                          </th>
                        ))}
                      </tr>
                      <tr className="payment-table">
                        <th>Count </th>
                        <th>Budget</th>
                        <th>Expense</th>
                        <th>Income</th>
                      </tr>
                    </thead>
                    <tbody>
                      {income.map((row, index) => (
                        <tr key={index}>
                          <td className="payment-head fw-bold">
                            {row.Project_Type}
                          </td>
                          <td
                            onClick={() => handleProjectClick(row.Project_Type)}
                          >
                            {row.Count}
                          </td>
                          <td>&#8377;{row.Budget.toLocaleString("en-IN")}</td>
                          <td>&#8377;{row.Expense.toLocaleString("en-IN")}</td>
                          <td>{formatIndianCurrency(row.Income)}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      {incometotal.map((row, index) => (
                        <tr key={index}>
                          <td className="fw-bold payment-head">
                            {Capitalize(row.Project_Type)}
                          </td>
                          <td className="fw-bold">{row.Count}</td>
                          <td className="fw-bold">
                            &#8377;{row.Budget.toLocaleString("en-IN")}
                          </td>
                          <td className="fw-bold">
                            &#8377;
                            {row.Expense.toLocaleString("en-IN")}
                          </td>
                          <td className="fw-bold">
                            &#8377;{row.Income.toLocaleString("en-IN")}
                          </td>
                        </tr>
                      ))}
                    </tfoot>
                  </table>
                </div>
              </div>
            </section>
            <section className="  mt-2 project-manage w-100 py-3">
              <div className="col-12 pt-3 ">
                {/* <h2 className="heading-entr">Operational Duration</h2> */}
              </div>
              <div className="">
                <DataTable
                  id="example"
                  data={totalall}
                  columns={columns2}
                  className="display"
                  options={{
                    paging: true,
                    pageLength: 20,
                    lengthMenu: [
                      [20, 30, 50],
                      [20, 30, 50],
                    ],
                    scrollX: true,
                  }}
                />
              </div>
            </section>
          </div>
        </div>
        </>
        )}
      </section>
    </>
  );
};

export default Payment_reports;
