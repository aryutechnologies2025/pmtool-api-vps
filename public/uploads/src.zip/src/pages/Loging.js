import { API_URL } from "../config.js";
import React, { useEffect, useState } from "react";
import "../assests/css/loging.css";
import { useNavigate } from "react-router-dom";
import Vector from "..//assests/images/Vector.svg";
import Rectangle from "..//assests/images/Rectangle.png";
import Mblogin from "../assests/images/mblogin.svg";
import { eye } from "react-icons-kit/feather/eye";
import { eyeOff } from "react-icons-kit/feather/eyeOff";
import Icon from "react-icons-kit";
import Footer from "../components/Footer";
import ReCAPTCHA from "react-google-recaptcha";

import { Link } from "react-router-dom";
import axios from "axios";
import Cookies from 'js-cookie';
import { CAPCHA_URL } from "../config.js";
import Loader from "../components/Loader.js";


function Login({ setIsLoggedIn }) {
  //error
  const [error, setError] = useState({});
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  

  // eye buttom
  const [type, setType] = useState("password");
  const [icon, setIcon] = useState(eyeOff);
  //navigate
  const navigate = useNavigate();

  const togglePasswordVisibility = () => {
    if (type === "password") {
      setType("text");
      setIcon(eye);
    } else {
      setType("password");
      setIcon(eyeOff);
    }
  };
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setMessage("");
    setError("");
    setLoading(true);
    setTimeout(async () => {
      try {
        // Make API request to login
        const response = await axios.post(`${API_URL}/api/check-login`, formData);

        if (response.data) {
          setIsLoggedIn(true)
          const { data, permission, token, rolename, roleName, employee_type } = response.data;

          localStorage.setItem('medicsuser', JSON.stringify(data));
          localStorage.setItem('medicspermission', JSON.stringify(permission));
          localStorage.setItem('medocsrolename', rolename);
          localStorage.setItem('medicsroleName', roleName);
          localStorage.setItem('medicsEmpName', employee_type);

          Cookies.set('token', token, { path: '/' });

          if (rolename.includes('Admin')) {
            navigate("/dashboard");
          }
          else if (rolename.includes(13)) {
            navigate("/project-manager-dashboard");
          }
          else if (rolename.includes(14)) {
            navigate("/team-coordinator-dashboard");
          }
          else if (employee_type === 'freelancers') {
            navigate("/freelancer-dashboard");
          }
          else if (rolename.includes(27)) {
            navigate("/publication-dashboard");
          }
          else if (rolename.includes(23)) {
            navigate("/accounts-main-dashboard");
          }
          else if (rolename.includes(28)) {
            navigate("/sme-dashboard");
          }
          else if ((employee_type === "full_time" || employee_type === "part_time") && !rolename.includes(13) && !rolename.includes(14) && !rolename.includes(23)) {
            navigate("/internal-dashboard");
          } else if (rolename.includes('Admin') || rolename.includes(13) || rolename.includes(23)) {
            navigate("/accounts-dashboard");
          }
        } else {
          setError({ general: "Login failed, token not found." });
        }
      } catch (err) {
        if (err.response) {
          if (err.response.status === 422) {
            const validationErrors = err.response.data.errors;
            setError(validationErrors);
          } else {
            // Other server errors
            setError({ general: err.response.data.message || "An unexpected error occurred." });
          }
        } else {
          // Network or other non-response errors
          setError({ general: "An unexpected error occurred." });
        }
      } finally {
        setLoading(false);
      }
    }, 30);
  };

   useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const role = params.get("role");
    const id = params.get("id");

    if (role && id) {
      axios
        .post(`${API_URL}/api/auto-login?role=${role}&id=${id}`)
        .then((res) => {
          setIsLoggedIn(true);

          const { user, rolename, roleName, employee_type, permission } =
            res.data;

          // Save user data to localStorage
          localStorage.setItem("workportal_user", JSON.stringify(user));
          localStorage.setItem("medicsuser", JSON.stringify(user));
          localStorage.setItem("medicsroleName", roleName);
          localStorage.setItem("medocsrolename", rolename);

          localStorage.setItem("medicspermission", JSON.stringify(permission));
          localStorage.setItem("medicsEmpName", employee_type);

          console.log("user", user, rolename, roleName);

          // Role-based redirection
          if (roleName.includes("Admin")) {
            navigate("/dashboard");
          } else if (rolename.includes(13)) {
            navigate("/project-manager-dashboard");
          } else if (rolename.includes(14)) {
            navigate("/team-coordinator-dashboard");
          } else if (rolename.includes(27)) {
            navigate("/publication-dashboard");
          } else if (rolename.includes(23)) {
            navigate("/accounts-main-dashboard");
          } else if (rolename.includes(28)) {
            navigate("/sme-dashboard");
          } else if (
            roleName.includes("Admin") ||
            rolename.includes(13) ||
            rolename.includes(23)
          ) {
            navigate("/accounts-dashboard");
          } else if (rolename.includes(11)) {
            navigate("/internal-dashboard");
          }
          else if ((employee_type === "full_time" || employee_type === "part_time") && !rolename.includes(13) && !rolename.includes(14) && !rolename.includes(23)) {
            navigate("/internal-dashboard");
          }
          else if (employee_type === 'freelancers') {
            navigate("/freelancer-dashboard");
          }
        
        })
        .catch((err) => {
          alert("Auto login failed");
          console.error(err);
        });
    }
  }, [navigate]);

  const [captchaValue, setCaptchaValue] = useState(null);

  const handleCaptchaChange = (value) => {
    setCaptchaValue(value);
    // console.log("Captcha value:", value);
  };
  if (loading) {
    return <Loader />;
  }
  return (
    <div className="container">
      <div className="aa mt-2">
        <div className="row  ">
          <div className="col-12  text-center mt-2">
            <img className="img-fluid " src={Vector} alt="img" />
          </div>
        </div>
        <div className="container  justify-content-center d-flex maindiv mt-4 ">
          <div className=" position-relative  pic-body ">
            <div className="position-relative  "></div>
            <img className=" loo-img " src={Rectangle} alt="img" />
            <img className="img-2" src={Mblogin} alt="img" />
            <h1 className="lo position-absolute">Login</h1>
            <div className="position-absolute text-center user-tag ">
              <form onSubmit={handleRegister}>
                <div className="input-box  mb-2  ">
                  <input
                    className="6 h-56px int"
                    type="text"
                    placeholder="Username"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                  />
                  {error.email && <p className="error-text">{error.email}</p>}
                </div>
                <div className="  input-box  d-flex ">
                  <input
                    className="6 h-56px int"
                    type={type}
                    placeholder="Password"
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                  />
                  <span
                    className="position-absolute login-eye pt-2 "
                    onClick={togglePasswordVisibility}
                  >
                    <Icon className=" " icon={icon} />
                  </span>
                </div>
                <div className="d-flex justify-content-end "><Link to="/register" className="rest-tag">Forget Your password ?</Link></div>

                {error.password && (
                  <p className="error-text ">{error.password}</p>
                )}
                {error.general && (
                  <p className="error-text ">{error.general}</p>
                )}

                <div>
                  <div>
                    {/* <ReCAPTCHA
                      // sitekey="6LdBR6wqAAAAAKiqjNXKIxWOyBtdn3Vx_-MdRc8-" //locatl
                      sitekey={CAPCHA_URL} //live
                      onChange={handleCaptchaChange}
                    /> */}
                  </div>
                  <div className="d-flex justify-content-center ">
                    <button
                      type="submit"
                      className="btn-login mt-1"
                      // disabled={!captchaValue}
                    >
                      Login
                    </button>

                  </div>
                </div>
              </form>
            </div>
            <div className="mt-5 pt-5">
              <Footer />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;
