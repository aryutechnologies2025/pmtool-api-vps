import { API_URL } from "../config";
import React from "react";
import "../assests/css/register.css";
import { useNavigate, useParams } from "react-router-dom";
import Vector from "..//assests/images/Vector.svg";
import Registerimg from "..//assests/images/registerimg.svg";
import { eye } from "react-icons-kit/feather/eye";
import Mblogin from "..//assests/images/mblogin.svg";
import { eyeOff } from "react-icons-kit/feather/eyeOff";
import Icon from "react-icons-kit";
import { useState } from "react";
import Footer from "../components/Footer";

import { Link } from "react-router-dom";
import axios from "axios";
import Rectangle from "..//assests/images/Rectangle.png";
import { useLocation } from "react-router-dom";
import Loader from "../components/Loader.js";


function Reset_password() {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const token = queryParams.get("token"); // Get token from query string

  const [type, setType] = useState("password");
    const [loading, setLoading] = useState(false);
  
  const [icon, setIcon] = useState(eyeOff);
  const [newType, setNewType] = useState("password");
  const [newIcon, setNewIcon] = useState(eyeOff);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    email_address: "",
    password: "",
    confirm_password: "",
  });

  const navigate = useNavigate();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const togglePasswordVisibility = () => {
    if (type === "password") {
      setType("text");
      setIcon(eye);
    } else {
      setType("password");
      setIcon(eyeOff);
    }
  };

  const toggleNewPasswordVisibility = () => {
    if (newType === "password") {
      setNewType("text");
      setNewIcon(eye);
    } else {
      setNewType("password");
      setNewIcon(eyeOff);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setMessage("");
    setError("");
    setLoading(true); 
    setTimeout(async () => {

    // Check for empty fields
    if (!formData.email_address) {
      setError({ email_address: ["Email address is required."] });
      return;
    }

    if (!formData.password) {
      setError({ password: ["Password is required."] });
      return;
    }

    if (!formData.confirm_password) {
      setError({ confirm_password: ["Please confirm your password."] });
      return;
    }

    // Check if passwords match
    if (formData.password !== formData.confirm_password) {
      setError({ confirm_password: ["Passwords do not match."] });
      return;
    }

    try {
      // const response = await axios.post(`${API_URL}/api/reset-password`, formData);
      const response = await axios.post(`${API_URL}/api/reset-password`, {
        ...formData,
        token,
      });
      setMessage(response.data.message);
      console.log("Registration Response:", response.data);
      navigate("/"); // Redirect after success
    } catch (err) {
      if (err.response) {
        if (err.response.data.error === "Invalid token.") {
          setMessage(
            "Your password reset link has expired. Please request a new one."
          );
        } else if (err.response.status === 422) {
          const validationErrors = err.response.data.errors;
          setError(validationErrors); // Store validation errors in state
          console.log("Validation Errors:", validationErrors);
        } else {
          console.log("Error:", err.response.data);
          setError({ general: "An unexpected error occurred." });
        }
      } else {
        console.log("Error:", err);
        setError({ general: "An unexpected error occurred." });
      }
    }finally {
      setLoading(false); 
  }
  },30); 
  };
  if (loading) {
    return <Loader />; 
  }
  return (
    
      <div className="container d-flex flex-column min-vh-100 justify-content-between"> 
        <div className="row ">
          <div className="col-12  text-center p-5">
            <img className="img-fluid " src={Vector} alt="img" />
          </div>
        </div>

        <div className="container position-relative  justify-content-center d-flex maindiv  ">
          <div className="  position-relative ">
            <div className="">
              <img className=" loo-img-reg " src={Registerimg} alt="img" />
              <img className="img-3" src={Mblogin} alt="img" />
              <h1 className="lo-reg position-absolute">Forget Password</h1>
              <div className="position-absolute text-center user-tag1  ">
                <form onSubmit={handleRegister}>
                  <div className="input-box  mb-2 ">
                    {/* <label>E-Mail Address</label> */}
                    <input
                      className={`w-506 h-56px int1 ${
                        error.email_address ? "input-error" : ""
                      }`}
                      type="text"
                      name="email_address"
                      value={formData.email_address}
                      onChange={handleInputChange}
                      placeholder="Email address"
                    />
                    {error.email_address && (
                      <p className="error-text">{error.email_address[0]}</p>
                    )}
                  </div>

                  <div className="input-box d-flex">
                    <input
                      className={`w-506 h-56px int1 ${
                        error.password ? "input-error" : ""
                      }`}
                      type={type}
                      name="password"
                      value={formData.password}
                      onChange={handleInputChange}
                      placeholder="New password"
                    />

                    <span onClick={togglePasswordVisibility}>
                      <Icon
                        className="position-absolute login-eye1 pt-2"
                        icon={icon}
                      />
                    </span>
                  </div>
                  {error.password && (
                    <p className="error-text">{error.password[0]}</p>
                  )}

                  {/* <div className=" text-end">
                      <a className="text-decoration-none forget-passed" href="">
                        use 8 or more characters with a mix of
                        letters,numbers,symbols{" "}
                      </a>
                    </div> */}

                  <div className="input-box  ">
                    <input
                      className={`w-506 h-56px int1 ${
                        error.confirm_password ? "input-error" : ""
                      }`}
                      type={newType}
                      name="confirm_password"
                      value={formData.confirm_password}
                      onChange={handleInputChange}
                      placeholder="Confirm password"
                    />

                    <span onClick={toggleNewPasswordVisibility}>
                      <Icon
                        className="position-absolute login-eye2 pt-2"
                        icon={newIcon}
                      />
                    </span>
                  </div>
                  {error.confirm_password && (
                    <p className="error-text">{error.confirm_password[0]}</p>
                  )}

                  <button type="submit" className="btn-login mt-3">
                    Reset Password
                  </button>

                  {message && <p className="success-message">{message}</p>}
                </form>
              </div>
            </div>
          </div>
        </div>
        <div className=" mt-5  foot">
          <Footer></Footer>
        </div>
      </div>
    
  );
}

export default Reset_password;
