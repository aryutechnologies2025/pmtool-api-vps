import { API_URL } from "../config";
import React from "react";
import "../assests/css/register.css";
import { useNavigate } from "react-router-dom";
import Vector from "..//assests/images/Vector.svg";
import Registerimg from "..//assests/images/registerimg.svg";
import { eye } from "react-icons-kit/feather/eye";
import Mblogin from "..//assests/images/mblogin.svg";
import { eyeOff } from "react-icons-kit/feather/eyeOff";
import Icon from "react-icons-kit";
import { useState } from "react";
import Footer from "../components/Footer";

import { Link } from "react-router-dom";
import axios from "axios";
import Rectangle from "..//assests/images/Rectangle.png";
import Loader from "../components/Loader.js";


function Register() {
  const [type, setType] = useState("password");
    const [loading, setLoading] = useState(false);
  
  const [icon, setIcon] = useState(eyeOff);
  const [newType, setNewType] = useState("password");
  const [newIcon, setNewIcon] = useState(eyeOff);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    email_address: "", // Assuming you're using email for the reset process
  });
  const navigate = useNavigate();
  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError("");
  };

  const togglePasswordVisibility = () => {
    if (type === "password") {
      setType("text");
      setIcon(eye);
    } else {
      setType("password");
      setIcon(eyeOff);
    }
  };

  const toggleNewPasswordVisibility = () => {
    if (newType === "password") {
      setNewType("text");
      setNewIcon(eye);
    } else {
      setNewType("password");
      setNewIcon(eyeOff);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setMessage("");
    setError("");
    setLoading(true); 
    setTimeout(async () => {

    if (!formData.email_address) {
      setError({ email_address: ["Email is required."] }); // Show error if email is empty
      return; // Prevent form submission
    }

    // Validate email format using a regex
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(formData.email_address)) {
      setError({ email_address: ["Please enter a valid email address."] }); // Show error if email format is invalid
      return; // Prevent form submission
    }

    try {
      const response = await axios.post(
        `${API_URL}/api/forget-password`,
        formData
      );
      setMessage(response.data.message);

      console.log("Registration Response:", response.data);
      // navigate("/reset-password"); // Redirect to the reset password page after successful submission
    } catch (err) {
      if (err.response && err.response.status === 422) {
        const validationErrors = err.response.data.errors;
        setError(validationErrors);
      } else if (
        err.response &&
        err.response.data.message === "Email not found in our records."
      ) {
        setError({ email_address: [err.response.data.message] });
      } else {
        setError({ general: "An unexpected error occurred." });
      }
    }finally {
      setLoading(false); 
  }
  },30); 
  };
  if (loading) {
    return <Loader />; 
  }

  return (
      <div className="container d-flex flex-column min-vh-100 justify-content-between">
        <div className="row ">
          <div className="col-12  text-center ">
            <img className="img-fluid " src={Vector} alt="img" />
          </div>
        </div>

        <div className="container position-relative  justify-content-center d-flex maindiv mt-4 ">
          <div className="  position-relative ">
            <div className="">
              <img className=" loo-img-reg " src={Registerimg} alt="img" />
              <img className="img-3" src={Mblogin} alt="img" />
              <h1 className="lo-reg position-absolute">Forget Password</h1>
              <div className="position-absolute text-center user-tag1  ">
                <form onSubmit={handleRegister}>
                  <div className="input-box  mb-2 ">
                    {/* <label>E-Mail Address</label> */}
                    <input
                      className={`w-506 h-56px int1 ${
                        error.email_address ? "input-error" : ""
                      }`}
                      type="text"
                      name="email_address"
                      value={formData.email_address}
                      onChange={handleInputChange}
                      placeholder="Email address"
                    />
                    {error.email_address && (
                      <p className="error-text">{error.email_address[0]}</p>
                    )}
                  </div>
                                  <div className="d-flex justify-content-end "><Link to="/" className="rest-tag">Click Me login page</Link></div>
                  

                  {/* <Link to="/reset-password"> */}
                  <button type="submit" className="btn-login">
                    Sumbit
                  </button>

                  {message && <p className="success-message">{message}</p>}
                  {/* </Link> */}
                </form>
              </div>
            </div>
          </div>
        </div>
        <div className="">
          <Footer></Footer>
        </div>
      </div>
 
  );
}

export default Register;
