import React from 'react';
import "../assests/css/site-map.css"

const SiteMap = () => {
  return (
    <div className="site-map">
      <h3>Site Map</h3>
      
      <div className="section">
        <h4>Authentication</h4>
        <ul>
          <li><a href="/" target="_blank" rel="noopener noreferrer">Login</a></li>
          <li><a href="/register" target="_blank" rel="noopener noreferrer">Register</a></li>
          <li><a href="/reset-password" target="_blank" rel="noopener noreferrer">Reset Password</a></li>
        </ul>
      </div>

      <div className="section">
        <h4>Dashboard</h4>
        <ul>
          <li><a href="/dashboard" target="_blank" rel="noopener noreferrer">Main Dashboard</a></li>
          <li><a href="/project-Management" target="_blank" rel="noopener noreferrer">Project Management</a></li>
          <li><a href="/project-Management/entry-process" target="_blank" rel="noopener noreferrer">Entry Process</a></li>
          <li><a href="/project-Management/project-view/:id" target="_blank" rel="noopener noreferrer">Project View</a></li>
        </ul>
      </div>

      <div className="section">
        <h4>Payment Status</h4>
        <ul>
          <li><a href="/paymentstatus" target="_blank" rel="noopener noreferrer">Payment Status</a></li>
        </ul>
      </div>

     

      <div className="section">
        <h4>People Management</h4>
        <ul>
          <li><a href="/people-details" target="_blank" rel="noopener noreferrer">People Details</a></li>
          <li><a href="/people-details/people_view_details" target="_blank" rel="noopener noreferrer">People View Details</a></li>
        </ul>
      </div>

      <div className="section">
        <h4>Modula</h4>
        <ul>
          <li><a href="/modula-institution" target="_blank" rel="noopener noreferrer">Modula Institution</a></li>
          <li><a href="/modula-department" target="_blank" rel="noopener noreferrer">Modula Department</a></li>
          <li><a href="/modula-profession" target="_blank" rel="noopener noreferrer">Modula Profession</a></li>
        </ul>
      </div>

      <div className="section">
        <h4>Entry Process</h4>
        <ul>
          <li><a href="/entry-process/process-view-details" target="_blank" rel="noopener noreferrer">Process View Details</a></li>
          <li><a href="/entry-process/enter_process_form" target="_blank" rel="noopener noreferrer">Enter Process Form</a></li>
          <li><a href="/entry-process/entryprocess-update-form" target="_blank" rel="noopener noreferrer">Entry Process Update Form</a></li>
          <li><a href="/entry-process/payment-form" target="_blank" rel="noopener noreferrer">Payment Form</a></li>
          <li><a href="/entry-process/payment-edit-form" target="_blank" rel="noopener noreferrer">Payment Edit Form</a></li>
          <li><a href="/entry-process/pending-form" target="_blank" rel="noopener noreferrer">Pending Form</a></li>
        </ul>
      </div>

      <div className="section">
        <h4>Dashboard Types</h4>
        <ul>
          <li><a href="/project-manager-dashboard" target="_blank" rel="noopener noreferrer">Project Manager Dashboard</a></li>
          <li><a href="/team-coordinator-dashboard" target="_blank" rel="noopener noreferrer">Team Coordinator Dashboard</a></li>
          <li><a href="/internal-dashboard" target="_blank" rel="noopener noreferrer">Internal Dashboard</a></li>
          <li><a href="/freelancer-dashboard" target="_blank" rel="noopener noreferrer">Freelancer Dashboard</a></li>
          <li><a href="/accounts-dashboard" target="_blank" rel="noopener noreferrer">Accounts Dashboard</a></li>
        </ul>
      </div>

      <div className="section">
        <h4>Project Management</h4>
        <ul>
          <li><a href="/project-list" target="_blank" rel="noopener noreferrer">Project List</a></li>
          <li><a href="/employe-project-list" target="_blank" rel="noopener noreferrer">Employee Project List</a></li>
          <li><a href="/employee-project-list" target="_blank" rel="noopener noreferrer">Employee Project Writer List</a></li>
        </ul>
      </div>

      <div className="section">
        <h4>Project View</h4>
        <ul>
          <li><a href="/project-view/:id" target="_blank" rel="noopener noreferrer">Project View by ID</a></li>
        </ul>
      </div>
    </div>
  );
};

export default SiteMap;
