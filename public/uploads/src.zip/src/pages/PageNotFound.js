import React from "react";
import { useNavigate } from "react-router-dom";

const PageNotFound = () => {
  let navigate = useNavigate();

  return (
    <div className="text-center page-not ">
      <p className="page-not1">404</p>
      <p className="page-not2">Look like you're lost</p>
      <p className="page-not-4">
        The page you are looking is not available !
      </p>
      <button
        onClick={() => navigate("/")}
        className=" page-not3"
      >
        Go To Login
      </button>
    </div>
  );
};

export default PageNotFound;
