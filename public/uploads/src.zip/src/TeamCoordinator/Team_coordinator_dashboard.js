import React from "react";

import { BsBarChartLine } from "react-icons/bs";
import Sider from "../components/Sider";

import Header from "../components/Header";
import { AiOutlineAlert } from "react-icons/ai";
import { MdDoNotDisturb } from "react-icons/md";
import { FaFileInvoiceDollar } from "react-icons/fa6";
import { GiPiggyBank } from "react-icons/gi";
import "../assests/css/project_management.css";
import ReactDOM from "react-dom";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { useState, useEffect } from "react";
import { VscGitStashPop } from "react-icons/vsc";
import Loader from "../components/Loader.js";

import { IoMdAdd } from "react-icons/io";
import Footer from "../components/Footer";
import Tooltip from "@mui/material/Tooltip";
import { useNavigate } from "react-router-dom";
import Breadcrumbs from "../routes/Breadcrumbs";
import { VscEye } from "react-icons/vsc";

// icon
import { TbHourglassLow } from "react-icons/tb";
import { SiFreelancer } from "react-icons/si";

import axios from "axios";
import { Link } from "react-router-dom";
// import { combineEventHandlers } from "recharts/types/util/ChartUtils.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";

DataTable.use(DT);

function Team_coordinator_dashboard() {
  const [data, setData] = useState([]);
  const [dataFoot, setFootData] = useState([]);
  // const [dataPeople, setDataPeople] = useState([]);
  const [dataPeopleInhouse, setDataPeopleInHouse] = useState([]);
  const [dataPeopleExtranel, setDataPeopleExternal] = useState([]);

  // useEffect(() => {
  //   const interval = setInterval(() => {
  //     fetchProjectManagerData();
  //   }, 5000);
  //   return () => clearInterval(interval);
  // }, []);

  const [loading, setLoading] = useState(true);

  const columns = [
    { title: "MONTH".toUpperCase(), data: "month" },
    { title: "Manuscript".toUpperCase(), data: "manuscript" },
    { title: "Statistics".toUpperCase(), data: "statistics" },
    { title: "Thesis".toUpperCase(), data: "thesis" },
    { title: "Others".toUpperCase(), data: "others" },
    { title: "NA", data: "not_assigned" },
    { title: "WD", data: "withdrawn" },
    { title: "Total".toUpperCase(), data: "total" },
    {
      title: "Manuscript (%)".toUpperCase(),
      data: "manuscript_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "Statistics (%)".toUpperCase(),
      data: "statistics_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "Thesis (%)".toUpperCase(),
      data: "thesis_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "Others (%)".toUpperCase(),
      data: "others_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "TARGET (%)",
      data: "target_percentage",
      render: (data) => {
        if (data !== null && data !== undefined) {
          return `${Number(data).toLocaleString()}%`;
        }
        return "N/A"; // Handle null or undefined values
      },
    },
  ];

  const handleNavigate = (type, createdby, month) => {
    // navigate(`/employee-project-list`, { state: { type, createdby } });
    navigate(`/employe-project-list`, { state: { type, createdby, month } });
  };

  const handleNavigateinhouse = (type, createdby, month) => {
    // navigate(`/employee-project-list`, { state: { type, createdby } });
    navigate(`/inhouse-project-list`, { state: { type, createdby, month } });
  };

  const handleProNavigate = (params) => {
    navigate(`/project-view`, { state: params });
  };

  const handleNavigatethesis = (type, createdby, employee_type, month) => {
    navigate(`/employee-project-list`, {
      state: { type, createdby, employee_type, month },
    });
    // navigate(`/employe-project-list`, { state: { type, createdby } });
  };

  //dashboard list
  const columnsPeople = [
    {
      title: "Team".toUpperCase(),
      data: "employee_name",
      render: (data) => data.charAt(0).toUpperCase() + data.slice(1),
    },
    {
      title: "Type of work".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex ">
               <div class="table-row-width"><div>Writing</div></div>
   
    </div>
             
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
            <div class="d-flex ">
               <div class="table-row-width"><div>Reviewing</div></div>
   
    </div>
             
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex ">
               <div class="table-row-width"><div>Statistician</div></div>
 
    </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex ">
               <div class="table-row-width"><div>Journal</div></div>
 
    </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Total Projects".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center ">
               
    <div class="mx-2">${writerCount}</div>
    </div>
             
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
            <div class="d-flex justify-content-center">
            
    <div class="mx-2">${reviewerCount}</div>
    </div>
             
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2">${statisticianCount}</div>
    </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2">${journalCount}</div>
    </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Pending".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerPendingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerPendingCount || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journalPendingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanPendingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2">${journalCount}</div>
    </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "On going".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerOngoingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerOngoingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanOngoingCount || 0
          : 0;
        let journalCount = positions.includes("8")
          ? row.journalOngoingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2">${journalCount}</div>
    </div>
           `;
        }
        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "need support".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerNeedCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerNeedCount || 0
          : 0;
        let statisticianCount = "-";
        let journalCount = "-";

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "plag & correction".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerCorrectionCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerCorrectionCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanCorrectionCount || 0
          : 0;
        let journalCount = "-";
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
                <div class="d-flex justify-content-center">
                  <div>${writerCount}</div>
                </div>
              `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
                 <div class="d-flex justify-content-center">
                  <div>${reviewerCount}</div>
                </div>
              `;
        }

        if (positions.includes("11")) {
          tableContent += `
                <div class="d-flex justify-content-center">
                  <div>${statisticianCount}</div>
                </div>
              `;
        }

        if (positions.includes("10")) {
          tableContent += `
                 <div class="d-flex justify-content-center">
               
          <div class="mx-2">${journalCount}</div>
          </div>
              `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "<4 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_4_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_4_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_4_days || 0
          : 0;
        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center   ${
               writerCount >= 1 ? "highlight-green  text-white" : ""
             }">
               ${writerCount}
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center ${
                reviewerCount >= 1 ? "highlight-green text-white" : ""
              }">
               ${reviewerCount}
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center ${
               statisticianCount >= 1 ? "highlight-green text-white" : ""
             }">
               ${statisticianCount}
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "5-8 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_5_to_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_5_to_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_5_to_8_days || 0
          : 0;

        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center ${
               writerCount >= 1 ? "highlight-yellow " : ""
             }">
               ${writerCount}
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center ${
                reviewerCount >= 1 ? "highlight-yellow" : ""
              }">
               ${reviewerCount}
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center ${
               statisticianCount >= 1 ? "highlight-yellow" : ""
             }">
               ${statisticianCount}
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: ">9 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_more_than_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_more_than_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_more_than_8_days || 0
          : 0;

        let journalCount = "-";

        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center ${
               writerCount >= 1 ? "highlight-red text-white" : ""
             }">
               ${writerCount}
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider-last"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center ${
                reviewerCount >= 1 ? "highlight-red text-white" : ""
              }">
               ${reviewerCount}
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center ${
               statisticianCount >= 1 ? "highlight-red text-white" : ""
             }">
               ${statisticianCount}
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "View Details".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                {/* <div className="d-flex justify-content-around  mt-1  ">
                           <button className="view-details" onClick={() => handleNavigate(row.position, row.id)}>
                             View details
                           </button>
                       </div> */}
                <div className="" title="View">
                  <span>
                    <VscEye
                      onClick={() =>
                        handleNavigateinhouse(
                          row.position,
                          row.id,
                          selectedMonth
                        )
                      }
                      className="open-icon"
                    />
                  </span>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  const columnsPeople1 = [
    {
      title: "Team".toUpperCase(),
      data: "employee_name",
      render: (data) => data.charAt(0).toUpperCase() + data.slice(1),
    },
    {
      title: "Type of work".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex ">
                <div class="table-row-width"><div>Writing</div></div>
    
     </div>
              
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex ">
                <div class="table-row-width"><div>Reviewing</div></div>
    
     </div>
              
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
               <div class="d-flex ">
                <div class="table-row-width"><div>Statistician</div></div>
  
     </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex ">
                <div class="table-row-width"><div>Journal</div></div>
  
     </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Total Projects".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center ">
                
     <div class="mx-2">${writerCount}</div>
     </div>
              
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex justify-content-center">
             
     <div class="mx-2">${reviewerCount}</div>
     </div>
              
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
     <div class="mx-2">${statisticianCount}</div>
     </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
     <div class="mx-2">${journalCount}</div>
     </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Pending".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerPendingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerPendingCount || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journalPendingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanPendingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center">
                <div>${writerCount}</div>
              </div>
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
               <div class="d-flex justify-content-center">
                <div>${reviewerCount}</div>
              </div>
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center">
                <div>${statisticianCount}</div>
              </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
     <div class="mx-2">${journalCount}</div>
     </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "On going".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerOngoingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerOngoingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanOngoingCount || 0
          : 0;
        let journalCount = positions.includes("8")
          ? row.journalOngoingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center">
                <div>${writerCount}</div>
              </div>
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
               <div class="d-flex justify-content-center">
                <div>${reviewerCount}</div>
              </div>
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center">
                <div>${statisticianCount}</div>
              </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
     <div class="mx-2">${journalCount}</div>
     </div>
            `;
        }
        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "need support".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerNeedCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerNeedCount || 0
          : 0;
        let statisticianCount = "-";
        let journalCount = "-";

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center">
                <div>${writerCount}</div>
              </div>
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
               <div class="d-flex justify-content-center">
                <div>${reviewerCount}</div>
              </div>
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center">
                <div>${statisticianCount}</div>
              </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
        <div class="mx-2">${journalCount}</div>
        </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "plag & correction".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerCorrectionCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerCorrectionCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanCorrectionCount || 0
          : 0;
        let journalCount = "-";
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
                <div class="d-flex justify-content-center">
                  <div>${writerCount}</div>
                </div>
              `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
                 <div class="d-flex justify-content-center">
                  <div>${reviewerCount}</div>
                </div>
              `;
        }

        if (positions.includes("11")) {
          tableContent += `
                <div class="d-flex justify-content-center">
                  <div>${statisticianCount}</div>
                </div>
              `;
        }

        if (positions.includes("10")) {
          tableContent += `
                 <div class="d-flex justify-content-center">
               
          <div class="mx-2">${journalCount}</div>
          </div>
              `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "<4 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_4_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_4_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_4_days || 0
          : 0;
        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center   ${
                writerCount >= 1 ? "highlight-green  text-white" : ""
              }">
                ${writerCount}
              </div>
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
               <div class="d-flex justify-content-center ${
                 reviewerCount >= 1 ? "highlight-green text-white" : ""
               }">
                ${reviewerCount}
              </div>
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center ${
                statisticianCount >= 1 ? "highlight-green text-white" : ""
              }">
                ${statisticianCount}
              </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
        <div class="mx-2">${journalCount}</div>
        </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "5-8 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_5_to_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_5_to_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_5_to_8_days || 0
          : 0;

        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center ${
                writerCount >= 1 ? "highlight-yellow " : ""
              }">
                ${writerCount}
              </div>
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
               <div class="d-flex justify-content-center ${
                 reviewerCount >= 1 ? "highlight-yellow" : ""
               }">
                ${reviewerCount}
              </div>
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center ${
                statisticianCount >= 1 ? "highlight-yellow" : ""
              }">
                ${statisticianCount}
              </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
        <div class="mx-2">${journalCount}</div>
        </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: ">9 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_more_than_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_more_than_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_more_than_8_days || 0
          : 0;

        let journalCount = "-";

        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center ${
                writerCount >= 1 ? "highlight-red text-white" : ""
              }">
                ${writerCount}
              </div>
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider-last"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
               <div class="d-flex justify-content-center ${
                 reviewerCount >= 1 ? "highlight-red text-white" : ""
               }">
                ${reviewerCount}
              </div>
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center ${
                statisticianCount >= 1 ? "highlight-red text-white" : ""
              }">
                ${statisticianCount}
              </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
        <div class="mx-2">${journalCount}</div>
        </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "View Details".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                {/* <div className="d-flex justify-content-around  mt-1  ">
                            <button className="view-details" onClick={() => handleNavigate(row.position, row.id)}>
                              View details
                            </button>
                        </div> */}
                <div className="" title="View">
                  <span>
                    <VscEye
                      onClick={() =>
                        handleNavigate(row.position, row.id, selectedMonth)
                      }
                      className="open-icon"
                    />
                  </span>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  const columnsThesisPeople1 = [
    {
      title: "Team".toUpperCase(),
      data: "employee_name",
      render: (data) => data.charAt(0).toUpperCase() + data.slice(1),
    },
    {
      title: "Type of work".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex ">
                <div class="table-row-width"><div>Writing</div></div>
    
     </div>
              
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex ">
                <div class="table-row-width"><div>Reviewing</div></div>
    
     </div>
              
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
               <div class="d-flex ">
                <div class="table-row-width"><div>statistician</div></div>
  
     </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex ">
                <div class="table-row-width"><div>Journal</div></div>
  
     </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Total Projects".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center ">
                
     <div class="mx-2">${writerCount}</div>
     </div>
              
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
             <div class="d-flex justify-content-center">
             
     <div class="mx-2">${reviewerCount}</div>
     </div>
              
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
     <div class="mx-2">${statisticianCount}</div>
     </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
     <div class="mx-2">${journalCount}</div>
     </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Pending".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerPendingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerPendingCount || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journalPendingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanPendingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center">
                <div>${writerCount}</div>
              </div>
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
               <div class="d-flex justify-content-center">
                <div>${reviewerCount}</div>
              </div>
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center">
                <div>${statisticianCount}</div>
              </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
     <div class="mx-2">${journalCount}</div>
     </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "On going".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerOngoingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerOngoingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanOngoingCount || 0
          : 0;
        let journalCount = positions.includes("8")
          ? row.journalOngoingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center">
                <div>${writerCount}</div>
              </div>
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
               <div class="d-flex justify-content-center">
                <div>${reviewerCount}</div>
              </div>
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center">
                <div>${statisticianCount}</div>
              </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
     <div class="mx-2">${journalCount}</div>
     </div>
            `;
        }
        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "need support".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerNeedCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerNeedCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanNeedCount || 0
          : 0;
        let journalCount = positions.includes("8")
          ? row.journalOngoingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center">
                <div>${writerCount}</div>
              </div>
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
               <div class="d-flex justify-content-center">
                <div>${reviewerCount}</div>
              </div>
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center">
                <div>${statisticianCount}</div>
              </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
        <div class="mx-2">${journalCount}</div>
        </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "plag & correction".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerCorrectionCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerCorrectionCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanCorrectionCount || 0
          : 0;
        let journalCount = "-";
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center">
                <div>${writerCount}</div>
              </div>
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
               <div class="d-flex justify-content-center">
                <div>${reviewerCount}</div>
              </div>
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center">
                <div>${statisticianCount}</div>
              </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
        <div class="mx-2">${journalCount}</div>
        </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "<4 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_4_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_4_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_4_days || 0
          : 0;
        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center   ${
                writerCount >= 1 ? "highlight-green  text-white" : ""
              }">
                ${writerCount}
              </div>
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
               <div class="d-flex justify-content-center ${
                 reviewerCount >= 1 ? "highlight-green text-white" : ""
               }">
                ${reviewerCount}
              </div>
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center ${
                statisticianCount >= 1 ? "highlight-green text-white" : ""
              }">
                ${statisticianCount}
              </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
        <div class="mx-2">${journalCount}</div>
        </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "5-8 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_5_to_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_5_to_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_5_to_8_days || 0
          : 0;

        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center ${
                writerCount >= 1 ? "highlight-yellow " : ""
              }">
                ${writerCount}
              </div>
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
               <div class="d-flex justify-content-center ${
                 reviewerCount >= 1 ? "highlight-yellow" : ""
               }">
                ${reviewerCount}
              </div>
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center ${
                statisticianCount >= 1 ? "highlight-yellow" : ""
              }">
                ${statisticianCount}
              </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
        <div class="mx-2">${journalCount}</div>
        </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: ">9 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_more_than_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_more_than_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_more_than_8_days || 0
          : 0;

        let journalCount = "-";

        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
              <div class="d-flex justify-content-center ${
                writerCount >= 1 ? "highlight-red text-white" : ""
              }">
                ${writerCount}
              </div>
            `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider-last"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
               <div class="d-flex justify-content-center ${
                 reviewerCount >= 1 ? "highlight-red text-white" : ""
               }">
                ${reviewerCount}
              </div>
            `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center ${
                statisticianCount >= 1 ? "highlight-red text-white" : ""
              }">
                ${statisticianCount}
              </div>
            `;
        }

        if (positions.includes("10")) {
          tableContent += `
               <div class="d-flex justify-content-center">
             
        <div class="mx-2">${journalCount}</div>
        </div>
            `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "View Details".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                {/* <div className="d-flex justify-content-around  mt-1  ">
                            <button className="view-details" onClick={() => handleNavigate(row.position, row.id)}>
                              View details
                            </button>
                        </div> */}
                <div className="" title="View">
                  <span>
                    <VscEye
                      onClick={() =>
                        handleNavigatethesis(
                          row.position,
                          row.id,
                          row.employee_type,
                          selectedMonth
                        )
                      }
                      className="open-icon"
                    />
                  </span>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];
  const parseDate = (dateStr) => {
    if (!dateStr) return 0;
    return new Date(dateStr.replace(" ", "T")); // replace space with "T"
  };
  const [works, setTypeOfWork] = useState([]);
  const [totalProjects, setProjectCount] = useState(0);
  const [processStatus, setProcessStatus] = useState(0);
  const [journalStatus, setJournalStatus] = useState(0);
  const [completed, setCompleted] = useState(0);
  const [setdata, setFetchData] = useState(0);
  const [tododata, setToDoData] = useState([]);
  const [inworkdata, setInWorkData] = useState([]);
  const [todolistD, setToDoListData] = useState([]);
  console.log("todolistD", todolistD);

  const [revertlist, setRevertData] = useState([]);

  console.log("check revert", revertlist);
  const [completeddata, setCompletedData] = useState([]);
  const [correctiondata, setCorrectionData] = useState([]);
  const [acceptRejectList, setProjectAcceptRejectStatus] = useState([]);
  const [projectStatusCount, setProjectStatusCount] = useState(0);
  const [dasCount, setCountVal] = useState([]);

  const [dataPeopleWriterExtranel, setdataPeopleWriterExtranel] = useState([]);

  // console.log("reject:", acceptRejectList);
  console.log("dasCount:", dasCount);

  const fetchProjectManagerData = async () => {
    // setLoading(true);
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/tcdashboard`,
        {
          params: {
            position: "team_coordinator",
            month: selectedMonth,
          },
        }
      );

      const responsedata = response.data;
      console.log("responsedata :", response);

      setCountVal(responsedata);
      setFetchData(responsedata);
      // console.log("allresponse:", responsedata);

      setTypeOfWork(responsedata.typeofwork);
      setProjectCount(responsedata.total_count);
      setProcessStatus(responsedata.process_staus);
      setJournalStatus(responsedata.journal_status);
      setCompleted(responsedata.completedCount);
      setData(responsedata.monthWiseTable.monthlyData);
      setFootData(responsedata.monthWiseTable.footerTotals);
      // setToDoListData([
      //   ...(responsedata.inToDoList || []),
      //   ...(responsedata.tc_to_do_list || [])
      // ]);
      setToDoData(responsedata.inProgress);
      setInWorkData(responsedata.urgentDataList);
      // Helper function to safely parse "YYYY-MM-DD HH:mm:ss"

      // const mergedRevertList = [
      //   ...responsedata.revert_writer,
      //   ...responsedata.notAssigned,

      //   // ...responsedata.revert_statistican,
      //   ...responsedata.revert,
      // ];

      // // Sort by created_at DESC
      // mergedRevertList.sort(
      //   (a, b) => parseDate(b.updated_at) - parseDate(a.updated_at)
      // );
      // console.log("mergedRevertList", mergedRevertList);
      // setRevertData(mergedRevertList);

      const mergedRevertList = [
        ...responsedata.revert_writer,
        ...responsedata.notAssigned,
        // ...responsedata.revert_statistican,
        ...responsedata.revert,
      ];

      // Remove duplicates based on `project_id`
      const uniqueRevertList = mergedRevertList.filter(
        (item, index, self) =>
          index === self.findIndex((t) => t.project_id === item.project_id)
      );

      // Sort by updated_at DESC
      uniqueRevertList.sort(
        (a, b) => parseDate(b.updated_at) - parseDate(a.updated_at)
      );

      console.log("uniqueRevertList", uniqueRevertList);
      setRevertData(uniqueRevertList);

      // setCompletedData(responsedata.completed);
      setDataPeopleInHouse(responsedata.inhouseExternal.peopleInhouse);
      setDataPeopleExternal(responsedata.inhouseExternal.peopleExternal);
      setdataPeopleWriterExtranel(
        responsedata.inhouseExternal.peopleWriterExternal
      );
      setCorrectionData(responsedata.freelancerProjecctList);
      setProjectAcceptRejectStatus(
        (responsedata.projectStatusList || []).filter(
          (project) => project.project_status !== null
        )
      );
      const filteredProjects = (responsedata.projectStatusList || []).filter(
        (project) => project.project_status !== null
      );
      setProjectStatusCount(filteredProjects.length); // Set the count

      const originalData = [
        // ...(responsedata.inToDoList || []),
        ...(responsedata.tc_to_do_lists || []),
      ];
      console.log("originalData :", originalData);
      const flattenedData = originalData.map((item) => ({
        created_by: item.created_by,
        has_role: item.has_role,
        hierarchy_level:
          item.hierarchy_level === null
            ? item.hierarchy_levels
            : item.hierarchy_level,
        process_status: item.process_status,
        process_statuses: item.process_statuses,
        project_id:
          typeof item.project_id === "number"
            ? item.project_ids
            : item.project_id,
      }));
      setToDoListData(flattenedData);
      setLoading(false);
    } catch (error) {
      console.error("error fetching data", error);
      setLoading(false);
    }
  };

  const date = new Date();
  const [selectedMonth, setSelectedMonth] = useState(
    `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`
  );

  useEffect(() => {
    // fetchProjectManagerData();

    fetchProjectManagerData();
  }, [selectedMonth]);

  const handleMonthChange = (e) => {
    setSelectedMonth(e.target.value);
    // You can add additional logic here if needed
  };

  const navigate = useNavigate();

  const handleEditClick = (id) => {
    navigate("/entry-process/entryprocess-update-form", {
      state: { rowId: id },
    });
  };

  // Safe retrieval of freelancer ID
  const freelancerId = localStorage.getItem("empname") || "";

  // Safe retrieval and parsing of project IDs
  let projectIds = [];

  try {
    const storedProjectIdsRaw = localStorage.getItem("projectallid");

    // Check if value is not null and not the string "undefined"
    if (storedProjectIdsRaw && storedProjectIdsRaw !== "undefined") {
      projectIds = JSON.parse(storedProjectIdsRaw);
    }
  } catch (error) {
    console.error("Failed to parse projectallid from localStorage:", error);
    projectIds = [];
  }

  console.log("Freelancer ID:", freelancerId);
  console.log("Project IDs:", projectIds);

  // Function to handle assignment click
  const handleasshinClick = () => {
    // Assuming dasCount.tcnotAssigned is a valid array
    const projectIds = dasCount.tcnotAssigned.map((item) => item);

    // Store only if not undefined
    if (freelancerId) {
      localStorage.setItem("empname", freelancerId);
    }

    if (projectIds && Array.isArray(projectIds)) {
      localStorage.setItem("projectallid", JSON.stringify(projectIds));
    }

    // Open new tab to project list
    window.open("/projectlist", "_blank");
  };

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <section className="container ">
          <div className="mt-4 w-100">
            {/* <div className="col-1 d-flex    justify-content-center">
            <Sider />
          </div> */}
            <div className="col-12 ">
              <div className="col-12">
                <Header></Header>
              </div>
              <div className=" pt-1 mt-3 py-3 project-manage w-100 ">
                <div className=" row mt-3 d-flex   w-100 ">
                  <div className="col-12 col-md-6  px-4 ">
                    <h className="heading-entr">Team Coordinator Dashboard</h>
                  </div>

                  <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                    <Breadcrumbs></Breadcrumbs>
                  </div>
                </div>
                <div className=" mt-4 px-4 gap-3 d-flex flex-wrap justify-content-end">
                  <div className="">
                    <input
                      type="month"
                      id="monthInput"
                      className="people-select px-1"
                      value={selectedMonth}
                      onChange={handleMonthChange}
                      placeholder="YYYY-MM"
                    />
                  </div>
                </div>
                <section className="col-12 ">
                  <div className="row  px-3">
                    <div className="row  gap-2">
                      <div className=" col-lg-3 col-md-4 total-project    mx-3">
                        <div className=" w-100 d-flex px-3  mt-3">
                          <div className="graphic-box  mt-2 ">
                            <BsBarChartLine className=" graphic-icon m-2" />
                          </div>
                          <div>
                            <div className=" d-flex mx-2 project-head gap-3 ">
                              <p className=" text-muted dash-year ">
                                {new Date().getFullYear()}
                              </p>
                              <p className=" text-muted dash-project">
                                Total Projects
                              </p>
                            </div>
                            <div className=" h1  px-2">{totalProjects}</div>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3  d-flex justify-content-around mt-1"
                          onClick={() =>
                            handleProNavigate({
                              type: "manuscript",
                              month: selectedMonth,
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">Manuscript</p>
                          <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2">{works.manuscript}</p>
                            <p className="p-tag3">
                              {/* {((works.manuscript / totalProjects) * 100).toFixed(2)} */}
                              {totalProjects !== 0
                                ? (
                                    (works.manuscript / totalProjects) *
                                    100
                                  ).toFixed(2)
                                : 0}
                              %
                            </p>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3"
                          onClick={() =>
                            handleProNavigate({
                              type: "thesis",
                              month: selectedMonth,
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">Thesis</p>
                          <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">{works.thesis}</p>
                            <p className="p-tag3 ">
                              {/* {((works.thesis / totalProjects) * 100).toFixed(2)}% */}
                              {totalProjects !== 0
                                ? (
                                    (works.thesis / totalProjects) *
                                    100
                                  ).toFixed(2)
                                : 0}
                              %
                            </p>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                          onClick={() =>
                            handleProNavigate({
                              type: "statistics",
                              month: selectedMonth,
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">Statistician</p>
                          <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">{works.statistics}</p>
                            <p className="p-tag3 ">
                              {/* {((works.statistics / totalProjects) * 100).toFixed(2)}% */}
                              {totalProjects !== 0
                                ? (
                                    (works.statistics / totalProjects) *
                                    100
                                  ).toFixed(2)
                                : 0}
                              %
                            </p>
                          </div>
                        </div>
                        {/* <div className="manage-title  mx-3 d-flex justify-content-around mt-3" onClick={() => handleProNavigate({ type: 'presentation' })}>
                        <p className="mt-1 pt-2 px-2 p-tag">Presentation</p>
                        <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">{works.presentation}</p>
                          <p className="p-tag3 ">
                          
                            {(totalProjects !== 0 ? (works.presentation / totalProjects * 100).toFixed(2) : 0)}
                            %
                          </p>
                        </div>
                      </div> */}
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3"
                          onClick={() =>
                            handleProNavigate({
                              type: "others",
                              month: selectedMonth,
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">Others</p>
                          <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">{works.others}</p>
                            <p className="p-tag3 ">
                              {/* {((works.others / totalProjects) * 100).toFixed(2)}% */}
                              {totalProjects !== 0
                                ? (
                                    (works.others / totalProjects) *
                                    100
                                  ).toFixed(2)
                                : 0}
                              %
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className=" col-lg-3 col-md-4 total-project   ">
                        <div className=" w-100 d-flex px-3 mt-3">
                          <div className="graphic-box  mt-2 ">
                            <BsBarChartLine className=" graphic-icon m-2" />
                          </div>
                          <div>
                            <div className="status-title px-2 mt-3 mx-3">
                              Process Status
                            </div>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-4"
                          onClick={() =>
                            handleProNavigate({
                              process_status: "not_assigned",
                              month: selectedMonth,
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">Not Assigned</p>
                          <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2">
                              {processStatus.not_assigned}
                            </p>
                            <p className="p-tag3">
                              {/* {(
                              (processStatus.not_assigned / totalProjects) *
                              100
                            ).toFixed(2)} */}
                              {totalProjects !== 0
                                ? (
                                    (processStatus.not_assigned /
                                      totalProjects) *
                                    100
                                  ).toFixed(2)
                                : 0}
                              %
                            </p>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3"
                          onClick={() =>
                            handleProNavigate({
                              process_status: "in_progress",
                              month: selectedMonth,
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">In Progress</p>
                          <div className="manage-num mt-1    pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">
                              {processStatus.in_progress}
                            </p>
                            <p className="p-tag3 ">
                              {/* {(
                              (processStatus.in_progress / totalProjects) *
                              100
                            ).toFixed(2)}
                            % */}
                              {totalProjects !== 0
                                ? (
                                    (processStatus.in_progress /
                                      totalProjects) *
                                    100
                                  ).toFixed(2)
                                : 0}
                              %
                            </p>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3"
                          onClick={() =>
                            handleProNavigate({
                              process_status: "pending_author",
                              month: selectedMonth,
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">Pending-Author</p>
                          <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">
                              {processStatus.pending_author}
                            </p>
                            <p className="p-tag3 ">
                              {/* {(
                              (processStatus.pending_author / totalProjects) *
                              100
                            ).toFixed(2)}
                            % */}
                              {totalProjects !== 0
                                ? (
                                    (processStatus.pending_author /
                                      totalProjects) *
                                    100
                                  ).toFixed(2)
                                : 0}
                              %
                            </p>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                          onClick={() =>
                            handleProNavigate({
                              process_status: "withdrawal",
                              month: selectedMonth,
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">Withdrawal</p>
                          <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">
                              {processStatus.withdrawal}
                            </p>
                            <p className="p-tag3 ">
                              {/* {(
                              (processStatus.withdrawal / totalProjects) *
                              100
                            ).toFixed(2)}
                            % */}
                              {totalProjects !== 0
                                ? (
                                    (processStatus.withdrawal / totalProjects) *
                                    100
                                  ).toFixed(2)
                                : 0}
                              %
                            </p>
                          </div>
                        </div>

                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3"
                          onClick={() =>
                            handleProNavigate({
                              process_status: "completed",
                              month: selectedMonth,
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">
                            completed {new Date().getFullYear()}
                          </p>
                          <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">{processStatus.completed}</p>
                            <p className="p-tag3 ">
                              {/* {(
                              (processStatus.completed / totalProjects) *
                              100
                            ).toFixed(2)}
                            % */}
                              {totalProjects !== 0
                                ? (
                                    (processStatus.completed / totalProjects) *
                                    100
                                  ).toFixed(2)
                                : 0}
                              %
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* <div className=" col total-project   mx-2">
                      <div className=" w-100 d-flex px-3 mt-3">
                        <div className="graphic-box  mt-2 ">
                          <BsBarChartLine className=" graphic-icon m-2" />
                        </div>
                        <div>
                          <div className="status-title px-2 mt-3 mx-3">
                            Journal Status
                          </div>
                        </div>
                      </div>
                      <div className="manage-title  mx-3 d-flex justify-content-around mt-3">
                        <p className="mt-1 pt-2 px-2 p-tag">
                          Waiting for Submission
                        </p>
                        <div
                          className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center"
                          onClick={() =>
                            handleProNavigate({
                              journal_status: "submit_to_journal",
                            })
                          }
                        >
                          <p className="p-tag2 ">
                            {journalStatus.submit_to_journal}
                          </p>
                          <p className="p-tag3 ">
                            {totalProjects !== 0
                              ? (
                                  (journalStatus.submit_to_journal /
                                    totalProjects) *
                                  100
                                ).toFixed(2)
                              : 0}{" "}
                            %
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                        onClick={() =>
                          handleProNavigate({ journal_status: "submitted" })
                        }
                      >
                        <p className="mt-1 px-2 pt-2 p-tag">
                          Submit/Peer Review
                        </p>
                        <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">
                            {journalStatus.submitted_peer_review}
                          </p>
                          <p className="p-tag3 ">
                            {totalProjects !== 0
                              ? (
                                  (journalStatus.submitted_peer_review /
                                    totalProjects) *
                                  100
                                ).toFixed(2)
                              : 0}{" "}
                            %
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3"
                        onClick={() =>
                          handleProNavigate({
                            journal_status: "reviewer_comments",
                          })
                        }
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">Reviewer Comment</p>
                        <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">
                            {journalStatus.reviewer_comments}
                          </p>
                          <p className="p-tag3 ">
                            {totalProjects !== 0
                              ? (
                                  (journalStatus.reviewer_comments /
                                    totalProjects) *
                                  100
                                ).toFixed(2)
                              : 0}{" "}
                            %
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3"
                        onClick={() =>
                          handleProNavigate({ journal_status: "resubmission" })
                        }
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">
                          Resubmission/Reject
                        </p>
                        <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">
                            {journalStatus.resubmission_rejected}
                          </p>
                          <p className="p-tag3 ">
                            {totalProjects !== 0
                              ? (
                                  (journalStatus.resubmission_rejected /
                                    totalProjects) *
                                  100
                                ).toFixed(2)
                              : 0}{" "}
                            %
                          </p>
                        </div>
                      </div>
                    </div> */}

                      {/* <div className=" col total-project">
                      <div className=" w-100 d-flex px-3 mt-3">
                        <div className="graphic-box  mt-2 ">
                          <BsBarChartLine className=" graphic-icon m-2" />
                        </div>
                        <div>
                          <div className="status-title px-2 mt-3 mx-3">
                            Completed Count
                          </div>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-4"
                        onClick={() =>
                          handleProNavigate({ completed_count: "manuscript" })
                        }
                      >
                        <p className="mt-1 px-2 pt-2 p-tag">Manuscript</p>
                        <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2">{completed.manuscript}</p>
                          <p className="p-tag3">
                            {works.manuscript &&
                            completed.manuscript &&
                            works.manuscript !== 0
                              ? (
                                  (completed.manuscript / works.manuscript) *
                                  100
                                ).toFixed(2)
                              : 0}{" "}
                            %
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3"
                        onClick={() =>
                          handleProNavigate({ completed_count: "thesis" })
                        }
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">Thesis</p>
                        <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">{completed.thesis}</p>
                          <p className="p-tag3">
                            {works.thesis &&
                            completed.thesis &&
                            works.thesis !== 0
                              ? (
                                  (completed.thesis / works.thesis) *
                                  100
                                ).toFixed(2)
                              : 0}{" "}
                            %
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                        onClick={() =>
                          handleProNavigate({ completed_count: "statistics" })
                        }
                      >
                        <p className="mt-1 px-2 pt-2 p-tag">Statistics</p>
                        <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">{completed.statistics}</p>
                          <p className="p-tag3">
                            {works.statistics &&
                            completed.statistics &&
                            works.statistics !== 0
                              ? (
                                  (completed.statistics / works.statistics) *
                                  100
                                ).toFixed(2)
                              : 0}{" "}
                            %
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3"
                        onClick={() =>
                          handleProNavigate({ completed_count: "others" })
                        }
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">Others</p>
                        <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">{completed.others}</p>
                          <p className="p-tag3">
                            {works.others &&
                            completed.others &&
                            works.others !== 0
                              ? (
                                  (completed.others / works.others) *
                                  100
                                ).toFixed(2)
                              : 0}{" "}
                            %
                          </p>
                        </div>
                      </div>
                    </div> */}
                    </div>
                  </div>

                  <section className="col-12">
                    <div className="row mx-3 py-2 gap-4 d-flex  flex-wrap">
                      {/* Task Count Boxes */}

                      <div
                        className="col project-task-project1 px-1 align-items-center d-flex justify-content-around"
                        onClick={() =>
                          handleProNavigate({
                            count_type: "emergency_work",
                            month: selectedMonth,
                          })
                        }
                      >
                        {/* <div className="task-box-dash align-items-center pt-3"> */}
                        <AiOutlineAlert className="project-icon" />
                        {/* </div> */}
                        <div className="project-writer-dashboard pt-1">
                          Emergency work
                        </div>
                        <div className="project-writer-dashboard-font  ">
                          {dasCount.urgentDataListCount}
                        </div>
                      </div>
                      <div
                        className="col project-task-project2 px-1 align-items-center d-flex justify-content-around"
                        onClick={handleasshinClick}
                      >
                        {/* <div className="task-box1-dash align-items-center pt-2"> */}
                        <MdDoNotDisturb className="project-icon3 " />
                        {/* </div> */}
                        {/* <div className="align-items-center"> */}
                        <div className="project-writer-dashboard-black pt-1 ">
                          Not Assgined Work
                        </div>
                        <div className="project-writer-dashboard-black-font mt-1">
                          {dasCount.not_assigned}
                        </div>
                        {/* </div> */}
                      </div>
                      <div
                        className="col project-task-project-orange px-1 align-items-center d-flex justify-content-around"
                        onClick={() =>
                          handleProNavigate({
                            count_type: "project_delay",
                            month: selectedMonth,
                          })
                        }
                      >
                        {/* <div className="task-box2-dash-orange align-items-center pt-1"> */}
                        <TbHourglassLow className="project-icon3" />
                        {/* </div> */}
                        {/* <div className="align-items-center"> */}
                        <div className="project-writer-dashboard-black pt-1">
                          Project Delay
                        </div>
                        <div className="project-writer-dashboard-font-black mt-1">
                          {dasCount.projectdelayDataCount}
                        </div>
                        {/* </div> */}
                      </div>
                      <div
                        className="col  project-task-project-blue px-1 align-items-center d-flex justify-content-around"
                        onClick={() =>
                          handleProNavigate({
                            count_type: "freelancer_count",
                            month: selectedMonth,
                          })
                        }
                      >
                        {/* <div className="task-box3-dash align-items-center pt-3"> */}
                        <SiFreelancer className="project-icon" />
                        {/* </div> */}
                        {/* <div className="align-items-center"> */}
                        <div className="project-writer-dashboard pt-1">
                          Freelancer
                        </div>
                        <div className="project-writer-dashboard-font mt-1">
                          {dasCount.freelancet_payment_count}
                        </div>
                        {/* </div> */}
                      </div>
                    </div>
                  </section>
                </section>
              </div>

              <section className=" pt-1 mt-3  project-manage-view w-100   ">
                <div className="d-flex flex-wrap  p-3 pt-0 scrollable-section  ">
                  {/* to do **/}
                  <div className="col m-0">
                    <div className="project-todo d-flex gap-5 pb-2 m-1 pt-1">
                      <div>To Do</div>
                      <div className="project-todo-round ">
                        {dasCount.tc_to_do_list_count}
                      </div>
                    </div>
                    <div className="task-list ">
                      {Array.isArray(todolistD) &&
                        todolistD.length > 0 &&
                        todolistD.map((task, index) => {
                          let level;
                          let bgColor = "";
                          switch (task.hierarchy_level) {
                            case "urgent_important":
                              level = "U/I";
                              bgColor = "bg-red";

                              break;
                            case "important_not_urgent":
                              level = "I/NU";
                              break;
                            case "urgent_not_important":
                              level = "U/NI";
                              break;
                            case "not_urgent_not_important":
                              level = "NU/NI";
                              break;
                          }

                          // if (task.has_role === true) {
                          //   bgColor = "bg-yellow";
                          // } else {
                          //   bgColor = "bg-white";
                          // }
                          if (level === "U/I") {
                            bgColor = "bg-red";
                          } else if (task.has_role === true) {
                            bgColor = "bg-yellow";
                          } else {
                            bgColor = "bg-white";
                          }
                          return (
                            <>
                              <Link
                                key={task.id}
                                to={`/project-view/${task.project_id}`}
                                className="text-decoration-none"
                              >
                                <div
                                  className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                                >
                                  <div className="m-0 task-name-todo">
                                    {Capitalize(task.project_id)}
                                  </div>
                                  <div
                                    className="task-comments"
                                    style={{
                                      color:
                                        task.hierarchy_level ===
                                        "urgent_important"
                                          ? "#FF0909" // Red
                                          : task.hierarchy_level ===
                                            "important_not_urgent"
                                          ? "#9932cc" // Yellow
                                          : task.hierarchy_level ===
                                            "urgent_not_important"
                                          ? "#FFA500" // Orange
                                          : task.hierarchy_level ===
                                            "not_urgent_not_important"
                                          ? "#00A300" // Green
                                          : "inherit", // Default
                                    }}
                                  >
                                    {level}
                                  </div>
                                </div>
                              </Link>
                            </>
                          );
                        })}
                    </div>
                  </div>

                  <div className="col m-0">
                    <div className="project-todo d-flex gap-5 pb-2 m-1 pt-1">
                      <div>Not Assigned</div>
                      <div className="project-todo-round">
                        {revertlist.length}
                      </div>
                    </div>

                    <div className="task-list">
                      {Array.isArray(revertlist) &&
                        revertlist.length > 0 &&
                        revertlist.map((task, index) => {
                          let level;
                          let bgColor = "";
                          const hierarchy =
                            task.project_data?.hierarchy_level ||
                            task.hierarchy_level;

                          switch (hierarchy) {
                            case "urgent_important":
                              level = "U/I";
                              bgColor = "bg-red";
                              break;
                            case "important_not_urgent":
                              level = "I/NU";
                              break;
                            case "urgent_not_important":
                              level = "U/NI";
                              break;
                            case "not_urgent_not_important":
                              level = "NU/NI";
                              break;
                          }

                          return (
                            <Link
                              key={task.project_data?.id || task.id}
                              to={`/project-view/${
                                task.project_data?.project_id || task.project_id
                              }`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                              >
                                <div className="m-0 task-name-todo">
                                  {Capitalize(
                                    task.project_data?.project_id ||
                                      task.project_id
                                  )}
                                </div>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      hierarchy === "urgent_important"
                                        ? "#FF0909"
                                        : hierarchy === "important_not_urgent"
                                        ? "#9932cc"
                                        : hierarchy === "urgent_not_important"
                                        ? "#FFA500"
                                        : hierarchy ===
                                          "not_urgent_not_important"
                                        ? "#00A300"
                                        : "inherit",
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          );
                        })}
                    </div>
                  </div>

                  <div className="col ">
                    <div className="project-todo4 d-flex gap-2 pb-2 m-1 pt-1">
                      <div>REJECTED</div>
                      <div className="project-todo-round ">
                        {projectStatusCount}
                      </div>
                    </div>
                    <div className="task-list ">
                      {Array.isArray(acceptRejectList) &&
                        acceptRejectList.length > 0 &&
                        [...acceptRejectList]
                          .sort(
                            (a, b) =>
                              new Date(b.project_data?.created_at) -
                              new Date(a.project_data?.created_at)
                          )
                          .map((task, index) => {
                            const isAllEmpty =
                              !task.journal &&
                              !task.writer &&
                              !task.statistican &&
                              !task.reviewer;

                            // const handleTaskClick = (e) => {
                            //   if (isAllEmpty) {
                            //     e.preventDefault(); // Prevent default navigation
                            //     handleEditClick(task.id); // Redirect to entry process update form
                            //   }
                            // };

                            let level;
                            let bgColor = "";

                            switch (task.hierarchy_level) {
                              case "urgent_important":
                                level = "U/I";
                                bgColor = "bg-red";
                                break;
                              case "important_not_urgent":
                                level = "I/NU";
                                break;
                              case "urgent_not_important":
                                level = "U/NI";
                                break;
                              case "not_urgent_not_important":
                                level = "NU/NI";
                                break;
                            }

                            return (
                              <>
                                <Link
                                  key={task.id}
                                  to={`/project-view/${task.project_id}`}
                                  className="text-decoration-none"
                                >
                                  <div
                                    className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                                  >
                                    <div className="m-0 task-name-todo">
                                      {Capitalize(task.project_id)}
                                    </div>
                                    <div
                                      className="task-comments"
                                      style={{
                                        color:
                                          task.hierarchy_level ===
                                          "urgent_important"
                                            ? "#FF0909" // Red
                                            : task.hierarchy_level ===
                                              "important_not_urgent"
                                            ? "#9932cc" // Yellow
                                            : task.hierarchy_level ===
                                              "urgent_not_important"
                                            ? "#FFA500" // Orange
                                            : task.hierarchy_level ===
                                              "not_urgent_not_important"
                                            ? "#00A300" // Green
                                            : "inherit", // Default
                                      }}
                                    >
                                      {level}
                                    </div>
                                  </div>
                                </Link>
                              </>
                            );
                          })}
                    </div>
                  </div>
                </div>
              </section>

              <section className="  mt-2 project-manage w-100 py-0">
                <div className="row p-3">
                  <div className="col-12 ">
                    <h className="heading-entr">Inhouse projects status </h>
                  </div>
                  <div className="px-1">
                    <DataTable
                      id="example"
                      data={dataPeopleInhouse}
                      columns={columnsPeople}
                      className="display"
                      options={{
                        paging: true,
                        pageLength: 20,
                        lengthMenu: [
                          [20, 30, 50],
                          [20, 30, 50],
                        ],
                        scrollX: true,
                      }}
                    />
                  </div>
                </div>
              </section>

              <section className=" pt-1 mt-2 project-manage w-100 ">
                <div className="row px-3">
                  <div className="col-12 ">
                    <h className="heading-entr">External projects status </h>
                  </div>
                  <div className="px-1">
                    <DataTable
                      id="example"
                      data={dataPeopleExtranel}
                      columns={columnsPeople1}
                      className="display"
                      options={{
                        paging: true,
                        pageLength: 20,
                        lengthMenu: [
                          [20, 30, 50],
                          [20, 30, 50],
                        ],
                        scrollX: true,
                      }}
                    />
                  </div>
                </div>
              </section>

              <section className="  mt-2 project-manage w-100 py-0">
                <div className="row p-3">
                  <div className="col-12 ">
                    <h className="heading-entr">Thesis Status </h>
                  </div>
                  <div className="px-1">
                    <DataTable
                      id="example"
                      data={dataPeopleWriterExtranel}
                      columns={columnsThesisPeople1}
                      className="display"
                      options={{
                        paging: true,
                        pageLength: 20,
                        lengthMenu: [
                          [20, 30, 50],
                          [20, 30, 50],
                        ],
                        scrollX: true,
                      }}
                    />
                  </div>
                  {/* <div className="col-12 px-2 table-responsive  table-wrapper-scroll-y my-custom-scrollbar  ">
                              <table className="table-head">
                                <thead>
                                  <tr className="text-center tr-head">
                                    <th>SI No</th>
                                    {columns.map((col, index) => (
                                      <th key={index}>{col.title}</th>
                                    ))}
                                  </tr>
                                </thead>
                                <tbody>
                                  {data.map((row, rowIndex) => (
                                    <tr key={rowIndex} className="text-center tr-head">
                                      <td>{rowIndex + 1}</td>
                                      {columns.map((col, colIndex) => (
                                        <td key={colIndex}>
                                          {col.render
                                            ? col.render(row[col.data])
                                            : row[col.data]}
                                        </td>
                                      ))}
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div> */}
                </div>
              </section>
            </div>
          </div>
          <div>
            <Footer />
          </div>
        </section>
      )}
    </>
  );
}

export default Team_coordinator_dashboard;
