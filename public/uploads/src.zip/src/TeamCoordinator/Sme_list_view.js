import React from "react";
import "../assests/css/entryprocess.css";
import { API_URL } from "../config.js";
import { IoIosSearch } from "react-icons/io";
// import { IoFilter } from "react-icons/io5";
import { IoMdAdd } from "react-icons/io";
import { VscGitStashPop } from "react-icons/vsc";
import { VscEye } from "react-icons/vsc";
import { NavLink } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";
import Breadcrumbs from "../routes/Breadcrumbs";
import { getDateFormate } from "../dateFormate.js";
import "react-datepicker/dist/react-datepicker.css";
import Header from "../components/Header.js";
import ReactDOM from "react-dom";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";

import { Capitalize } from "../campsCase.js";

import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";

import { useLocation } from "react-router-dom";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import Loader from "../components/Loader.js";


DataTable.use(DT);
function Sme_list_view() {
  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };
    const [loading, setLoading] = useState(true);


  const location = useLocation();
  const { type } = location.state || {};
  console.log("type: " + type);
  const [data, setData] = useState([]);

    console.log("data:", data);

  const [filteredData, setFilteredData] = useState([]);
  // console.log("alldata:", filteredData);
  const [important, setImportant] = useState([]);
  // console.log("emegergy:", important);

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        `${API_URL}/api/author/publication-status`,
        {
          params: {
            type: type || "",
            position: "27",
          },
        }
      );

      // Check if response.data.data exists and is an array
      const responseData = response.data.data || [];
      const dataArray = Array.isArray(responseData)
        ? responseData
        : [responseData];

        console.log("responedtaa:",dataArray)

      if (type === "submit_to_journal") {
        const flattenedData = dataArray.map((item) => ({
          id: item.id,
          project_id: item.project_id,
          type_of_work: item.type_of_work,
          title: item.title,
          projectduration: item.projectduration,
          client_name: item.client_name,
          entry_date: item.entry_date,
          journal_status: item.journal_status[0].status,
          process_status: item.process_status,
          payment_status: item.payment_status.payment_status || "-",
          department: item.department.name,
        }));
        setData(flattenedData);
        setFilteredData(flattenedData);
        setImportant(flattenedData);
      } else {
        const flattenedData = dataArray.map((item) => ({
          id: item.id,
          project_id: item.project_id || " ",
          type_of_work: item.type_of_work || " ",
          title: item.title || " ",
          projectduration: item.projectduration || " ",
          client_name: item.client_name || " ",
          entry_date: item.entry_date || " ",
          // journal_status: item.journal_status[0].status || " ",
          process_status: item.process_status || "-",
          payment_status: item.payment_status || "-",
          // department: item.department.name || " ",
        }));
        setData(flattenedData);
        setFilteredData(flattenedData);
        setImportant(flattenedData);
              setLoading(false);

      }
    } catch (error) {
      console.error("Error fetching data", error);
    } finally {
    setLoading(false); // stop loader after fetch
  }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const navigate = useNavigate();

  const handleViewClick = (id) => {
    navigate("/entry-process/process-view-details", {
      state: { rowId: id },
    });
  };

  const truncateText = (text, limit) => {
    if (text && text.length > limit) {
      return text.slice(0, limit) + "..."; // Truncate and add ellipsis if text is longer
    }
    return text;
  };

  const columns = [
    {
      title: " Project ID".toUpperCase(),
      data: "project_id",
      render: (data) => Capitalize(data),
    },
    {
      title: "DATE",
      data: "entry_date",
      render: (data) => getDateFormate(data),
    },
    // {
    //   title: "Department".toUpperCase(),
    //   data: null,
    //   render: (data) =>
    //     data?.department?.name ? Capitalize(data.department.name) : "-",
    // },
    // {
    //   title: "Institution".toUpperCase(),
    //   data: null,
    //   render: (data) =>
    //     data?.institute?.name ? Capitalize(data.institute.name) : "-",
    // },
    {
      title: "Client Name".toUpperCase(),
      data: "client_name",
      render: (data) => `Dr.${Capitalize(data)}`,
    },
    // {
    //   title: "Profession".toUpperCase(),
    //   data: null,
    //   render: (data) =>
    //     data?.profession?.name ? Capitalize(data.profession.name) : "-",
    // },
    {
      title: "TITLE",
      data: null,
      render: (data, type, row) => {
        const id = `title-${row.sno || Math.random()}`;

        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div
                className="d-flex justify-content-center"
                // onClick={togglePopuptitle}
                onMouseEnter={() => row.title} // Pass title dynamically
                // onMouseLeave={handleMouseLeave}
                id={`title-${row.sno || Math.random()}`}
              >
                {truncateText(row.title, 10)}
              </div>,

              container
            );
          }
        }, 0);

        return `<div id="${id}"></div>`;
      },
    },
    {
      title: "Process Status".toUpperCase(),
      data: null,
      render: (data) => CapitalizeCaseU(data.process_status),
    },
    {
      title: "Duration".toUpperCase(),
      data: null,
      render: (data) => CapitalizeCaseU(data.projectduration),
    },

    {
      title: "PAYMENT STATUS",
      data: null,
      render: (data) => CapitalizeCaseU(data.payment_status),
    },
    {
      title: "ACTIONS",
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                <div className="" title="View">
                  <span>
                    <VscEye
                      onClick={() => handleViewClick(row.id)}
                      className="open-icon"
                    />
                  </span>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];


  // useEffect(() => {
  //   const handleLoad = () => {
  //     setTimeout(() => {
  //       setLoading(false);
  //     }, 1000);
  //   };

  //   if (document.readyState === "complete") {
  //     handleLoad();
  //   } else {
  //     window.addEventListener("load", handleLoad);
  //   }

  //   return () => window.removeEventListener("load", handleLoad);
  // }, []);

  // if (loading) {
  //   return <Loader />;
  // }

  return (
    <>
          {loading ? (
            <Loader />
          ) : (
    <section className="container d-flex flex-column min-vh-100 justify-content-between">
      <div className=" row mt-4">
        {/* <div className=" col-1   d-flex justify-content-center">
          <Sider></Sider>
        </div> */}

        <div className="col-12  ">
          <div className="col-12">
            <Header></Header>
          </div>

          <div className="col-12 mt-3 pt-1 wapper w-100 py-5">
            <div className=" row mt-3 d-flex   w-100 ">
              <div className="col-12 col-md-9  px-4 ">
                <p className="heading-entr">Project View</p>
              </div>
              <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>

            <div className="px-1">
              <DataTable
                id="example"
                data={filteredData}
                columns={columns}
                className="display"
                options={{
                  scrollX: true,
                  select: true,
                  pageLength: 20, // Default number of rows per page
                  lengthMenu: [
                    [20, 30, 50],
                    [20, 30, 50],
                  ],
                }}
              />
            </div>
          </div>
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </section>
    )}
    </>
  );
}

export default Sme_list_view;
