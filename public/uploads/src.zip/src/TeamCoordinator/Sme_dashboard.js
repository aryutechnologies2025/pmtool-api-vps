import React from "react";

import { BsBarChartLine } from "react-icons/bs";
import Sider from "../components/Sider";

import Header from "../components/Header";
import { AiOutlineAlert } from "react-icons/ai";
import { MdDoNotDisturb } from "react-icons/md";
import { FaFileInvoiceDollar } from "react-icons/fa6";
import { GiPiggyBank } from "react-icons/gi";
import "../assests/css/project_management.css";
import ReactDOM from "react-dom";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { useState, useEffect } from "react";
import { VscGitStashPop } from "react-icons/vsc";
import { IoMdAdd } from "react-icons/io";
import Footer from "../components/Footer";
import Tooltip from "@mui/material/Tooltip";
import { useNavigate } from "react-router-dom";
import Breadcrumbs from "../routes/Breadcrumbs";
import { VscEye } from "react-icons/vsc";
// icon
import { TbHourglassLow } from "react-icons/tb";
import { SiFreelancer } from "react-icons/si";
import { SiQuicklook } from "react-icons/si";

import axios from "axios";
import { Link } from "react-router-dom";
// import { combineEventHandlers } from "recharts/types/util/ChartUtils.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import Loader from "../components/Loader.js";
DataTable.use(DT);

function Sme_dashboard() {
  const [loading, setLoading] = useState(true);

  const columns = [
    { title: "MONTH".toUpperCase(), data: "month" },
    { title: "Manuscript".toUpperCase(), data: "manuscript" },
    { title: "Statistics".toUpperCase(), data: "statistics" },
    { title: "Thesis".toUpperCase(), data: "thesis" },
    { title: "Others".toUpperCase(), data: "others" },
    { title: "NA", data: "not_assigned" },
    { title: "WD", data: "withdrawn" },
    { title: "Total".toUpperCase(), data: "total" },
    {
      title: "Manuscript (%)".toUpperCase(),
      data: "manuscript_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "Statistics (%)".toUpperCase(),
      data: "statistics_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "Thesis (%)".toUpperCase(),
      data: "thesis_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "Others (%)".toUpperCase(),
      data: "others_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "TARGET (%)",
      data: "target_percentage",
      render: (data) => {
        if (data !== null && data !== undefined) {
          return `${Number(data).toLocaleString()}%`;
        }
        return "N/A"; // Handle null or undefined values
      },
    },
  ];

  const handleNavigate = (type, createdby) => {
    // navigate(`/employee-project-list`, { state: { type, createdby } });
    navigate(`/employe-project-list`, { state: { type, createdby } });
  };

  const handleProNavigate = (params) => {
    navigate(`/sme-list-view`, { state: params });
  };

  const handlePaymentStatusNavigate = (params) => {
    navigate(`/payment-status-list`, { state: params });
  };

  //dashboard list
  const [totalProjects, setProjectCount] = useState(0);
  const [journalStatus, setJournalStatus] = useState(0);
  const [paymentStatus, setPaymentStatus] = useState(0);
  // console.log("payment:", paymentStatus);
  const [filterData, setDataFilter] = useState(0);
  const [smelist, setTCList] = useState([]);
  const [reviewerlist, setReviewerList] = useState([]);
  const [statisticanlist, setStatisticanList] = useState([]);
  const [publicationManager, setPublicationManagerList] = useState([]);
  const [writerlist, setWriterList] = useState([]);
  // console.log("writerlistcheck", writerlist);
  // console.log("reviewerlistcheck", reviewerlist);

  const [emworkid, setEmworkid] = useState([]);
  // console.log("emowrkL:", emworkid);

  const fetchProjectManagerData = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/sme/list`);
      const responsedata = response.data;
      console.log("response", responsedata);
      setDataFilter(responsedata);
      setEmworkid(responsedata.urgentImportantIds);
      setProjectCount(responsedata.projectcount);
      setJournalStatus(responsedata.journal_status);
      setPaymentStatus(responsedata.paymentStatusCounts);
      setTCList(responsedata.smelist);
      const flatenDataReviewer = responsedata.reviewerist
        .map((item) => {
          return {
            assign_date: item.assign_date,
            assign_user: item.assign_user,
            comments: item.comments,
            created_at: item.created_at,
            created_by: item.created_by,
            updated_at: item.updated_at,
            work_type: item.documents[0]?.select_document,
            type_of_work: item.project_data?.type_of_work,
            id: item.id,
            project_data: item.project_data,
            project_duration: item.project_duration,
            project_id: item.project_id,
            review: item.review,
            status: item.status,
            status_date: item.status_date,
            type: item.type,
            type_of_article: item.type_of_article,
            tc_status: item.project_data?.tc_data?.[0]?.type_sme,
          };
        })
        .filter((item) => {
          // if it's not a thesis, filter out "statistican"
          if (item.type_of_work !== "thesis") {
            return item.tc_status !== "statistican";
          }

          // otherwise, allow it
          return true;
        });

      setReviewerList(flatenDataReviewer);

      // console.log("statisticanlist", flatenDataStatistican);
      const flatenDataStatistican = responsedata.statisticanlist
        .map((item) => {
          // Parse the stringified array for work_type
          let workTypes = [];
          try {
            workTypes = JSON.parse(item.documents[0].select_document) || [];
          } catch (e) {
            workTypes = [];
          }

          return {
            assign_date: item.assign_date,
            assign_user: item.assign_user,
            comments: item.comments,
            work_type: workTypes, // Now this is an actual array
            type_of_work: item.project_data.type_of_work,
            id: item.id,
            project_data: item.project_data,
            project_id: item.project_id,
            review: item.review,
            status: item.status,
            type: item.type,
            type_of_article: item.type_of_article,
            reviewerlength: item.project_data.reviewer_data.length,
            writerlength: item.project_data.writer_data.length,
            reviewer_status: item.project_data.reviewer_data[1]?.status, // Using index 0
            reviewer_status_type: item.project_data.reviewer_data[0]?.status, // Same as above if you need it
            writer_status_type: item.project_data.writer_data[0]?.status, // Same as above if you need it
            statistican_status: item.project_data.statistican_data[1]?.status,
            statistican_status_type:
              item.project_data.statistican_data[0]?.status,
            tc_status: item.project_data.tc_data[0]?.type_sme,
          };
        })
        .filter((item) => {
          let isThesis;
          const isStatictican = item.statistican_status === "need_support";
          if (!isStatictican) {
            isThesis = item.type_of_work === "thesis";
          }

          if (isThesis) {
            if (item.writerlength === 2 && item.reviewerlength === 1) {
              return false;
            }
            // hide if thesis & reviewer_status is "completed"
            return item.reviewer_status !== "completed";
          } else {
            const isStaticticann =
              item.statistican_status_type === "need_support";
            let hasreviewerStatusCompleted;
            let haswriterStatusCompleted;
            if (!isStaticticann) {
              // check if reviewer_status is "completed"
              hasreviewerStatusCompleted =
                item.reviewer_status_type === "completed";
              // console.log("isStaticticann", hasreviewerStatusCompleted);

              haswriterStatusCompleted =
                item.writer_status_type === "completed";
            }
            if (hasreviewerStatusCompleted) {
              console.log(
                "hasreviewerStatusCompleted",
                hasreviewerStatusCompleted
              );
              // work_type should exactly match one of these (now checking array items)
              const allowedWorkTypes = [
                "writing",
                "with_statistics",
                "with_publication",
                "thesis_statistics_with_text",
                "writing, with_publication",
                "writing, with_statistics",

                "with_publication, writing",
                "with_statistics, writing",
              ];
              const isSpecificWorkType = allowedWorkTypes.includes(
                item.work_type[0]
              );

              // hide if (status completed && work type is specific)
              return (
                hasreviewerStatusCompleted &&
                isSpecificWorkType &&
                item.tc_status === "statistican"
              );
            }

            if (hasreviewerStatusCompleted) {
              console.log(
                "hasreviewerStatusCompleted",
                hasreviewerStatusCompleted
              );
              // work_type should exactly match one of these (now checking array items)
              const allowedWorkTypes = [
                "writing",
                "with_statistics",
                "with_publication",
                "thesis_statistics_with_text",
                "writing, with_publication",
                "writing, with_statistics",

                "with_publication, writing",
                "with_statistics, writing",
              ];
              const isSpecificWorkType = allowedWorkTypes.includes(
                item.work_type[0]
              );

              // hide if (status completed && work type is specific)
              return !(hasreviewerStatusCompleted && isSpecificWorkType);
            } else {
              // work_type should exactly match one of these (now checking array items)
              const allowedWorkTypes = [
                "writing",
                "with_statistics",
                "with_publication",
                "thesis_statistics_with_text",
                "writing, with_publication",
                "writing, with_statistics",

                "with_publication, writing",
                "with_statistics, writing",
              ];
              const isSpecificWorkType = allowedWorkTypes.includes(
                item.work_type[0]
              );

              // hide if (status completed && work type is specific)
              return !(haswriterStatusCompleted && isSpecificWorkType);
            }
          }
        });

      setStatisticanList(flatenDataStatistican);
      console.log("statisticanlist", flatenDataStatistican);

      setPublicationManagerList(responsedata.publication_list);
      const flatenDataWriter = responsedata.writerList.map((item) => {
        return {
          assign_date: item.assign_date,
          assign_user: item.assign_user,
          comments: item.comments,
          work_type: item.documents[0].select_document,
          type_of_work: item.project_data.type_of_work,
          id: item.id,
          project_data: item.project_data,
          project_id: item.project_id,
          review: item.review,
          status: item.status,
          type: item.type,
          type_of_article: item.type_of_article,
        };
      });
      // .filter(
      //   (item) =>
      //     item.status === "need_support" ||
      //     item.type_of_work === "thesis" ||
      //     item.work_type === '["thesis_statistics_with_text"]' ||
      //     item.work_type === '["writing","with_publication"]' ||
      //     item.work_type ===
      //       '["writing","with_statistics","with_publication"]' ||
      //     item.work_type === '["writing","with_statistics"]' ||
      //     item.work_type === '["writing"]'
      // );
      setWriterList(flatenDataWriter);
      setLoading(false);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      fetchProjectManagerData();
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const navigate = useNavigate();

  const handleEditClick = (id) => {
    navigate("/entry-process/entryprocess-update-form", {
      state: { rowId: id },
    });
  };

  const freelancerId = localStorage.getItem("empname");
  const projectIds = JSON.parse(localStorage.getItem("projectallid"));

  // console.log("Freelancer ID:", freelancerId);
  // console.log("Project IDs:", projectIds);

  const handleEmergencyClick = () => {
    // const freelancerId = freelancer_id;
    const projectIds = emworkid.map((item) => item);

    // Store in localStorage
    localStorage.setItem("empname", freelancerId);
    localStorage.setItem("projectallid", JSON.stringify(projectIds));

    // Open the project list page in a new tab
    window.open("/projectlist", "_blank");
  };

  // useEffect(() => {
  //   const handleLoad = () => {
  //     setTimeout(() => {
  //       setLoading(false);
  //     }, 5000);
  //   };

  //   if (document.readyState === "complete") {
  //     handleLoad();
  //   } else {
  //     window.addEventListener("load", handleLoad);
  //   }

  //   return () => window.removeEventListener("load", handleLoad);
  // }, []);

  // if (loading) {
  //   return <Loader />;
  // }

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <section className="container ">
          <div className="mt-4 w-100">
            {/* <div className="col-1 d-flex    justify-content-center">
            <Sider />
          </div> */}
            <div className="col-12 ">
              <div className="col-12">
                <Header></Header>
              </div>
              <div className=" pt-1 mt-3 py-3 project-manage w-100 ">
                <div className=" row mt-3 d-flex   w-100 ">
                  <div className="col-12 col-md-6  px-4 ">
                    <h1 className="heading-entr">SME Dashboard</h1>
                  </div>

                  <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                    <Breadcrumbs></Breadcrumbs>
                  </div>
                </div>
                <section className="col-12  ">
                  <div className="row  px-3">
                    <div className="row gap-5">
                      <div className=" col-3 total-project-accounts pt-3  mx-3">
                        <div
                          className="manage-title  mx-3  d-flex justify-content-around mt-1"
                          onClick={() =>
                            handleProNavigate({
                              type: "client_review",
                              // listview: "sme",
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">Client Review</p>
                          <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2">
                              {totalProjects.client_review}
                            </p>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3"
                          onClick={() =>
                            handleProNavigate({
                              type: "completed_list",
                              // listview: "sme",
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">Completed</p>
                          <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">{totalProjects.completed}</p>
                          </div>
                        </div>
                      </div>

                      <div className=" col-3 total-project">
                        <div className=" w-100 d-flex px-3 mt-3">
                          <div className="graphic-box  mt-2 ">
                            <BsBarChartLine className=" graphic-icon m-2" />
                          </div>
                          <div>
                            <div className="status-title px-2 mt-3 mx-3">
                              Journal Status
                            </div>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-4"
                          onClick={() =>
                            handleProNavigate({
                              type: "pending_author",
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">Pending Author</p>
                          <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2">
                              {journalStatus.pending_author || "0"}
                            </p>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3"
                          onClick={() =>
                            handleProNavigate({ type: "rejected" })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">Rejected</p>
                          <div className="manage-num mt-1    pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">
                              {journalStatus.rejected || "0"}
                            </p>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                          onClick={() =>
                            handleProNavigate({
                              type: "reviewer_comments",
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">
                            Reviewer Comments
                          </p>
                          <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">
                              {journalStatus.reviewer_comments || "0"}
                            </p>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                          onClick={() =>
                            handleProNavigate({ type: "resubmission" })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">Resubmission</p>
                          <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">
                              {journalStatus.submit_to_journal || "0"}
                            </p>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3"
                          onClick={() =>
                            handleProNavigate({
                              type: "submit_to_journal",
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">
                            Submit to journal
                          </p>
                          <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">
                              {journalStatus.submit_to_journal || "0"}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className=" col-3 total-project   mx-2">
                        <div className=" w-100 d-flex px-3 mt-3">
                          <div className="graphic-box  mt-2 ">
                            <BsBarChartLine className=" graphic-icon m-2" />
                          </div>
                          <div>
                            <div className="status-title px-2 mt-3 mx-3">
                              Payment Status
                            </div>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-4"
                          onClick={() =>
                            handlePaymentStatusNavigate({
                              payment_status: "advance_pending",
                            })
                          }
                        >
                          <p className="mt-1 px-2 pt-2 p-tag">
                            Advance Pending
                          </p>
                          <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2">
                              {paymentStatus.advance_pending}
                            </p>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                          onClick={() =>
                            handlePaymentStatusNavigate({
                              payment_status: "partial_payment_pending",
                            })
                          }
                        >
                          <p className="mt-1 px-2 pt-2 p-tag">
                            Partial Payment Pending
                          </p>
                          <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">
                              {paymentStatus.partial_payment_pending}
                            </p>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3"
                          onClick={() =>
                            handlePaymentStatusNavigate({
                              payment_status: "final_payment_pending",
                            })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">
                            Final Payment Pending
                          </p>
                          <div className="manage-num mt-1 pt-3  mx-1 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">
                              {paymentStatus.final_payment_pending}
                            </p>
                          </div>
                        </div>
                        <div
                          className="manage-title  mx-3 d-flex justify-content-around mt-3"
                          onClick={() =>
                            handleProNavigate({ type: "journal_list" })
                          }
                        >
                          <p className="mt-1 pt-2 px-2 p-tag">
                            Journal Payment Pending
                          </p>
                          <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                            <p className="p-tag2 ">{filterData.journalList}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <section className="col-12">
                    <div className="row mx-3 py-2 gap-4 d-flex  flex-wrap">
                      <div
                        className="col project-task-project1 px-1 align-items-center d-flex justify-content-around"
                        onClick={handleEmergencyClick}
                      >
                        <AiOutlineAlert className="project-icon" />
                        {/* </div> */}
                        <div className="project-writer-dashboard pt-1">
                          Emergency Work
                        </div>
                        <div className="project-writer-dashboard-font mt-1 ">
                          {filterData.urgentImportantCount}
                        </div>
                      </div>
                      <div
                        className="col project-task-project2 px-1 align-items-center d-flex justify-content-around"
                        onClick={() =>
                          handleProNavigate({ type: "quick_review" })
                        }
                      >
                        <SiQuicklook className="project-icon3 " />

                        <div className="project-writer-dashboard-black pt-2 ">
                          Quick Review
                        </div>
                        <div className="project-writer-dashboard-font-black mt-1 ">
                          {filterData.quickReviewCount}
                        </div>
                      </div>
                    </div>
                  </section>
                </section>
              </div>
              <section className=" pt-1 mt-3  project-manage-view w-100   ">
                <div className="d-flex flex-wrap  p-3 pt-0 scrollable-section  ">
                  {/**** To Do */}
                  <div className="col m-0  ">
                    <div className="project-todo d-flex gap-2 pb-2 m-1 pt-1">
                      <div>TEAM COORDINATOR</div>
                      <div className="project-todo-round ">
                        {filterData.smelistCount}
                      </div>
                    </div>
                    <div className="task-list">
                      {Array.isArray(smelist) &&
                        smelist.length > 0 &&
                        [...smelist]
                          .sort(
                            (a, b) =>
                              new Date(b.project_data?.created_at) -
                              new Date(a.project_data?.created_at)
                          )
                          .map((task, index) => {
                            let level;
                            let bgColor = "";
                            switch (task.project_data?.hierarchy_level) {
                              case "urgent_important":
                                level = "U/I";
                                bgColor = "bg-red";
                                break;
                              case "important_not_urgent":
                                level = "I/NU";
                                break;
                              case "urgent_not_important":
                                level = "U/NI";
                                break;
                              case "not_urgent_not_important":
                                level = "NU/NI";
                                break;
                            }

                            return (
                              <>
                                <Link
                                  key={task.project_data?.id}
                                  to={`/project-view/${task.project_data?.project_id}`}
                                  className="text-decoration-none"
                                >
                                  <div
                                    className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                                  >
                                    <div className="m-0 task-name-todo">
                                      {Capitalize(
                                        task.project_data?.project_id
                                      )}
                                    </div>
                                    <div
                                      className="task-comments"
                                      style={{
                                        color:
                                          task.project_data?.hierarchy_level ===
                                          "urgent_important"
                                            ? "#FF0909" // Red
                                            : task.project_data
                                                ?.hierarchy_level ===
                                              "important_not_urgent"
                                            ? "#9932cc" // Yellow
                                            : task.project_data
                                                ?.hierarchy_level ===
                                              "urgent_not_important"
                                            ? "#FFA500" // Orange
                                            : task.project_data
                                                ?.hierarchy_level ===
                                              "not_urgent_not_important"
                                            ? "#00A300" // Green
                                            : "inherit", // Default
                                      }}
                                    >
                                      {level}
                                    </div>
                                  </div>
                                </Link>
                              </>
                            );
                          })}
                    </div>
                  </div>
                  <div className="col">
                    <div className="project-todo2 d-flex gap-5 pb-2 m-1 pt-1">
                      <div>WRITER</div>
                      <div className="project-todo-round">
                        {filterData.writerListCount}
                      </div>
                    </div>
                    <div className="task-list">
                      {Array.isArray(writerlist) &&
                        writerlist.length > 0 &&
                        [...writerlist]
                          .sort(
                            (a, b) =>
                              new Date(b.project_data?.created_at) -
                              new Date(a.project_data?.created_at)
                          )
                          .map((task, index) => {
                            let level;
                            let bgColor = "";
                            switch (task.project_data?.hierarchy_level) {
                              case "urgent_important":
                                level = "U/I";
                                bgColor = "bg-red";
                                break;
                              case "important_not_urgent":
                                level = "I/NU";
                                break;
                              case "urgent_not_important":
                                level = "U/NI";
                                break;
                              case "not_urgent_not_important":
                                level = "NU/NI";
                                break;
                              default:
                                level = "";
                            }

                            return (
                              <Link
                                key={task.project_data?.id}
                                to={`/project-view/${task.project_data?.project_id}`}
                                className="text-decoration-none"
                              >
                                <div
                                  className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                                >
                                  <div className="m-0 task-name-todo">
                                    {task.project_data?.project_id}
                                  </div>
                                  <div
                                    className="task-comments"
                                    style={{
                                      color:
                                        task.project_data?.hierarchy_level ===
                                        "urgent_important"
                                          ? "#FF0909"
                                          : task.project_data
                                              ?.hierarchy_level ===
                                            "important_not_urgent"
                                          ? "#9932cc"
                                          : task.project_data
                                              ?.hierarchy_level ===
                                            "urgent_not_important"
                                          ? "#FFA500"
                                          : task.project_data
                                              ?.hierarchy_level ===
                                            "not_urgent_not_important"
                                          ? "#00A300"
                                          : "inherit",
                                    }}
                                  >
                                    {level}
                                  </div>
                                </div>
                              </Link>
                            );
                          })}
                    </div>
                  </div>

                  <div className="col ">
                    <div className="project-todo2 d-flex gap-5 pb-2 m-1 pt-1 ">
                      <div>REVIEWER</div>
                      <div className="project-todo-round ">
                        {filterData.revieweristCount}
                      </div>
                    </div>
                    <div className="task-list ">
                      {Array.isArray(reviewerlist) &&
                        reviewerlist.length > 0 &&
                        [...reviewerlist]
                          .sort(
                            (a, b) =>
                              new Date(b.project_data?.created_at) -
                              new Date(a.project_data?.created_at)
                          )
                          .map((task, index) => {
                            let level;
                            let bgColor = "";
                            switch (task.project_data?.hierarchy_level) {
                              case "urgent_important":
                                level = "U/I";
                                bgColor = "bg-red";
                                break;
                              case "important_not_urgent":
                                level = "I/NU";
                                break;
                              case "urgent_not_important":
                                level = "U/NI";
                                break;
                              case "not_urgent_not_important":
                                level = "NU/NI";
                                break;
                            }

                            return (
                              <>
                                <Link
                                  key={task.project_data?.id}
                                  to={`/project-view/${task.project_data?.project_id}`}
                                  state={{ data: "reviewer" }}
                                  className="text-decoration-none"
                                >
                                  <div
                                    className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                                  >
                                    <div className="m-0 task-name-todo">
                                      {Capitalize(
                                        task.project_data?.project_id
                                      )}
                                    </div>
                                    <div
                                      className="task-comments"
                                      style={{
                                        color:
                                          task.project_data?.hierarchy_level ===
                                          "urgent_important"
                                            ? "#FF0909" // Red
                                            : task.project_data
                                                ?.hierarchy_level ===
                                              "important_not_urgent"
                                            ? "#9932cc" // Yellow
                                            : task.project_data
                                                ?.hierarchy_level ===
                                              "urgent_not_important"
                                            ? "#FFA500" // Orange
                                            : task.project_data
                                                ?.hierarchy_level ===
                                              "not_urgent_not_important"
                                            ? "#00A300" // Green
                                            : "inherit", // Default
                                      }}
                                    >
                                      {level}
                                    </div>
                                  </div>
                                </Link>
                              </>
                            );
                          })}
                    </div>
                  </div>
                  <div className="col ">
                    <div className="project-todo3 d-flex gap-5 pb-2 m-1 pt-1">
                      <div>STATISTICIAN</div>
                      <div className="project-todo-round ">
                        {statisticanlist.length}
                      </div>
                    </div>
                    <div className="task-list ">
                      {Array.isArray(statisticanlist) &&
                        statisticanlist.length > 0 &&
                        [...statisticanlist]
                          .sort(
                            (a, b) =>
                              new Date(b.project_data?.created_at) -
                              new Date(a.project_data?.created_at)
                          )
                          .map((task, index) => {
                            let level;
                            let bgColor = "";
                            switch (task.project_data?.hierarchy_level) {
                              case "urgent_important":
                                level = "U/I";
                                bgColor = "bg-red";
                                break;
                              case "important_not_urgent":
                                level = "I/NU";
                                break;
                              case "urgent_not_important":
                                level = "U/NI";
                                break;
                              case "not_urgent_not_important":
                                level = "NU/NI";
                                break;
                            }

                            return (
                              <>
                                <Link
                                  key={task.project_data?.id}
                                  to={`/project-view/${task.project_data?.project_id}`}
                                  state={{ data: "statistican" }}
                                  className="text-decoration-none"
                                >
                                  <div
                                    className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                                  >
                                    <div className="m-0 task-name-todo">
                                      {Capitalize(
                                        task.project_data?.project_id
                                      )}
                                    </div>
                                    <div
                                      className="task-comments"
                                      style={{
                                        color:
                                          task.project_data?.hierarchy_level ===
                                          "urgent_important"
                                            ? "#FF0909" // Red
                                            : task.project_data
                                                ?.hierarchy_level ===
                                              "important_not_urgent"
                                            ? "#9932cc" // Yellow
                                            : task.project_data
                                                ?.hierarchy_level ===
                                              "urgent_not_important"
                                            ? "#FFA500" // Orange
                                            : task.project_data
                                                ?.hierarchy_level ===
                                              "not_urgent_not_important"
                                            ? "#00A300" // Green
                                            : "inherit", // Default
                                      }}
                                    >
                                      {level}
                                    </div>
                                  </div>
                                </Link>
                              </>
                            );
                          })}
                    </div>
                  </div>
                  <div className="col ">
                    <div className="project-todo-public d-flex gap-1 pb-2 m-1 pt-1">
                      <div>PUBLICATION MANAGER</div>
                      <div className="project-todo-round">
                        {filterData.publication_count}
                      </div>
                    </div>
                    <div className="task-list ">
                      {Array.isArray(publicationManager) &&
                        publicationManager.length > 0 &&
                        [...publicationManager]
                          .sort(
                            (a, b) =>
                              new Date(b.project_data?.created_at) -
                              new Date(a.project_data?.created_at)
                          )
                          .map((task, index) => {
                            let level;
                            let bgColor = "";
                            switch (task.project_data?.hierarchy_level) {
                              case "urgent_important":
                                level = "U/I";
                                bgColor = "bg-red";
                                break;
                              case "important_not_urgent":
                                level = "I/NU";
                                break;
                              case "urgent_not_important":
                                level = "U/NI";
                                break;
                              case "not_urgent_not_important":
                                level = "NU/NI";
                                break;
                            }

                            return (
                              <>
                                <Link
                                  to={`/project-view/${task.project_data?.project_id}`}
                                  state={{ data: "Publication Manager" }}
                                  className="text-decoration-none"
                                >
                                  <div
                                    className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                                  >
                                    <div className="m-0 task-name-todo">
                                      {Capitalize(
                                        task.project_data?.project_id
                                      )}
                                    </div>
                                    <div
                                      className="task-comments"
                                      style={{
                                        color:
                                          task.project_data?.hierarchy_level ===
                                          "urgent_important"
                                            ? "#FF0909" // Red
                                            : task.project_data
                                                ?.hierarchy_level ===
                                              "important_not_urgent"
                                            ? "#9932cc" // Yellow
                                            : task.project_data
                                                ?.hierarchy_level ===
                                              "urgent_not_important"
                                            ? "#FFA500" // Orange
                                            : task.project_data
                                                ?.hierarchy_level ===
                                              "not_urgent_not_important"
                                            ? "#00A300" // Green
                                            : "inherit", // Default
                                      }}
                                    >
                                      {level}
                                    </div>
                                  </div>
                                </Link>
                              </>
                            );
                          })}
                    </div>
                  </div>
                </div>
              </section>
            </div>
          </div>
          <div>
            <Footer />
          </div>
        </section>
      )}
    </>
  );
}

export default Sme_dashboard;
