import { Link, useLocation, useParams } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronRight } from '@fortawesome/free-solid-svg-icons';

const Breadcrumbs = () => {
  const location = useLocation();
  const { id } = useParams();

  // Define human-readable names for the routes
  const routeNames = {
    'project-management': 'Project Management',
    'entry-process': 'Entry Process',
    'processstatus': 'Process Status',
    'paymentstatus': 'Payment Status',
    'pending': 'Pending',
    'settings': 'Settings',
    'people-details': 'People Details',
    'admin-profile': 'Admin Profile',
    'project-view': 'Project View',
    'process-view-details': 'Process View Details',
    'department-form': 'Department Form',
    'profession-form': 'Profession Form',
    'modula-institution': 'Modular Institution',
    'team-coordinator-dashboard': 'Team Coordinator Dashboard',
    'internal-dashboard': 'Internal Dashboard',
    'freelancer-dashboard': 'Freelancer Dashboard',
    'project-manager-dashboard': 'Project Manager Dashboard',
    'modula-department': 'Modular Department',
    'modula-profession': 'Modular Profession',
    'admin-dashboard': 'Admin Dashboard',
    'enter_process_form': 'Enter Process Form',
    'process-status-form': 'Process Status Form',
    'payment-form': 'Payment Form',
    'pending-form': 'Pending Form',
    'people_view_details': 'People View Details',
    'payment-edit-form': 'Payment Edit Form',
    'entryprocess-update-form': 'Entry Process Update Form',
    'accounts-dashboard': 'Accounts Dashboard',
    'dashboard': 'Dashboard',
    'project-list': 'Project List',
    'employee-project-list': 'Employee Project List',
    'employe-project-list': 'Employee Project List',
    'delete-process': 'Delete List',
    'sme-dashboard': 'SME Dashboard',
    'public-view': 'Publication View',
    'publication-dashboard':'Publication Dashboard',
    //  reports

    'process-report': 'Process Reports',
    'operational-report': 'Operational Reports',
    'client-analysis': 'Client Analysis',
    'employee-performance': 'Employee Performance',
    'payment-reports': 'Payment Reports',
    'sme-list': 'SME ProjectList',
    'accounts-main-dashboard':'Accounts Dashboard',
    'accounts-task-view':'Accounts Task View',

    'public-list-view':'Public List View',
    'payment-status-list':'Payment Status List',
    'employee-project-lists':'Employee Project Lists',

    'freelancer-project-list':'Freelancer Project List',
    'team-coordinator-list' :'Team Coordinator List',
    'project-activity':'Project Activity',
  };

  const pathnames = location.pathname.split('/').filter(x => x);

  const rolename = localStorage.getItem('medocsrolename') || 'Admin';
  const emp_type = localStorage.getItem('medicsEmpName') || 'Admin';


  return (
    <nav>
      <ul className="breadcrumbs">

        {rolename.includes('Admin') && (
          <li>

            <Link to="/dashboard">Home</Link>
          </li>
        )}
        {rolename.includes(13) && (
          <li>

            <Link to="/project-manager-dashboard">Home</Link>
          </li>
        )}

        {rolename.includes(28) && (
          <li>

            <Link to="/sme-dashboard">Home</Link>
          </li>
        )}

        {rolename.includes(27) && (
          <li>

            <Link to="/publication-dashboard">Home</Link>
          </li>
        )}
        {rolename.includes(14) && (
          <li>

            <Link to="/team-coordinator-dashboard">Home</Link>
          </li>
        )}
        {rolename.includes(23) && (
          <li>

            <Link to="/accounts-main-dashboard">Home</Link>
          </li>
        )}
        {emp_type === 'freelancers' && (
          <li>

            <Link to="/freelancer-dashboard">Home</Link>
          </li>
        )}
        {
          (emp_type === "full_time" || emp_type === "part_time") && !rolename.includes('Admin') &&!rolename.includes(13) && !rolename.includes(14) && !rolename.includes(23) && !rolename.includes(28) && !rolename.includes(27) && (
            <li>
              <Link to="/internal-dashboard">Home</Link>
            </li>
          ) 
        }
        <span className="arrow">
          <FontAwesomeIcon icon={faChevronRight} />
        </span>

        {pathnames.map((value, index) => {
          const to = `/${pathnames.slice(0, index + 1).join('/')}`;
          const routeLabel = routeNames[value] || value; // Use human-readable label or default to the raw value

          return (
            <li key={to}>
              <Link to={to}>{routeLabel}</Link>
              {index < pathnames.length - 1 && (
                <span className="arrow">
                  <FontAwesomeIcon icon={faChevronRight} />
                </span>
              )}
            </li>
          );
        })}

        {/* {id && (
          <li>
            <span>{id}</span>
          </li>
        )} */}
      </ul>
    </nav>
  );
};

export default Breadcrumbs;

