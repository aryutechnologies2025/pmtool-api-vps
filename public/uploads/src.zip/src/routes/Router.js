import React from "react";
import Loging from "../pages/Loging";

import { Routes, Route } from "react-router-dom";
import Register from "../pages/Register";
import Process1 from "../components/Process1";
import { useState, useEffect } from "react";

import ProcessStatus from "../components/ProcessStatus";
import Paymentstatus from "../components/Paymentstatus";
import Pending from "../components/Pending";
import Dashboard from "../components/Dashboard";
import Project_management from "../components/Project_management";
import Peoples from "../components/Peoples_details";
import Modula from "../modulas/Modula_institution";
import Modula_department from "../modulas/Modula_department";
import Modula_profession from "../modulas/Modula_profession";
import Process_statistic from "../form/Process_status-form";
import Institute_form from "../form/Process_details";

import Payment_form from "../form/Payment_form";
import Pending_form from "../form/Pending_form";
import Enterprocess_form from "../form/Enterprocess_form";
import Settings from "../components/Settings";
import Admin_profile from "../components/Admin_profile";
import Project_manager_dashboard from "../projectmanager/Project_manager_dashboard";
import Team_coordinator_dashboard from "../TeamCoordinator/Team_coordinator_dashboard.js";
import Internal_dashboard from "../inter/Internal_dashboard.js";
import Freelancer_dashboard from "../inter/Freelancer_dashboard.js";
import Payment_edit_form from "../form/Payment_edit_form.js";
import Enterprocess_update_form from "../form/Enterprocess_update_form.js";
import Project_management_view from "../components/Project_management_view";
import Peoples_view_details from "../components/people_view_details.js";
import Payment_view from "../form/Payment_view.js";
import ProjectViewList from "../components/ProjectView.js";
import ProjectEmpaViewListv from "../components/ProjectEmpView.js";

import ProjectViewEmployeeList from "../components/empProjectView.js";
import Accounts_dashboard from "../components/Accounts_dashboard";
import AccountsProjects from "../components/Account_projects_list.js";
import Accounts_view from "../components/Accounts_list.js";
import Csv_file from "../components/Csv_file.js";
import ProjectWriterEmployeeList from "../components/employeeProjectView.js";
import Reset_password from "../pages/Reset.js";
import SiteMap from "../pages/Sitemap.js";
import Project_view from "../components/projectlist.js";
import ProjectList from "../components/projectlistTable.js";
import PaymentstatusList from "../components/paymentstatuslist.js";
import Delete_process from "../components/Delete_process.js";

import Project_activity from "../components/projectActivity.js";
import Log from "../components/projectLog.js";
import ProtectedRoute from "../components/ProtectedRoute.js";
import PageNotFound from "../pages/PageNotFound.js";
import Login from "../pages/Loging.js";
import { Navigate } from "react-router-dom";
import Sme_dashboard from "../TeamCoordinator/Sme_dashboard.js";
import Publication_dashboard from "../publication/Publication_dashboard.js";
import Authour_form from "../publication/Authour_form.js";
import Public_view from "../publication/Public_view.js";
import Process_reports from "../reports/Process_reports.js";
import Operational_reports from "../reports/Operational_reports.js";
import Client_analysis from "../reports/Client_analysis.js";
import Employee_performance from "../reports/Employee_performance.js";
import Client_record from "../reports/Client_record.js";
import Payment_reports from "../reports/Payment_reports.js";
import Sme_list from "../TeamCoordinator/Sme_list.js";
import Accounts_main_dashboard from "../Accounts/Accounts_main_dashboard.js";
import Accounts_task_view from "../Accounts/Accounts_task_view.js";
import Account_invoice from "../Accounts/Account_invoice.js";
import Coverletter from "../publication/Coverletter.js";
import Public_list_view from "../publication/Public_list_view.js";
import Sme_list_view from "../TeamCoordinator/Sme_list_view.js";
import Inhouse_project_list from "../components/Inhouse_projectview.js";
import Invoice_list from "../Accounts/Invoice_list.js";
import Freelancer_projectlist from "../inter/Freelancer_projectlist.js";
import Team_coordinator_list from "../TeamCoordinator/Team_coordinator_list.js";
import Publication_list from "../publication/Publication_list.js";

function Router() {
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    // Check local storage during initial render
    const userDetails = localStorage.getItem("medicsuser");
    return userDetails ? true : false;
  });

  useEffect(() => {
    const handleStorageChange = () => {
      const userDetails = localStorage.getItem("medicsuser");
      setIsLoggedIn(userDetails ? true : false);
    };

    window.addEventListener("storage", handleStorageChange);

    return () => {
      window.removeEventListener("storage", handleStorageChange);
    };
  }, []);

  console.log("logged", isLoggedIn);

  return (
    <div>
      {/* <Breadcrumbs></Breadcrumbs> */}

      <Routes>
        <Route path=" " element={<PageNotFound />} />
        <Route path="/site-map" element={<SiteMap />} />
        <Route path="/csvbtn" element={<Csv_file />} />
        {/* <Route path="/" element={<Loging />} /> */}
        <Route path="/register" element={<Register />} />
        <Route path="/reset-password" element={<Reset_password />} />

        <Route
          path="/"
          element={
            isLoggedIn ? (
              <Navigate to="/dashboard" replace />
            ) : (
              <Login setIsLoggedIn={setIsLoggedIn} />
            )
          }
        />

        <Route
          path="/auto-login"
          element={
         
              <Login setIsLoggedIn={setIsLoggedIn} />
            
          }
        />

        <Route
          path="/project-activity"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Project_activity />
            </ProtectedRoute>
          }
        />
        <Route
          path="/log"
          element={
            // <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Log />
            // </ProtectedRoute>
          }
        />

        <Route
          path="/dashboard"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Dashboard />{" "}
            </ProtectedRoute>
          }
        />
        <Route
          path="project-Management"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Project_management />
            </ProtectedRoute>
          }
        ></Route>
        <Route
          path="entry-process"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Process1 />
            </ProtectedRoute>
          }
        ></Route>
        <Route
          path="paymentStatus/payment-view"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Payment_view />
            </ProtectedRoute>
          }
        />
        <Route
          path="/delete-process"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Delete_process />
            </ProtectedRoute>
          }
        />
        <Route
          path="processstatus"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <ProcessStatus />
            </ProtectedRoute>
          }
        />
        <Route
          path="paymentstatus"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Paymentstatus />
            </ProtectedRoute>
          }
        />
        <Route
          path="pending"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Pending />
            </ProtectedRoute>
          }
        />
        <Route
          path="settings"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Settings />
            </ProtectedRoute>
          }
        />
        <Route
          path="people-details"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Peoples />
            </ProtectedRoute>
          }
        />
        <Route
          path="admin-profile"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Admin_profile />
            </ProtectedRoute>
          }
        />

        {/* modula */}
        <Route
          path="/project-view"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Project_view />
            </ProtectedRoute>
          }
        />

        <Route
          path="/team-coordinator-list"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Team_coordinator_list />
            </ProtectedRoute>
          }
        />
        <Route
          path="/payment-status-list"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <PaymentstatusList />
            </ProtectedRoute>
          }
        />
        <Route
          path="/modula-institution"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Modula />
            </ProtectedRoute>
          }
        />
        <Route
          path="/modula-department"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Modula_department />
            </ProtectedRoute>
          }
        />
        <Route
          path="/modula-profession"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Modula_profession />
            </ProtectedRoute>
          }
        />
        <Route
          path="entry-process/process-view-details"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Institute_form />
            </ProtectedRoute>
          }
        />

        <Route
          path="entry-process/delete-process"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Delete_process />
            </ProtectedRoute>
          }
        />
        {/* form */}
        <Route
          path="entry-process/enter_process_form"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Enterprocess_form />
            </ProtectedRoute>
          }
        />
        <Route
          path="entry-process/entryprocess-update-form"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Enterprocess_update_form />
            </ProtectedRoute>
          }
        />
        <Route
          path="processstatus/process-status-form"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Process_statistic />
            </ProtectedRoute>
          }
        />

        <Route
          path="entry-process/payment-form"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Payment_form />
            </ProtectedRoute>
          }
        />
        <Route
          path="entry-process/payment-edit-form"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Payment_edit_form />
            </ProtectedRoute>
          }
        />
        <Route
          path="entry-process/pending-form"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Pending_form />
            </ProtectedRoute>
          }
        />
        <Route
          path="/sme-dashboard"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Sme_dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/sme-list"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Sme_list />
            </ProtectedRoute>
          }
        />
        <Route
          path="/sme-list-view"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Sme_list_view />
            </ProtectedRoute>
          }
        />

        <Route
          path="/publication-dashboard"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Publication_dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/publication-list"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Publication_list />
            </ProtectedRoute>
          }
        />
        {/* public forms */}
        <Route
          path="/public-list-view"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Public_list_view />
            </ProtectedRoute>
          }
        />

        <Route
          path="public-list-view/public-view-details"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Institute_form />
            </ProtectedRoute>
          }
        />

        <Route
          path="/public-view/:id"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Public_view />
            </ProtectedRoute>
          }
        />
        <Route
          path="/cover-letter"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Coverletter />
            </ProtectedRoute>
          }
        />

        {/* reports */}

        <Route
          path="/process-report"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Process_reports />
            </ProtectedRoute>
          }
        />
        <Route
          path="/operational-report"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Operational_reports />
            </ProtectedRoute>
          }
        />
        <Route
          path="/client-analysis"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Client_analysis />
            </ProtectedRoute>
          }
        />
        <Route
          path="/employee-performance"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Employee_performance />
            </ProtectedRoute>
          }
        />
        <Route
          path="/client-record"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Client_record />
            </ProtectedRoute>
          }
        />
        <Route
          path="/payment-reports"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Payment_reports />
            </ProtectedRoute>
          }
        />

        {/* accounts */}
        <Route
          path="/accounts-main-dashboard"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Accounts_main_dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/invoice-list"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Invoice_list />
            </ProtectedRoute>
          }
        />
        <Route
          path="/accounts-view"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Accounts_view />
            </ProtectedRoute>
          }
        />
        <Route
          path="accounts-view/accounts-view-details"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Institute_form />
            </ProtectedRoute>
          }
        />
        <Route
          path="/accounts-task-view/:id"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Accounts_task_view />
            </ProtectedRoute>
          }
        />
        <Route
          path="/accounts-invoice"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Account_invoice />
            </ProtectedRoute>
          }
        />

        {/* dashboard */}
        <Route
          path="/project-manager-dashboard"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Project_manager_dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/project-view/:id"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Project_management_view />
            </ProtectedRoute>
          }
        />
        <Route
          path="/team-coordinator-dashboard"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Team_coordinator_dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/internal-dashboard"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Internal_dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/freelancer-dashboard"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Freelancer_dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/accounts-dashboard"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Accounts_dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/accounts-projects"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <AccountsProjects />
            </ProtectedRoute>
          }
        />
        <Route
          path="/projectlist"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <ProjectList />
            </ProtectedRoute>
          }
        />
        <Route
          path="/project-list"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <ProjectViewList />
            </ProtectedRoute>
          }
        ></Route>
        <Route
          path="/employee-project-lists"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <ProjectEmpaViewListv />
            </ProtectedRoute>
          }
        ></Route>
        <Route
          path="/employe-project-list"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <ProjectViewEmployeeList />
            </ProtectedRoute>
          }
        ></Route>
        <Route
          path="/inhouse-project-list"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Inhouse_project_list />
            </ProtectedRoute>
          }
        ></Route>
        <Route
          path="/freelancer-project-list"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Freelancer_projectlist />
            </ProtectedRoute>
          }
        ></Route>
        <Route
          path="/employee-project-list"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <ProjectWriterEmployeeList />
            </ProtectedRoute>
          }
        ></Route>

        <Route
          path="people-details/people_view_details"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <Peoples_view_details />
            </ProtectedRoute>
          }
        />
      </Routes>
    </div>
  );
}

export default Router;
