import React from "react";

import { BsBarChartLine } from "react-icons/bs";
import Sider from "../components/Sider";

import Header from "../components/Header";
import { AiOutlineAlert } from "react-icons/ai";
import { MdDoNotDisturb } from "react-icons/md";
import { FaFileInvoiceDollar } from "react-icons/fa6";
import { GiPiggyBank } from "react-icons/gi";
import "../assests/css/project_management.css";
import ReactDOM from "react-dom";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { useState, useEffect } from "react";
import { VscGitStashPop } from "react-icons/vsc";

import { IoMdAdd } from "react-icons/io";
import Footer from "../components/Footer";
import Tooltip from "@mui/material/Tooltip";
import { useNavigate } from "react-router-dom";
import Breadcrumbs from "../routes/Breadcrumbs";
import { VscEye } from "react-icons/vsc";
import Loader from "../components/Loader.js";
// icon
import { TbHourglassLow } from "react-icons/tb";
import { SiFreelancer } from "react-icons/si";

import axios from "axios";
import { Link } from "react-router-dom";
// import { combineEventHandlers } from "recharts/types/util/ChartUtils.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";

DataTable.use(DT);

function Project_manager_dashboard() {
  const [data, setData] = useState([]);
  const [dataFoot, setFootData] = useState([]);
  // const [dataPeople, setDataPeople] = useState([]);
  const [dataPeopleInhouse, setDataPeopleInHouse] = useState([]);
  const [dataPeopleExtranel, setDataPeopleExternal] = useState([]);
  const [dataPeopleWriterExtranel, setdataPeopleWriterExtranel] = useState([]);

  useEffect(() => {
    // fetchProjectManagerData();
    const interval = setInterval(() => {
      fetchProjectManagerData();
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleViewClick = (id) => {
    navigate("/entry-process/process-view-details", {
      state: { rowId: id },
    });
  };

  const columns = [
    { title: "MONTH".toUpperCase(), data: "month" },
    { title: "Manuscript".toUpperCase(), data: "manuscript" },
    { title: "Statistics".toUpperCase(), data: "statistics" },
    { title: "Thesis".toUpperCase(), data: "thesis" },
    { title: "Others".toUpperCase(), data: "others" },
    { title: "NA", data: "not_assigned" },
    { title: "WD", data: "withdrawn" },
    { title: "Total".toUpperCase(), data: "total" },
    {
      title: "Manuscript (%)".toUpperCase(),
      data: "manuscript_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "Statistics (%)".toUpperCase(),
      data: "statistics_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "Thesis (%)".toUpperCase(),
      data: "thesis_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "Others (%)".toUpperCase(),
      data: "others_percentage",
      render: (data) => `${data}%`,
    },
    {
      title: "TARGET (%)",
      data: "target_percentage",
      render: (data) => {
        if (data !== null && data !== undefined) {
          return `${Number(data).toLocaleString()}%`;
        }
        return "N/A"; // Handle null or undefined values
      },
    },
  ];

  // projject list table

  window.handleidClick = function (value1, value2) {
    console.log("Clicked value1:", value1);
    console.log("Clicked value2:", value2);

    // Set the first value in localStorage
    localStorage.setItem("empname", value1);

    // Set the second value in localStorage
    localStorage.setItem("projectallid", value2);

    // Open the new page in a new tab
    window.open("/projectlist", "_blank");
  };

  const freelancerId = localStorage.getItem("empname");
  const projectIds = JSON.parse(localStorage.getItem("projectallid"));

  console.log("Freelancer ID:", freelancerId);
  console.log("Project IDs:", projectIds);

  const handleidClick = function (freelancerId, projectIdsJson) {
    const projectIds = JSON.parse(projectIdsJson);

    console.log("Clicked freelancerId:", freelancerId);
    console.log("Clicked projectIds:", projectIds);

    // Store values in localStorage
    localStorage.setItem("empname", freelancerId);
    localStorage.setItem("projectallid", JSON.stringify(projectIds));

    // Navigate to another page
    window.open("/projectlist", "_blank");
  };

  const handleNavigate = (type, createdby, month) => {
    // navigate(`/employee-project-list`, { state: { type, createdby } });
    navigate(`/employe-project-list`, { state: { type, createdby, month } });
  };

  const handleProNavigate = (params) => {
    navigate(`/project-view`, { state: params });
  };

  const handlePaymentStatusNavigate = (params) => {
    navigate(`/payment-status-list`, { state: params });
  };

  // const columnsPeople = [
  //   {
  //     title: "S.No".toUpperCase(),
  //     data: null,
  //     render: (data, type, row, meta) => meta.row + 1, // Incremental index
  //   },
  //   {
  //     title: "Name".toUpperCase(),
  //     data: "employee_name",
  //     render: (data) => data.charAt(0).toUpperCase() + data.slice(1), // Capitalize name
  //   },
  //   {
  //     title: "Position".toUpperCase(),
  //     data: "created_by_user.name",
  //     render: (data) => data.charAt(0).toUpperCase() + data.slice(1), // Capitalize position
  //   },
  //   {
  //     title: "Employee Type".toUpperCase(),
  //     data: "employee_type",
  //     render: (data) => (data ? CapitalizeCase(data) : "-"), // Capitalize or show "N/A"
  //   },
  //   {
  //     title: "Total Projects".toUpperCase(),
  //     data: null,
  //     render: (data, type, row) => {
  //       if (row.position === "7") return row.writer_count;
  //       if (row.position === "8") return row.reviewer_count;
  //       if (row.position === "10") return row.journal_count;
  //       if (row.position === "11") return row.statistican_count;
  //       return 0; // Default value
  //     },
  //   },
  //   {
  //     title: "Pending".toUpperCase(),
  //     data: null,
  //     render: (data, type, row) => {
  //       if (row.position === "7") return row.writerPendingCount;
  //       if (row.position === "8") return row.reviewerPendingCount;
  //       if (row.position === "10") return row.journalPendingCount;
  //       if (row.position === "11") return row.statisticanPendingCount;
  //       return 0; // Default value
  //     },
  //   },
  //   {title:"Ongoing",
  //     data:"ongoing"
  //   },
  //   {title:"Need Support",
  //     data:"ongoing"
  //   },
  //   {title:"Plag Correction",
  //     data:"ongoing"
  //   },
  //   {
  //     title: "<4 Days".toUpperCase(),
  //     data: null,
  //     defaultContent: "-", // Placeholder
  //     width: "100px"
  //   },
  //   {
  //     title: "5-8 Days".toUpperCase(),
  //     data: null,
  //     defaultContent: "-", // Placeholder
  //      width: "100px"
  //   },
  //   {
  //     title: ">9 Days".toUpperCase(),
  //     data: null,
  //     defaultContent: "-", // Placeholder
  //      width: "100px"
  //   },
  //   // {
  //   //   title: "Actions".toUpperCase(),
  //   //   data: null,
  //   //   render: (data, type, row) => `
  //   //     <button class="btn btn-primary btn-sm action-btn" onclick="viewDetails('${row.id}')">
  //   //       View Details
  //   //     </button>
  //   //   `, // Renders a button with an onclick handler
  //   // },
  // ];

  //dashboard list

  const handleNavigateinhouse = (type, createdby, month) => {
    // navigate(`/employee-project-list`, { state: { type, createdby } });
    navigate(`/inhouse-project-list`, { state: { type, createdby, month } });
  };

  const columnsPeople = [
    {
      title: "Team".toUpperCase(),
      data: "employee_name",
      render: (data) => data.charAt(0).toUpperCase() + data.slice(1),
    },
    {
      title: "Type of work".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex ">
               <div class="table-row-width"><div>Writing</div></div>
   
    </div>
             
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
            <div class="d-flex ">
               <div class="table-row-width"><div>Reviewing</div></div>
   
    </div>
             
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex ">
               <div class="table-row-width"><div>statistician</div></div>
 
    </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex ">
               <div class="table-row-width"><div>Journal</div></div>
 
    </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Total Projects".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;
        const freelancerId = row.id;
        const projectIdsSource =
          row.reviewer_project_ids ||
          row.statistican_project_ids ||
          row.writer_project_ids ||
          [];
        const projectIds = Array.isArray(projectIdsSource)
          ? projectIdsSource.map((item) => item)
          : [];
        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center ">
               
    <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${writerCount}</div>
    </div>
             
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
            <div class="d-flex justify-content-center">
            
    <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${reviewerCount}</div>
    </div>
             
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${statisticianCount}</div>
    </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2">${journalCount}</div>
    </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Pending".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerPendingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerPendingCount || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journalPendingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanPendingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2">${journalCount}</div>
    </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "On going".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerOngoingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerOngoingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanOngoingCount || 0
          : 0;
        let journalCount = positions.includes("8")
          ? row.journalOngoingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2">${journalCount}</div>
    </div>
           `;
        }
        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "need support".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerNeedCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerNeedCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanNeedCount || 0
          : 0;
        let journalCount = "-";

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "plag & correction".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerCorrectionCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerCorrectionCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanCorrectionCount || 0
          : 0;
        let journalCount = "-";
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "<4 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_4_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_4_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_4_days || 0
          : 0;
        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="box-pad">
             <div class="d-flex justify-content-center   ${
               writerCount >= 1 ? "highlight-green  text-white" : ""
             }">
               ${writerCount}
             </div></div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
            <div class="box-pad">
              <div class="d-flex justify-content-center ${
                reviewerCount >= 1 ? "highlight-green text-white" : ""
              }">
               ${reviewerCount}
             </div></div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
            <div class="box-pad">
             <div class="d-flex justify-content-center ${
               statisticianCount >= 1 ? "highlight-green text-white" : ""
             }">
               ${statisticianCount}
             </div></div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "5-8 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_5_to_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_5_to_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_5_to_8_days || 0
          : 0;

        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
            <div class="box-pad">
             <div class="d-flex justify-content-center ${
               writerCount >= 1 ? "highlight-yellow " : ""
             }">
               ${writerCount}
             </div></div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
           <div class="box-pad">
              <div class="d-flex justify-content-center ${
                reviewerCount >= 1 ? "highlight-yellow" : ""
              }">
               ${reviewerCount}
             </div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center ${
               statisticianCount >= 1 ? "highlight-yellow" : ""
             }">
               ${statisticianCount}
             </div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: ">9 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_more_than_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_more_than_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_more_than_8_days || 0
          : 0;

        let journalCount = "-";

        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center ${
               writerCount >= 1 ? "highlight-red text-white" : ""
             }">
               ${writerCount}
             </div></div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider-last"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
         <div class="box-pad">
              <div class="d-flex justify-content-center ${
                reviewerCount >= 1 ? "highlight-red text-white" : ""
              }">
               ${reviewerCount}
             </div></div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center ${
               statisticianCount >= 1 ? "highlight-red text-white" : ""
             }">
               ${statisticianCount}
             </div></div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "View Details".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                {/* <div className="d-flex justify-content-around  mt-1  ">
                           <button className="view-details" onClick={() => handleNavigate(row.position, row.id)}>
                             View details
                           </button>
                       </div> */}
                <div className="" title="View">
                  <span>
                    <VscEye
                      onClick={() =>
                        handleNavigateinhouse(
                          row.position,
                          row.id,
                          selectedMonth
                        )
                      }
                      className="open-icon"
                    />
                  </span>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  const columnsPeople1 = [
    {
      title: "Team".toUpperCase(),
      data: "employee_name",
      render: (data) => data.charAt(0).toUpperCase() + data.slice(1),
    },
    {
      title: "Type of work".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex ">
               <div class="table-row-width"><div>Writing</div></div>
   
    </div>
             
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
            <div class="d-flex ">
               <div class="table-row-width"><div>Reviewing</div></div>
   
    </div>
             
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex ">
               <div class="table-row-width"><div>statistician</div></div>
 
    </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex ">
               <div class="table-row-width"><div>Journal</div></div>
 
    </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Total Projects".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        const freelancerId = row.id;
        const projectIdsSource =
          row.reviewer_project_ids ||
          row.statistican_project_ids ||
          row.writer_project_ids ||
          [];
        const projectIds = Array.isArray(projectIdsSource)
          ? projectIdsSource.map((item) => item)
          : [];

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center ">
               
    <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${writerCount}</div>
    </div>
             
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
            <div class="d-flex justify-content-center">
            
    <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${reviewerCount}</div>
    </div>
             
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
   <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${statisticianCount}</div>
    </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2">${journalCount}</div>
    </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Pending".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerPendingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerPendingCount || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journalPendingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanPendingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2">${journalCount}</div>
    </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "On going".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerOngoingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerOngoingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanOngoingCount || 0
          : 0;
        let journalCount = positions.includes("8")
          ? row.journalOngoingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2">${journalCount}</div>
    </div>
           `;
        }
        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "need support".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerNeedCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerNeedCount || 0
          : 0;
        let statisticianCount = "-";
        let journalCount = "-";

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "plag & correction".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerCorrectionCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerCorrectionCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanCorrectionCount || 0
          : 0;
        let journalCount = "-";
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "<4 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_4_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_4_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_4_days || 0
          : 0;
        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center   ${
               writerCount >= 1 ? "highlight-green  text-white" : ""
             }">
               ${writerCount}
             </div></div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
           <div class="box-pad">
              <div class="d-flex justify-content-center ${
                reviewerCount >= 1 ? "highlight-green text-white" : ""
              }">
               ${reviewerCount}
             </div></div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center ${
               statisticianCount >= 1 ? "highlight-green text-white" : ""
             }">
               ${statisticianCount}
             </div></div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
           <div class="box-pad">
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div></div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "5-8 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_5_to_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_5_to_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_5_to_8_days || 0
          : 0;

        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center ${
               writerCount >= 1 ? "highlight-yellow " : ""
             }">
               ${writerCount}
             </div></div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
           <div class="box-pad">
              <div class="d-flex justify-content-center ${
                reviewerCount >= 1 ? "highlight-yellow" : ""
              }">
               ${reviewerCount}
             </div></div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center ${
               statisticianCount >= 1 ? "highlight-yellow" : ""
             }">
               ${statisticianCount}
             </div></div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
           <div class="box-pad">
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div></div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: ">9 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_more_than_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_more_than_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_more_than_8_days || 0
          : 0;

        let journalCount = "-";

        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center ${
               writerCount >= 1 ? "highlight-red text-white" : ""
             }">
               ${writerCount}
             </div></div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider-last"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
           <div class="box-pad">
              <div class="d-flex justify-content-center ${
                reviewerCount >= 1 ? "highlight-red text-white" : ""
              }">
               ${reviewerCount}
             </div></div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center ${
               statisticianCount >= 1 ? "highlight-red text-white" : ""
             }">
               ${statisticianCount}
             </div></div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "View Details".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                {/* <div className="d-flex justify-content-around  mt-1  ">
                           <button className="view-details" onClick={() => handleNavigate(row.position, row.id)}>
                             View details
                           </button>
                       </div> */}
                <div className="" title="View">
                  <span>
                    <VscEye
                      onClick={() =>
                        handleNavigate(row.position, row.id, selectedMonth)
                      }
                      className="open-icon"
                    />
                  </span>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  const columnsThesisPeople1 = [
    {
      title: "Team".toUpperCase(),
      data: "employee_name",
      render: (data) => data.charAt(0).toUpperCase() + data.slice(1),
    },
    {
      title: "Type of work".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex ">
               <div class="table-row-width"><div>Writing</div></div>
   
    </div>
             
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
            <div class="d-flex ">
               <div class="table-row-width"><div>Reviewing</div></div>
   
    </div>
             
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex ">
               <div class="table-row-width"><div>statistician</div></div>
 
    </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex ">
               <div class="table-row-width"><div>Journal</div></div>
 
    </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Total Projects".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewer_count || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journal_count || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statistican_count || 0
          : 0;

        let tableContent = `<table class="nested-table">`;
        const freelancerId = row.id;
        const projectIdsSource =
          row.reviewer_project_ids ||
          row.statistican_project_ids ||
          row.writer_project_ids ||
          [];
        const projectIds = Array.isArray(projectIdsSource)
          ? projectIdsSource.map((item) => item)
          : [];

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center ">
               
    <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${writerCount}</div>
    </div>
             
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }
        if (positions.includes("8")) {
          tableContent += `
            <div class="d-flex justify-content-center">
            
    <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${reviewerCount}</div>
    </div>
             
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2 my-clickable-span" onclick='handleidClick (${freelancerId}, ${JSON.stringify(
            JSON.stringify(projectIds)
          )})'>${statisticianCount}</div>
    </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2">${journalCount}</div>
    </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "Pending".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerPendingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerPendingCount || 0
          : 0;
        let journalCount = positions.includes("10")
          ? row.journalPendingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanPendingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2">${journalCount}</div>
    </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "On going".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerOngoingCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerOngoingCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanOngoingCount || 0
          : 0;
        let journalCount = positions.includes("8")
          ? row.journalOngoingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
    <div class="mx-2">${journalCount}</div>
    </div>
           `;
        }
        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "need support".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerNeedCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerNeedCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanNeedCount || 0
          : 0;
        let journalCount = positions.includes("8")
          ? row.journalOngoingCount || 0
          : 0;

        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "plag & correction".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        let positions = row.position.split(",").map((pos) => pos.trim());

        let writerCount = positions.includes("7")
          ? row.writerCorrectionCount || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.reviewerCorrectionCount || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.statisticanCorrectionCount || 0
          : 0;
        let journalCount = "-";
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${writerCount}</div>
             </div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
              <div class="d-flex justify-content-center">
               <div>${reviewerCount}</div>
             </div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
             <div class="d-flex justify-content-center">
               <div>${statisticianCount}</div>
             </div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "<4 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_4_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_4_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_4_days || 0
          : 0;
        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center   ${
               writerCount >= 1 ? "highlight-green  text-white" : ""
             }">
               ${writerCount}
             </div></div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
           <div class="box-pad">
              <div class="d-flex justify-content-center ${
                reviewerCount >= 1 ? "highlight-green text-white" : ""
              }">
               ${reviewerCount}
             </div></div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center ${
               statisticianCount >= 1 ? "highlight-green text-white" : ""
             }">
               ${statisticianCount}
             </div></div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
           <div class="box-pad">
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div></div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "5-8 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_5_to_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_5_to_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_5_to_8_days || 0
          : 0;

        let journalCount = "-";
        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center ${
               writerCount >= 1 ? "highlight-yellow " : ""
             }">
               ${writerCount}
             </div></div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
           <div class="box-pad">
              <div class="d-flex justify-content-center ${
                reviewerCount >= 1 ? "highlight-yellow" : ""
              }">
               ${reviewerCount}
             </div></div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center ${
               statisticianCount >= 1 ? "highlight-yellow" : ""
             }">
               ${statisticianCount}
             </div></div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
           <div class="box-pad">
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div></div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: ">9 Days".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

        let positions = row.position.split(",").map((pos) => pos.trim());

        // Extract counts safely
        let writerCount = positions.includes("7")
          ? row.positionWiseCompletion["7"]?.completed_in_more_than_8_days || 0
          : 0;
        let reviewerCount = positions.includes("8")
          ? row.positionWiseCompletion["8"]?.completed_in_more_than_8_days || 0
          : 0;
        let statisticianCount = positions.includes("11")
          ? row.positionWiseCompletion["11"]?.completed_in_more_than_8_days || 0
          : 0;

        let journalCount = "-";

        // Build nested table
        let tableContent = `<table class="nested-table">`;

        if (positions.includes("7")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center ${
               writerCount >= 1 ? "highlight-red text-white" : ""
             }">
               ${writerCount}
             </div></div>
           `;
        }
        if (positions.includes("7") && positions.includes("8")) {
          tableContent += `<div class="row-divider-last"></div>`;
        }

        if (positions.includes("8")) {
          tableContent += `
           <div class="box-pad">
              <div class="d-flex justify-content-center ${
                reviewerCount >= 1 ? "highlight-red text-white" : ""
              }">
               ${reviewerCount}
             </div></div>
           `;
        }

        if (positions.includes("11")) {
          tableContent += `
           <div class="box-pad">
             <div class="d-flex justify-content-center ${
               statisticianCount >= 1 ? "highlight-red text-white" : ""
             }">
               ${statisticianCount}
             </div></div>
           `;
        }

        if (positions.includes("10")) {
          tableContent += `
           <div class="box-pad">
              <div class="d-flex justify-content-center">
            
       <div class="mx-2">${journalCount}</div>
       </div></div>
           `;
        }

        tableContent += `</table>`;

        return tableContent;
      },
    },
    {
      title: "View Details".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                {/* <div className="d-flex justify-content-around  mt-1  ">
                           <button className="view-details" onClick={() => handleNavigate(row.position, row.id)}>
                             View details
                           </button>
                       </div> */}
                <div className="" title="View">
                  <span>
                    <VscEye
                      onClick={() =>
                        handleNavigatethesis(
                          row.position,
                          row.id,
                          row.employee_type,
                          selectedMonth
                        )
                      }
                      className="open-icon"
                    />
                  </span>
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  const [works, setTypeOfWork] = useState([]);
  const [totalProjects, setProjectCount] = useState(0);
  const [processStatus, setProcessStatus] = useState(0);
  const [journalStatus, setJournalStatus] = useState(0);
  const [completed, setCompleted] = useState(0);
  const [setdata, setFetchData] = useState(0);
  const [tododata, setToDoData] = useState([]);
  const [todolistD, setToDoListData] = useState([]);

  console.log("todo:", setdata);
  const [inworkdata, setInWorkData] = useState([]);
  const [reviewdata, setReviewData] = useState([]);
  const [completeddata, setCompletedData] = useState([]);
  const [correctiondata, setCorrectionData] = useState([]);
  const [acceptRejectList, setProjectAcceptRejectStatus] = useState([]);
  const [projectStatusCount, setProjectStatusCount] = useState(0);
  const [dasCount, setCountVal] = useState([]);
  const [paymentStatus, setPaymentStatus] = useState(0);

  const fetchProjectManagerData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/entry_process/pmDashboard`,
        {
          params: {
            position: "project_manager",
            month: selectedMonth,
          },
        }
      );

      const responsedata = response.data;
      console.log("responsedata :", response);
      setCountVal(responsedata);
      setFetchData(responsedata);
      setTypeOfWork(responsedata.typeofwork);
      setProjectCount(responsedata.total_count);
      setProcessStatus(responsedata.process_staus);
      setJournalStatus(responsedata.journal_status);
      setCompleted(responsedata.completedCount);
      setData(responsedata.monthWiseTable.monthlyData);
      setFootData(responsedata.monthWiseTable.footerTotals);
      setToDoListData(responsedata.inToDoList);
      setToDoData(responsedata.inProgress);
      setInWorkData(responsedata.urgentDataList);
      setReviewData(responsedata.projectdelayDataList);
      // setCompletedData(responsedata.completed);
      setPaymentStatus(responsedata.paymentStatusCounts);
      setDataPeopleInHouse(responsedata.inhouseExternal.peopleInhouse);
      setDataPeopleExternal(responsedata.inhouseExternal.peopleExternal);
      setdataPeopleWriterExtranel(
        responsedata.inhouseExternal.peopleWriterExternal
      );

      setCorrectionData(responsedata.freelancerProjecctList);
      setProjectAcceptRejectStatus(
        (responsedata.projectStatusList || []).filter(
          (project) => project.project_status !== null
        )
      );
      const filteredProjects = (responsedata.projectStatusList || []).filter(
        (project) => project.project_status !== null
      );
      setProjectStatusCount(filteredProjects.length); // Set the count
    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  const date = new Date();
  const [selectedMonth, setSelectedMonth] = useState(
    `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`
  );

  const handleNavigatethesis = (type, createdby, month) => {
    navigate(`/employee-project-list`, { state: { type, createdby, month } });
    // navigate(`/employe-project-list`, { state: { type, createdby } });
  };

  useEffect(() => {
    // fetchProjectManagerData();

    fetchProjectManagerData();
  }, [selectedMonth]);

  const handleMonthChange = (e) => {
    setSelectedMonth(e.target.value);
    // You can add additional logic here if needed
  };

  // const columnsThesisPeople1 = [
  //   {
  //     title: "Team".toUpperCase(),
  //     data: "employee_name",
  //     render: (data) => data.charAt(0).toUpperCase() + data.slice(1),
  //   },
  //   {
  //     title: "Type of work".toUpperCase(),
  //     data: null,
  //     render: (data, type, row) => {
  //       let positions = row.position.split(",").map((pos) => pos.trim());

  //       let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
  //       let reviewerCount = positions.includes("8")
  //         ? row.reviewer_count || 0
  //         : 0;
  //       let journalCount = positions.includes("10")
  //         ? row.journal_count || 0
  //         : 0;
  //       let statisticianCount = positions.includes("11")
  //         ? row.statistican_count || 0
  //         : 0;

  //       let tableContent = `<table class="nested-table">`;

  //       if (positions.includes("7")) {
  //         tableContent += `
  //             <div class="d-flex ">
  //               <div class="table-row-width"><div>Writing</div></div>

  //    </div>

  //           `;
  //       }
  //       if (positions.includes("7") && positions.includes("8")) {
  //         tableContent += `<div class="row-divider"></div>`;
  //       }
  //       if (positions.includes("8")) {
  //         tableContent += `
  //            <div class="d-flex ">
  //               <div class="table-row-width"><div>Reviewing</div></div>

  //    </div>

  //           `;
  //       }

  //       if (positions.includes("11")) {
  //         tableContent += `
  //              <div class="d-flex ">
  //               <div class="table-row-width"><div>Statistican</div></div>

  //    </div>
  //           `;
  //       }

  //       if (positions.includes("10")) {
  //         tableContent += `
  //              <div class="d-flex ">
  //               <div class="table-row-width"><div>Journal</div></div>

  //    </div>
  //           `;
  //       }

  //       tableContent += `</table>`;

  //       return tableContent;
  //     },
  //   },
  //   {
  //     title: "Total Projects".toUpperCase(),
  //     data: null,
  //     render: (data, type, row) => {
  //       let positions = row.position.split(",").map((pos) => pos.trim());

  //       let writerCount = positions.includes("7") ? row.writer_count || 0 : 0;
  //       let reviewerCount = positions.includes("8")
  //         ? row.reviewer_count || 0
  //         : 0;
  //       let journalCount = positions.includes("10")
  //         ? row.journal_count || 0
  //         : 0;
  //       let statisticianCount = positions.includes("11")
  //         ? row.statistican_count || 0
  //         : 0;

  //       let tableContent = `<table class="nested-table">`;

  //       if (positions.includes("7")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center ">

  //    <div class="mx-2">${writerCount}</div>
  //    </div>

  //           `;
  //       }
  //       if (positions.includes("7") && positions.includes("8")) {
  //         tableContent += `<div class="row-divider"></div>`;
  //       }
  //       if (positions.includes("8")) {
  //         tableContent += `
  //            <div class="d-flex justify-content-center">

  //    <div class="mx-2">${reviewerCount}</div>
  //    </div>

  //           `;
  //       }

  //       if (positions.includes("11")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center">

  //    <div class="mx-2">${statisticianCount}</div>
  //    </div>
  //           `;
  //       }

  //       if (positions.includes("10")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center">

  //    <div class="mx-2">${journalCount}</div>
  //    </div>
  //           `;
  //       }

  //       tableContent += `</table>`;

  //       return tableContent;
  //     },
  //   },
  //   {
  //     title: "Pending".toUpperCase(),
  //     data: null,
  //     render: (data, type, row) => {
  //       let positions = row.position.split(",").map((pos) => pos.trim());

  //       let writerCount = positions.includes("7")
  //         ? row.writerPendingCount || 0
  //         : 0;
  //       let reviewerCount = positions.includes("8")
  //         ? row.reviewerPendingCount || 0
  //         : 0;
  //       let journalCount = positions.includes("10")
  //         ? row.journalPendingCount || 0
  //         : 0;
  //       let statisticianCount = positions.includes("11")
  //         ? row.statisticanPendingCount || 0
  //         : 0;

  //       let tableContent = `<table class="nested-table">`;

  //       if (positions.includes("7")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center">
  //               <div>${writerCount}</div>
  //             </div>
  //           `;
  //       }
  //       if (positions.includes("7") && positions.includes("8")) {
  //         tableContent += `<div class="row-divider"></div>`;
  //       }

  //       if (positions.includes("8")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center">
  //               <div>${reviewerCount}</div>
  //             </div>
  //           `;
  //       }

  //       if (positions.includes("11")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center">
  //               <div>${statisticianCount}</div>
  //             </div>
  //           `;
  //       }

  //       if (positions.includes("10")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center">

  //    <div class="mx-2">${journalCount}</div>
  //    </div>
  //           `;
  //       }

  //       tableContent += `</table>`;

  //       return tableContent;
  //     },
  //   },
  //   {
  //     title: "On going".toUpperCase(),
  //     data: null,
  //     render: (data, type, row) => {
  //       let positions = row.position.split(",").map((pos) => pos.trim());

  //       let writerCount = positions.includes("7")
  //         ? row.writerOngoingCount || 0
  //         : 0;
  //       let reviewerCount = positions.includes("8")
  //         ? row.reviewerOngoingCount || 0
  //         : 0;
  //       let statisticianCount = positions.includes("11")
  //         ? row.statisticanOngoingCount || 0
  //         : 0;
  //       let journalCount = positions.includes("8")
  //         ? row.journalOngoingCount || 0
  //         : 0;

  //       let tableContent = `<table class="nested-table">`;

  //       if (positions.includes("7")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center">
  //               <div>${writerCount}</div>
  //             </div>
  //           `;
  //       }
  //       if (positions.includes("7") && positions.includes("8")) {
  //         tableContent += `<div class="row-divider"></div>`;
  //       }

  //       if (positions.includes("8")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center">
  //               <div>${reviewerCount}</div>
  //             </div>
  //           `;
  //       }

  //       if (positions.includes("11")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center">
  //               <div>${statisticianCount}</div>
  //             </div>
  //           `;
  //       }

  //       if (positions.includes("10")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center">

  //    <div class="mx-2">${journalCount}</div>
  //    </div>
  //           `;
  //       }
  //       tableContent += `</table>`;

  //       return tableContent;
  //     },
  //   },
  //   {
  //     title: "need support".toUpperCase(),
  //     data: null,
  //     render: (data, type, row) => {
  //       let positions = row.position.split(",").map((pos) => pos.trim());

  //       let writerCount = positions.includes("7")
  //         ? row.writerNeedCount || 0
  //         : 0;
  //       let reviewerCount = positions.includes("8")
  //         ? row.reviewerNeedCount || 0
  //         : 0;
  //       let statisticianCount = positions.includes("11")
  //         ? row.statisticanNeedCount || 0
  //         : 0;
  //       let journalCount = "-";

  //       let tableContent = `<table class="nested-table">`;

  //       if (positions.includes("7")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center">
  //               <div>${writerCount}</div>
  //             </div>
  //           `;
  //       }
  //       if (positions.includes("7") && positions.includes("8")) {
  //         tableContent += `<div class="row-divider"></div>`;
  //       }

  //       if (positions.includes("8")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center">
  //               <div>${reviewerCount}</div>
  //             </div>
  //           `;
  //       }

  //       if (positions.includes("11")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center">
  //               <div>${statisticianCount}</div>
  //             </div>
  //           `;
  //       }

  //       if (positions.includes("10")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center">

  //       <div class="mx-2">${journalCount}</div>
  //       </div>
  //           `;
  //       }

  //       tableContent += `</table>`;

  //       return tableContent;
  //     },
  //   },
  //   {
  //     title: "plag & correction".toUpperCase(),
  //     data: null,
  //     render: (data, type, row) => {
  //       let positions = row.position.split(",").map((pos) => pos.trim());

  //       let writerCount = positions.includes("7")
  //         ? row.writerCorrectionCount || 0
  //         : 0;
  //       let reviewerCount = positions.includes("8")
  //         ? row.reviewerCorrectionCount || 0
  //         : 0;
  //       let statisticianCount = positions.includes("11")
  //         ? row.statisticanCorrectionCount || 0
  //         : 0;
  //       let journalCount = "-";
  //       let tableContent = `<table class="nested-table">`;

  //       if (positions.includes("7")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center">
  //               <div>${writerCount}</div>
  //             </div>
  //           `;
  //       }
  //       if (positions.includes("7") && positions.includes("8")) {
  //         tableContent += `<div class="row-divider"></div>`;
  //       }

  //       if (positions.includes("8")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center">
  //               <div>${reviewerCount}</div>
  //             </div>
  //           `;
  //       }

  //       if (positions.includes("11")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center">
  //               <div>${statisticianCount}</div>
  //             </div>
  //           `;
  //       }

  //       if (positions.includes("10")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center">

  //       <div class="mx-2">${journalCount}</div>
  //       </div>
  //           `;
  //       }

  //       tableContent += `</table>`;

  //       return tableContent;
  //     },
  //   },
  //   {
  //     title: "<4 Days".toUpperCase(),
  //     data: null,
  //     render: (data, type, row) => {
  //       if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

  //       let positions = row.position.split(",").map((pos) => pos.trim());

  //       // Extract counts safely
  //       let writerCount = positions.includes("7")
  //         ? row.positionWiseCompletion["7"]?.completed_in_4_days || 0
  //         : 0;
  //       let reviewerCount = positions.includes("8")
  //         ? row.positionWiseCompletion["8"]?.completed_in_4_days || 0
  //         : 0;
  //       let statisticianCount = positions.includes("11")
  //         ? row.positionWiseCompletion["11"]?.completed_in_4_days || 0
  //         : 0;
  //       let journalCount = "-";
  //       // Build nested table
  //       let tableContent = `<table class="nested-table">`;

  //       if (positions.includes("7")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center   ${
  //               writerCount >= 1 ? "highlight-green  text-white" : ""
  //             }">
  //               ${writerCount}
  //             </div>
  //           `;
  //       }
  //       if (positions.includes("7") && positions.includes("8")) {
  //         tableContent += `<div class="row-divider"></div>`;
  //       }

  //       if (positions.includes("8")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center ${
  //                reviewerCount >= 1 ? "highlight-green text-white" : ""
  //              }">
  //               ${reviewerCount}
  //             </div>
  //           `;
  //       }

  //       if (positions.includes("11")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center ${
  //               statisticianCount >= 1 ? "highlight-green text-white" : ""
  //             }">
  //               ${statisticianCount}
  //             </div>
  //           `;
  //       }

  //       if (positions.includes("10")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center">

  //       <div class="mx-2">${journalCount}</div>
  //       </div>
  //           `;
  //       }

  //       tableContent += `</table>`;

  //       return tableContent;
  //     },
  //   },
  //   {
  //     title: "5-8 Days".toUpperCase(),
  //     data: null,
  //     render: (data, type, row) => {
  //       if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

  //       let positions = row.position.split(",").map((pos) => pos.trim());

  //       // Extract counts safely
  //       let writerCount = positions.includes("7")
  //         ? row.positionWiseCompletion["7"]?.completed_in_5_to_8_days || 0
  //         : 0;
  //       let reviewerCount = positions.includes("8")
  //         ? row.positionWiseCompletion["8"]?.completed_in_5_to_8_days || 0
  //         : 0;
  //       let statisticianCount = positions.includes("11")
  //         ? row.positionWiseCompletion["11"]?.completed_in_5_to_8_days || 0
  //         : 0;

  //       let journalCount = "-";
  //       // Build nested table
  //       let tableContent = `<table class="nested-table">`;

  //       if (positions.includes("7")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center ${
  //               writerCount >= 1 ? "highlight-yellow " : ""
  //             }">
  //               ${writerCount}
  //             </div>
  //           `;
  //       }
  //       if (positions.includes("7") && positions.includes("8")) {
  //         tableContent += `<div class="row-divider"></div>`;
  //       }

  //       if (positions.includes("8")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center ${
  //                reviewerCount >= 1 ? "highlight-yellow" : ""
  //              }">
  //               ${reviewerCount}
  //             </div>
  //           `;
  //       }

  //       if (positions.includes("11")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center ${
  //               statisticianCount >= 1 ? "highlight-yellow" : ""
  //             }">
  //               ${statisticianCount}
  //             </div>
  //           `;
  //       }

  //       if (positions.includes("10")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center">

  //       <div class="mx-2">${journalCount}</div>
  //       </div>
  //           `;
  //       }

  //       tableContent += `</table>`;

  //       return tableContent;
  //     },
  //   },
  //   {
  //     title: ">9 Days".toUpperCase(),
  //     data: null,
  //     render: (data, type, row) => {
  //       if (!row.position || !row.positionWiseCompletion) return "-"; // Ensure required properties exist

  //       let positions = row.position.split(",").map((pos) => pos.trim());

  //       // Extract counts safely
  //       let writerCount = positions.includes("7")
  //         ? row.positionWiseCompletion["7"]?.completed_in_more_than_8_days || 0
  //         : 0;
  //       let reviewerCount = positions.includes("8")
  //         ? row.positionWiseCompletion["8"]?.completed_in_more_than_8_days || 0
  //         : 0;
  //       let statisticianCount = positions.includes("11")
  //         ? row.positionWiseCompletion["11"]?.completed_in_more_than_8_days || 0
  //         : 0;

  //       let journalCount = "-";

  //       // Build nested table
  //       let tableContent = `<table class="nested-table">`;

  //       if (positions.includes("7")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center ${
  //               writerCount >= 1 ? "highlight-red text-white" : ""
  //             }">
  //               ${writerCount}
  //             </div>
  //           `;
  //       }
  //       if (positions.includes("7") && positions.includes("8")) {
  //         tableContent += `<div class="row-divider-last"></div>`;
  //       }

  //       if (positions.includes("8")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center ${
  //                reviewerCount >= 1 ? "highlight-red text-white" : ""
  //              }">
  //               ${reviewerCount}
  //             </div>
  //           `;
  //       }

  //       if (positions.includes("11")) {
  //         tableContent += `
  //             <div class="d-flex justify-content-center ${
  //               statisticianCount >= 1 ? "highlight-red text-white" : ""
  //             }">
  //               ${statisticianCount}
  //             </div>
  //           `;
  //       }

  //       if (positions.includes("10")) {
  //         tableContent += `
  //              <div class="d-flex justify-content-center">

  //       <div class="mx-2">${journalCount}</div>
  //       </div>
  //           `;
  //       }

  //       tableContent += `</table>`;

  //       return tableContent;
  //     },
  //   },
  //   {
  //     title: "View Details".toUpperCase(),
  //     data: null,
  //     render: (data, type, row) => {
  //       const id = `process-${row.sno || Math.random()}`;
  //       setTimeout(() => {
  //         const container = document.getElementById(id);
  //         if (container && !container.hasChildNodes()) {
  //           ReactDOM.render(
  //             <div className="d-flex justify-content-center">
  //               {/* <div className="d-flex justify-content-around  mt-1  ">
  //                           <button className="view-details" onClick={() => handleNavigate(row.position, row.id)}>
  //                             View details
  //                           </button>
  //                       </div> */}
  //               <div className="" title="View">
  //                 <span>
  //                   <VscEye
  //                     onClick={() => handleNavigatethesis(row.position, row.id)}
  //                     className="open-icon"
  //                   />
  //                 </span>
  //               </div>
  //             </div>,
  //             container
  //           );
  //         }
  //       }, 0);
  //       return `<div id="${id}"></div>`;
  //     },
  //   },
  // ];

  const navigate = useNavigate();

  const handleEditClick = (id) => {
    navigate("/entry-process/entryprocess-update-form", {
      state: { rowId: id },
    });
  };

  const [loading, setLoading] = useState(true);
  console.log("loading :", loading);
  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 5000);
    };
    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }
    return () => window.removeEventListener("load", handleLoad);
  }, []);
  //  useEffect(() => {
  //   setLoading(true)
  // }, []);
  if (loading) {
    return <Loader />;
  }

  return (
    <>
      <section className="container ">
        <div className="mt-4 w-100">
          {/* <div className="col-1 d-flex    justify-content-center">
            <Sider />
          </div> */}
          <div className="col-12 ">
            <div className="col-12">
              <Header></Header>
            </div>
            <div className=" pt-1 mt-3 py-3 project-manage w-100 ">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className="col-12 col-md-5  px-4 ">
                  <h className="heading-entr">Project Manager Dashboard</h>
                </div>
                <div className="col-2 text-center   pb-2">
                  <div className="d-flex justify-content-center ">
                    <Tooltip title="Add Project">
                      <div className="add-icon">
                        <Link to="/entry-process/enter_process_form">
                          <IoMdAdd className="add1-icon" />
                        </Link>
                      </div>
                    </Tooltip>
                  </div>
                </div>
                <div className=" col-5 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>
              <div className="mt-4 px-4 gap-3 d-flex flex-wrap justify-content-end">
                <div className="">
                  <input
                    type="month"
                    id="monthInput"
                    className="people-select px-1"
                    value={selectedMonth}
                    onChange={handleMonthChange}
                    placeholder="YYYY-MM"
                  />
                </div>
              </div>
              <section className="d-flex flex-wrap p-2 gap-2 ">
                <div className=" col total-project    ">
                  <div className=" w-100 d-flex px-3  mt-3">
                    <div className="graphic-box  mt-2 ">
                      <BsBarChartLine className=" graphic-icon m-2" />
                    </div>
                    <div>
                      <div className=" d-flex mx-2 project-head gap-3 ">
                        <p className=" text-muted dash-year ">
                          {new Date().getFullYear()}
                        </p>
                        <p className=" text-muted dash-project">
                          Total Projects
                        </p>
                      </div>
                      <div className=" h1  px-2">{totalProjects}</div>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3  d-flex justify-content-around mt-1"
                    onClick={() =>
                      handleProNavigate({
                        type: "manuscript",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">Manuscript</p>
                    <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2">{works.manuscript}</p>
                      <p className="p-tag3">
                        {/* {((works.manuscript / totalProjects) * 100).toFixed(2)} */}
                        {totalProjects !== 0
                          ? ((works.manuscript / totalProjects) * 100).toFixed(
                              2
                            )
                          : 0}
                        %
                      </p>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3"
                    onClick={() =>
                      handleProNavigate({
                        type: "thesis",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">Thesis</p>
                    <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">{works.thesis}</p>
                      <p className="p-tag3 ">
                        {/* {((works.thesis / totalProjects) * 100).toFixed(2)}% */}
                        {totalProjects !== 0
                          ? ((works.thesis / totalProjects) * 100).toFixed(2)
                          : 0}
                        %
                      </p>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                    onClick={() =>
                      handleProNavigate({
                        type: "statistics",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">Statistics</p>
                    <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">{works.statistics}</p>
                      <p className="p-tag3 ">
                        {/* {((works.statistics / totalProjects) * 100).toFixed(2)}% */}
                        {totalProjects !== 0
                          ? ((works.statistics / totalProjects) * 100).toFixed(
                              2
                            )
                          : 0}
                        %
                      </p>
                    </div>
                  </div>
                  {/* <div className="manage-title  mx-3 d-flex justify-content-around mt-3" onClick={() => handleProNavigate({ type: 'presentation' })}>
                        <p className="mt-1 pt-2 px-2 p-tag">Presentation</p>
                        <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">{works.presentation}</p>
                          <p className="p-tag3 ">
                          
                            {(totalProjects !== 0 ? (works.presentation / totalProjects * 100).toFixed(2) : 0)}
                            %
                          </p>
                        </div>
                      </div> */}
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3"
                    onClick={() =>
                      handleProNavigate({
                        type: "others",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">Others</p>
                    <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">{works.others}</p>
                      <p className="p-tag3 ">
                        {/* {((works.others / totalProjects) * 100).toFixed(2)}% */}
                        {totalProjects !== 0
                          ? ((works.others / totalProjects) * 100).toFixed(2)
                          : 0}
                        %
                      </p>
                    </div>
                  </div>
                </div>

                <div className=" col total-project   ">
                  <div className=" w-100 d-flex px-3 mt-3">
                    <div className="graphic-box  mt-2 ">
                      <BsBarChartLine className=" graphic-icon m-2" />
                    </div>
                    <div>
                      <div className="status-title px-2 mt-3 mx-3">
                        Process Status
                      </div>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-4"
                    onClick={() =>
                      handleProNavigate({
                        process_status: "not_assigned",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">Not Assigned</p>
                    <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2">{processStatus.not_assigned}</p>
                      <p className="p-tag3">
                        {/* {(
                              (processStatus.not_assigned / totalProjects) *
                              100
                            ).toFixed(2)} */}
                        {totalProjects !== 0
                          ? (
                              (processStatus.not_assigned / totalProjects) *
                              100
                            ).toFixed(2)
                          : 0}
                        %
                      </p>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3"
                    onClick={() =>
                      handleProNavigate({
                        process_status: "in_progress",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">In Progress</p>
                    <div className="manage-num mt-1    pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">{processStatus.in_progress}</p>
                      <p className="p-tag3 ">
                        {/* {(
                              (processStatus.in_progress / totalProjects) *
                              100
                            ).toFixed(2)}
                            % */}
                        {totalProjects !== 0
                          ? (
                              (processStatus.in_progress / totalProjects) *
                              100
                            ).toFixed(2)
                          : 0}
                        %
                      </p>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3"
                    onClick={() =>
                      handleProNavigate({
                        process_status: "pending_author",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">Pending-Author</p>
                    <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">{processStatus.pending_author}</p>
                      <p className="p-tag3 ">
                        {/* {(
                              (processStatus.pending_author / totalProjects) *
                              100
                            ).toFixed(2)}
                            % */}
                        {totalProjects !== 0
                          ? (
                              (processStatus.pending_author / totalProjects) *
                              100
                            ).toFixed(2)
                          : 0}
                        %
                      </p>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                    onClick={() =>
                      handleProNavigate({
                        process_status: "withdrawal",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">Withdrawal</p>
                    <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">{processStatus.withdrawal}</p>
                      <p className="p-tag3 ">
                        {/* {(
                              (processStatus.withdrawal / totalProjects) *
                              100
                            ).toFixed(2)}
                            % */}
                        {totalProjects !== 0
                          ? (
                              (processStatus.withdrawal / totalProjects) *
                              100
                            ).toFixed(2)
                          : 0}
                        %
                      </p>
                    </div>
                  </div>

                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3"
                    onClick={() =>
                      handleProNavigate({
                        process_status: "completed",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">
                      completed {new Date().getFullYear()}
                    </p>
                    <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">{processStatus.completed}</p>
                      <p className="p-tag3 ">
                        {/* {(
                              (processStatus.completed / totalProjects) *
                              100
                            ).toFixed(2)}
                            % */}
                        {totalProjects !== 0
                          ? (
                              (processStatus.completed / totalProjects) *
                              100
                            ).toFixed(2)
                          : 0}
                        %
                      </p>
                    </div>
                  </div>
                </div>

                <div className=" col total-project   mx-2">
                  <div className=" w-100 d-flex px-3 mt-3">
                    <div className="graphic-box  mt-2 ">
                      <BsBarChartLine className=" graphic-icon m-2" />
                    </div>
                    <div>
                      <div className="status-title px-2 mt-3 mx-3">
                        Journal Status
                      </div>
                    </div>
                  </div>
                  <div className="manage-title  mx-3 d-flex justify-content-around mt-4">
                    <p className="mt-1 pt-2 px-2 p-tag">
                      Waiting for Submission
                    </p>
                    <div
                      className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center"
                      onClick={() =>
                        handleidClick(
                          freelancerId,
                          JSON.stringify(
                            journalStatus?.submit_to_journal?.ids || []
                          )
                        )
                      }
                    >
                      <p className="p-tag2 ">
                        {journalStatus?.submit_to_journal?.count}
                      </p>
                      <p className="p-tag3 ">
                        {works.manuscript !== 0
                          ? (
                              (journalStatus?.submit_to_journal?.count /
                                works.manuscript) *
                              100
                            ).toFixed(2) + "%"
                          : "0%"}
                      </p>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                    onClick={() =>
                      handleidClick(
                        freelancerId,
                        JSON.stringify(
                          journalStatus?.submitted_peer_review?.ids || []
                        )
                      )
                    }
                  >
                    <p className="mt-1 px-2 pt-2 p-tag">Submit/Peer Review</p>
                    <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">
                        {journalStatus?.submitted_peer_review?.count}
                      </p>
                      <p className="p-tag3 ">
                        {works.manuscript !== 0
                          ? (
                              (journalStatus?.submitted_peer_review?.count /
                                works.manuscript) *
                              100
                            ).toFixed(2) + "%"
                          : "0%"}
                      </p>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3"
                    onClick={() =>
                      handleidClick(
                        freelancerId,
                        JSON.stringify(
                          journalStatus?.reviewer_comments?.ids || []
                        )
                      )
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">Reviewer Comment</p>
                    <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">
                        {journalStatus?.reviewer_comments?.count}
                      </p>
                      <p className="p-tag3 ">
                        {works.manuscript !== 0
                          ? (
                              (journalStatus?.reviewer_comments?.count /
                                works.manuscript) *
                              100
                            ).toFixed(2) + "%"
                          : "0%"}
                      </p>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3"
                    onClick={() =>
                      handleidClick(
                        freelancerId,
                        JSON.stringify(
                          journalStatus?.resubmission_rejected?.ids || []
                        )
                      )
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">Resubmission/Reject</p>
                    <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">
                        {journalStatus?.resubmission_rejected?.count}
                      </p>
                      <p className="p-tag3 ">
                        {works.manuscript !== 0
                          ? (
                              (journalStatus?.resubmission_rejected?.count /
                                works.manuscript) *
                              100
                            ).toFixed(2) + "%"
                          : "0%"}
                      </p>
                    </div>
                  </div>
                </div>

                <div className=" col total-project   ">
                  <div className=" w-100 d-flex px-3 mt-3">
                    <div className="graphic-box  mt-2 ">
                      <BsBarChartLine className=" graphic-icon m-2" />
                    </div>
                    <div>
                      <div className="status-title px-2 mt-3 mx-3">
                        Payment Status
                      </div>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-4"
                    onClick={() =>
                      handlePaymentStatusNavigate({
                        payment_status: "advance_pending",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 px-2 pt-2 p-tag">Advance Pending</p>
                    <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2">{paymentStatus.advance_pending}</p>
                      <p className="p-tag3 ">
                        {/* {(
                                              (paymentStatus.advance_pending / totalProjects) *
                                              100
                                            ).toFixed(2)} */}
                        {totalProjects !== 0
                          ? (
                              (paymentStatus.advance_pending / totalProjects) *
                              100
                            ).toFixed(2)
                          : 0}
                        %
                      </p>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3"
                    onClick={() =>
                      handlePaymentStatusNavigate({
                        payment_status: "partial_payment_pending",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">
                      Partial Payment Pending
                    </p>
                    <div className="manage-num mt-1 pt-3  mx-1 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">
                        {paymentStatus.partial_payment_pending}
                      </p>
                      <p className="p-tag3 ">
                        {/* {(
                                              (paymentStatus.payment_pending / totalProjects) *
                                              100
                                            ).toFixed(2)} */}
                        {totalProjects !== 0
                          ? (
                              (paymentStatus.partial_payment_pending /
                                totalProjects) *
                              100
                            ).toFixed(2)
                          : 0}
                        %
                      </p>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                    onClick={() =>
                      handlePaymentStatusNavigate({
                        payment_status: "final_payment_pending",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 px-2 pt-2 p-tag">
                      Final Payment Pending
                    </p>
                    <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">
                        {paymentStatus.final_payment_pending}
                      </p>
                      <p className="p-tag3 ">
                        {/* {(
                                              (paymentStatus.partial_payment_pending / totalProjects) *
                                              100
                                            ).toFixed(2)} */}
                        {totalProjects !== 0
                          ? (
                              (paymentStatus.final_payment_pending /
                                totalProjects) *
                              100
                            ).toFixed(2)
                          : 0}
                        %
                      </p>
                    </div>
                  </div>
                  <div
                    className="manage-title mx-3 d-flex justify-content-around mt-3"
                    onClick={() =>
                      handlePaymentStatusNavigate({
                        payment_status: "completed",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">
                      Full Payment Received
                    </p>
                    <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">{paymentStatus.completed}</p>
                      <p className="p-tag3">
                        {totalProjects !== 0
                          ? (
                              (paymentStatus.completed / totalProjects) *
                              100
                            ).toFixed(2)
                          : 0}
                        %
                      </p>
                    </div>
                  </div>
                </div>

                <div className=" col total-project">
                  <div className=" w-100 d-flex px-3 mt-3">
                    <div className="graphic-box  mt-2 ">
                      <BsBarChartLine className=" graphic-icon m-2" />
                    </div>
                    <div>
                      <div className="status-title px-2 mt-3 mx-3">
                        Completed Count
                      </div>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-4"
                    onClick={() =>
                      handleProNavigate({
                        completed_count: "manuscript",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 px-2 pt-2 p-tag">Manuscript</p>
                    <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2">{completed.manuscript}</p>
                      <p className="p-tag3">
                        {works.manuscript &&
                        completed.manuscript &&
                        works.manuscript !== 0
                          ? (
                              (completed.manuscript / works.manuscript) *
                              100
                            ).toFixed(2)
                          : 0}{" "}
                        %
                      </p>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3"
                    onClick={() =>
                      handleProNavigate({
                        completed_count: "thesis",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">Thesis</p>
                    <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">{completed.thesis}</p>
                      <p className="p-tag3">
                        {works.thesis && completed.thesis && works.thesis !== 0
                          ? ((completed.thesis / works.thesis) * 100).toFixed(2)
                          : 0}{" "}
                        %
                      </p>
                    </div>
                  </div>
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                    onClick={() =>
                      handleProNavigate({
                        completed_count: "statistics",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 px-2 pt-2 p-tag">Statistics</p>
                    <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">{completed.statistics}</p>
                      {/* <p className="p-tag3 ">{(works.statistics !== 0 ? (completed.statistics / works.statistics * 100).toFixed(2) : 0)} %</p> */}
                      <p className="p-tag3">
                        {works.statistics &&
                        completed.statistics &&
                        works.statistics !== 0
                          ? (
                              (completed.statistics / works.statistics) *
                              100
                            ).toFixed(2)
                          : 0}{" "}
                        %
                      </p>
                    </div>
                  </div>
                  {/* <div className="manage-title  mx-3 d-flex justify-content-around mt-3" onClick={() => handleProNavigate({ completed_count: 'presentation' })}>
                                       <p className="mt-1 pt-2 px-2 p-tag">
                                         Presentation
                                       </p>
                                       <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                                         <p className="p-tag2 ">{completed.presentation}</p>
                                         <p className="p-tag3 ">{(totalProjects !== 0 ? (completed.presentation / totalProjects * 100).toFixed(2) : 0)} %</p>
                                       </div>
                                     </div> */}
                  <div
                    className="manage-title  mx-3 d-flex justify-content-around mt-3"
                    onClick={() =>
                      handleProNavigate({
                        completed_count: "others",
                        month: selectedMonth,
                      })
                    }
                  >
                    <p className="mt-1 pt-2 px-2 p-tag">Others</p>
                    <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                      <p className="p-tag2 ">{completed.others}</p>
                      <p className="p-tag3">
                        {works.others && completed.others && works.others !== 0
                          ? ((completed.others / works.others) * 100).toFixed(2)
                          : 0}{" "}
                        %
                      </p>
                    </div>
                  </div>
                </div>
              </section>

              <section className="col-12">
                <div className="row mx-3 py-2 gap-4 d-flex  flex-wrap">
                  {/* Task Count Boxes */}

                  <div
                    className="col project-task-project1 px-1 align-items-center d-flex justify-content-around"
                    onClick={() =>
                      handleProNavigate({
                        count_type: "emergency_work",
                        month: selectedMonth,
                      })
                    }
                  >
                    {/* <div className="task-box-dash align-items-center pt-3"> */}
                    <AiOutlineAlert className="project-icon" />
                    {/* </div> */}
                    <div className="project-writer-dashboard ">
                      Emergency work
                    </div>
                    <div className="project-writer-dashboard-font mt-1 ">
                      {dasCount.urgentDataListCount}
                    </div>
                  </div>
                  <div
                    className="col project-task-project2 px-1 align-items-center d-flex justify-content-around"
                    onClick={() =>
                      handleProNavigate({
                        count_type: "not_assigned_work",
                        month: selectedMonth,
                      })
                    }
                  >
                    {/* <div className="task-box1-dash align-items-center pt-2"> */}
                    <MdDoNotDisturb className="project-icon3 " />
                    {/* </div> */}
                    {/* <div className="align-items-center"> */}
                    <div className="project-writer-dashboard-black ">
                      Not Assgined Work
                    </div>
                    <div className="project-writer-dashboard-black-font mt-1">
                      {dasCount.not_assigned}
                    </div>
                    {/* </div> */}
                  </div>
                  <div
                    className="col project-task-project-orange px-1 align-items-center d-flex justify-content-around"
                    onClick={() =>
                      handleProNavigate({
                        count_type: "project_delay",
                        month: selectedMonth,
                      })
                    }
                  >
                    {/* <div className="task-box2-dash-orange align-items-center pt-1"> */}
                    <TbHourglassLow className="project-icon3" />
                    {/* </div> */}
                    {/* <div className="align-items-center"> */}
                    <div className="project-writer-dashboard-black ">
                      Project Delay
                    </div>
                    <div className="project-writer-dashboard-font-black mt-1">
                      {dasCount.projectdelayDataCount}
                    </div>
                    {/* </div> */}
                  </div>
                  <div
                    className="col  project-task-project-blue px-1 align-items-center d-flex justify-content-around"
                    onClick={() =>
                      handleProNavigate({
                        count_type: "freelancer_count",
                        month: selectedMonth,
                      })
                    }
                  >
                    {/* <div className="task-box3-dash align-items-center pt-3"> */}
                    <SiFreelancer className="project-icon" />
                    {/* </div> */}
                    {/* <div className="align-items-center"> */}
                    <div className="project-writer-dashboard ">Freelancer</div>
                    <div className="project-writer-dashboard-font mt-1">
                      {dasCount.freelancet_payment_count}
                    </div>
                    {/* </div> */}
                  </div>
                </div>
              </section>
            </div>

            <section className=" pt-1 mt-3  project-manage-view w-100   ">
              <div className="d-flex flex-wrap  p-3 pt-0 scrollable-section  ">
                {/* to do **/}
                <div className="col m-0">
                  <div className="project-todo d-flex gap-2 pb-2 m-1 pt-1">
                    <div>To Do</div>
                    <div className="project-todo-round ">
                      {todolistD.length}
                      {/* {setdata.inToDoListCount} */}
                    </div>
                  </div>
                  <div className="task-list ">
                    {Array.isArray(todolistD) &&
                      todolistD.length > 0 &&
                      todolistD.map((task, index) => {
                        let level;
                        let bgColor = "";
                        switch (task.hierarchy_level) {
                          case "urgent_important":
                            level = "U/I";

                            break;
                          case "important_not_urgent":
                            level = "I/NU";
                            break;
                          case "urgent_not_important":
                            level = "U/NI";
                            break;
                          case "not_urgent_not_important":
                            level = "NU/NI";
                            break;
                        }

                        if (task.process_status === "not_assigned") {
                          bgColor = "bg-yellow";
                        } else {
                          bgColor = "bg-white";
                        }

                        return (
                          <>
                            <div
                              // key={task.id}
                              onClick={() => handleViewClick(task.id)}
                              // to={`/entry-process/process-view-details`}
                              className="text-decoration-none"
                            >
                              <div
                                // onClick={() => handleViewClick(task.id)}
                                className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                              >
                                <div className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </div>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </div>
                          </>
                        );
                      })}
                  </div>
                </div>

                <div className="col m-0">
                  <div className="project-todo d-flex gap-2 pb-2 m-1 pt-1">
                    <div>IN PROGRESS</div>
                    <div className="project-todo-round ">
                      {setdata.inProgressCount}
                    </div>
                  </div>
                  <div className="task-list ">
                    {Array.isArray(tododata) &&
                      tododata.length > 0 &&
                      tododata.map((task, index) => {
                        // Check if all four fields are empty
                        const isAllEmpty =
                          !task.journal &&
                          !task.writer &&
                          !task.statistican &&
                          !task.reviewer;

                        const hierarchy_level = task.hierarchy_level;

                        // // Define handle click to conditionally navigate
                        // const handleTaskClick = (e) => {
                        //   if (isAllEmpty) {
                        //     e.preventDefault(); // Prevent default navigation
                        //     handleEditClick(task.id); // Redirect to entry process update form
                        //   }
                        // };

                        let level;
                        let bgColor = "";

                        switch (task.hierarchy_level) {
                          case "urgent_important":
                            level = "U/I";
                            bgColor = "bg-red";
                            break;
                          case "important_not_urgent":
                            level = "I/NU";
                            break;
                          case "urgent_not_important":
                            level = "U/NI";
                            break;
                          case "not_urgent_not_important":
                            level = "NU/NI";
                            break;
                        }

                        return (
                          <>
                            {/* {!isAllEmpty ? (
                              <Link
                                key={task.id}
                                to={`/project-view/${task.project_id}`}
                                className="text-decoration-none"
                              >
                                <div
                                  className={`task-details d-flex justify-content-between m-2 p-2 ${
                                    isAllEmpty ? `${bgColor}` : ""
                                  }`}
                                >
                                  <div className="m-0 task-name-todo">
                                    {Capitalize(task.project_id)}
                                  </div>
                                  <div
                                    className="task-comments"
                                    style={{
                                      color:
                                        task.hierarchy_level ===
                                        "urgent_important"
                                          ? "#FF0909" // Red
                                          : task.hierarchy_level ===
                                            "important_not_urgent"
                                          ? "#9932cc" // Yellow
                                          : task.hierarchy_level ===
                                            "urgent_not_important"
                                          ? "#FFA500" // Orange
                                          : task.hierarchy_level ===
                                            "not_urgent_not_important"
                                          ? "#00A300" // Green
                                          : "inherit", // Default
                                    }}
                                  >
                                    {level}
                                  </div>
                                </div>
                              </Link>
                            ) : ( */}
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                              >
                                <div className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </div>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          </>
                        );
                      })}
                  </div>
                </div>
                <div className="col ">
                  <div className="project-todo3 d-flex gap-2  pb-2 m-1 pt-1">
                    <div className="">EMERGENCY WORK</div>
                    <div className="project-todo-round ">
                      {setdata.urgentDataListCount}
                    </div>
                  </div>
                  <div className="task-list ">
                    {Array.isArray(inworkdata) &&
                      inworkdata.length > 0 &&
                      inworkdata.map((task, index) => {
                        const isAllEmpty =
                          !task.journal &&
                          !task.writer &&
                          !task.statistican &&
                          !task.reviewer;

                        // const handleTaskClick = (e) => {
                        //   if (isAllEmpty) {
                        //     e.preventDefault(); // Prevent default navigation
                        //     handleEditClick(task.id); // Redirect to entry process update form
                        //   }
                        // };

                        let level;
                        let bgColor = "";

                        switch (task.hierarchy_level) {
                          case "urgent_important":
                            level = "U/I";
                            bgColor = "bg-red";
                            break;
                          case "important_not_urgent":
                            level = "I/NU";
                            break;
                          case "urgent_not_important":
                            level = "U/NI";
                            break;
                          case "not_urgent_not_important":
                            level = "NU/NI";
                            break;
                        }

                        return (
                          <>
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                              >
                                <div className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </div>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          </>
                        );
                      })}
                  </div>
                </div>
                <div className="col ">
                  <div className="project-todo2 d-flex gap-2 pb-2 m-1 pt-1 ">
                    <div>PROJECT DELAY</div>
                    <div className="project-todo-round ">
                      {dasCount.projectdelayDataCount}
                    </div>
                  </div>
                  <div className="task-list ">
                    {Array.isArray(reviewdata) &&
                      reviewdata.length > 0 &&
                      reviewdata.map((task, index) => {
                        const isAllEmpty =
                          !task.journal &&
                          !task.writer &&
                          !task.statistican &&
                          !task.reviewer;

                        // const handleTaskClick = (e) => {
                        //   if (isAllEmpty) {
                        //     e.preventDefault(); // Prevent default navigation
                        //     handleEditClick(task.id); // Redirect to entry process update form
                        //   }
                        // };

                        let level;
                        let bgColor = "";

                        switch (task.hierarchy_level) {
                          case "urgent_important":
                            level = "U/I";
                            bgColor = "bg-red";
                            break;
                          case "important_not_urgent":
                            level = "I/NU";
                            break;
                          case "urgent_not_important":
                            level = "U/NI";
                            break;
                          case "not_urgent_not_important":
                            level = "NU/NI";
                            break;
                        }

                        return (
                          <>
                            {/* {!isAllEmpty ? (
                              <Link
                                key={task.id}
                                to={`/project-view/${task.project_id}`}
                                className="text-decoration-none"
                              >
                                <div
                                  className={`task-details d-flex justify-content-between m-2 p-2 ${
                                    isAllEmpty ? "bg-yellow" : ""
                                  }`}
                                >
                                  <div className="m-0 task-name-todo">
                                    {Capitalize(task.project_id)}
                                  </div>
                                  <div
                                    className="task-comments"
                                    style={{
                                      color:
                                        task.hierarchy_level ===
                                        "urgent_important"
                                          ? "#FF0909" // Red
                                          : task.hierarchy_level ===
                                            "important_not_urgent"
                                          ? "#9932cc" // Yellow
                                          : task.hierarchy_level ===
                                            "urgent_not_important"
                                          ? "#FFA500" // Orange
                                          : task.hierarchy_level ===
                                            "not_urgent_not_important"
                                          ? "#00A300" // Green
                                          : "inherit", // Default
                                    }}
                                  >
                                    {level}
                                  </div>
                                </div>
                              </Link>
                            ) : ( */}
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                              >
                                <div className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </div>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          </>
                        );
                      })}
                  </div>
                </div>
                <div className="col ">
                  <div className="project-todo3 d-flex gap-2 pb-2 m-1 pt-1">
                    <div>FREELANCER</div>
                    <div className="project-todo-round ">
                      {correctiondata.length}
                      {/* {setdata.freelancerProjecctCount} */}
                    </div>
                  </div>
                  <div className="task-list ">
                    {Array.isArray(correctiondata) &&
                      correctiondata.length > 0 &&
                      correctiondata.map((task, index) => {
                        const isAllEmpty =
                          !task.journal &&
                          !task.writer &&
                          !task.statistican &&
                          !task.reviewer;

                        // const handleTaskClick = (e) => {
                        //   if (isAllEmpty) {
                        //     e.preventDefault(); // Prevent default navigation
                        //     handleEditClick(task.id); // Redirect to entry process update form
                        //   }
                        // };

                        let level;
                        let bgColor = "";

                        switch (task.hierarchy_level) {
                          case "urgent_important":
                            level = "U/I";
                            bgColor = "bg-red";
                            break;
                          case "important_not_urgent":
                            level = "I/NU";
                            break;
                          case "urgent_not_important":
                            level = "U/NI";
                            break;
                          case "not_urgent_not_important":
                            level = "NU/NI";
                            break;
                        }

                        return (
                          <>
                            {/* {!isAllEmpty ? (
                              <Link
                                key={task.id}
                                to={`/project-view/${task.project_id}`}
                                className="text-decoration-none"
                              >
                                <div
                                  className={`task-details d-flex justify-content-between m-2 p-2 ${
                                    isAllEmpty ? "bg-yellow" : ""
                                  }`}
                                >
                                  <div className="m-0 task-name-todo">
                                    {Capitalize(task.project_id)}
                                  </div>
                                  <div
                                    className="task-comments"
                                    style={{
                                      color:
                                        task.hierarchy_level ===
                                        "urgent_important"
                                          ? "#FF0909" // Red
                                          : task.hierarchy_level ===
                                            "important_not_urgent"
                                          ? "#9932cc" // Yellow
                                          : task.hierarchy_level ===
                                            "urgent_not_important"
                                          ? "#FFA500" // Orange
                                          : task.hierarchy_level ===
                                            "not_urgent_not_important"
                                          ? "#00A300" // Green
                                          : "inherit", // Default
                                    }}
                                  >
                                    {level}
                                  </div>
                                </div>
                              </Link>
                            ) : ( */}
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                              >
                                <div className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </div>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                            {/* )} */}
                          </>
                        );
                      })}
                  </div>
                </div>
                <div className="col ">
                  <div className="project-todo4 d-flex gap-2 pb-2 m-1 pt-1">
                    <div>REJECTED</div>
                    <div className="project-todo-round ">
                      {projectStatusCount}
                    </div>
                  </div>
                  <div className="task-list ">
                    {Array.isArray(acceptRejectList) &&
                      acceptRejectList.length > 0 &&
                      acceptRejectList.map((task, index) => {
                        const isAllEmpty =
                          !task.journal &&
                          !task.writer &&
                          !task.statistican &&
                          !task.reviewer;

                        // const handleTaskClick = (e) => {
                        //   if (isAllEmpty) {
                        //     e.preventDefault(); // Prevent default navigation
                        //     handleEditClick(task.id); // Redirect to entry process update form
                        //   }
                        // };

                        let level;
                        let bgColor = "";

                        switch (task.hierarchy_level) {
                          case "urgent_important":
                            level = "U/I";
                            bgColor = "bg-red";
                            break;
                          case "important_not_urgent":
                            level = "I/NU";
                            break;
                          case "urgent_not_important":
                            level = "U/NI";
                            break;
                          case "not_urgent_not_important":
                            level = "NU/NI";
                            break;
                        }

                        return (
                          <>
                            {/* {!isAllEmpty ? (
                              <Link
                                key={task.id}
                                to={`/project-view/${task.project_id}`}
                                className="text-decoration-none"
                              >
                                <div
                                  className={`task-details d-flex justify-content-between m-2 p-2 ${
                                    isAllEmpty ? "bg-yellow" : ""
                                  }`}
                                >
                                  <div className="m-0 task-name-todo">
                                    {Capitalize(task.project_id)}
                                  </div>
                                  <div
                                    className="task-comments"
                                    style={{
                                      color:
                                        task.hierarchy_level ===
                                        "urgent_important"
                                          ? "#FF0909" // Red
                                          : task.hierarchy_level ===
                                            "important_not_urgent"
                                          ? "#9932cc" // Yellow
                                          : task.hierarchy_level ===
                                            "urgent_not_important"
                                          ? "#FFA500" // Orange
                                          : task.hierarchy_level ===
                                            "not_urgent_not_important"
                                          ? "#00A300" // Green
                                          : "inherit", // Default
                                    }}
                                  >
                                    {level}
                                  </div>
                                </div>
                              </Link>
                            ) : ( */}
                            <Link
                              key={task.id}
                              to={`/project-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${bgColor}`}
                              >
                                <div className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </div>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          </>
                        );
                      })}
                  </div>
                </div>
              </div>
            </section>

            <section className="  mt-2 project-manage w-100 py-0">
              <div className="row p-3">
                <div className="col-12 ">
                  <h className="heading-entr">Inhouse projects status </h>
                </div>
                <div className="px-1">
                  <DataTable
                    id="example"
                    data={dataPeopleInhouse}
                    columns={columnsPeople}
                    className="display"
                    options={{
                      paging: true,
                      pageLength: 20,
                      lengthMenu: [
                        [20, 30, 50],
                        [20, 30, 50],
                      ],
                      scrollX: true,
                    }}
                  />
                </div>
              </div>
            </section>

            <section className=" pt-1 mt-2 project-manage w-100 ">
              <div className="row px-3">
                <div className="col-12 ">
                  <h className="heading-entr">External projects status </h>
                </div>
                <div className="px-1">
                  <DataTable
                    id="example"
                    data={dataPeopleExtranel}
                    columns={columnsPeople1}
                    className="display"
                    options={{
                      paging: true,
                      pageLength: 20,
                      lengthMenu: [
                        [20, 30, 50],
                        [20, 30, 50],
                      ],
                      scrollX: true,
                    }}
                  />
                </div>
              </div>
            </section>

            <section className="  mt-2 project-manage w-100 py-0">
              <div className="row p-3">
                <div className="col-12 ">
                  <h className="heading-entr">Thesis Status </h>
                </div>
                <div className="px-1">
                  <DataTable
                    id="example"
                    data={dataPeopleWriterExtranel}
                    columns={columnsThesisPeople1}
                    className="display"
                    options={{
                      paging: true,
                      pageLength: 20,
                      lengthMenu: [
                        [20, 30, 50],
                        [20, 30, 50],
                      ],
                      scrollX: true,
                    }}
                  />
                </div>
                {/* <div className="col-12 px-2 table-responsive  table-wrapper-scroll-y my-custom-scrollbar  ">
                              <table className="table-head">
                                <thead>
                                  <tr className="text-center tr-head">
                                    <th>SI No</th>
                                    {columns.map((col, index) => (
                                      <th key={index}>{col.title}</th>
                                    ))}
                                  </tr>
                                </thead>
                                <tbody>
                                  {data.map((row, rowIndex) => (
                                    <tr key={rowIndex} className="text-center tr-head">
                                      <td>{rowIndex + 1}</td>
                                      {columns.map((col, colIndex) => (
                                        <td key={colIndex}>
                                          {col.render
                                            ? col.render(row[col.data])
                                            : row[col.data]}
                                        </td>
                                      ))}
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div> */}
              </div>
            </section>

            <section className="  project-manage w-100 mt-2 py-0">
              <div className="row  p-3">
                <div className="col-12 ">
                  <h className="heading-entr">Month wise projects status </h>
                </div>
                {/* <div className="px-1">
                            <DataTable
                              id="example"
                              data={data}
                              columns={columns}
                              className="display"
                              options={{
                                paging: false,
                                pageLength: 12,
                                lengthMenu: [
                                  [10, 20, 30, 50],
                                  [10, 20, 30, 50],
                                ],
                                scrollX: true,
                                columnDefs: [
                                  { targets: "_all", orderable: false },
                                  { targets: [1], orderable: true },
                                ],
                              }}
                            />
                          </div> */}
                <div className="col-12 px-2 table-responsive  table-wrapper-scroll-y my-custom-scrollbar  ">
                  <table className="table-head">
                    <thead>
                      <tr className="text-center tr-head">
                        {/* <th>SI No</th> */}
                        {columns.map((col, index) => (
                          <th key={index}>{col.title}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {data.map((row, rowIndex) => (
                        <tr key={rowIndex} className="text-center tr-head">
                          {/* <td>{rowIndex + 1}</td> */}
                          {columns.map((col, colIndex) => (
                            <td key={colIndex}>
                              {col.render
                                ? col.render(row[col.data])
                                : row[col.data]}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="text-center tr-foot">
                        <td className="total-name-table" colSpan={1}>
                          Total
                        </td>
                        <td>{dataFoot.manuscript}</td>
                        <td>{dataFoot.statistics}</td>
                        <td>{dataFoot.thesis}</td>
                        <td>{dataFoot.others}</td>
                        <td>{dataFoot.not_assigned}</td>
                        <td>{dataFoot.withdrawn}</td>
                        <td>{dataFoot.total}</td>
                        <td>
                          {Number(dataFoot.manuscript_percentage).toFixed(2)}%
                        </td>
                        <td>
                          {Number(dataFoot.statistics_percentage).toFixed(2)}%
                        </td>
                        <td>
                          {Number(dataFoot.thesis_percentage).toFixed(2)}%
                        </td>
                        <td>
                          {Number(dataFoot.others_percentage).toFixed(2)}%
                        </td>
                        {/* <td >{dataFoot.target_percentage}%</td> */}
                        <td>
                          {dataFoot.target_percentage
                            ? Number(
                                dataFoot.target_percentage
                              ).toLocaleString() + "%"
                            : "N/A"}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </section>
          </div>
        </div>
        <div>
          <Footer />
        </div>
      </section>
    </>
  );
}

export default Project_manager_dashboard;
