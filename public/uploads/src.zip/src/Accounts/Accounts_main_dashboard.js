import React from "react";

import { BsBarChartLine } from "react-icons/bs";
import Sider from "../components/Sider";

import Header from "../components/Header";
import { AiOutlineAlert } from "react-icons/ai";
import { MdDoNotDisturb } from "react-icons/md";
import { FaFileInvoiceDollar } from "react-icons/fa6";
import { GiPiggyBank } from "react-icons/gi";
import "../assests/css/project_management.css";
import ReactDOM from "react-dom";
import { API_URL } from "../config.js";
import { Capitalize } from "../campsCase.js";
import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { useState, useEffect } from "react";
import { VscGitStashPop } from "react-icons/vsc";

import { IoMdAdd } from "react-icons/io";
import Footer from "../components/Footer";
import Tooltip from "@mui/material/Tooltip";
import { useNavigate } from "react-router-dom";
import Breadcrumbs from "../routes/Breadcrumbs";
import { VscEye } from "react-icons/vsc";

// icon
import { TbHourglassLow } from "react-icons/tb";
import { SiFreelancer } from "react-icons/si";

import axios from "axios";
import { Link } from "react-router-dom";
// import { combineEventHandlers } from "recharts/types/util/ChartUtils.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import { getDateFormate } from "../dateFormate.js";
import Swal from "sweetalert2";
import { capitalize } from "@mui/material";

DataTable.use(DT);

function Accounts_main_dashboard() {
  const [data, setData] = useState(null);
  console.log("dataall:", data);
  const [dataFoot, setFootData] = useState([]);
  // const [dataPeople, setDataPeople] = useState([]);
  const [dataPeopleInhouse, setDataPeopleInHouse] = useState([]);
  const [dataPeopleExtranel, setDataPeopleExternal] = useState([]);

  useEffect(() => {
    fetchProjectManagerData();
  }, []);

  // const handleNavigate = (type, createdby) => {
  //   navigate(`/employe-project-list`, { state: { type, createdby } });
  // };

  const handleProNavigate = (params) => {
    navigate(`/accounts-view`, { state: params });
  };

  // /

  const [works, setTypeOfWork] = useState([]);
  const [final, setTypeOfFinal] = useState([]);

  const [totalProjects, setProjectCount] = useState(0);
  const [processStatus, setProcessStatus] = useState(0);
  const [journalStatus, setJournalStatus] = useState(0);
  const [completed, setCompleted] = useState(0);
  const [setdata, setFetchData] = useState(0);

  const [todolistD, setToDoListData] = useState([]);

  const [revertlist, setRevertData] = useState([]);

  console.log("check revert", processStatus);
  const [acceptRejectList, setProjectAcceptRejectStatus] = useState([]);
  const [projectStatusCount, setProjectStatusCount] = useState(0);

  const [freelancerProjectcount, setFreelancerProjectcount] = useState([]);

  const [dasCount, setCountVal] = useState([]);

  //
  const [tododata, setToDoData] = useState([]);
  const [inworkdata, setInWorkData] = useState([]);
  const [completeddata, setCompletedData] = useState([]);
  const [widthdrawn, setWidthdrawn] = useState([]);

  // console.log("todo:", tododata);
  // console.log("Verfiy:", inworkdata);
  // console.log("completed:", completeddata);

  const fetchProjectManagerData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/accountant/payment-task`
      );
      console.log("response1 :", response.data.data);
      setCompletedData(response.data.data.completed);
      setWidthdrawn(response.data.data.withdrawal);
      setTypeOfWork(response.data.data.payment_count);
      setTypeOfFinal(response.data.data.final_payment_pending);
      setProjectStatusCount(response.data.data.journalPaymentPendingCount);
      setFreelancerProjectcount(response.data.data.journalPaymentPending);

      setProcessStatus(response.data.data);
      const originaltodoData = response.data.data.to_do;
      const flattenedDataTODO = originaltodoData.map((item) => ({
        created_by: item.created_by,
        has_role: item.has_role,
        hierarchy_level:
          item.hierarchy_level === null
            ? item.hierarchy_levels
            : item.hierarchy_level,
        process_status: item.process_status,
        process_statuses: item.process_statuses,
        project_id:
          typeof item.project_id === "number"
            ? item.project_ids
            : item.project_id,
      }));
      setToDoData(flattenedDataTODO);
      const originalData = response.data.data.verificationList;
      const flattenedData = originalData.map((item) => ({
        ...item,
        ...item.project_data, // Spread all `project_data` fields to root
        id: item.id, // Keep other root fields if needed
      }));
      setInWorkData(flattenedData);

      // console.log("response:", response.data);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  const navigate = useNavigate();

  const handleEditClick = (id) => {
    navigate("/entry-process/entryprocess-update-form", {
      state: { rowId: id },
    });
  };
  // accounts details list

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;

  const [isOpen, setIsOpen] = useState(false);
  const [modalData, setModalData] = useState({
    paymentStatus: "",
    totalCost: 0,
    projectId: "",
  });

  const togglePopup = (paymentStatus, total_cost, projectid) => {
    setModalData({
      paymentStatus,
      totalCost: total_cost,
      projectId: projectid,
    });
    setIsOpen(!isOpen);
  };
  const [paymentData, setPaymentData] = useState({
    totalPaymentPendingCount: 0,
    totalAdvancePendingCount: 0,
    totalPartialPaymentPendingCount: 0,
    totalPaymentPending: 0,
    totalAdvancePending: 0,
    totalPartialPaymentPending: 0,
  });

  const fetchPayementProject = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/payment_processes/payment-list`
      );

      const responsedata = response.data;
      console.log("responsedata : ", responsedata);
      setPaymentData(responsedata);
      setData(response.data.projects);
      // setPaymentDataDetails(response.data.paymentProjectDetails);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  const [freelancerData, setPaymentDataDetails] = useState([]);

  const [freelid, setFreeid] = useState([]);
  const fetchFreelancerProject = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/payment_processes/getfreelancerdetails`
      );

      const responsedata = response.data;
      console.log("responseFreelancerdata : ", responsedata);
      setPaymentDataDetails(responsedata);

      const flattenedToData = responsedata.map((item) => {
        return {
          projectid: item,
        };
      });
      setFreeid(flattenedToData);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  useEffect(() => {
    fetchPayementProject();
    fetchFreelancerProject();
  }, []);

  //verify check
  const paymentVerify = async (
    paymentStatus,
    payment_id,
    project_id,
    rowIndex
  ) => {
    try {
      // console.log("paymentStatus :", paymentStatus);
      if (paymentStatus === "completed") {
        const result = await Swal.fire({
          icon: "question",
          title: "Are you sure?",
          text: "Do you want to change the payment status?",
          showCancelButton: true,
          confirmButtonText: "Yes, proceed",
          cancelButtonText: "No, cancel",
        });

        if (!result.isConfirmed) {
          // If the user clicks "No", exit without making the request
          return;
        }
        // Make the request to the backend
        const response = await axios.post(
          `${API_URL}/api/payment_processes/payment-status`,
          {
            payment_id: payment_id,
            project_id: project_id,
            created_by: createdby,
          }
        );
        // Display success message
        Swal.fire({
          icon: "success",
          title: "Payment Status Updated!",
          text: "The payment status has been successfully updated.",
          confirmButtonText: "OK",
        });

        fetchPayementProject();
        console.log("Payment status updated successfully", response.data);
      } else {
        await Swal.fire({
          icon: "question",
          title: "Payment Pending",
          text: "Your payment is still pending. Verification will be available once the payment is completed.",
          confirmButtonText: "OK",
        });
      }
    } catch (error) {
      console.error("Error updating payment status", error);

      // Display error message
      Swal.fire({
        icon: "error",
        title: "Error!",
        text: error.response
          ? error.response.data.message
          : "There was an issue updating the payment status.",
        confirmButtonText: "Try Again",
      });
    }
  };

  // useEffect(() => {
  //    fetchPayementProject();

  //  }, []);

  const columns = [
    {
      title: "Client Name".toUpperCase(),
      data: null,
      render: (data) => `Dr.${CapitalizeCaseU(data.client_name)}`,
    },
    {
      title: "Project ID".toUpperCase(),
      data: null,
      render: (data) => CapitalizeCaseU(data.project_id),
    },
    // { title: "Project Name", data: "title" },
    {
      title: "Payment Date".toUpperCase(),
      data: "paymentdate",
      render: (data) => {
        // Check if data is valid (not null, undefined, empty, or '-')
        return data && data !== "-" ? getDateFormate(data) : "-";
      },
    },
    {
      title: "Payment Status".toUpperCase(),
      data: null,
      render: (data, type, row) => {
        const id = `actions-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            const paymentStatus = row.paymentstatus;
            const total_cost = row.total_cost;
            const projectid = row.project_id;

            // Determine the class based on payment status
            let statusClass = "status-other";
            let handleClick = null;
            let displayText = "";

            if (paymentStatus === "completed") {
              statusClass = "status-completed-account ";
              displayText = "Completed";
            } else if (paymentStatus === "-") {
              displayText = "-";
            } else {
              statusClass = "status-pending";
              handleClick = () =>
                togglePopup(paymentStatus, total_cost, projectid);
              displayText = "Pending";
            }

            // Only render if paymentStatus is not "-"
            if (paymentStatus !== "-") {
              ReactDOM.render(
                <div className="d-flex justify-content-center">
                  <div className="">
                    <div className={`${statusClass}`} onClick={handleClick}>
                      {displayText}
                    </div>
                  </div>
                </div>,
                container
              );
            } else {
              // If paymentStatus is "-", render nothing or some specific content for that case
              ReactDOM.render(
                <div className="d-flex justify-content-center">
                  <div className="">
                    <div className="status-other">{displayText}</div>
                  </div>
                </div>,
                container
              );
            }
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
    {
      title: "Actions".toUpperCase(),
      data: null,
      render: (data, type, row, meta) => {
        const id = `actions-${row.sno || Math.random()}`;
        const paymentdate = row.paymentdate;
        const is_verify = row.is_verify;
        const rowIndex = meta.row; // Get the row index
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-center">
                {paymentdate && paymentdate !== "-" ? (
                  <div className="">
                    {is_verify === 0 ? (
                      // Pass a function to the onClick handler
                      <button
                        className="verify-button"
                        onClick={() =>
                          paymentVerify(
                            row.paymentstatus,
                            row.payment_id,
                            row.id,
                            rowIndex
                          )
                        }
                      >
                        Verify
                      </button>
                    ) : (
                      <button className="verify-button">Verified</button>
                      // <span></span>
                    )}
                  </div>
                ) : (
                  <div className="">{"-"}</div>
                )}
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  return (
    <>
      <section className="container ">
        <div className="mt-4 w-100">
          {/* <div className="col-1 d-flex    justify-content-center">
            <Sider />
          </div> */}
          <div className="col-12 ">
            <div className="col-12">
              <Header></Header>
            </div>
            <div className=" pt-1 mt-3 py-3 project-manage w-100 ">
              <div className=" row mt-3 d-flex   w-100 ">
                <div className="col-12 col-md-6  px-4 pt-2">
                  <h className="heading-entr">Accounts Dashboard</h>
                </div>

                <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                  <Breadcrumbs></Breadcrumbs>
                </div>
              </div>
              <section className="col-12 ">
                <div className="row  px-3">
                  <div className="row  gap-2">
                    <div className=" col-3  total-project-accounts pt-3   mx-3">
                      <div
                        className="manage-title  mx-3  d-flex justify-content-around mt-1"
                        onClick={() =>
                          handleProNavigate({ type: "advance_pending" })
                        }
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">Advance Pending</p>
                        <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2">{works.advance_pending}</p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3"
                        onClick={() =>
                          handleProNavigate({ type: "partial_payment_pending" })
                        }
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">
                          Partial Payment Pending
                        </p>
                        <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">
                            {works.partial_payment_pending}
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                        onClick={() =>
                          handleProNavigate({ type: "final_payment_pending" })
                        }
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">
                          Final Payment pending
                        </p>
                        <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">{final}</p>
                        </div>
                      </div>
                    </div>

                    <div className=" col-3  total-project-accounts  pt-3 ">
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-1"
                        onClick={() =>
                          handleProNavigate({ type: "withdrawal" })
                        }
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">Withdraw</p>
                        <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2">
                            {processStatus.withdrawlList_count}
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3"
                        onClick={() => handleProNavigate({ type: "completed" })}
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">Completed</p>
                        <div className="manage-num mt-1    pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">
                            {processStatus.completedList_count}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className=" col-3  total-project-accounts  pt-3 mx-2">
                      <div className="manage-title  mx-3 d-flex justify-content-around mt-1">
                        <p className="mt-1 pt-2 px-2 p-tag">
                          Verfication Pending
                        </p>
                        <div
                          className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center"
                          onClick={() =>
                            handleProNavigate({
                              type: "verification",
                            })
                          }
                        >
                          <p className="p-tag2 ">
                            {processStatus.verificationList_count}
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3 "
                        onClick={() =>
                          handleProNavigate({
                            type: "freelancer",
                          })
                        }
                      >
                        <p className="mt-1 px-2 pt-2 p-tag">
                          Freelancer Payment Pending
                        </p>
                        <div className="manage-num mt-1 pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">
                            {processStatus.freelancerListCount || "0"}
                          </p>
                        </div>
                      </div>
                      <div
                        className="manage-title  mx-3 d-flex justify-content-around mt-3"
                        onClick={() =>
                          handleProNavigate({
                            type: "journalPending",
                          })
                        }
                      >
                        <p className="mt-1 pt-2 px-2 p-tag">
                          Journal Payment Pending
                        </p>
                        <div className="manage-num mt-1  pt-3 d-flex justify-content-around align-items-center">
                          <p className="p-tag2 ">
                            {processStatus.journalList || "0"}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </div>

            {/* account main details */}

            <section className=" mt-2 project-manage w-100 py-0">
              <div className="row  p-3">
                <div className="col-12 ">
                  <h className="heading-entr">Internal </h>
                </div>
                <div className="px-1">
                  <DataTable
                    id="example"
                    data={data}
                    columns={columns}
                    className="display"
                    options={{
                      paging: true,
                      pageLength: 20,
                      lengthMenu: [
                        [20, 30, 50],
                        [20, 30, 50],
                      ],
                      // order: [],
                      scrollX: true,
                    }}
                  />
                </div>
              </div>
            </section>
            {isOpen && (
              <div className="modal-container-view">
                <div className="modal-box">
                  <div className="d-flex justify-content-end">
                    <span className="modal-close " onClick={togglePopup}>
                      &times;
                    </span>
                  </div>
                  <div className="modal-body">
                    <div className="row mb-3">
                      <div className="col-6 text-end project-account">
                        Project ID :
                      </div>
                      <div className="col-6 text-start view-project-title1">
                        {capitalize(modalData.projectId)}
                      </div>
                    </div>
                    <div className="row mb-3">
                      <div className="col-6 text-end project-account">
                        Status :
                      </div>
                      <div className="col-6 text-start view-project-title1">
                        {CapitalizeCaseU(modalData.paymentStatus)}
                      </div>
                    </div>
                    <div className="row mb-3">
                      <div className="col-6 text-end project-account">
                        Amount :
                      </div>
                      <div className="col-6 text-start view-project-title1">
                        {modalData.totalCost}
                      </div>
                    </div>
                  </div>
                  {/* <hr></hr>
                <div className="col text-center view-project-title">
                  Once Project Will Completed After 21 days Amount Will Be
                  Credited
                </div> */}
                </div>
              </div>
            )}

            <section className=" pt-1 mt-3  project-manage-view w-100   ">
              <div className="d-flex flex-wrap  p-3 pt-0 scrollable-section  ">
                <div className="col m-0">
                  <div className="project-todo d-flex justify-content-between gap-5 pb-2 m-1 pt-1">
                    <div>TODO</div>
                    <div className="project-todo-round ">
                      {processStatus.todo_count || "0"}
                    </div>
                  </div>
                  <div className="task-list ">
                    {Array.isArray(tododata) &&
                      tododata.length > 0 &&
                      tododata.map((task, index) => {
                        const isAllEmpty =
                          !task.journal &&
                          !task.writer &&
                          !task.statistican &&
                          !task.reviewer;

                        let level;

                        switch (task.hierarchy_level) {
                          case "urgent_important":
                            level = "U/I";
                            break;
                          case "important_not_urgent":
                            level = "I/NU";
                            break;
                          case "urgent_not_important":
                            level = "U/NI";
                            break;
                          case "not_urgent_not_important":
                            level = "NU/NI";
                            break;
                        }

                        return (
                          <>
                            <Link
                              key={task.id}
                              to={`/accounts-task-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                              <div
                                className={`task-details d-flex justify-content-between m-2 p-2 ${
                                  isAllEmpty ? "bg-yellow" : ""
                                }`}
                              >
                                <div className="m-0 task-name-todo">
                                  {Capitalize(task.project_id)}
                                </div>
                                <div
                                  className="task-comments"
                                  style={{
                                    color:
                                      task.hierarchy_level ===
                                      "urgent_important"
                                        ? "#FF0909" // Red
                                        : task.hierarchy_level ===
                                          "important_not_urgent"
                                        ? "#9932cc" // Yellow
                                        : task.hierarchy_level ===
                                          "urgent_not_important"
                                        ? "#FFA500" // Orange
                                        : task.hierarchy_level ===
                                          "not_urgent_not_important"
                                        ? "#00A300" // Green
                                        : "inherit", // Default
                                  }}
                                >
                                  {level}
                                </div>
                              </div>
                            </Link>
                          </>
                        );
                      })}
                  </div>
                </div>
                <div className="col ">
                  <div className="project-todo1 d-flex gap-5 pb-2 m-1 pt-1">
                    <div>VERIFICATION</div>
                    <div className="project-todo-round ">
                      {processStatus.verificationList_count}
                    </div>

                  
                  </div>
                  <div className="task-list ">
                    {Array.isArray(inworkdata) &&
                      inworkdata.length > 0 &&
                      inworkdata.map((task, index) => {
                        const isAllEmpty =
                          !task.journal &&
                          !task.writer &&
                          !task.statistican &&
                          !task.reviewer;

                        let level;

                        switch (task.hierarchy_level) {
                          case "urgent_important":
                            level = "U/I";
                            break;
                          case "important_not_urgent":
                            level = "I/NU";
                            break;
                          case "urgent_not_important":
                            level = "U/NI";
                            break;
                          case "not_urgent_not_important":
                            level = "NU/NI";
                            break;
                        }

                        return (
                          <>
                            <Link
                              to={`/accounts-task-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                            <div
                              className={`task-details d-flex justify-content-between m-2 p-2 ${
                                isAllEmpty ? "bg-yellow" : "bg-red"
                              }`}
                            >
                              <div className="m-0 task-name-todo">
                                {Capitalize(task.project_id)}
                              </div>
                              <div
                                className="task-comments"
                                style={{
                                  color:
                                    task.hierarchy_level === "urgent_important"
                                      ? "#FF0909" // Red
                                      : task.hierarchy_level ===
                                        "important_not_urgent"
                                      ? "#9932cc" // Yellow
                                      : task.hierarchy_level ===
                                        "urgent_not_important"
                                      ? "#FFA500" // Orange
                                      : task.hierarchy_level ===
                                        "not_urgent_not_important"
                                      ? "#00A300" // Green
                                      : "inherit", // Default
                                }}
                              >
                                {level}
                              </div>
                            </div>
                            </Link>
                          </>
                        );
                      })}
                  </div>
                </div>
                <div className="col ">
                  <div className="project-todo2 d-flex gap-5 pb-2 m-1 pt-1 ">
                    <div>WITHDRAWN</div>
                    <div className="project-todo-round ">
                      {processStatus.withdrawlList_count}
                    </div>
                  </div>
                  <div className="task-list ">
                    {Array.isArray(widthdrawn) &&
                      widthdrawn.length > 0 &&
                      widthdrawn.map((task, index) => {
                        const isAllEmpty =
                          !task.journal &&
                          !task.writer &&
                          !task.statistican &&
                          !task.reviewer;

                        let level;

                        switch (task.hierarchy_level) {
                          case "urgent_important":
                            level = "U/I";
                            break;
                          case "important_not_urgent":
                            level = "I/NU";
                            break;
                          case "urgent_not_important":
                            level = "U/NI";
                            break;
                          case "not_urgent_not_important":
                            level = "NU/NI";
                            break;
                        }

                        return (
                          <>
                            <Link
                              to={`/accounts-task-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                            <div
                              className={`task-details d-flex justify-content-between m-2 p-2 ${
                                isAllEmpty ? "bg-yellow" : ""
                              }`}
                            >
                              <div className="m-0 task-name-todo">
                                {Capitalize(task.project_id)}
                              </div>
                              <div
                                className="task-comments"
                                style={{
                                  color:
                                    task.hierarchy_level === "urgent_important"
                                      ? "#FF0909"
                                      : task.hierarchy_level ===
                                        "important_not_urgent"
                                      ? "#9932cc"
                                      : task.hierarchy_level ===
                                        "urgent_not_important"
                                      ? "#FFA500"
                                      : task.hierarchy_level ===
                                        "not_urgent_not_important"
                                      ? "#00A300"
                                      : "inherit",
                                }}
                              >
                                {level}
                              </div>
                            </div>
                            </Link>
                          </>
                        );
                      })}
                  </div>
                </div>
                <div className="col ">
                  <div className="project-todo4 d-flex gap-5 pb-2 m-1 pt-1">
                    <div>COMPLETED</div>
                    <div className="project-todo-round ">
                      {processStatus.completedList_count}
                    </div>
                  </div>
                  <div className="task-list ">
                    {Array.isArray(completeddata) &&
                      completeddata.length > 0 &&
                      completeddata.map((task, index) => {
                        const isAllEmpty =
                          !task.journal &&
                          !task.writer &&
                          !task.statistican &&
                          !task.reviewer;

                        let level;

                        switch (task.hierarchy_level) {
                          case "urgent_important":
                            level = "U/I";
                            break;
                          case "important_not_urgent":
                            level = "I/NU";
                            break;
                          case "urgent_not_important":
                            level = "U/NI";
                            break;
                          case "not_urgent_not_important":
                            level = "NU/NI";
                            break;
                        }

                        return (
                          <>
                            <Link
                              to={`/accounts-task-view/${task.project_id}`}
                              className="text-decoration-none"
                            >
                            <div
                              className={`task-details d-flex justify-content-between m-2 p-2 ${
                                isAllEmpty ? "bg-yellow" : ""
                              }`}
                            >
                              <div className="m-0 task-name-todo">
                                {Capitalize(task.project_id)}
                              </div>
                              <div
                                className="task-comments"
                                style={{
                                  color:
                                    task.hierarchy_level === "urgent_important"
                                      ? "#FF0909" // Red
                                      : task.hierarchy_level ===
                                        "important_not_urgent"
                                      ? "#9932cc" // Yellow
                                      : task.hierarchy_level ===
                                        "urgent_not_important"
                                      ? "#FFA500" // Orange
                                      : task.hierarchy_level ===
                                        "not_urgent_not_important"
                                      ? "#00A300" // Green
                                      : "inherit", // Default
                                }}
                              >
                                {level}
                              </div>
                            </div>
                            </Link>
                          </>
                        );
                      })}
                  </div>
                </div>
                <div className="col ">
                  <div className="project-todo2 d-flex  pb-2 m-1 pt-1">
                    <div>JOURNAL PAYMENT PENDING</div>
                    <div className="project-todo-round ">
                      {projectStatusCount}
                    </div>
                  </div>

                  <div className="task-list ">
                    {Array.isArray(freelancerProjectcount) &&
                      freelancerProjectcount.length > 0 &&
                      freelancerProjectcount.map((task, index) => {
                        const isAllEmpty =
                          !task.journal &&
                          !task.writer &&
                          !task.statistican &&
                          !task.reviewer;

                        let level;

                        switch (task.project_data.hierarchy_level) {
                          case "urgent_important":
                            level = "U/I";
                            break;
                          case "important_not_urgent":
                            level = "I/NU";
                            break;
                          case "urgent_not_important":
                            level = "U/NI";
                            break;
                          case "not_urgent_not_important":
                            level = "NU/NI";
                            break;
                        }

                        return (
                          <>
                            <Link
                              to={`/accounts-task-view/${task.project_data.project_id}`}
                              className="text-decoration-none"
                            >
                            <div
                              className={`task-details d-flex justify-content-between m-2 p-2 ${
                                isAllEmpty ? "bg-yellow" : ""
                              }`}
                            >
                              <div className="m-0 task-name-todo">
                                {Capitalize(task.project_data.project_id)}
                              </div>
                              <div
                                className="task-comments"
                                style={{
                                  color:
                                    task.project_data.hierarchy_level ===
                                    "urgent_important"
                                      ? "#FF0909" // Red
                                      : task.hierarchy_level ===
                                        "important_not_urgent"
                                      ? "#9932cc" // Yellow
                                      : task.hierarchy_level ===
                                        "urgent_not_important"
                                      ? "#FFA500" // Orange
                                      : task.hierarchy_level ===
                                        "not_urgent_not_important"
                                      ? "#00A300" // Green
                                      : "inherit", // Default
                                }}
                              >
                                {level}
                              </div>
                            </div>
                            </Link>
                          </>
                        );
                      })}
                  </div>
                </div>      
              </div>
            </section>
          </div>
        </div>                                                                                                                              
        <div>
          <Footer />
        </div>
      </section>
    </>
  );
}

export default Accounts_main_dashboard;
