import React from "react";
import Breadcrumbs from "../routes/Breadcrumbs";
import Header from "../components/Header";

function Account_invoice() {
  return (
    <>
      <div className="app-background">
        <section className="container d-flex flex-column justify-content-between min-vh-100">
          <div className="row mt-4">
            <div className="col-12">
              <Header />
              <div className="col-12  mt-3 project-manage-view pb-3 w-100">
                <div className=" row mt-3 d-flex   w-100 ">
                  <div className="col-12 col-md-9  px-4  pt-2">
                    <p className="heading-entr">Invoice</p>
                  </div>
                  <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                    <Breadcrumbs></Breadcrumbs>
                  </div>
                </div>
                <section>
                  <div className="row px-3">
                    <div className="col-12 float-start">
                      <div className="col-12 ">
                        <div className="view-heading-title ">Bill To:</div>
                      </div>
                    </div>
                    <div className="d-flex px-1">
                      <div className="col-12 col-md-8 d-flex flex-column">
                        <div className="row">
                          <div className="col-6">
                            <div className="col-12 col-md-12 float-start pt-2 d-flex  ">
                              <div className=" statis-name-details">
                                Client Name
                              </div>
                              <div className="view-details-data">
                                : Bharathwaj
                              </div>
                            </div>
                            <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                              <div className="statis-name-details  ">
                                Company Name
                              </div>
                              <div className="view-details-data">: Aryu</div>
                            </div>
                            <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                              <div className="statis-name-details  ">
                                Bill Address
                              </div>
                              <div className="view-details-data">
                                : chennai(600201)
                              </div>
                            </div>

                            <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                              <div className="statis-name-details ">Phone</div>

                              <div className="view-details-data">
                                : 985476321
                              </div>
                            </div>

                            <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                              <div className="statis-name-details  ">Email</div>

                              <div className="view-details-data">
                                : bharath123@gmail.com
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <section className="">
                        <div className="col-12 mt-5 pt-5">
                          <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details ">
                              Invoice Number
                            </label>

                            <div className="view-details-data">: 1225487</div>
                          </div>
                          <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details ">
                              Invoice Date
                            </label>

                            <div className="view-details-data">
                              : 20-03-2025
                            </div>
                          </div>
                        </div>
                      </section>
                    </div>
                  </div>
                </section>
                <section>
                  <div class="container mt-4 mx-1">
                    <h2 class="view-heading-title">Service Details :</h2>
                    <table class="table table-striped table-bordered table-hover">
                      <thead class="table-primary">
                        <tr>
                          <th>No</th>
                          <th>Description of Service</th>
                          <th>Quantity</th>
                          <th>Rate per Hour</th>
                          <th>Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>srm</td>
                          <td>Professor</td>
                          <td>Science</td>
                          <td>ABC University</td>
                        </tr>
                        <tr>
                          <td>2</td>
                          <td>medics</td>
                          <td>Researcher</td>
                          <td>Biology</td>
                          <td>XYZ Institute</td>
                        </tr>
                        <tr>
                          <td>1</td>
                          <td>srm</td>
                          <td>Professor</td>
                          <td>Science</td>
                          <td>ABC University</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </section>
                <section className="mx-3">
                  <div className="d-flex justify-content-between">
                    <div>
                      <div className="col-12 ">
                        <div className="view-heading-title ">
                          Terms and Conditions :
                        </div>
                      </div>
                      <div>
                        <ul>
                          <li>Payment is due Upon Receipt of the invoice</li>
                          <li>Payment is due Upon Receipt of the invoice</li>

                          <li>Payment is due Upon Receipt of the invoice</li>
                        </ul>
                      </div>
                    </div>
                    <div className="w-25">
                      <div className="col-12 col-md-12 float-start pt-2 d-flex justify-content-between">
                        <div className="statis-name-details">Subtotal</div>
                        <div className="view-details-data">$12,547.20</div>
                      </div>
                      <div className="col-12 col-md-12 float-start pt-2 d-flex justify-content-between">
                        <div className="statis-name-details">Tax (8%)</div>
                        <div className="view-details-data">$23.20</div>
                      </div>

                      <div className="boder-account">
                        <div className="col-12 col-md-12 float-start pt-2 d-flex justify-content-between">
                          <div className="fw-bold statis-name-details ">
                            Total Amount Due
                          </div>
                          <div className="view-details-data">$231254.20</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>

                <section>
                  <div className="row px-3">
                    <div className="col-12 float-start">
                      <div className="col-12 ">
                        <div className="view-heading-title ">
                          Payment Information:
                        </div>
                      </div>
                    </div>
                    <div className="d-flex px-1">
                      <div className="col-12 col-md-8 d-flex flex-column">
                        <div className="row">
                          <div className="col-6">
                            <div className="col-12 col-md-12 float-start pt-2 d-flex  ">
                              <div className=" statis-name-details">
                                Payment Method
                              </div>
                              <div className="view-details-data">: bank</div>
                            </div>
                            <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                              <div className="statis-name-details  ">
                                Due Date
                              </div>
                              <div className="view-details-data">
                                : 25-06-25
                              </div>
                            </div>
                            <div className="col-12 col-md-12 float-start pt-2 d-flex mb-3 ">
                              <div className="statis-name-details  ">
                                Bank Account
                              </div>
                              <div className="view-details-data">
                                : 12545245-254-525
                              </div>
                            </div>

                            <div className=" mx-2">
                              <div className="view-heading-title">
                                Questions :
                              </div>
                            </div>

                            <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                              <div className="statis-name-details  ">Email</div>

                              <div className="view-details-data">
                                : bharath123@gmail.com
                              </div>
                            </div>

                            <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                              <div className="statis-name-details ">
                                Call us
                              </div>

                              <div className="view-details-data">
                                : 985476321
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <section className="">
                        <div className="col-12 mt-5 pt-5">
                          <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details ">Date</label>

                            <div className="view-details-data">
                              : 20-03-2025
                            </div>
                          </div>
                          <div className="border-account-view mx-1 mt-5"></div>
                          <div className="col-md-12 d-flex pt-2 px-5">
                            Bharathwaj
                          </div>
                        </div>
                      </section>
                    </div>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}

export default Account_invoice;
