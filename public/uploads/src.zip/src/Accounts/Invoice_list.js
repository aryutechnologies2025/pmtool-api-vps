import React from "react";
import "../assests/css/entryprocess.css";
import { API_URL } from "../config.js";
import { IoIosSearch } from "react-icons/io";
// import { IoFilter } from "react-icons/io5";
import { IoMdAdd } from "react-icons/io";
import { VscGitStashPop } from "react-icons/vsc";
import { VscEye } from "react-icons/vsc";
import { NavLink } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
// import { MdKeyboardArrowDown } from "react-icons/md";
import axios from "axios";
// import axios from '../api/axiosConfig.js';

import { FaBookReader } from "react-icons/fa";
import Swal from "sweetalert2";

import DatePicker from "react-datepicker";
import Breadcrumbs from "../routes/Breadcrumbs";

import "react-datepicker/dist/react-datepicker.css";
import Header from "../components/Header.js";

import ReactDOM from "react-dom";

import DataTable from "datatables.net-react";
import DT from "datatables.net-dt";
import "datatables.net-select-dt";
import "datatables.net-responsive-dt";
import { TfiPencilAlt } from "react-icons/tfi";
import { RiDeleteBin6Line } from "react-icons/ri";
import { TbClockExclamation } from "react-icons/tb";
import { Capitalize } from "../campsCase.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { IoIosMailOpen } from "react-icons/io";

import Tooltip from "@mui/material/Tooltip";
import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";
import { getDateFormate } from "../dateFormate.js";
import { saveAs } from "file-saver";
import Papa from "papaparse";
import { Link } from "react-router-dom";
import { FaIndianRupeeSign } from "react-icons/fa6";

import { LuBadgeDollarSign } from "react-icons/lu";
import { format, parseISO } from "date-fns";
import Loader from "../components/Loader.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import { FiDownload } from "react-icons/fi";

DataTable.use(DT);
function Invoice_list() {
  const getTodayDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const [data, setData] = useState([]);

  const [createdby, setcreatedby] = useState("");
  //author name

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const created_by = parsedDetails ? parsedDetails.id : null;

  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const [tabledata, settabledata] = useState([]);

  console.log("tabledata:", tabledata);

  const [pid, setPid] = useState([]);

  console.log("pid:", pid);

  const fetchDatatable = async (params = {}) => {
    const start =
      params.start_date !== undefined ? params.start_date : startDate;
    const end = params.end_date !== undefined ? params.end_date : endDate;
    console.log(createdby);

    try {
      const response = await axios.get(
        `${API_URL}/api/accountant/get-invoice-details`,
        {
          params: {
            start_date: start,
            end_date: end,
          },
        }
      );

      settabledata(response.data);
      const ids = response.data.map((item) => item.ids);
      setPid(ids);

      console.log("invoicedoc:", response.data[4].invoice_doc);

      console.log("all list:", response.data);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  useEffect(() => {
    fetchDatatable();
  }, []);

  const handleFilterClick = () => {
    fetchDatatable({
      start_date: startDate,
      end_date: endDate,
    });
  };

  const handleClearClick = () => {
    setStartDate("");
    setEndDate("");
    fetchDatatable({ start_date: "", end_date: "" });
  };

  const handleStartDateChange = (date) => {
    setStartDate(date ? format(date, "yyyy-MM-dd") : "");
  };

  const handleEndDateChange = (date) => {
    setEndDate(date ? format(date, "yyyy-MM-dd") : "");
  };

  // const handleDownload = async (createdby, date, type, projectid) => {
  //   try {
  //     const updatedData = {
  //       createdby: createdby,
  //       date: date,
  //       type: type,
  //       projectid: projectid,

  //     };

  //     const response = await axios.get(
  //       `${API_URL}/api/accountant/get-invoice-details`,
  //       {
  //         params: updatedData,
  //         responseType: "blob",
  //       }
  //     );

  //     const blob = new Blob([response.data], { type: "application/zip" });

  //     const link = document.createElement("a");
  //     link.href = URL.createObjectURL(blob);
  //     link.download = `${id}_${new Date().toISOString().split("T")[0]}.zip`;

  //     document.body.appendChild(link);
  //     link.click();
  //     document.body.removeChild(link);
  //   } catch (error) {
  //     Swal.fire("Error", "Failed to download", "error");
  //   }
  // };

  const columns = [
    {
      title: " Project ID".toUpperCase(),
      data: "project_id",
      render: (data) => Capitalize(data),
    },
    {
      title: "GST",
      data: "is_gst",
      render: (data) => Capitalize(data),
    },
    {
      title: "Invoice Number".toUpperCase(),
      data: "invoice_no",
      render: (data) => Capitalize(data),
    },
    {
      title: "Payment Status",
      data: "payment_status",
      render: (data) => Capitalize(data),
    },

    {
      title: "Client Name".toUpperCase(),
      data: "client_name",
      render: (data) => `Dr.${Capitalize(data)}`,
    },
    {
      title: "DATE",
      data: "created_date",
      render: (data) => getDateFormate(data),
    },
    {
      title: "SEND CLIENT MAIL",
      data: null,
      render: (data, type, row) => {
        const id = `title-${row.sno || Math.random()}`;

        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div>
                <button
                  className="view-pending"
                  onClick={() => handleSendMail(row.ids)}
                >
                  send mail
                </button>
              </div>,

              container
            );
          }
        }, 0);

        return `<div id="${id}"></div>`;
      },
    },

    {
      title: "ACTIONS",
      data: null,
      render: (data, type, row) => {
        const id = `process-${row.sno || Math.random()}`;
        setTimeout(() => {
          const container = document.getElementById(id);
          if (container && !container.hasChildNodes()) {
            ReactDOM.render(
              <div className="d-flex justify-content-around">
                <div title="Download Invoice">
                  <FiDownload
                    onClick={async () => {
                      try {
                        const invoicepdf = row.invoice_doc;
                        // console.log("invoicepdf :", invoicepdf);
                        const downloadUrl = `${API_URL}/${invoicepdf}`;
                        // const downloadUrl = `${API_URL}/api/accountant/get-invoice-details?invoice_doc=${invoicepdf}`;

                        // console.log("Downloading from:", downloadUrl);

                        // Create temporary link for download
                        const link = document.createElement("a");
                        link.href = downloadUrl;
                        link.setAttribute("download", invoicepdf);
                        link.setAttribute("target", "_blank");
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                      } catch (error) {
                        console.error("Download failed:", error);
                        alert("Download failed or file not found.");
                      }
                    }}
                    style={{ cursor: "pointer" }}
                  />
                </div>
              </div>,
              container
            );
          }
        }, 0);
        return `<div id="${id}"></div>`;
      },
    },
  ];

  const handleSendMail = async (pid) => {
    try {
      // Show confirmation dialog
      const result = await Swal.fire({
        title: "Are you sure?",
        text: "Do you want to send the Mail to the client?",
        showCancelButton: true,
        confirmButtonText: "Send Email",
        cancelButtonText: "No, cancel",
        icon: "warning",
      });

      if (result.isConfirmed) {
        // Show the loading spinner
        document.getElementById("global-loader").style.display = "flex";
        await new Promise((resolve) => setTimeout(resolve, 500));
        const response = await axios.get(
          `${API_URL}/api/accountant/invoice-mail`,
          {
            params: {
              project_id: pid,
            },
          }
        );

        console.log("Mail data:", response.data);

        // Show success message after email is sent
        Swal.fire({
          icon: "success",
          title: "Notification Sent",
          text: "The email notification was sent successfully.",
        });
      } else {
        Swal.fire({
          icon: "error",
          title: "Cancelled",
          text: "The email notification was not sent.",
        });
      }
    } catch (error) {
      console.error("Error fetching mail data:", error);

      // Show error message if fetching fails
      Swal.fire({
        icon: "error",
        title: "Error",
        text: "Failed to fetch mail data.",
      });
    } finally {
      // Hide the loading spinner once the process is complete
      document.getElementById("global-loader").style.display = "none";
    }
  };

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleLoad = () => {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => window.removeEventListener("load", handleLoad);
  }, []);

  if (loading) {
    return <Loader />;
  }

  return (
    <section className="container d-flex flex-column justify-content-between min-vh-100">
      <div className=" row mt-4">
        {/* <div className=" col-1   d-flex justify-content-center">
          <Sider></Sider>
        </div> */}

        <div className="col-12  ">
          <div className="col-12">
            <Header></Header>
          </div>

          <div className="col-12 mt-3 pt-1 wapper w-100 py-5">
            <div className=" row mt-3 d-flex   w-100 ">
              <div className="col-12 col-md-9  px-4 ">
                <p className="heading-entr">Invoice List</p>
              </div>
              <div className=" col-3 pt-3 px-2 d-none d-md-block text-end">
                <Breadcrumbs></Breadcrumbs>
              </div>
            </div>

            <div className="row p-2">
              <div className="col-12 d-flex flex-wrap justify-content-between gap-3">
                <div className="d-flex flex-wrap justify-content-left gap-3">
                  <div className="width-default">
                    <label htmlFor="start-date" className="mx-2">
                      Start-Date
                    </label>
                    <DatePicker
                      type="date"
                      id="start-date"
                      className="form-control-date"
                      selected={startDate ? parseISO(startDate) : null}
                      onChange={handleStartDateChange}
                      autoComplete="off"
                      isClearable
                      dateFormat="yyyy-MM-dd"
                    />
                  </div>

                  <div className="width-default">
                    <label htmlFor="end-date" className="mx-2">
                      End-Date
                    </label>
                    <DatePicker
                      type="date"
                      id="end-date"
                      className="form-control-date"
                      selected={endDate ? parseISO(endDate) : null}
                      onChange={handleEndDateChange}
                      autoComplete="off"
                      isClearable
                      dateFormat="yyyy-MM-dd"
                    />
                  </div>

                  {/* <div className="mt-4 width-default">
                    <select
                      id="type-of-work"
                      className="form-select-date"
                      value={filtertypeofwork}
                      onChange={handleTypeOfWorkChange}
                    >
                      <option value="all">Type Of Work</option>
                      {typeofwork.map((work) => (
                        <option
                          key={work.type_of_work}
                          value={work.type_of_work}
                        >
                          {Capitalize(work.type_of_work)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="width-default">
                    <label htmlFor="institutions" className="px-2">
                      Institutions
                    </label>
                    <select
                      id="institutions"
                      className="form-select-date ms-3 ms-md-0"
                      value={filterIntitution}
                      onChange={handleInstitutionChange}
                    >
                      <option value="all">Institutions</option>
                      {institutions.length > 0 &&
                        institutions.map((work) => (
                          <option key={work.id} value={work.id}>
                            {Capitalize(work.name)}
                          </option>
                        ))}
                    </select>
                  </div> */}

                  {/* <div className="width-default">
                    <label htmlFor="author-name" className="px-2">
                      Author Name
                    </label>
                    <select
                      id="author-name"
                      className="form-select-date ms-3 ms-md-0"
                      value={filterAuthorName}
                      onChange={handleAuthorNameChange}
                    >
                      <option value="all">Select an author</option>
                      {authorname.map((work) => (
                        <option key={work.id} value={work.id}>
                          {Capitalize(work.employee_name) +
                            "/" +
                            Capitalize(work.employee_type)}
                        </option>
                      ))}
                    </select>
                  </div> */}

                  <div className="mt-4">
                    <button
                      className="button-primary"
                      onClick={handleFilterClick}
                    >
                      Filter
                    </button>
                  </div>

                  <div className="mt-4 ">
                    <button
                      className="button-primary-all"
                      onClick={handleClearClick}
                    >
                      All Clear
                    </button>
                  </div>
                  {/* <div className="mt-4 ">
                    <NavLink to="/entry-process/delete-process">
                      <button className="button-primary-delete">
                        Deleted List
                      </button>
                    </NavLink>
                  </div> */}
                </div>
              </div>
            </div>
            <div className="p-2">
              <DataTable
                id="example"
                data={tabledata}
                columns={columns}
                className="display"
                options={{
                  scrollX: true,
                  select: true,
                  pageLength: 20, // Default number of rows per page
                  lengthMenu: [
                    [20, 30, 50],
                    [20, 30, 50],
                  ],
                  order: [],
                }}
              />
            </div>
          </div>
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </section>
  );
}

export default Invoice_list;
