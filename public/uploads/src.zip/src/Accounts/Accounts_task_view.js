import React, { useState, useRef, useEffect } from "react";

import { Link } from "react-router-dom";

import Sider from "../components/Sider";
import { formatDistanceToNow, format } from "date-fns";
import Header from "../components/Header";
import "../assests/css/project-management-view.css";
import "../assests/css/payment_form.css";
import Profile from "../assests/images/profile.png";
import Medicslogo from "../assests/images/medicslogo.svg";
import Breadcrumbs from "../routes/Breadcrumbs";
import { IoMdAdd } from "react-icons/io";
import RichEditor_view from "../components/RichEditor_view.js";
import { Editor } from "primereact/editor";

import { IoMdClose } from "react-icons/io";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import { FiDownload } from "react-icons/fi";
import Select from "react-select";
import { useParams } from "react-router-dom";
import { API_URL } from "../config.js";
import { HRMS_API_URL } from "../config.js";
import { CapitalizeCase } from "../capsUnderCase.js";
import { CapitalizeCaseU } from "../capsUnderCaseU.js";
import Swal from "sweetalert2";
import Footer from "../components/Footer";

import { getTimeDateFormate } from "../getTimeDateFormate.js";
import { getDateFormate } from "../dateFormate.js";
import axios from "axios";
import Loader from "../components/Loader.js";
import { faChevronRight } from "@fortawesome/free-solid-svg-icons";

import PDF from "../assests/images/pdf.svg";
import Excel from "../assests/images/excel.svg";

import Word from "../assests/images/word.svg";
import Image from "../assests/images/image.svg";

import logoImage from "../assests/images/Vector.svg";

import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { formatIndianCurrency } from "../AmountFormet.js";

function Accounts_task_view() {
  const { id } = useParams();

  //  const [formData, setFormData] = useState({

  //   });

  const [showGst, setShowGst] = useState(null);
  // const [dueDate, setSelectedDueDate] = useState(null);

  const invoiceRef = useRef();

  // const handleDownloadPDF = () => {
  //   const input = invoiceRef.current;

  //   html2canvas(input, { scale: 2 }).then((canvas) => {
  //     const imgData = canvas.toDataURL("image/png");
  //     const pdf = new jsPDF("p", "mm", "a4");

  //     const topMargin = 20;
  //     const sideMargin = 10;
  //     const pageWidth = 280;
  //     const pageHeight = 300;

  //     const imgWidth = pageWidth - sideMargin * 2;
  //     const imgHeight = (canvas.height * imgWidth) / canvas.width;

  //     let yPos = topMargin;
  //     while (yPos < imgHeight) {
  //       pdf.addImage(imgData, "PNG", sideMargin, yPos, imgWidth, imgHeight);
  //       yPos += pageHeight - topMargin;
  //       if (yPos < imgHeight) {
  //         pdf.addPage();
  //         yPos = topMargin;
  //       }
  //     }

  //     pdf.text("",10, 10);
  //     pdf.save("invoice.pdf");
  //   });
  // };

  //   const handleDownloadPDF = () => {
  //     const input = invoiceRef.current;

  //     html2canvas(input, { scale: 3 }).then((canvas) => {
  //         const imgData = canvas.toDataURL("image/png");
  //         const pdf = new jsPDF("p", "mm", "a4");

  //         const imgWidth = 280; // Full width of A4 in mm
  //         const imgHeight = 280; // Maintain aspect ratio

  //         if (imgHeight > 600) {
  //             pdf.internal.pageSize.height = imgHeight;
  //         }

  //         pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
  //         pdf.save("invoice.pdf");
  //     });
  // };

  const storedDetatis = localStorage.getItem("medicsuser");
  const parsedDetails = JSON.parse(storedDetatis);
  const createdby = parsedDetails ? parsedDetails.id : null;

  // const handleDownloadPDF = async () => {
  //   const input = invoiceRef.current;
  //   document.getElementById("global-loader").style.display = "flex";
  //   setTimeout(async () => {
  //   try {
  //     await new Promise((resolve) => setTimeout(resolve, 1000));

  //     const canvas = await html2canvas(input, {
  //       scale: 2,
  //       useCORS: true,
  //       logging: true,
  //       ignoreElements: (element) => {
  //         return false;
  //       },
  //       onclone: (clonedDoc) => {
  //         const images = clonedDoc.querySelectorAll("img");
  //         images.forEach((img) => {
  //           if (!img.style.display || img.style.display === "none") {
  //             img.style.display = "block";
  //           }
  //         });
  //       },
  //     });

  //     const formData = new FormData();
  //     formData.append("project_id", invoice.id);
  //     formData.append("invoice_no", invoicenum);
  //     formData.append("is_gst", showGst ? "yes" : "no");
  //     formData.append("created_date", entrydate);
  //     formData.append("created_by", createdby);
  //     formData.append("invoice_doc", pdfBlob, `${invoicenum.replace("#", "")}.pdf`);
  //     try {
  //       const response = await axios.post(
  //         `${API_URL}/api/accountant/store_invoice_details`, formData, {
  //         headers: {
  //           "Content-Type": "multipart/form-data",
  //         },
  //     });

  //       console.log("Invoice stored:", response);
  //     } catch (error) {
  //       console.error("Error posting invoice details:", error);
  //     }
  //     if (!canvas) {
  //       console.error("Canvas is empty!");
  //       return;
  //     }

  //     const imgData = canvas.toDataURL("image/jpeg", 0.85);
  //     const pdf = new jsPDF("p", "mm", "a4");
  //     const margin = 8;
  //     const imgWidth = 275 - 2 * margin;
  //     const imgHeight = 297 - 2 * margin;

  //     pdf.addImage(imgData, "JPEG", margin, margin, imgWidth, imgHeight);
  //     const pdfBlob = pdf.output("blob");
  //     pdf.save(`${invoicenum.replace('#', '')}.pdf`);
  //     Swal.fire({
  //       icon: "success",
  //       title: "Downloaded!",
  //       text: "Invoice downloaded successfully.",
  //       timer: 2000,
  //       showConfirmButton: false,
  //     });
  //       } catch (err) {
  //     console.error("Error generating PDF:", err);
  //   } finally {
  //     document.getElementById("global-loader").style.display = "none";
  //   }
  // }, 500);
  // };

  // const handleDownloadPDF = () => {
  //   const input = invoiceRef.current;

  //   html2canvas(input, {
  //     scale: 3,
  //     useCORS: true, // Enable cross-origin handling
  //     allowTaint: true, // Allow tainted images
  //   }).then((canvas) => {
  //     const imgData = canvas.toDataURL("image/png");
  //     const pdf = new jsPDF("p", "mm", "a4");

  //     const margin = 8;
  //     const imgWidth = 275 - 2 * margin;
  //     const imgHeight = 297 - 2 * margin;

  //     pdf.addImage(imgData, "PNG", margin, margin, imgWidth, imgHeight);
  //     pdf.save("invoice.pdf");
  //   });
  // };

  // ap

  const [selectedDueDate, setSelectedDueDate] = useState("");
  const [isDueDateInvalid, setIsDueDateInvalid] = useState(false);

  // const handleDownloadPDF = async () => {
  //   const confirmResult = await Swal.fire({
  //     title: "Generate Invoice?",
  //     text: "Do you want to generate and download this invoice?",
  //     icon: "question",
  //     showCancelButton: true,
  //     confirmButtonText: "Yes, generate it!",
  //     cancelButtonText: "Cancel",
  //   });
  //   if (!confirmResult.isConfirmed) return;
  //   const input = invoiceRef.current;
  //   document.getElementById("global-loader").style.display = "flex";

  //   setTimeout(async () => {
  //     try {
  //       await new Promise((resolve) => setTimeout(resolve, 1000));

  //       const canvas = await html2canvas(input, {
  //         scale: 2,
  //         useCORS: true,
  //         logging: true,
  //         ignoreElements: () => false,
  //         onclone: (clonedDoc) => {
  //           const images = clonedDoc.querySelectorAll("img");
  //           images.forEach((img) => {
  //             if (!img.style.display || img.style.display === "none") {
  //               img.style.display = "block";
  //             }
  //           });
  //         },
  //       });

  //       if (!canvas) {
  //         console.error("Canvas is empty!");
  //         return;
  //       }

  //       const imgData = canvas.toDataURL("image/jpeg", 0.85);
  //       const pdf = new jsPDF("p", "mm", "a4");
  //       const margin = 8;
  //       const imgWidth = 275 - 2 * margin;
  //       const imgHeight = 297 - 2 * margin;
  //       pdf.addImage(imgData, "JPEG", margin, margin, imgWidth, imgHeight);
  //       pdf.save(`${invoicenum.replace('#', '')}.pdf`);

  //       // Convert PDF to Blob
  //       const pdfBlob = pdf.output("blob");

  //       // Prepare FormData
  //       const formData = new FormData();
  //       formData.append("project_id", invoice.id);
  //       formData.append("invoice_no", invoicenum);
  //       formData.append("is_gst",  gstOption);
  //       formData.append("due_date",dueDate)
  //       formData.append("created_date", entrydate);
  //       formData.append("created_by", createdby);
  //       formData.append("invoice_doc", pdfBlob,`${invoicenum.replace('#', '')}.pdf`);

  //       // Debug: confirm the file is present
  //       console.log("FormData entries:", [...formData.entries()]);

  //       const response = await axios.post(`${API_URL}/api/accountant/store-invoice-details`, formData);

  //       console.log("Upload success:", response.data);

  //       Swal.fire({
  //         icon: "success",
  //         title: "Generate!",
  //         text: "Invoice Generate successfully.",
  //         timer: 2000,
  //         confirmButtonText: "OK",
  //         showConfirmButton: true,
  //       });

  //     } catch (err) {
  //       console.error("Upload error:", err.response?.data || err);
  //       Swal.fire({
  //         icon: "error",
  //         title: "Upload Failed",
  //         text: err.response?.data?.message || "Something went wrong.",
  //       });
  //     } finally {
  //       document.getElementById("global-loader").style.display = "none";
  //     }
  //   }, 500);
  // };

  const [invoice, setInvoiceDetails] = useState([]);
  console.log("invoice:", invoice);

  console.log("invoice id :", invoice.id);

  const trimmedAmount = Math.abs(invoice.received_amount);
  const [settingInvoice, setInvoiceSettingDetails] = useState([]);
  const [signature, setSignatureImage] = useState([]);
  console.log("signature :", signature);
  // console.log("settingInvoice :", settingInvoice);

  const [totalAmount, setTotalAmountDue] = useState(0);
  const [gstAmount, setGstAmount] = useState(0);
  const [igst, setIGST] = useState(0);
  const [cgst, setCGST] = useState(0);
  const [sgst, setSGST] = useState(0);
  const [gstOption, setGstOption] = useState("exclusive"); // "inclusive", "exclusive", "without"
  const gstRate = 0.18; // 18% GST

  // Assume this comes from your business logic (e.g., interstate=true → IGST)

  useEffect(() => {
    const baseAmount = invoice.total_received_amount || 0;
    let calculatedGst, taxableAmount;
    if (gstOption === "without") {
      // Without GST → No tax applied
      // setShowGst(false);
      // setTotalAmountDue(baseAmount);
      // setGstAmount(0);
      // return;
      setShowGst(true);
      taxableAmount = baseAmount;
      calculatedGst = baseAmount * gstRate;
      setTotalAmountDue(baseAmount + calculatedGst);
    }

    if (gstOption === "inclusive") {
      // GST is INCLUDED → Extract GST from total
      setShowGst(true);
      taxableAmount = baseAmount / (1 + gstRate);
      calculatedGst = baseAmount - taxableAmount;
      setTotalAmountDue(baseAmount); // No change (GST already included)
    } else {
      // GST is EXCLUSIVE → Add GST on top

      setShowGst(false);
      setTotalAmountDue(baseAmount);
      setGstAmount(0);
      return;
    }

    setGstAmount(calculatedGst);

    // Auto-determine IGST or CGST+SGST (no radio selection)
    if (showGst) {
      // Interstate → IGST (18%)
      const splitTax = calculatedGst / 2;
      // setShowGst(true);
      setIGST(calculatedGst);
      setCGST(splitTax);
      setSGST(splitTax);
    } else {
      // Intrastate → CGST + SGST (9% each)
      // setShowGst(true);
      const splitTax = calculatedGst / 2;
      setIGST(calculatedGst);
      setCGST(splitTax);
      setSGST(splitTax);
    }
  }, [gstOption, invoice.total_received_amount]);

  // console.log("total_received_amount :",invoice.total_received_amount);
  // console.log("totalAmount :",totalAmount);
  // console.log("totaligst :",totaligst);
  // console.log("totalcgst :",totalcgst);
  // console.log("totalsgst :",totalsgst);

  const paymentData = [
    {
      thesis: invoice.projectId,
      quantity: 1,
      amount: invoice.total_received_amount,
      total: invoice.total_received_amount,
    },
  ];

  const handleDownloadPDF = async () => {
    if (!selectedDueDate) {
      setIsDueDateInvalid(true);
      Swal.fire({
        icon: "warning",
        title: "Missing Due Date",
        text: "Please select a due date before generating the invoice.",
      });
      return;
    }

    const confirmResult = await Swal.fire({
      title: "Generate Invoice?",
      text: "Do you want to generate and download this invoice?",
      icon: "question",
      showCancelButton: true,
      confirmButtonText: "Yes, generate it!",
      cancelButtonText: "Cancel",
    });

    if (!confirmResult.isConfirmed) return;

    const input = invoiceRef.current;
    document.getElementById("global-loader").style.display = "flex";

    setTimeout(async () => {
      try {
        await new Promise((resolve) => setTimeout(resolve, 1000));

        const canvas = await html2canvas(input, {
          scale: 2,
          useCORS: true,
          logging: true,
          ignoreElements: () => false,
          onclone: (clonedDoc) => {
            const images = clonedDoc.querySelectorAll("img");
            images.forEach((img) => {
              if (!img.style.display || img.style.display === "none") {
                img.style.display = "block";
              }
            });
          },
        });

        if (!canvas) {
          console.error("Canvas is empty!");
          return;
        }

        const imgData = canvas.toDataURL("image/jpeg", 0.85);

        // Create a new jsPDF instance with A4 size
        const pdf = new jsPDF("p", "mm", "a4");
        const margin = 1; // Increased margin for better spacing
        const imgWidth = 277 - 0 * margin; // A4 width - margins
        const imgHeight = 297 - 2 * margin; // A4 height - margins

        // Add image to PDF with appropriate width and height
        pdf.addImage(imgData, "JPEG", margin, margin, imgWidth, imgHeight);
        pdf.setFontSize(12);
        // pdf.save(`${invoicenum.replace("#", "")}.pdf`);

        const pdfBlob = pdf.output("blob");

        const formData = new FormData();
        formData.append("project_id", invoice.id);
        formData.append("invoice_no", invoicenum);
        formData.append("is_gst", gstOption);
        formData.append("payment_status", paymentStatus);
        formData.append("due_date", selectedDueDate);
        formData.append("created_date", entrydate);
        formData.append("created_by", createdby);
        formData.append(
          "invoice_doc",
          pdfBlob,
          `${invoicenum.replace("#", "")}.pdf`
        );

        console.log("FormData entries:", [...formData.entries()]);
       
        const response = await axios.post(
          `${API_URL}/api/accountant/store-invoice-details`,
          formData
        );

        console.log("Upload success:", response.data);

        Swal.fire({
          icon: "success",
          title: "Generate!",
          text: "Invoice generated successfully.",
          timer: 2000,
          confirmButtonText: "OK",
          showConfirmButton: true,
        });
      } catch (err) {
        console.error("Upload error:", err.response?.data || err);
        Swal.fire({
          icon: "error",
          title: "Upload Failed",
          text: err.response?.data?.message || "Something went wrong.",
        });
      } finally {
        document.getElementById("global-loader").style.display = "none";
      }
    }, 500);
  };

  console.log("id:", id);
  const [entrydate, setEntrydata] = useState([]);
  const [invoicenum, setInvoicenum] = useState([]);

  console.log("dateentry:", entrydate);
  console.log("InvoiceNumber:", invoicenum);

  const fetchInvoiceData = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/api/accountant/payment-invoice`,
        {
          params: {
            project_id: id,
          },
        }
      );

      console.log("response :", response.data);

      setEntrydata(response.data.data[0].entry_date);
      setInvoicenum(response.data.data[0].invoice_number);

      const fetchData = response.data.data;
      const formedData = (Array.isArray(fetchData) ? fetchData : []).map(
        (item) => ({
          id: item?.id ?? "",
          projectId: item?.project_id ?? "",
          title: item?.title ?? "",
          client_name: item?.client_name ?? "",
          email: item?.email ?? "",
          contact_number: item?.contact_number ?? "",
          profession: item?.profession?.name ?? "",
          institute: item?.institute?.name ?? "",
          department: item?.department?.name ?? "",
          process_status: item?.process_status ?? "",
          project_status: item?.project_status ?? "",
          payment_status: item?.payment_process?.payment_status ?? "",
          invoice_date:
            item?.payment_process?.payment_data[0]?.payment_date ?? "",
          budget: item?.budget ?? 0,
          total_pending_amount: item?.total_pending_amount ?? 0,
          received_amount: Math.abs(item?.received_amount ?? 0),
          total_received_amount: Math.abs(item?.total_received_amount ?? 0),
          advance_pending_total: item?.advance_pending_total ?? 0,
          partial_payment_pending_total:
            item?.partial_payment_pending_total ?? 0,
        })
      );

      const fetchSettingData = response.data.settings;
      console.log("fetchSettingData :", fetchSettingData);
      const formedSettingData = (
        Array.isArray(fetchSettingData) ? fetchSettingData : []
      ).map((item) => ({
        account_number: item?.account_number ?? "",
        address: item?.address ?? "",
        email: item?.email ?? "",
        bank_name: item?.bank_name ?? "",
        branch_name: item?.branch_name ?? "",
        company_name: item?.company_name ?? "",
        contact_no: item?.contact_no ?? "",
        ifsc: item?.ifsc ?? "",
        name: item?.name ?? "",
        phone_number: item?.phone_number ?? "",
        sign_image: item?.sign_image ?? "",
        payment_status: item?.payment_process?.payment_status ?? "",
        budget: item?.budget ?? 0,
        received_amount: item?.total_received_amount ?? 0,
        advance_payment: item?.advance_pending_total ?? 0,
        partial_payment_amount: item?.partial_payment_pending_total ?? 0,
      }));

      console.log("Processed Data:", formedData);

      // If you're sure there's always exactly one item, get the first object
      const invoiceData = formedData[0];
      const invoiceSettingData = formedSettingData[0];
      setInvoiceDetails(invoiceData);
      setInvoiceSettingDetails(invoiceSettingData);
      setSignatureImage(
        invoiceSettingData.sign_image
          ? `${API_URL}/signatures/${invoiceSettingData.sign_image}`
          : null
      );

      console.log("invoiceData :", invoiceData);

      // console.log("projectid:",response.data);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };
  useEffect(() => {
    if (id) {
      fetchInvoiceData();
    }
  }, [id]);

  const [paymentStatus, setPaymentStatus] = useState("");



  return (
    <>
      <div className="app-background">
        <section className="container d-flex flex-column justify-content-between min-vh-100">
          <div className="row mt-4">
            <div className="col-12">
              <Header />
              <div className="col-12  mt-3 project-manage-view pb-3 w-100">
                <div className=" row mt-3 d-flex   w-100 ">
                  <div className="col-12 col-md-6  px-4 ">
                    <div className="view-heading ">
                      {CapitalizeCaseU(invoice.projectId)}
                    </div>
                  </div>
                  <div className=" col-6 pt-3 px-2 d-none d-md-block text-end">
                    <Breadcrumbs></Breadcrumbs>
                  </div>
                </div>

                <div className="row mb-2">
                  <section className="col-7 ">
                    <div className="row px-3">
                      <div className="col-12 float-start">
                        <div className="col-12 ">
                          <div className="view-heading-title ">
                            Project Title:
                            <span className="view-project-title mx-2 ">
                              {CapitalizeCaseU(invoice.title)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="d-flex px-1">
                      <section className="">
                        <div className="col-12">
                          <label className="heading-entr mt-1 px-2 ">
                            Client Informations
                          </label>
                        </div>
                        <div className="col-12">
                          <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details ">
                              Client Name
                            </label>

                            <div className="view-details-data">
                              : {CapitalizeCaseU(invoice.client_name)}
                            </div>
                          </div>

                          <div className="col-md-12 d-flex  pt-2">
                            <label className="statis-name-details ">
                              Email ID
                            </label>

                            <div className="view-details-data">
                              : {invoice.email}
                            </div>
                          </div>

                          <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details ">
                              Contact No
                            </label>

                            <div className="view-details-data">
                              : {invoice.contact_number}
                            </div>
                          </div>

                          <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details  ">
                              Institute
                            </label>

                            <div className="view-details-data">
                              : {invoice.institute}
                            </div>
                          </div>
                          <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details">
                              Department
                            </label>

                            <div className="view-details-data">
                              : {invoice.department}
                            </div>
                          </div>

                          <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details ">
                              Profession
                            </label>

                            <div className="view-details-data">
                              : {invoice.profession}
                            </div>
                          </div>
                        </div>
                      </section>
                      <section className="">
                        <div className="col-12">
                          <label className="heading-entr mt-1 px-2 ">
                            Payment Information
                          </label>
                        </div>
                        <div className="col-12">
                          <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details ">
                              Process Status
                            </label>

                            <div className="view-details-data">
                              : {CapitalizeCaseU(invoice.process_status)}
                            </div>
                          </div>

                          <div className="col-md-12 d-flex  pt-2">
                            <label className="statis-name-details ">
                              Payment Status
                            </label>

                            <div className="view-details-data">
                              : {CapitalizeCaseU(invoice.payment_status)}
                            </div>
                          </div>

                          <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details ">
                              Budget
                            </label>

                            <div className="view-details-data">
                              : {formatIndianCurrency(invoice.budget)}
                            </div>
                          </div>

                          <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details  ">
                              Advance Payment
                            </label>

                            <div className="view-details-data">
                              :{" "}
                              {formatIndianCurrency(
                                invoice.advance_pending_total
                              )}
                            </div>
                          </div>
                          <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details">
                              Partial Payment Amount
                            </label>

                            <div className="">
                              :{" "}
                              {formatIndianCurrency(
                                invoice.partial_payment_pending_total
                              )}
                            </div>
                          </div>

                          {/* <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details ">
                              Recevied Amount
                            </label>

                            <div className="view-details-data">
                              : {CapitalizeCaseU(invoice.total_received_amount)}
                            </div>
                          </div> */}
                          <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details ">
                              Balance Amount
                            </label>

                            <div className="view-details-data">
                              : ₹{trimmedAmount}
                            </div>
                          </div>
                          {/* <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details">Select Due Date</label>:
                            <div className="view-details-data mx-2">
                              <input 
                                type="date" 
                                onChange={(e) => setSelectedDueDate(e.target.value)} 
                                className="form-control due-date"
                              />
                            </div>
                          </div> */}

                          <div className="col-md-12 d-flex pt-2">
                            <label className="statis-name-details">
                              Select Due Date
                            </label>
                            :
                            <div className="view-details-data mx-2">
                              <input
                                type="date"
                                value={selectedDueDate}
                                onChange={(e) => {
                                  setSelectedDueDate(e.target.value);
                                  setIsDueDateInvalid(false); // clear red when valid
                                }}
                                className={`form-control due-date ${
                                  isDueDateInvalid ? "is-invalid" : ""
                                }`}
                              />
                              {isDueDateInvalid && (
                                <div className="invalid-feedback d-block">
                                  Please select a due date.
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="d-flex">
                            {/* Option 1: GST Inclusive */}
                            <div className="form-check mx-2">
                              <input
                                className="form-check-input"
                                type="radio"
                                id="inclusive"
                                name="gstoption"
                                value="inclusive"
                                checked={gstOption === "inclusive"}
                                onChange={() => setGstOption("inclusive")}
                              />
                              <label
                                className="label-public-name"
                                htmlFor="inclusive"
                              >
                                GST Inclusive
                              </label>
                            </div>

                            {/* Option 2: GST Exclusive */}
                            <div className="form-check mx-2">
                              <input
                                className="form-check-input"
                                type="radio"
                                id="exclusive"
                                name="gstoption"
                                value="exclusive"
                                checked={gstOption === "exclusive"}
                                onChange={() => setGstOption("exclusive")}
                              />
                              <label
                                className="label-public-name"
                                htmlFor="exclusive"
                              >
                                GST Exclusive
                              </label>
                            </div>

                            {/* Option 3: Without GST */}
                            <div className="form-check mx-2">
                              <input
                                className="form-check-input"
                                type="radio"
                                id="without"
                                name="gstoption"
                                value="without"
                                checked={gstOption === "without"}
                                onChange={() => setGstOption("without")}
                              />
                              <label
                                className="label-public-name"
                                htmlFor="without"
                              >
                                Without GST
                              </label>
                            </div>
                          </div>

                          <div className="d-flex  align-items-center">
                            {/* Paid */}
                            <div className="form-check mx-2">
                              <input
                                className="form-check-input"
                                type="radio"
                                id="paid"
                                name="paymentStatus"
                                value="paid"
                                checked={paymentStatus === "paid"}
                                onChange={() => setPaymentStatus("paid")}
                              />
                              <label
                                className="label-public-name"
                                htmlFor="paid"
                              >
                                Paid
                              </label>
                            </div>

                            {/* Unpaid */}
                            <div className="form-check mx-2">
                              <input
                                className="form-check-input "
                                type="radio"
                                id="unpaid"
                                name="paymentStatus"
                                value="unpaid"
                                checked={paymentStatus === "unpaid"}
                                onChange={() => setPaymentStatus("unpaid")}
                              />
                              <label
                                className="label-public-name"
                                htmlFor="unpaid"
                              >
                                Unpaid
                              </label>
                            </div>

                            {/* Pending */}
                            <div className="form-check mx-2">
                              <input
                                className="form-check-input"
                                type="radio"
                                id="pending"
                                name="paymentStatus"
                                value="pending"
                                checked={paymentStatus === "pending"}
                                onChange={() => setPaymentStatus("pending")}
                              />
                              <label
                                className="label-public-name"
                                htmlFor="pending"
                              >
                                Pending
                              </label>
                            </div>
                          </div>
                        </div>
                      </section>
                    </div>
                  </section>
                </div>

                {/* invoice */}
                <div className="mx-2">
                  <button
                    className="save-form-task mb-2 pt-1"
                    onClick={handleDownloadPDF}
                  >
                    Generate invoice
                  </button>
                </div>
                <div ref={invoiceRef} className=" ">
                  <section className="invoice-all-border ">
                    <div className="d-flex justify-content-between px-1  boder-black-bottom">
                      <div className="pt-3 px-2">
                        <img
                          className="img-fluid header-logo"
                          src={logoImage}
                          alt="img"
                        />
                      </div>
                      <div>
                        <div className=" invoice-title  ">INVOICE</div>
                        {paymentStatus && (
                          <div className={`status-box-pay ${paymentStatus}`}>
                            {paymentStatus.charAt(0).toUpperCase() +
                              paymentStatus.slice(1)}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="col-12  boder-black-bottom">
                      <div className="col-12 d-flex mt-1  mx-2">
                        <label className="invoice-length ">
                          Invoice Number
                        </label>

                        <div className="">: {invoicenum}</div>
                      </div>
                      <div className="col-md-12 d-flex pt-2 mx-2">
                        <label className="invoice-length ">Invoice Date</label>

                        <div className="">
                          :{" "}
                          {getDateFormate(invoice.invoice_date) || "dd-mm-yyyy"}
                        </div>
                      </div>
                      <div className="col-md-12 d-flex pt-2 mx-2">
                        <label className="invoice-length">
                          Invoice Due Date
                        </label>
                        <div className="">
                          :{" "}
                          {selectedDueDate
                            ? getDateFormate(selectedDueDate)
                            : "dd-mm-yyyy"}
                        </div>
                      </div>
                    </div>
                    <section>
                      <div className="row px-3  ">
                        <div className="d-flex px-1">
                          <div className="col-12 col-md-6 d-flex flex-column boder-black-right pt-2 pb-1">
                            <div className="row">
                              <div className="col-12 float-start ">
                                <div className="col-12 mx-2 ">
                                  <div className="view-heading-title fw-bold ">
                                    From :
                                  </div>
                                </div>
                              </div>
                              <div className="col-12 ">
                                <div className="col-12 col-md-12 float-start pt-1 d-flex mx-2 ">
                                  <div className=" invoice-all-head">
                                    {CapitalizeCaseU(
                                      settingInvoice.company_name
                                    )}
                                  </div>
                                </div>
                              </div>
                              <div className="col-12">
                                <div className="col-12 col-md-12 float-start pt-1 d-flex mx-2 ">
                                  <div className=" invoice-all-head">
                                    {CapitalizeCaseU(settingInvoice.name)}
                                  </div>
                                </div>
                                <div className="col-12 col-md-12 float-start pt-1 d-flex mx-2 ">
                                  <div className="invoice-all-head">
                                    {CapitalizeCaseU(settingInvoice.address)}
                                  </div>
                                </div>
                                <div className="col-12 col-md-12 float-start pt-1 d-flex mx-2 ">
                                  <div className="invoice-all-head  ">
                                    91 {settingInvoice.phone_number}
                                  </div>
                                </div>

                                <div className="col-12 col-md-12 float-start pt-1 d-flex mx-2">
                                  <div className="invoice-all-head ">
                                    {settingInvoice.email}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          {/*  */}

                          <div className="col-12 col-md-6 d-flex flex-column pt-2 pb-1">
                            <div className="row">
                              <div className="col-12 float-start">
                                <div className="col-12 mx-2">
                                  <div className="view-heading-title fw-bold ">
                                    To :
                                  </div>
                                </div>
                              </div>
                              <div className="col-12">
                                <div className="col-12 col-md-12 float-start pt-1 d-flex mx-2 ">
                                  <div className=" invoice-all-head">
                                    {CapitalizeCaseU(invoice.client_name)}
                                  </div>
                                </div>
                              </div>
                              <div className="col-12">
                                {/* <div className="col-12 col-md-12 float-start pt-1 d-flex mx-2 ">
                                  <div className=" invoice-all-head">xxxxx</div>
                                </div>
                                <div className="col-12 col-md-12 float-start pt-1 d-flex mx-2 ">
                                  <div className="invoice-all-head">
                                    No 33/ 14 , Ground floor, Jayammal St,
                                    Ayyavoo Colony, Aminjikarai, Chennai, Tamil
                                    Nadu 600029
                                  </div>
                                </div> */}

                                <div className="col-12 col-md-12 float-start pt-1 d-flex mx-2 ">
                                  <div className=" invoice-all-head">
                                    {invoice.institute}
                                  </div>
                                </div>

                                <div className="col-12 col-md-12 float-start pt-1 d-flex mx-2 ">
                                  <div className="invoice-all-head  ">
                                    91 {invoice.contact_number}
                                  </div>
                                </div>

                                <div className="col-12 col-md-12 float-start pt-1 d-flex mx-2">
                                  <div className="invoice-all-head ">
                                    {invoice.email}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </section>
                    <section className="boder-black-top">
                      <div class="container mt-2 mx-1">
                        <h2 class="fw-bold view-heading-title">
                          Service Details :
                        </h2>
                        <table class="table table-striped table-bordered table-hover">
                          <thead class="table-primary">
                            <tr>
                              <th className="invoice-table">#</th>
                              <th className="invoice-table-project">
                                Item & Description
                              </th>
                              <th className="invoice-table">Qty</th>
                              <th className="invoice-table">Rate</th>
                              <th className="invoice-table">Amount</th>
                            </tr>
                          </thead>
                          <tbody>
                            {paymentData.map((item, index) => (
                              <tr key={item.id}>
                                <td>{index + 1}</td>
                                <td className=" text-start px-2">
                                  {item.thesis}
                                </td>
                                <td>{item.quantity}</td>
                                <td>
                                  {/* {item.amount.toLocaleString("en-IN", {
                                    style: "currency",
                                    currency: "INR",
                                  })} */}
                                  {formatIndianCurrency(invoice.budget)}
                                </td>
                                <td>
                                  {/* {item.total.toLocaleString("en-IN", {
                                    style: "currency",
                                    currency: "INR",
                                  })} */}
                                  {formatIndianCurrency(invoice.budget)}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </section>
                    <section className="mx-3">
                      <div className="row">
                        <div className="col-9">
                          <div className="col-12 ">
                            <div className="fw-bold view-heading-title ">
                              Notes :
                            </div>
                          </div>
                          <div>
                            <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                              <div className="invoice-length-payment">
                                Advance Payment
                              </div>
                              <div className="">
                                :{" "}
                                {formatIndianCurrency(
                                  invoice.advance_pending_total
                                )}
                              </div>
                            </div>
                            <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                              <div className="invoice-length-payment">
                                Partial Payment Amount
                              </div>
                              <div className="">
                                :{" "}
                                {formatIndianCurrency(
                                  invoice.partial_payment_pending_total
                                )}
                              </div>
                            </div>
                            {/* <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                              <div className="invoice-length-payment">
                                Recevied Amount
                              </div>
                              <div className="">
                                : {invoice.total_received_amount}
                              </div>
                            </div> */}
                            <div className="col-12 col-md-12 float-start pt-2 d-flex  ">
                              <div className="invoice-length-payment">
                                Balance Amount
                              </div>
                              <div className="">
                                :{" "}
                                {formatIndianCurrency(invoice.received_amount)}
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-3 boder-black ">
                          <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                            <div className="invoice-length">Subtotal</div>
                            <div className="">
                              {formatIndianCurrency(
                                invoice.total_received_amount
                              )}
                            </div>
                          </div>

                          {showGst && (
                            <>
                              <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                                <div className="invoice-length">GST Rate</div>
                                <div className="">18%</div>
                              </div>
                              {/* <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                                <div className="invoice-length">IGST</div>
                                <div className="">{formatIndianCurrency(igst)}</div>
                              </div> */}
                              <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                                <div className="invoice-length">CGST(9%)</div>
                                <div className="">
                                  {formatIndianCurrency(cgst)}
                                </div>
                              </div>
                              <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                                <div className="invoice-length">SGST(9%)</div>
                                <div className="">
                                  {formatIndianCurrency(sgst)}
                                </div>
                              </div>
                            </>
                          )}

                          <hr></hr>
                          <div className="col-12 col-md-12 float-start pt-2 d-flex ">
                            <div className="fw-bold invoice-length ">Total</div>
                            {/* <div className="">₹1,129.25</div> */}
                            <div className="fw-bold ">
                              {formatIndianCurrency(totalAmount)}
                            </div>
                          </div>
                          <hr></hr>
                          <div className="col-12 col-md-12 float-start pt-2 d-flex  ">
                            <div className="fw-bold invoice-length  ">
                              Balance Due
                            </div>
                            {/* <div className="">₹1,129.25</div> */}
                            <div className="fw-bold ">
                              {formatIndianCurrency(invoice.received_amount)}
                            </div>
                          </div>
                        </div>
                      </div>
                    </section>

                    <section className="boder-black-top">
                      <div className="row ">
                        {/* <div className="col-12 float-start mt-1">
                          <div className="col-12 ">
                            <div className="payment-invoice px-3">
                              Payment Information:
                            </div>
                          </div>
                        </div> */}

                        <div className="row px-1">
                          <div className="col-12 col-md-9 d-flex flex-column">
                            <div className="row px-3">
                              <div className="col-12">
                                <div className="fw-bold view-heading-title  mx-2">
                                  Bank Details :
                                </div>

                                <div className="col-12 col-md-12 float-start = d-flex mx-2 ">
                                  <div className=" invoice-length">
                                    Bank Name
                                  </div>
                                  <div className="">
                                    : {settingInvoice.bank_name}
                                  </div>
                                </div>
                                <div className="col-12 col-md-12 float-start pt-2 d-flex mx-2">
                                  <div className="invoice-length  ">A/C NO</div>
                                  <div className="">
                                    : {settingInvoice.account_number}
                                  </div>
                                </div>
                                <div className="col-12 col-md-12 float-start pt-2 d-flex  mx-2">
                                  <div className="invoice-length  ">
                                    IFSC Code
                                  </div>
                                  <div className="">
                                    : {settingInvoice.ifsc}
                                  </div>
                                </div>
                                <div className="col-12 col-md-12 float-start pt-2 d-flex  mx-2">
                                  <div className="invoice-length  ">Branch</div>
                                  <div className="">
                                    : {settingInvoice.branch_name}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <section className="col-3">
                            <div className="col-12 mt-3">
                              <div className="col-md-12 d-flex pt-2 px-4">
                                <label className=" ">Date</label>

                                <div className="">
                                  : {getDateFormate(invoice.invoice_date)}
                                </div>
                              </div>
                              {/* <div className="mx-1 mt-2 ">
                                <img
                                  src={signature}
                                  alt="sign"
                                  className="signature-image"
                                />
  

                              </div> */}

                              {/* <div className="border-account-view mx-1 "></div> */}
                              <div className="col-md-12 d-flex pt-2 px-4">
                                {settingInvoice.name}
                              </div>
                            </div>
                          </section>
                        </div>
                      </div>
                    </section>
                  </section>
                </div>
              </div>
            </div>
          </div>
          <div>
            <Footer />
          </div>
        </section>
      </div>
    </>
  );
}

export default Accounts_task_view;
