
import './App.css';
import Router from './routes/Router';
import { BrowserRouter } from 'react-router-dom';
import { SettingsProvider } from "./components/SettingsContext"; // Ensure correct import path

function App() {
  return (
    <div >
      <SettingsProvider>
        <BrowserRouter>
          <Router />
        </BrowserRouter>
      </SettingsProvider>
    </div>
  );
}

export default App;
