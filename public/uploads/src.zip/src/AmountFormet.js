export const formatIndianCurrency = (value) => {
    const amount = Number(value) || 0;
    const hasDecimals = amount % 1 !== 0;
    
    return '₹' + new Intl.NumberFormat('en-IN', {
      maximumFractionDigits: hasDecimals ? 2 : 0
    }).format(amount);
  };
  
  // Examples:
  // formatIndianCurrency(100000) → "₹1,00,000"
  // formatIndianCurrency(1234.56) → "₹1,234.56"
  // formatIndianCurrency(1234.5) → "₹1,234.5"